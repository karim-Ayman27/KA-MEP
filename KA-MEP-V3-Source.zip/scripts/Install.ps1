#requires -Version 5.1
[CmdletBinding()]
param(
    [string] $RevitVersion = 'All'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Accept All, a single year, or any explicit comma-separated subset. Reject empty,
# unknown, mixed-All, and duplicate entries before any filesystem changes.
function Resolve-RevitVersionSelection([string] $Selection) {
    $supported = @('2022', '2023', '2024', '2025', '2026', '2027')
    if ([string]::IsNullOrWhiteSpace($Selection)) { throw 'Select at least one supported Revit version: 2022, 2023, 2024, 2025, 2026, 2027.' }
    $selectionText = $Selection.Trim()
    if ($selectionText -eq 'All') { return $supported }
    $selected = @{}
    foreach ($item in $selectionText.Split(',')) {
        $year = $item.Trim()
        if ($supported -notcontains $year -or $selected.ContainsKey($year)) {
            throw 'RevitVersion must be All or a comma-separated list of 2022, 2023, 2024, 2025, 2026, 2027 without duplicates.'
        }
        $selected[$year] = $true
    }
    foreach ($year in $supported) { if ($selected.ContainsKey($year)) { $year } }
}

$years = @(Resolve-RevitVersionSelection $RevitVersion)

if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
    throw 'Run this installer on Windows, on the computer that has Revit installed.'
}

$packageRoot = Split-Path -Parent $PSScriptRoot
$appData = [Environment]::GetFolderPath([Environment+SpecialFolder]::ApplicationData)
if ([string]::IsNullOrWhiteSpace($appData)) { throw 'The current user ApplicationData folder is unavailable.' }
$addinsRoot = Join-Path $appData 'Autodesk\Revit\Addins'
$ownedFiles = @('KAMEP.Revit.dll', 'KAMEP.Core.dll', 'KAMEP.Mcp.Server.exe', 'KAMEP.Mcp.Server.exe.config')
$legacyFiles = @('PipeTakeoff.Revit.dll', 'PipeTakeoff.Core.dll')
$addinId = 'CC1AD833-5F88-45E1-9C5F-BB0A4B3A0DBE'

function Assert-RegularPath([string] $Path) {
    if (Test-Path -LiteralPath $Path) {
        $item = Get-Item -LiteralPath $Path -Force
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Refusing to replace a symbolic link or junction: $Path"
        }
    }
}

function Assert-AvailableFile([string] $Path) {
    Assert-RegularPath $Path
    if (Test-Path -LiteralPath $Path) {
        $stream = $null
        try { $stream = [IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None) }
        catch { throw "Cannot update '$Path'. Close Revit and Claude Desktop, then check that the file is writable. $($_.Exception.Message)" }
        finally { if ($null -ne $stream) { $stream.Dispose() } }
    }
}

function Get-FileSha256([string] $Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Assert-FileSha256([string] $Path, [string] $Expected) {
    $actual = Get-FileSha256 $Path
    if ($actual -ne $Expected) {
        throw "SHA256 verification failed for '$Path'. Expected $Expected; found $actual. The previous installation will be restored."
    }
}

function Assert-OwnedManifest([string] $Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return }
    Assert-RegularPath $Path
    $xml = New-Object System.Xml.XmlDocument
    $xml.XmlResolver = $null
    try { $xml.Load($Path) }
    catch { throw "The existing manifest cannot be identified as KA MEP: $Path" }
    $entries = @($xml.SelectNodes('/RevitAddIns/AddIn'))
    if ($entries.Count -ne 1 -or
        $entries[0].GetAttribute('Type') -ne 'Application' -or
        [string]$entries[0].AddInId -ne $addinId -or
        [string]$entries[0].FullClassName -ne 'PipeTakeoff.Revit.App') {
        throw "Refusing to overwrite a manifest that does not belong to this add-in: $Path"
    }
}

function Write-Manifest([string] $Path, [string] $AssemblyPath) {
    $xml = New-Object System.Xml.XmlDocument
    [void] $xml.AppendChild($xml.CreateXmlDeclaration('1.0', 'utf-8', $null))
    $root = $xml.CreateElement('RevitAddIns')
    [void] $xml.AppendChild($root)
    $addin = $xml.CreateElement('AddIn')
    $addin.SetAttribute('Type', 'Application')
    [void] $root.AppendChild($addin)
    $values = [ordered]@{
        Name = 'KA MEP'
        Assembly = $AssemblyPath
        AddInId = $addinId
        FullClassName = 'PipeTakeoff.Revit.App'
        VendorId = 'KAMP'
        VendorDescription = 'Karim Ayman'
    }
    foreach ($key in $values.Keys) {
        $node = $xml.CreateElement($key)
        $node.InnerText = $values[$key]
        [void] $addin.AppendChild($node)
    }
    $xml.Save($Path)
}

# Check every selected version before changing any installed binaries or manifest.
$plans = @()
foreach ($year in $years) {
    $source = Join-Path $packageRoot "release\$year"
    foreach ($file in $ownedFiles) {
        if (-not (Test-Path -LiteralPath (Join-Path $source $file) -PathType Leaf)) {
            throw "Missing release file: $(Join-Path $source $file). Extract the complete release package or build it first."
        }
    }
    $yearRoot = Join-Path $addinsRoot $year
    $target = Join-Path $yearRoot 'KAMEP'
    $manifest = Join-Path $yearRoot 'KAMEP.addin'
    $legacyTarget = Join-Path $yearRoot 'PipeTakeoff'
    $legacyManifest = Join-Path $yearRoot 'PipeTakeoff.addin'
    Assert-RegularPath $yearRoot
    Assert-RegularPath $target
    Assert-OwnedManifest $manifest
    foreach ($file in $ownedFiles) { Assert-AvailableFile (Join-Path $target $file) }
    Assert-AvailableFile $manifest
    $legacyPaths = @()
    if (Test-Path -LiteralPath $legacyManifest) {
        # A matching registration is required before touching the previous release.
        Assert-OwnedManifest $legacyManifest
        Assert-RegularPath $legacyTarget
        $legacyPaths = @($legacyManifest) + @($legacyFiles | ForEach-Object { Join-Path $legacyTarget $_ })
        foreach ($path in $legacyPaths) { Assert-AvailableFile $path }
    }
    $plans += [pscustomobject]@{
        Year = $year; Source = $source; Root = $yearRoot; Target = $target; Manifest = $manifest
        LegacyTarget = $legacyTarget; LegacyManifest = $legacyManifest; LegacyPaths = $legacyPaths
    }
}

foreach ($plan in $plans) {
    [void] [IO.Directory]::CreateDirectory($plan.Root)
    [void] [IO.Directory]::CreateDirectory($plan.Target)
    $stage = Join-Path $plan.Root ('.KAMEP-install-' + [Guid]::NewGuid().ToString('N'))
    [void] [IO.Directory]::CreateDirectory($stage)
    $changed = New-Object 'System.Collections.Generic.List[string]'
    $movedLegacy = New-Object 'System.Collections.Generic.List[string]'
    $expectedHashes = @{}
    $manifestCommitted = $false
    $preserveStage = $false
    try {
        foreach ($file in $ownedFiles) {
            $sourceFile = Join-Path $plan.Source $file
            $stagedFile = Join-Path $stage $file
            $expectedHashes[$file] = Get-FileSha256 $sourceFile
            Copy-Item -LiteralPath $sourceFile -Destination $stagedFile
            Assert-FileSha256 $stagedFile $expectedHashes[$file]
            $destination = Join-Path $plan.Target $file
            if (Test-Path -LiteralPath $destination) {
                Copy-Item -LiteralPath $destination -Destination (Join-Path $stage ($file + '.backup'))
            }
        }
        $stagedManifest = Join-Path $stage 'KAMEP.addin'
        $manifestBackup = Join-Path $stage 'KAMEP.addin.backup'
        if (Test-Path -LiteralPath $plan.Manifest) {
            Copy-Item -LiteralPath $plan.Manifest -Destination $manifestBackup
        }
        Write-Manifest $stagedManifest (Join-Path $plan.Target 'KAMEP.Revit.dll')
        # Check again immediately before replacement in case Revit started during staging.
        foreach ($file in $ownedFiles) { Assert-AvailableFile (Join-Path $plan.Target $file) }
        Assert-OwnedManifest $plan.Manifest
        Assert-AvailableFile $plan.Manifest
        if ($plan.LegacyPaths.Count -gt 0) { Assert-OwnedManifest $plan.LegacyManifest }
        foreach ($path in $plan.LegacyPaths) { Assert-AvailableFile $path }
        foreach ($file in $ownedFiles) {
            $changed.Add($file)
            $destination = Join-Path $plan.Target $file
            Copy-Item -LiteralPath (Join-Path $stage $file) -Destination $destination -Force
            Unblock-File -LiteralPath $destination
        }
        # A release label may stay V1.0 across builds. Verify the actual installed
        # bytes before committing registration, independently of assembly version.
        foreach ($file in $ownedFiles) {
            $destination = Join-Path $plan.Target $file
            Assert-FileSha256 $destination $expectedHashes[$file]
            Write-Host "Verified installed file: $destination | SHA256: $($expectedHashes[$file])"
        }
        # Keep the old registration and binaries recoverable until the new manifest commits.
        # Move the old manifest first so Revit can never see two registrations from this upgrade.
        foreach ($path in $plan.LegacyPaths) {
            if (Test-Path -LiteralPath $path) {
                [IO.File]::Move($path, (Join-Path $stage ([IO.Path]::GetFileName($path) + '.legacy')))
                $movedLegacy.Add($path)
            }
        }
        if (Test-Path -LiteralPath $plan.Manifest) {
            [IO.File]::Replace($stagedManifest, $plan.Manifest, [NullString]::Value)
        }
        else {
            [IO.File]::Move($stagedManifest, $plan.Manifest)
        }
        $manifestCommitted = $true
        Write-Host "Installed KA MEP for Revit $($plan.Year): $($plan.Manifest)"
    }
    catch {
        $originalError = $_
        $canRestoreLegacyManifest = $true
        if ($manifestCommitted) {
            try {
                if (Test-Path -LiteralPath $manifestBackup) {
                    [IO.File]::Replace($manifestBackup, $plan.Manifest, [NullString]::Value)
                }
                else { Remove-Item -LiteralPath $plan.Manifest -Force }
            }
            catch {
                $preserveStage = $true
                $canRestoreLegacyManifest = $false
                Write-Warning "Could not restore the previous registration: $($_.Exception.Message)"
            }
        }
        foreach ($file in $changed) {
            try {
                $backup = Join-Path $stage ($file + '.backup')
                $destination = Join-Path $plan.Target $file
                if (Test-Path -LiteralPath $backup) { Copy-Item -LiteralPath $backup -Destination $destination -Force }
                elseif (Test-Path -LiteralPath $destination) { Remove-Item -LiteralPath $destination -Force }
            }
            catch {
                $preserveStage = $true
                Write-Warning "Could not restore '$file': $($_.Exception.Message)"
            }
        }
        foreach ($path in $movedLegacy) {
            # Do not introduce duplicate registration if the new manifest could not be rolled back.
            if ($path -eq $plan.LegacyManifest -and -not $canRestoreLegacyManifest) { continue }
            try {
                [IO.File]::Move((Join-Path $stage ([IO.Path]::GetFileName($path) + '.legacy')), $path)
            }
            catch {
                $preserveStage = $true
                Write-Warning "Could not restore '$path': $($_.Exception.Message)"
            }
        }
        if ($preserveStage) { Write-Warning "Backup files were retained for recovery in: $stage" }
        throw $originalError
    }
    finally {
        if (-not $preserveStage) {
            try { Remove-Item -LiteralPath $stage -Recurse -Force }
            catch { Write-Warning "Could not remove the temporary installer folder '$stage': $($_.Exception.Message)" }
        }
    }
    if ($plan.LegacyPaths.Count -gt 0 -and
        (Test-Path -LiteralPath $plan.LegacyTarget -PathType Container) -and
        @(Get-ChildItem -LiteralPath $plan.LegacyTarget -Force).Count -eq 0) {
        try { Remove-Item -LiteralPath $plan.LegacyTarget }
        catch { Write-Warning "Could not remove the empty previous installation folder: $($_.Exception.Message)" }
    }
}

Write-Host 'Start Revit, then open KA MEP > Workspace > KA MEP. Installation is for the current Windows user only.'
