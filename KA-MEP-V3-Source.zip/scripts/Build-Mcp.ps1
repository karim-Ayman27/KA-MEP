#requires -Version 5.1
[CmdletBinding()]
param(
    [ValidateSet('2022', '2023', '2024', '2025', '2026', '2027', 'All')][string] $RevitVersion = 'All'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw 'Install the .NET 8 or .NET 10 SDK before building the Claude MCP helper.' }
$years = if ($RevitVersion -eq 'All') { @('2022', '2023', '2024', '2025', '2026', '2027') } else { @($RevitVersion) }
foreach ($year in $years) {
    foreach ($name in @('KAMEP.Revit.dll', 'KAMEP.Core.dll')) {
        if (-not (Test-Path -LiteralPath (Join-Path $root "release/$year/$name") -PathType Leaf)) {
            throw "Missing release/$year/$name. Build the selected Revit releases before building the helper."
        }
    }
}

# Run once, after all Revit builds, so the shared Core project is never built concurrently.
& dotnet build (Join-Path $root 'src/KAMEP.Mcp.Server/KAMEP.Mcp.Server.csproj') -c Release --nologo
if ($LASTEXITCODE -ne 0) { throw 'KA MEP Claude MCP helper build failed.' }
$output = Join-Path $root 'src/KAMEP.Mcp.Server/bin/Release/net48'
$helperFiles = @('KAMEP.Mcp.Server.exe', 'KAMEP.Mcp.Server.exe.config')
foreach ($name in $helperFiles) {
    if (-not (Test-Path -LiteralPath (Join-Path $output $name) -PathType Leaf)) { throw "Missing helper build output: $name" }
}
$coreHash = (Get-FileHash -LiteralPath (Join-Path $output 'KAMEP.Core.dll') -Algorithm SHA256).Hash
foreach ($year in $years) {
    $releaseCore = Join-Path $root "release/$year/KAMEP.Core.dll"
    if ((Get-FileHash -LiteralPath $releaseCore -Algorithm SHA256).Hash -ne $coreHash) {
        throw "The Revit $year Core DLL differs from the helper dependency. Rebuild the selected Revit releases from the current source before copying the helper."
    }
}
foreach ($year in $years) {
    foreach ($name in $helperFiles) {
        Copy-Item -LiteralPath (Join-Path $output $name) -Destination (Join-Path $root "release/$year/$name") -Force
    }
}
Write-Host "Built Claude MCP helper and copied its EXE/config to Revit $($years -join ', ') releases."
