#!/usr/bin/env python3
"""Archive editable sources and the six current releases before building Setup.

Run with --plan to inspect the selection without creating an archive. Python 3.9+
and no third-party packages are required. Build.ps1 must finish before packaging.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import tempfile
import xml.etree.ElementTree as ET
import zipfile


ROOT = Path(__file__).resolve().parents[1]
YEARS = tuple(str(year) for year in range(2022, 2028))
RELEASE_FILES = (
    "KAMEP.Revit.dll", "KAMEP.Core.dll",
    "KAMEP.Mcp.Server.exe", "KAMEP.Mcp.Server.exe.config",
)
SOURCE_ROOTS = ("src", "assets", "tests", "scripts", "installer", "docs")
ROOT_FILES = ("Directory.Build.props", "Install.cmd", "README.md", "README.ar.md", ".gitignore")
EXCLUDED_PARTS = {
    "bin", "obj", "generated", "__pycache__", ".git", ".vs", ".idea",
    "node_modules", "artifacts", "secrets", "credentials", "sessions",
}
SOURCE_EXTENSIONS = {
    ".cs", ".csproj", ".sln", ".slnx", ".props", ".targets", ".config",
    ".ps1", ".py", ".cmd", ".bat", ".sh", ".md", ".txt", ".json",
    ".xml", ".html", ".csv", ".manifest", ".png", ".ico", ".jpg",
    ".jpeg", ".svg", ".log", ".yml", ".yaml",
}
PRIVATE_NAMES = {
    "connection.json", "endpoint.json", "claude_desktop_config.json",
    "credentials.json", "secrets.json", "appsettings.local.json",
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def source_files():
    selected = []
    for name in ROOT_FILES:
        path = ROOT / name
        if path.is_file():
            selected.append(path)
    for directory in SOURCE_ROOTS:
        for path in (ROOT / directory).rglob("*"):
            relative = path.relative_to(ROOT)
            if EXCLUDED_PARTS.intersection(part.lower() for part in relative.parts):
                continue
            if path.is_symlink():
                raise ValueError("Source archive cannot follow a link: " + str(relative))
            if not path.is_file():
                continue
            name = path.name.lower()
            if name in PRIVATE_NAMES or re.fullmatch(r"(?:connection|endpoint)(?:-[^/]*)?\.json", name) or name.startswith(".env") or name.endswith((".user", ".local.json")):
                continue
            if path.suffix.lower() in SOURCE_EXTENSIONS:
                selected.append(path)
    return sorted(selected, key=lambda path: path.relative_to(ROOT).as_posix())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", action="store_true", help="print planned members; create no package")
    parser.add_argument("--output-directory", type=Path, default=ROOT / "artifacts/source-archive")
    args = parser.parse_args()
    props = ET.parse(ROOT / "Directory.Build.props").getroot().find("PropertyGroup")
    version, label, build = (props.findtext(name) for name in ("Version", "ReleaseLabel", "BuildId"))
    if not re.fullmatch(r"V\d+\.\d+(?:\.\d+)?", label or "") or not re.fullmatch(r"\d{8}-\d{2}", build or ""):
        raise ValueError("Invalid release identity in Directory.Build.props")
    sources = source_files()
    releases = [ROOT / "release" / year / name for year in YEARS for name in RELEASE_FILES]
    files = sorted(sources + releases, key=lambda path: path.relative_to(ROOT).as_posix())
    destination = args.output_directory.resolve() / f"KA-MEP-{label}-Build-{build}-source.zip"
    if args.plan:
        print(json.dumps({
            "destination": str(destination), "release": label, "build": build,
            "file_count": len(files) + 2,
            "files": [path.relative_to(ROOT).as_posix() for path in files] + ["release/SHA256SUMS.txt", "SOURCE-MANIFEST.json"],
            "missing_release_files": [path.relative_to(ROOT).as_posix() for path in releases if not path.is_file()],
        }, indent=2))
        return
    contents = {}
    identity = (version + "+" + build).encode("utf-8")
    for path in files:
        if not path.is_file() or path.is_symlink():
            raise ValueError("Missing or linked package input: " + str(path))
        relative = path.relative_to(ROOT).as_posix()
        data = path.read_bytes()
        if path in releases:
            if path.suffix in (".dll", ".exe") and (data[:2] != b"MZ" or identity not in data):
                raise ValueError("Stale release binary; run Build.ps1 first: " + relative)
            if path.suffix == ".config":
                runtime = ET.fromstring(data).find("startup/supportedRuntime")
                if runtime is None or runtime.get("version") != "v4.0" or runtime.get("sku") != ".NETFramework,Version=v4.8":
                    raise ValueError("Invalid helper runtime configuration: " + relative)
        contents[relative] = data
    contents["release/SHA256SUMS.txt"] = "".join(
        f"{digest(contents[path.relative_to(ROOT).as_posix()])}  {path.relative_to(ROOT / 'release').as_posix()}\n"
        for path in releases
    ).encode("ascii")
    manifest = {
        "release": label, "version": version, "build": build,
        "scope": "Editable projects, source, assets, tests, scripts, documentation and six current Revit releases.",
        "excluded": "Old artifacts, bin/obj/generated outputs, credentials and runtime endpoint/Claude configuration files.",
        "files": [{"path": name, "bytes": len(data), "sha256": digest(data)} for name, data in sorted(contents.items())],
    }
    manifest_data = (json.dumps(manifest, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
    contents["SOURCE-MANIFEST.json"] = manifest_data
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=destination.parent, suffix=".zip.tmp", delete=False) as stream:
            temporary = Path(stream.name)
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for name, data in sorted(contents.items()):
                entry = zipfile.ZipInfo(name, (2026, 1, 1, 0, 0, 0))
                entry.compress_type = zipfile.ZIP_DEFLATED
                entry.external_attr = 0o100644 << 16
                archive.writestr(entry, data)
        with zipfile.ZipFile(temporary) as archive:
            if archive.testzip() is not None or set(archive.namelist()) != set(contents):
                raise ValueError("Source ZIP verification failed")
            for name, data in contents.items():
                if archive.read(name) != data:
                    raise ValueError("Source ZIP byte mismatch: " + name)
        temporary.replace(destination)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()
    sha = digest(destination.read_bytes())
    destination.with_suffix(".zip.sha256").write_text(f"{sha}  {destination.name}\n", encoding="ascii")
    destination.with_suffix(".manifest.json").write_bytes(manifest_data)
    print(f"Created source archive: {destination}")
    print(f"Verified {len(contents)} files; SHA256: {sha}")


if __name__ == "__main__":
    main()
