[CmdletBinding()]
param(
    [ValidateSet('2022', '2023', '2024', '2025', '2026', '2027', 'All')][string]$RevitVersion = 'All',
    [string]$RevitApiDir,
    [switch]$UsePackageRevitApi
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw 'Install the .NET 10 SDK before building all supported releases (or .NET 8 for Revit 2022-2026).' }
if ($RevitApiDir -and $RevitVersion -eq 'All') { throw 'Specify one RevitVersion when supplying RevitApiDir.' }
$years = if ($RevitVersion -eq 'All') { @('2022', '2023', '2024', '2025', '2026', '2027') } else { @($RevitVersion) }
foreach ($year in $years) {
    $project = Join-Path $root 'src/PipeTakeoff.Revit/PipeTakeoff.Revit.csproj'
    $arguments = @('build', $project, '-c', 'Release', "-p:RevitVersion=$year")
    if ($UsePackageRevitApi) { $arguments += '-p:UsePackageRevitApi=true' }
    if ($RevitApiDir) { $arguments += "-p:RevitApiDir=$RevitApiDir" }
    & dotnet @arguments
    if ($LASTEXITCODE -ne 0) { throw "Build failed for Revit $year." }
    $framework = if ([int]$year -le 2024) { 'net48' } elseif ($year -eq '2027') { 'net10.0-windows' } else { 'net8.0-windows' }
    $output = Join-Path $root "src/PipeTakeoff.Revit/bin/Release/$year/$framework"
    $release = Join-Path $root "release/$year"
    New-Item -Path $release -ItemType Directory -Force | Out-Null
    foreach ($name in @('KAMEP.Revit.dll', 'KAMEP.Core.dll')) {
        Copy-Item -LiteralPath (Join-Path $output $name) -Destination (Join-Path $release $name) -Force
    }
    # Remove only the former names owned by this project when rebuilding an old checkout.
    foreach ($name in @('PipeTakeoff.Revit.dll', 'PipeTakeoff.Core.dll')) {
        $legacy = Join-Path $release $name
        if (Test-Path -LiteralPath $legacy -PathType Leaf) { Remove-Item -LiteralPath $legacy -Force }
    }
}
& (Join-Path $PSScriptRoot 'Build-Mcp.ps1') -RevitVersion $RevitVersion
Write-Host 'KA MEP build complete. Run scripts/Install.ps1 on Windows with Revit closed.'
