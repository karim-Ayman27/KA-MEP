#requires -Version 5.1
[CmdletBinding()]
param(
    [string] $RevitVersion = 'All'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Accept All, a single year, or any explicit comma-separated subset. Reject empty,
# unknown, mixed-All, and duplicate entries before any filesystem changes.
function Resolve-RevitVersionSelection([string] $Selection) {
    $supported = @('2022', '2023', '2024', '2025', '2026', '2027')
    if ([string]::IsNullOrWhiteSpace($Selection)) { throw 'Select at least one supported Revit version: 2022, 2023, 2024, 2025, 2026, 2027.' }
    $selectionText = $Selection.Trim()
    if ($selectionText -eq 'All') { return $supported }
    $selected = @{}
    foreach ($item in $selectionText.Split(',')) {
        $year = $item.Trim()
        if ($supported -notcontains $year -or $selected.ContainsKey($year)) {
            throw 'RevitVersion must be All or a comma-separated list of 2022, 2023, 2024, 2025, 2026, 2027 without duplicates.'
        }
        $selected[$year] = $true
    }
    foreach ($year in $supported) { if ($selected.ContainsKey($year)) { $year } }
}

$years = @(Resolve-RevitVersionSelection $RevitVersion)

if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { throw 'Run this uninstaller on Windows.' }
$appData = [Environment]::GetFolderPath([Environment+SpecialFolder]::ApplicationData)
if ([string]::IsNullOrWhiteSpace($appData)) { throw 'The current user ApplicationData folder is unavailable.' }
$addinsRoot = Join-Path $appData 'Autodesk\Revit\Addins'
$identities = @(
    @{ Folder = 'KAMEP'; Manifest = 'KAMEP.addin'; Files = @('KAMEP.Revit.dll', 'KAMEP.Core.dll', 'KAMEP.Mcp.Server.exe', 'KAMEP.Mcp.Server.exe.config'); Legacy = $false },
    @{ Folder = 'PipeTakeoff'; Manifest = 'PipeTakeoff.addin'; Files = @('PipeTakeoff.Revit.dll', 'PipeTakeoff.Core.dll'); Legacy = $true }
)
$plans = @()

foreach ($year in $years) {
    $yearRoot = Join-Path $addinsRoot $year
    foreach ($identity in $identities) {
    $target = Join-Path $yearRoot $identity.Folder
    $manifest = Join-Path $yearRoot $identity.Manifest
    # Only a recognized old registration authorizes removal of the old release's DLLs.
    if ($identity.Legacy -and -not (Test-Path -LiteralPath $manifest)) { continue }
    $paths = @($yearRoot, $target, $manifest) + @($identity.Files | ForEach-Object { Join-Path $target $_ })
    foreach ($path in $paths) {
        if (Test-Path -LiteralPath $path) {
            if (((Get-Item -LiteralPath $path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "Refusing to remove a symbolic link or junction: $path"
            }
        }
    }
    if (Test-Path -LiteralPath $manifest) {
        $xml = New-Object System.Xml.XmlDocument
        $xml.XmlResolver = $null
        try { $xml.Load($manifest) }
        catch { throw "The existing manifest cannot be identified as KA MEP: $manifest" }
        $entries = @($xml.SelectNodes('/RevitAddIns/AddIn'))
        if ($entries.Count -ne 1 -or
            $entries[0].GetAttribute('Type') -ne 'Application' -or
            [string]$entries[0].AddInId -ne 'CC1AD833-5F88-45E1-9C5F-BB0A4B3A0DBE' -or
            [string]$entries[0].FullClassName -ne 'PipeTakeoff.Revit.App') {
            throw "Refusing to delete a manifest that does not belong to this add-in: $manifest"
        }
    }
    $files = @($manifest) + @($identity.Files | ForEach-Object { Join-Path $target $_ })
    foreach ($file in $files) {
        if (Test-Path -LiteralPath $file) {
            $stream = $null
            try { $stream = [IO.File]::Open($file, [IO.FileMode]::Open, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None) }
            catch { throw "Cannot remove '$file'. Close Revit and Claude Desktop, then check that the file is writable. $($_.Exception.Message)" }
            finally { if ($null -ne $stream) { $stream.Dispose() } }
        }
    }
    $plans += [pscustomobject]@{ Year = $year; Target = $target; Files = $files }
    }
}

# Remove only KA MEP's known files and a recognized previous Pipe Takeoff release.
# Preserve unrelated files and orphaned legacy DLLs without a matching registration.
foreach ($plan in $plans) {
    foreach ($file in $plan.Files) {
        if (Test-Path -LiteralPath $file) { Remove-Item -LiteralPath $file -Force }
    }
    if ((Test-Path -LiteralPath $plan.Target -PathType Container) -and
        @(Get-ChildItem -LiteralPath $plan.Target -Force).Count -eq 0) {
        Remove-Item -LiteralPath $plan.Target
    }
    Write-Host "Removed KA MEP files for Revit $($plan.Year), if installed: $($plan.Target)"
}
