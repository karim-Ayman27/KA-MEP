#requires -Version 5.1
[CmdletBinding()]
param([string] $OutputDirectory)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw 'Install the .NET 8 SDK before building the installer.' }
if ([string]::IsNullOrWhiteSpace($OutputDirectory)) { $OutputDirectory = Join-Path $root 'artifacts' }
$OutputDirectory = [IO.Path]::GetFullPath($OutputDirectory)
$props = [xml](Get-Content -LiteralPath (Join-Path $root 'Directory.Build.props') -Raw)
$version = [string]$props.Project.PropertyGroup.Version
$releaseLabel = [string]$props.Project.PropertyGroup.ReleaseLabel
$buildId = [string]$props.Project.PropertyGroup.BuildId
if ($releaseLabel -notmatch '^V[0-9]+\.[0-9]+(?:\.[0-9]+)?$') { throw 'ReleaseLabel must use a version label such as V1.0.' }
if ($buildId -notmatch '^[0-9]{8}-[0-9]{2}$') { throw 'BuildId must use YYYYMMDD-NN.' }
$years = @('2022', '2023', '2024', '2025', '2026', '2027')
$files = @('scripts/Install.ps1', 'scripts/Uninstall.ps1')
foreach ($year in $years) {
    $files += "release/$year/KAMEP.Revit.dll", "release/$year/KAMEP.Core.dll", "release/$year/KAMEP.Mcp.Server.exe", "release/$year/KAMEP.Mcp.Server.exe.config"
}

foreach ($relative in $files) {
    $source = Join-Path $root $relative
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing installer input: $source. Build all six Revit releases first." }
    if ($relative.EndsWith('.dll') -or $relative.EndsWith('.exe')) {
        $identity = [Reflection.AssemblyName]::GetAssemblyName($source)
        if ($identity.Version.ToString(3) -ne $version) {
            throw "Release version mismatch: $relative is $($identity.Version), expected $version. Rebuild all six Revit releases before packaging."
        }
        if ($identity.Name -ne [IO.Path]::GetFileNameWithoutExtension($source)) { throw "Unexpected assembly identity in $relative." }
        $productVersion = [Diagnostics.FileVersionInfo]::GetVersionInfo($source).ProductVersion
        if ($productVersion -ne "$version+$buildId") {
            throw "Stale release binary: $relative is '$productVersion', expected '$version+$buildId'. Rebuild all six Revit releases."
        }
    }
    if ($relative.EndsWith('.exe.config')) {
        $config = [xml](Get-Content -LiteralPath $source -Raw)
        if ([string]$config.configuration.startup.supportedRuntime.version -ne 'v4.0' -or
            [string]$config.configuration.startup.supportedRuntime.sku -ne '.NETFramework,Version=v4.8') {
            throw "Invalid helper runtime configuration: $relative. Rebuild the Claude MCP helper."
        }
    }
}
foreach ($name in @('KAMEP.Core.dll', 'KAMEP.Mcp.Server.exe', 'KAMEP.Mcp.Server.exe.config')) {
    $expectedHash = (Get-FileHash -LiteralPath (Join-Path $root "release/2022/$name") -Algorithm SHA256).Hash
    foreach ($year in $years) {
        if ((Get-FileHash -LiteralPath (Join-Path $root "release/$year/$name") -Algorithm SHA256).Hash -ne $expectedHash) {
            throw "Inconsistent shared release file: release/$year/$name. Rebuild all six releases and the helper from the same source."
        }
    }
}

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$generated = Join-Path $root 'installer/generated'
[void][IO.Directory]::CreateDirectory($generated)
$payload = Join-Path $generated 'payload.zip'
$payloadTemp = $payload + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
try {
    $stream = [IO.File]::Open($payloadTemp, [IO.FileMode]::CreateNew)
    try {
        $archive = New-Object IO.Compression.ZipArchive($stream, [IO.Compression.ZipArchiveMode]::Create, $false)
        try {
            foreach ($relative in $files) {
                $entry = $archive.CreateEntry($relative, [IO.Compression.CompressionLevel]::Optimal)
                $entry.LastWriteTime = [DateTimeOffset]::new(2026, 1, 1, 0, 0, 0, [TimeSpan]::Zero)
                $inputStream = [IO.File]::OpenRead((Join-Path $root $relative))
                try {
                    $entryStream = $entry.Open()
                    try { $inputStream.CopyTo($entryStream) }
                    finally { $entryStream.Dispose() }
                }
                finally { $inputStream.Dispose() }
            }
        }
        finally { $archive.Dispose() }
    }
    finally { $stream.Dispose() }
    Move-Item -LiteralPath $payloadTemp -Destination $payload -Force
}
finally { if (Test-Path -LiteralPath $payloadTemp) { Remove-Item -LiteralPath $payloadTemp -Force } }
$payloadHash = (Get-FileHash -LiteralPath $payload -Algorithm SHA256).Hash
[IO.File]::WriteAllText((Join-Path $generated 'payload.sha256'), $payloadHash, [Text.Encoding]::ASCII)

$project = Join-Path $root 'installer/KAMEP.Setup.csproj'
& dotnet build $project -c Release --nologo
if ($LASTEXITCODE -ne 0) { throw 'KA MEP installer build failed.' }
$built = Join-Path $root 'installer/bin/Release/net48/KA-MEP-Setup.exe'
if (-not (Test-Path -LiteralPath $built -PathType Leaf)) { throw "Installer output was not created: $built" }
[void][IO.Directory]::CreateDirectory($OutputDirectory)
$destination = Join-Path $OutputDirectory "KA-MEP-Setup-$releaseLabel-Full-2022-2023-2024-2025-2026-2027-Build-$buildId.exe"
Copy-Item -LiteralPath $built -Destination $destination -Force
$checksum = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash.ToLowerInvariant()
[IO.File]::WriteAllText(($destination + '.sha256'), "$checksum  $([IO.Path]::GetFileName($destination))`n", [Text.Encoding]::ASCII)
Write-Host "Created self-contained installer: $destination"
Write-Host "SHA256: $checksum"
