#requires -Version 5.1
<#
Signs already-built KA MEP files on Windows using an existing code-signing
certificate in CurrentUser\My. This script never creates a certificate,
changes a trust store, exports a private key, builds, or installs anything.
#>
[CmdletBinding(SupportsShouldProcess = $true, DefaultParameterSetName = 'Assemblies')]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[A-Fa-f0-9 ]{40,80}$')]
    [string] $CertificateThumbprint,

    [Parameter(ParameterSetName = 'Assemblies')]
    [ValidateSet('2022', '2023', '2024', '2025', '2026', '2027')]
    [string[]] $RevitVersion = @('2022', '2023', '2024', '2025', '2026', '2027'),

    [Parameter(Mandatory = $true, ParameterSetName = 'Installer')]
    [string] $InstallerPath,

    [string] $SignToolPath,
    [Uri] $TimestampUrl = 'https://timestamp.digicert.com'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$publisher = 'Karim Ayman'
$codeSigningOid = '1.3.6.1.5.5.7.3.3'
$root = Split-Path -Parent $PSScriptRoot

function Restore-SigningPlan($plan) {
    # ReplaceFile can move the old file to Backup and then throw before
    # returning success. Preserve/recover that backup even when Committed
    # is false; cleanup must never delete the sole original copy.
    $hasBackup = Test-Path -LiteralPath $plan.Backup -PathType Leaf
    $hasTarget = Test-Path -LiteralPath $plan.Target -PathType Leaf
    if ($plan.Existed) {
        if ($hasBackup) {
            if ($hasTarget) { [IO.File]::Replace($plan.Backup, $plan.Target, [NullString]::Value) }
            else { [IO.File]::Move($plan.Backup, $plan.Target) }
        }
        elseif (-not $hasTarget -or (Get-FileHash -LiteralPath $plan.Target -Algorithm SHA256).Hash -ne $plan.OriginalHash) {
            throw 'The original cannot be confirmed and its backup is unavailable.'
        }
    }
    elseif ($hasTarget -and ($plan.Committed -or -not (Test-Path -LiteralPath $plan.Stage -PathType Leaf))) {
        if ((Get-FileHash -LiteralPath $plan.Target -Algorithm SHA256).Hash -ne $plan.SignedHash) {
            throw 'The newly created target changed; refusing to delete it during recovery.'
        }
        [IO.File]::Delete($plan.Target)
    }
}

if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
    throw 'Authenticode signing requires Windows, Windows SDK SignTool, and an existing trusted code-signing certificate. No files were changed.'
}
if (-not $TimestampUrl.IsAbsoluteUri -or $TimestampUrl.Scheme -ne 'https' -or
    -not [string]::IsNullOrEmpty($TimestampUrl.UserInfo) -or -not [string]::IsNullOrEmpty($TimestampUrl.Fragment)) {
    throw 'TimestampUrl must be an absolute HTTPS RFC 3161 timestamp URL without credentials or a fragment.'
}
$thumbprint = $CertificateThumbprint.Replace(' ', '').ToUpperInvariant()
if ($thumbprint -notmatch '^[0-9A-F]{40}$') { throw 'Specify the 40-hex-character certificate thumbprint, not a file or password.' }

if ([string]::IsNullOrWhiteSpace($SignToolPath)) {
    $command = Get-Command signtool.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($command) { $SignToolPath = $command.Source }
}
if ([string]::IsNullOrWhiteSpace($SignToolPath) -or -not (Test-Path -LiteralPath $SignToolPath -PathType Leaf)) {
    throw 'Install Windows SDK SignTool and pass its full path with -SignToolPath (or add signtool.exe to PATH).'
}
$SignToolPath = (Resolve-Path -LiteralPath $SignToolPath).ProviderPath
$certificate = Get-Item -LiteralPath ("Cert:\CurrentUser\My\" + $thumbprint) -ErrorAction Stop
if (-not $certificate.HasPrivateKey) { throw 'The selected certificate has no accessible private key.' }
if (-not [string]::Equals($certificate.GetNameInfo([Security.Cryptography.X509Certificates.X509NameType]::SimpleName, $false),
    $publisher, [StringComparison]::OrdinalIgnoreCase)) {
    throw "The certificate subject must identify '$publisher'. Metadata cannot change the publisher certified by its issuer."
}
$now = [DateTime]::UtcNow
if ($now -lt $certificate.NotBefore.ToUniversalTime() -or $now -gt $certificate.NotAfter.ToUniversalTime()) {
    throw 'The selected certificate is not currently valid.'
}
$eku = @($certificate.Extensions | Where-Object { $_.Oid.Value -eq '2.5.29.37' })
if ($eku.Count -ne 1 -or -not @($eku[0].EnhancedKeyUsages | Where-Object { $_.Value -eq $codeSigningOid }).Count) {
    throw 'The certificate must explicitly include the Code Signing enhanced key usage.'
}
$chain = New-Object Security.Cryptography.X509Certificates.X509Chain
try {
    $chain.ChainPolicy.RevocationMode = [Security.Cryptography.X509Certificates.X509RevocationMode]::Online
    $chain.ChainPolicy.RevocationFlag = [Security.Cryptography.X509Certificates.X509RevocationFlag]::ExcludeRoot
    $chain.ChainPolicy.VerificationFlags = [Security.Cryptography.X509Certificates.X509VerificationFlags]::NoFlag
    $chain.ChainPolicy.UrlRetrievalTimeout = [TimeSpan]::FromSeconds(30)
    [void] $chain.ChainPolicy.ApplicationPolicy.Add((New-Object Security.Cryptography.Oid($codeSigningOid)))
    if (-not $chain.Build($certificate)) {
        $problems = ($chain.ChainStatus | ForEach-Object { $_.Status.ToString() + ': ' + $_.StatusInformation.Trim() }) -join '; '
        throw "The signing certificate is not trusted/valid on this Windows computer: $problems. No trust stores were changed."
    }
}
finally { $chain.Dispose() }

$props = [xml](Get-Content -LiteralPath (Join-Path $root 'Directory.Build.props') -Raw)
$identity = [string]$props.Project.PropertyGroup.Version + '+' + [string]$props.Project.PropertyGroup.BuildId
$targets = @()
if ($PSCmdlet.ParameterSetName -eq 'Installer') {
    if ([IO.Path]::GetExtension($InstallerPath) -ne '.exe') { throw 'InstallerPath must name an already-built KA MEP .exe file.' }
    $targets += $InstallerPath
}
else {
    foreach ($year in ($RevitVersion | Select-Object -Unique)) {
        $targets += (Join-Path $root "release/$year/KAMEP.Revit.dll"), (Join-Path $root "release/$year/KAMEP.Core.dll")
    }
}
if ($targets.Count -eq 0) { throw 'Select at least one Revit version.' }
$plans = @()
foreach ($target in $targets) {
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Missing input: $target. Build the intended release before signing." }
    $target = (Resolve-Path -LiteralPath $target).ProviderPath
    $version = [Diagnostics.FileVersionInfo]::GetVersionInfo($target)
    if ($version.ProductVersion -ne $identity -or $version.ProductName -ne 'KA MEP' -or $version.CompanyName -ne $publisher) {
        throw "Stale or unexpected input: $target. Expected KA MEP / $publisher / $identity."
    }
    $plans += [pscustomobject]@{
        Target = $target; OriginalHash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
        Stage = $null; Backup = $null; Directory = $null; Attempted = $false; Committed = $false; Existed = $true; SignedHash = $null
    }
}
if (-not $PSCmdlet.ShouldProcess(($plans.Target -join ', '), "Sign and timestamp as $publisher; verify trust before replacing originals")) { return }

function Assert-Signature([string] $Path) {
    & $SignToolPath verify /pa /all /v $Path
    if ($LASTEXITCODE -ne 0) { throw "SignTool verification failed: $Path" }
    $signature = Get-AuthenticodeSignature -LiteralPath $Path
    if ($signature.Status -ne [System.Management.Automation.SignatureStatus]::Valid -or
        $null -eq $signature.SignerCertificate -or $signature.SignerCertificate.Thumbprint -ne $thumbprint -or
        $null -eq $signature.TimeStamperCertificate) {
        throw "The signed file lacks a valid trusted signature from the selected certificate and a timestamp: $Path"
    }
}

$retainRecoveryFiles = $false
try {
    # Stage every signature first. A failed sign/timestamp/verification leaves all inputs intact.
    foreach ($plan in $plans) {
        $plan.Directory = Join-Path ([IO.Path]::GetDirectoryName($plan.Target)) ('.ka-mep-signing-' + [Guid]::NewGuid().ToString('N'))
        [void] [IO.Directory]::CreateDirectory($plan.Directory)
        $plan.Stage = Join-Path $plan.Directory ([IO.Path]::GetFileName($plan.Target))
        $plan.Backup = Join-Path $plan.Directory 'original.backup'
        [IO.File]::Copy($plan.Target, $plan.Stage, $false)
        & $SignToolPath sign /s My /sha1 $thumbprint /fd SHA256 /tr $TimestampUrl.AbsoluteUri /td SHA256 /d 'KA MEP' $plan.Stage
        if ($LASTEXITCODE -ne 0) { throw "Signing or timestamping failed: $($plan.Target)" }
        Assert-Signature $plan.Stage
        $plan.SignedHash = (Get-FileHash -LiteralPath $plan.Stage -Algorithm SHA256).Hash
    }
    if ($PSCmdlet.ParameterSetName -eq 'Installer') {
        # Keep Build-Installer's download checksum consistent with the signed EXE.
        $installerPlan = $plans[0]
        $checksumPath = $installerPlan.Target + '.sha256'
        $checksumStage = Join-Path $installerPlan.Directory 'signed.sha256'
        [IO.File]::WriteAllText($checksumStage, ($installerPlan.SignedHash.ToLowerInvariant() + '  ' + [IO.Path]::GetFileName($installerPlan.Target) + "`n"), [Text.Encoding]::ASCII)
        $exists = Test-Path -LiteralPath $checksumPath -PathType Leaf
        $plans += [pscustomobject]@{
            Target = $checksumPath; OriginalHash = $(if ($exists) { (Get-FileHash -LiteralPath $checksumPath -Algorithm SHA256).Hash } else { $null })
            Stage = $checksumStage; Backup = (Join-Path $installerPlan.Directory 'checksum.backup'); Directory = $null
            Attempted = $false; Committed = $false; Existed = $exists; SignedHash = (Get-FileHash -LiteralPath $checksumStage -Algorithm SHA256).Hash
        }
    }
    # Refuse to overwrite binaries changed by a concurrent build while signing was in progress.
    foreach ($plan in $plans) {
        if ($plan.Existed) {
            if ((Get-FileHash -LiteralPath $plan.Target -Algorithm SHA256).Hash -ne $plan.OriginalHash) { throw "Input changed during signing: $($plan.Target)" }
        }
        elseif (Test-Path -LiteralPath $plan.Target) { throw "Destination appeared during signing: $($plan.Target)" }
    }
    foreach ($plan in $plans) {
        $plan.Attempted = $true
        if ($plan.Existed) { [IO.File]::Replace($plan.Stage, $plan.Target, $plan.Backup) }
        else { [IO.File]::Move($plan.Stage, $plan.Target) }
        $plan.Committed = $true
        if ((Get-FileHash -LiteralPath $plan.Target -Algorithm SHA256).Hash -ne $plan.SignedHash) { throw "Final file hash mismatch: $($plan.Target)" }
    }
}
catch {
    $signingError = $_
    foreach ($plan in ($plans | Sort-Object -Property Target -Descending)) {
        if (-not $plan.Attempted) { continue }
        try {
            Restore-SigningPlan $plan
        }
        catch {
            $retainRecoveryFiles = $true
            Write-Warning "Could not restore $($plan.Target). Recovery copy: $($plan.Backup). $($_.Exception.Message)"
        }
    }
    throw $signingError
}
finally {
    if (-not $retainRecoveryFiles) {
        foreach ($directory in @($plans.Directory | Where-Object { $_ } | Select-Object -Unique)) {
            try {
                if (Test-Path -LiteralPath $directory -PathType Container) { Remove-Item -LiteralPath $directory -Recurse -Force }
            }
            catch { Write-Warning "Signing temporary files could not be removed: $directory. $($_.Exception.Message)" }
        }
    }
}

foreach ($plan in $plans) {
    [pscustomobject]@{ File = $plan.Target; Sha256 = $plan.SignedHash.ToLowerInvariant(); Publisher = $publisher; CertificateThumbprint = $thumbprint; Build = $identity }
}
Write-Host 'Signing completed. Validate the installed add-in in Revit on a separate Windows computer before release.'
