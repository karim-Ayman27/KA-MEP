#!/usr/bin/env python3
"""Verify the current release EXE and exact embedded payload without running Windows code. Requires Pillow."""
from pathlib import Path
import hashlib, json, struct, zipfile
import xml.etree.ElementTree as ET
from PIL import Image
def pixels(image):
 return image.get_flattened_data() if hasattr(image,'get_flattened_data') else image.getdata()
r=Path(__file__).resolve().parents[1]
props=ET.parse(r/'Directory.Build.props').getroot().find('PropertyGroup')
version=props.findtext('Version'); label=props.findtext('ReleaseLabel'); build=props.findtext('BuildId')
identity=(version+'+'+build).encode()
p=r/f'artifacts/KA-MEP-Setup-{label}-Full-2022-2023-2024-2025-2026-2027-Build-{build}.exe'; b=p.read_bytes()
assert b[:2]==b'MZ'
pe=struct.unpack_from('<I',b,0x3c)[0]; assert b[pe:pe+4]==b'PE\0\0'
assert struct.unpack_from('<H',b,pe+4)[0]==0x8664
nsec=struct.unpack_from('<H',b,pe+6)[0]; osize=struct.unpack_from('<H',b,pe+20)[0]; opt=pe+24
assert struct.unpack_from('<H',b,opt+68)[0]==2
sections=[]
for i in range(nsec):
 at=opt+osize+40*i; vs,va,rs,rp=struct.unpack_from('<IIII',b,at+8); sections.append((va,max(vs,rs),rp))
def off(rva):
 for va,size,rp in sections:
  if va<=rva<va+size:return rp+rva-va
 raise ValueError(rva)
dirbase=opt+(112 if struct.unpack_from('<H',b,opt)[0]==0x20b else 96)
res_rva,res_len=struct.unpack_from('<II',b,dirbase+16); base=off(res_rva)
def entries(rel):
 named,ids=struct.unpack_from('<HH',b,base+rel+12)
 return [struct.unpack_from('<II',b,base+rel+16+8*i) for i in range(named+ids)]
resources={}
for typ,node in entries(0):
 if not node&0x80000000: continue
 for rid,child in entries(node&0x7fffffff):
  for lang,leaf in entries(child&0x7fffffff):
   rv,size=struct.unpack_from('<II',b,base+leaf)
   resources.setdefault(typ,{})[rid]=b[off(rv):off(rv)+size]
assert 3 in resources and 14 in resources
ico=(r/'installer/Setup.ico').read_bytes()
white_ico=(r/'assets/branding/Logo.ico').read_bytes()
assert ico!=white_ico and white_ico in b
assert struct.unpack_from('<H',ico,4)[0]==7
frames={}
for i in range(7):
 w,h,_,_,planes,bpp,size,offset=struct.unpack_from('<BBBBHHII',ico,6+16*i)
 frames[w or 256]=ico[offset:offset+size]
assert set(frames)=={16,24,32,48,64,128,256}
external=Image.open(r/'installer/Setup.ico')
internal=Image.open(r/'assets/branding/Logo.ico')
for size in frames:
 black=external.ico.getimage((size,size)).convert('RGBA')
 white=internal.ico.getimage((size,size)).convert('RGBA')
 assert black.getchannel('A').tobytes()==white.getchannel('A').tobytes(),size
 assert black.getchannel('A').getbbox() is not None,size
 assert all((red,green,blue)==(0,0,0) for red,green,blue,opacity in pixels(black) if opacity>0),size
 assert all((red,green,blue)==(255,255,255) for red,green,blue,opacity in pixels(white) if opacity>0),size
group=next(iter(resources[14].values())); assert struct.unpack_from('<H',group,4)[0]==7
for i in range(7):
 w,h,_,_,planes,bpp,size,rid=struct.unpack_from('<BBBBHHIH',group,6+14*i)
 assert resources[3][rid]==frames[w or 256]
payload=(r/'installer/generated/payload.zip').read_bytes(); assert payload in b
assert hashlib.sha256(payload).hexdigest().upper().encode() in b
with zipfile.ZipFile(r/'installer/generated/payload.zip') as z:
 expected={'scripts/Install.ps1','scripts/Uninstall.ps1'}|{f'release/{y}/{dll}' for y in (2022,2023,2024,2025,2026,2027) for dll in ('KAMEP.Revit.dll','KAMEP.Core.dll','KAMEP.Mcp.Server.exe','KAMEP.Mcp.Server.exe.config')}
 assert len(z.namelist())==26 and len(expected)==26 and set(z.namelist())==expected and z.testzip() is None
 for name in expected: assert z.read(name)==(r/name).read_bytes(), name
 for year in (2022,2023,2024,2025,2026,2027):
  dll=z.read(f'release/{year}/KAMEP.Revit.dll')
  assert identity in dll
  for feature in ('CableTrayTakeoffCommand','ConduitTakeoffCommand','DuctTakeoffCommand','SheetExportCommand','ElectricalTakeoffForm','ReleaseIdentity','TagAssistantCommand','TagAssistantRevitService','TagAssistantForm','TagPatternPreview','SheetEditorCommand','SheetEditorRevitService','SheetEditorForm','SheetEditorModel','ModelReviewCommand','ModelReviewForm','ModelReviewService','ReviewIssueGroup','ReviewIssueGrouping','RibbonLogoBytes','SpaceTakeoffCommand','ClashManagerCommand','McpConnectionCommand','McpConnectionForm','McpReadService'):
   assert feature.encode() in dll, (year, feature)
  assert 'Export Excel (.xlsx)'.encode('utf-16-le') in dll
  core=z.read(f'release/{year}/KAMEP.Core.dll')
  assert identity in core
  for feature in ('XlsxExporter','DuctXlsxExporter','ElectricalXlsxExporter','TagLayoutEngine','ModelReviewXlsxExporter','SpaceHeightEngine','SpaceTakeoffXlsxExporter','ClashHtmlImporter','ClashXlsxExporter','McpLoopbackServer','McpLoopbackClient','McpLimits'):
   assert feature.encode() in core, (year,feature)
  helper=z.read(f'release/{year}/KAMEP.Mcp.Server.exe')
  assert identity in helper and b'.NETFramework,Version=v4.8' in helper, year
  assert b'RevitAPI' not in helper, year
  for feature in ('McpProtocolEngine','ConnectionFileBridge','ToolCatalog','BoundedLineReader','KAMEP.Core'):
   assert feature.encode() in helper, (year,feature)
  runtime=ET.fromstring(z.read(f'release/{year}/KAMEP.Mcp.Server.exe.config')).find('startup/supportedRuntime')
  assert runtime is not None and runtime.attrib.get('version')=='v4.0' and runtime.attrib.get('sku')=='.NETFramework,Version=v4.8',year
  for size in (16,32,64,128,256):
   assert (r/f'assets/branding/Logo{size}.png').read_bytes() in dll
   assert (r/f'assets/branding/RibbonLogo{size}.png').read_bytes() in dll
  assert (r/'assets/branding/Logo.ico').read_bytes() in dll
for size in (16,32,64,128,256):
 assert (r/f'assets/branding/Logo{size}.png').read_bytes() in b
 im=Image.open(r/f'assets/branding/Logo{size}.png').convert('RGBA')
 ribbon=Image.open(r/f'assets/branding/RibbonLogo{size}.png').convert('RGBA')
 assert im.size==(size,size)
 assert ribbon.size==im.size
 alpha=im.getchannel('A')
 assert ribbon.getchannel('A').tobytes()==alpha.tobytes(),size
 assert all((red,green,blue)==(0,0,0) for red,green,blue,opacity in pixels(ribbon) if opacity>0),size
 assert all(alpha.getpixel(point)==0 for point in ((0,0),(size-1,0),(0,size-1),(size-1,size-1))), size
 assert all((red,green,blue)==(255,255,255) for red,green,blue,opacity in pixels(im) if opacity>0), size
 box=alpha.point(lambda v:255 if v>=128 else 0).getbbox(); tolerance=max(1.5,size*.01)
 assert box is not None, size
 assert abs((box[0]+box[2])/2-size/2)<=tolerance and abs((box[1]+box[3])/2-size/2)<=tolerance,(size,box)
assert hashlib.sha256(b).hexdigest()==p.with_suffix('.exe.sha256').read_text().split()[0]
assert 'level="asInvoker"' in (r/'installer/app.manifest').read_text()
brand_baseline=r/f'docs/validation-v2-{build}/unchanged-brand-assets.json'
if brand_baseline.exists():
 for name,sha in json.loads(brand_baseline.read_text()).items():
  assert hashlib.sha256((r/name).read_bytes()).hexdigest()==sha,name
print('PASS x64 GUI EXE; all 7 Windows RT_GROUP_ICON frames match the black external logo, with unchanged alpha/geometry.')
print('PASS embedded white/transparent logos in installer and all six Revit DLLs; centered alpha bounds within 1% (pixel rounding allowed).')
print('PASS separate black/transparent ribbon logos in all six Revit DLLs; exact original alpha and geometry; other branded assets unchanged.')
print('PASS exact 26-file payload; six current Revit versions with the local MCP helper and its .NET 4.8 runtime config; no Autodesk API binaries.')
print('EXE bytes:',len(b),'SHA256:',hashlib.sha256(b).hexdigest())

assert identity in b
print(f'PASS {label} / Build {build} throughout; Claude MCP, Clash Manager, HVAC Spaces, Model Review, Sheet Parameters, Tag Assistant, quantity Excel and PDF/DWG implementations packaged.')
