@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Install.ps1"
if errorlevel 1 (
    echo.
    echo KA MEP installation failed. Read the error above.
) else (
    echo.
    echo KA MEP installation complete. Start Revit and open KA MEP.
)
pause
