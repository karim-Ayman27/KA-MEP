# KA MEP logo assets

Build 20261023-01 keeps public V2.0 and uses a black transparent monogram only for the installer EXE file icon. The white transparent UI assets introduced in Build 20261022-01 are retained. `Original-KA-MEP.jpg` is the original user upload, preserved byte for byte. Its SHA256 is `b2e95b31756c60dd2c5ca21d320b72c806860b9b0765f109d1174361df738e24`.

The user requested the color/background change and continued with the proposed precise programmatic conversion after image-tool attempts produced noisy edges. The accepted assets are derived directly from the original upload, not the rejected generated images. No new logo design was introduced.

`KA-MEP-Logo.png` is a1024×1024 RGBA master. The original grayscale is converted to alpha by clamping `(245 - luminance) *255/235` to0..255, removing near-white JPEG background while retaining antialiased edge coverage. The original mark's half-alpha bounds `(172,318,1127,962)` are cropped, resized with Lanczos to840×566, and centered on the transparent square. Every visible RGB pixel is pure white. There is no shadow, outline or opaque tile.

`Logo16.png`, `Logo32.png`, `Logo64.png`, `Logo128.png` and `Logo256.png` are transparent RGBA size conversions of that master. `Logo.ico` contains seven 32-bit DIB frames with DWORD-aligned, bottom-up 1-bit AND masks:16,24,32,48,64,128,256px. DIB encoding supports the existing .NET Framework/System.Drawing loader as well as Windows icons. `installer/Setup.ico` is a separate black version for the Windows EXE file icon. It preserves the shared icon's geometry, alpha coverage, frame sizes and mask layout; it is intentionally not byte-identical to the white `Logo.ico`.

The application Hub and installer PictureBoxes have transparent backgrounds, revealing their existing navy headers. Revit Home/Info ribbon buttons consume the embedded PNGs directly; shared window icons use the ICO. White is intentional, including in host-controlled light themes; no background tile is introduced.

`archive-black/` preserves the previous generated black master, white-backed icons and their original provenance. Do not embed those archived resources. Rejected image-tool outputs remain in `/workspace/generated_images/` and are not bundled.

`docs/validation-white-logo/logo-on-navy.png` is only a visual preview composite; distributed logo files remain transparent. The white UI assets and separate black EXE icon are included in the V2.0 / Build 20261023-01 installer; see docs/VALIDATION.md for package verification.
