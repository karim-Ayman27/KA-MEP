# KA MEP logo assets

The black KA monogram was supplied by Karim Ayman as `1-387976.jpg` in this conversation. `Original-KA-MEP.jpg` preserves that upload byte for byte. These assets implement the supplied brand mark; they are not a replacement logo design.

`KA-MEP-Logo.png` is the 1254 × 1254 transparent PNG master. The image editing tool removed the white background while preserving the supplied monogram's geometry and proportions. The edited master was visually compared with the original. It retains generous clear space around the mark.

The `Logo16.png`, `Logo32.png`, `Logo64.png`, `Logo128.png`, and `Logo256.png` files are technical size conversions of that master, rendered onto an opaque white square for contrast in both light and dark application chrome. ImageMagick performs the resizing with the Lanczos filter; it does not redraw the monogram.

`Logo.ico` contains 16, 24, 32, 48, 64, 128, and 256 pixel frames. `installer/Setup.ico` is an identical copy for the Windows installer executable. Display the transparent master on a white square in application headers.

Source upload SHA-256: `b2e95b31756c60dd2c5ca21d320b72c806860b9b0765f109d1174361df738e24`.

Generation provenance: the image editing tool output was `/workspace/generated_images/exec-45e7950c-368e-42f8-800c-62bea0466af6.png`; it remains in place. No external stock images, fonts, or additional logo artwork were introduced.
