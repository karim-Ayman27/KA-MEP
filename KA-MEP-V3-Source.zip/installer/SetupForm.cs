using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KAMEP.Setup
{
    internal sealed class SetupForm : Form
    {
        private static readonly Color Ink = Color.FromArgb(19, 34, 51);
        private static readonly Color Accent = Color.FromArgb(0, 139, 132);
        private readonly List<CheckBox> versionChoices = new List<CheckBox>();
        private readonly ComboBox action = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 230 };
        private readonly Button run = new Button { Text = "Install KA MEP", AutoSize = false, Width = 170, Height = 40 };
        private readonly Button close = new Button { Text = "Close", Width = 100, Height = 40 };
        private readonly Label status = new Label { Text = "Ready to install. Close Revit before continuing.", AutoSize = true, MaximumSize = new Size(680, 0) };
        private readonly TextBox details = new TextBox { Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, Dock = DockStyle.Fill, BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };
        private readonly ProgressBar progress = new ProgressBar { Dock = DockStyle.Fill, Height = 5, Style = ProgressBarStyle.Blocks };
        private readonly Label logPath = new Label { AutoSize = true, MaximumSize = new Size(680, 0), ForeColor = Color.FromArgb(92, 106, 119) };
        private readonly object logLock = new object();
        private StreamWriter logWriter;
        private bool busy;

        internal SetupForm()
        {
            Text = "KA MEP | " + KAMEP.Branding.ReleaseIdentity.Display + " | Setup";
            Font = new Font("Segoe UI", 9.5F);
            BackColor = Color.FromArgb(244, 247, 250);
            ForeColor = Ink;
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(770, 650);
            MinimumSize = new Size(730, 620);
            StartPosition = FormStartPosition.CenterScreen;
            Icon = KAMEP.Branding.BrandImages.WindowIcon();
            var scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true };
            var layout = new TableLayoutPanel { Dock = DockStyle.Top, Height = 560, ColumnCount = 1, RowCount = 6, Padding = new Padding(25, 25, 25, 0), BackColor = BackColor };
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 12));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            scroll.Controls.Add(layout);
            Controls.Add(scroll);
            scroll.Resize += (sender, args) => layout.Height = Math.Max(scroll.ClientSize.Height, (int)(535F * Font.Height / 17F));

            var header = new TableLayoutPanel
            {
                Name = "SetupBrandHeader", AutoSize = true, Dock = DockStyle.Fill, BackColor = Ink, Padding = new Padding(18, 10, 18, 10),
                Margin = new Padding(0, 0, 0, 15), ColumnCount = 2, RowCount = 3
            };
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 112F));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            header.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            header.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            header.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var logo = new PictureBox
            {
                Name = "SetupBrandLogo", Image = KAMEP.Branding.BrandImages.Logo(256), SizeMode = PictureBoxSizeMode.Zoom,
                Dock = DockStyle.Fill, BackColor = Color.Transparent, Margin = new Padding(0, 0, 18, 0)
            };
            logo.Disposed += delegate { if (logo.Image != null) logo.Image.Dispose(); };
            header.Controls.Add(logo, 0, 0);
            header.SetRowSpan(logo, 3);
            var brand = new Label { Text = "KA MEP", AutoSize = true, Font = new Font("Segoe UI", 26F, FontStyle.Bold), ForeColor = Color.White, Dock = DockStyle.Fill, Margin = Padding.Empty, TextAlign = ContentAlignment.MiddleLeft };
            var subtitle = new Label { Text = "MODEL REVIEW + SHEETS + MEP TOOLS", AutoSize = true, ForeColor = Color.FromArgb(98, 220, 207), Dock = DockStyle.Fill, Margin = Padding.Empty, TextAlign = ContentAlignment.MiddleLeft };
            var release = new Label { Text = KAMEP.Branding.ReleaseIdentity.Display + "\r\nREVIT 2022.1+ / 2023 / 2024 / 2025 / 2026 / 2027", AutoSize = true, ForeColor = Color.FromArgb(201, 214, 225), Dock = DockStyle.Fill, Margin = Padding.Empty, TextAlign = ContentAlignment.MiddleLeft };
            header.Controls.Add(brand, 1, 0);
            header.Controls.Add(subtitle, 1, 1);
            header.Controls.Add(release, 1, 2);
            layout.Controls.Add(header, 0, 0);

            var choices = new TableLayoutPanel { AutoSize = true, Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 4, Margin = new Padding(0, 0, 0, 8) };
            choices.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 145));
            choices.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            choices.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            choices.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            choices.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            choices.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            choices.Controls.Add(new Label { Text = "Revit versions", Font = new Font(Font, FontStyle.Bold), AutoSize = true, Margin = new Padding(0, 5, 3, 3) }, 0, 0);
            var versions = new TableLayoutPanel { Name = "RevitVersionChoices", AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, Dock = DockStyle.Fill, ColumnCount = 3, RowCount = 2, Margin = Padding.Empty };
            for (int column = 0; column < 3; column++) versions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F / 3));
            versions.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            versions.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            for (int index = 0; index < InstallerEngine.SupportedVersions.Length; index++)
            {
                string year = InstallerEngine.SupportedVersions[index];
                var choice = new CheckBox
                {
                    Name = "version" + year, Text = "Revit " + (year == "2022" ? "2022.1+" : year),
                    Tag = year, Checked = true, AutoSize = true, Margin = new Padding(0, 4, 8, 3)
                };
                versionChoices.Add(choice);
                versions.Controls.Add(choice, index % 3, index / 3);
            }
            choices.Controls.Add(versions, 1, 0);
            choices.Controls.Add(new Label { Text = "Setup action", Font = new Font(Font, FontStyle.Bold), AutoSize = true, Margin = new Padding(0, 5, 3, 3) }, 0, 1);
            action.Items.AddRange(new object[] { "Install / update KA MEP", "Uninstall KA MEP" });
            action.SelectedIndex = 0;
            action.SelectedIndexChanged += (sender, args) => run.Text = action.SelectedIndex == 1 ? "Uninstall KA MEP" : "Install KA MEP";
            choices.Controls.Add(action, 1, 1);
            var scope = new Label { Text = "Installs for your Windows account. No administrator access required.", AutoSize = true, MaximumSize = new Size(660, 0), Margin = new Padding(0, 5, 0, 0) };
            choices.Controls.Add(scope, 0, 2);
            choices.SetColumnSpan(scope, 2);
            var creator = new Label { Text = "Created by Karim Ayman  |  01032638143\nLinkedIn: karimayman27  |  mech.karim.ayman@gmail.com", AutoSize = true, ForeColor = Color.FromArgb(92, 106, 119), MaximumSize = new Size(660, 0), Margin = Padding.Empty };
            choices.Controls.Add(creator, 0, 3);
            choices.SetColumnSpan(creator, 2);
            layout.Controls.Add(choices, 0, 1);
            status.Margin = new Padding(0, 4, 0, 9);
            layout.Controls.Add(status, 0, 2);
            progress.Margin = new Padding(0, 0, 0, 7);
            layout.Controls.Add(progress, 0, 3);
            details.Font = new Font("Consolas", 9F);
            details.Margin = new Padding(0, 3, 0, 9);
            details.Text = "KA MEP | " + KAMEP.Branding.ReleaseIdentity.Display + "\r\nSpaces / HVAC takeoff / physical clear heights\r\nClash Manager / import, review and verify clashes\r\nClaude MCP / optional local read-only model access\r\nModel Review / Sheet Parameters / Tag Assistant\r\nMEP quantities / formatted Excel / PDF and DWG sheets\r\nChoose your Revit versions, then select Install KA MEP.\r\nRevit 2022 requires the Autodesk 2022.1 update or later.";
            layout.Controls.Add(details, 0, 4);
            logPath.Margin = new Padding(0, 0, 0, 8);
            layout.Controls.Add(logPath, 0, 5);
            var buttons = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 70, Padding = new Padding(25, 5, 25, 15), FlowDirection = FlowDirection.RightToLeft, Margin = Padding.Empty, WrapContents = false };
            close.Click += (sender, args) => Close();
            StyleButton(close, Color.White, Ink);
            run.Click += RunClicked;
            StyleButton(run, Accent, Color.White);
            buttons.Controls.Add(close);
            buttons.Controls.Add(run);
            Controls.Add(buttons);
            AcceptButton = run;
            CancelButton = close;
            FormClosing += (sender, args) => { if (busy) args.Cancel = true; };
            Shown += (sender, args) =>
            {
                var workingArea = Screen.FromControl(this).WorkingArea;
                MinimumSize = new Size(Math.Min(MinimumSize.Width, workingArea.Width), Math.Min(MinimumSize.Height, workingArea.Height));
                Size = new Size(Math.Min(Width, workingArea.Width), Math.Min(Height, workingArea.Height));
                Location = new Point(workingArea.Left + (workingArea.Width - Width) / 2, workingArea.Top + (workingArea.Height - Height) / 2);
            };
        }

        private static void StyleButton(Button button, Color background, Color foreground)
        {
            button.BackColor = background;
            button.ForeColor = foreground;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = background == Color.White ? 1 : 0;
            button.FlatAppearance.BorderColor = Color.FromArgb(206, 215, 224);
            button.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            button.Cursor = Cursors.Hand;
            button.Margin = new Padding(10, 5, 0, 0);
        }

        private async void RunClicked(object sender, EventArgs args)
        {
            if (busy) return;
            var selectedVersions = new List<string>();
            foreach (var choice in versionChoices) if (choice.Checked) selectedVersions.Add((string)choice.Tag);
            if (selectedVersions.Count == 0)
            {
                MessageBox.Show(this, "Select at least one Revit version.", "KA MEP Setup", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (InstallerEngine.IsRevitRunning())
            {
                MessageBox.Show(this, "Save your work and close every Revit window, then run setup again.", "Close Revit first", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            var version = InstallerEngine.NormalizeVersionSelection(string.Join(",", selectedVersions));
            var uninstall = action.SelectedIndex == 1;
            SetBusy(true);
            details.Clear();
            status.ForeColor = Ink;
            status.Text = uninstall ? "Removing KA MEP..." : "Installing KA MEP...";
            try
            {
                var logs = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KAMEP", "Logs");
                Directory.CreateDirectory(logs);
                var path = Path.Combine(logs, "Setup-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N").Substring(0, 8) + ".log");
                logWriter = new StreamWriter(path, false, new System.Text.UTF8Encoding(false)) { AutoFlush = true };
                logPath.Text = "Log: " + path;
                Report("KA MEP " + KAMEP.Branding.ReleaseIdentity.Display + " setup | " + DateTime.Now.ToString("u"));
                var exitCode = await Task.Run(() => InstallerEngine.Run(uninstall, version, Report));
                if (exitCode != 0) throw new InvalidOperationException("Setup did not complete (exit code " + exitCode + "). Review the details and log, then retry.");
                status.ForeColor = Accent;
                status.Text = uninstall ? "KA MEP was removed for the selected Revit versions."
                    : "KA MEP is installed. Start Revit and open KA MEP > Workspace > KA MEP.";
                Report(status.Text);
                progress.Value = 100;
            }
            catch (Exception error)
            {
                status.ForeColor = Color.FromArgb(177, 53, 60);
                status.Text = "Setup could not finish. " + error.Message;
                Report("ERROR: " + error.Message);
            }
            finally
            {
                lock (logLock) { if (logWriter != null) { logWriter.Dispose(); logWriter = null; } }
                SetBusy(false);
            }
        }

        private void SetBusy(bool value)
        {
            busy = value;
            run.Enabled = close.Enabled = action.Enabled = !value;
            foreach (var choice in versionChoices) choice.Enabled = !value;
            ControlBox = !value;
            progress.Style = value ? ProgressBarStyle.Marquee : ProgressBarStyle.Blocks;
            if (value) progress.Value = 0;
        }

        private void Report(string message)
        {
            lock (logLock)
            {
                try { if (logWriter != null) logWriter.WriteLine(message); }
                catch (IOException) { /* Keep setup and its visible output usable if disk logging fails. */ }
            }
            if (IsDisposed || Disposing) return;
            if (InvokeRequired) BeginInvoke(new Action<string>(AppendDetails), message);
            else AppendDetails(message);
        }

        private void AppendDetails(string message)
        {
            if (!IsDisposed) details.AppendText(message + Environment.NewLine);
        }
    }
}
