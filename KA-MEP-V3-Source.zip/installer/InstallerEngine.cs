using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;

namespace KAMEP.Setup
{
    internal static class InstallerEngine
    {
        internal static readonly string[] PayloadFiles =
        {
            "scripts/Install.ps1", "scripts/Uninstall.ps1",
            "release/2022/KAMEP.Revit.dll", "release/2022/KAMEP.Core.dll",
            "release/2022/KAMEP.Mcp.Server.exe", "release/2022/KAMEP.Mcp.Server.exe.config",
            "release/2023/KAMEP.Revit.dll", "release/2023/KAMEP.Core.dll",
            "release/2023/KAMEP.Mcp.Server.exe", "release/2023/KAMEP.Mcp.Server.exe.config",
            "release/2024/KAMEP.Revit.dll", "release/2024/KAMEP.Core.dll",
            "release/2024/KAMEP.Mcp.Server.exe", "release/2024/KAMEP.Mcp.Server.exe.config",
            "release/2025/KAMEP.Revit.dll", "release/2025/KAMEP.Core.dll",
            "release/2025/KAMEP.Mcp.Server.exe", "release/2025/KAMEP.Mcp.Server.exe.config",
            "release/2026/KAMEP.Revit.dll", "release/2026/KAMEP.Core.dll",
            "release/2026/KAMEP.Mcp.Server.exe", "release/2026/KAMEP.Mcp.Server.exe.config",
            "release/2027/KAMEP.Revit.dll", "release/2027/KAMEP.Core.dll",
            "release/2027/KAMEP.Mcp.Server.exe", "release/2027/KAMEP.Mcp.Server.exe.config"
        };

        internal static readonly string[] SupportedVersions = { "2022", "2023", "2024", "2025", "2026", "2027" };

        // Always pass the exact checked subset to PowerShell, including when all are selected.
        internal static string NormalizeVersionSelection(string version)
        {
            const string message = "Choose one or more Revit versions: 2022, 2023, 2024, 2025, 2026, 2027.";
            if (string.IsNullOrWhiteSpace(version)) throw new ArgumentException(message, "version");
            version = version.Trim();
            if (string.Equals(version, "All", StringComparison.OrdinalIgnoreCase))
                return string.Join(",", SupportedVersions);
            var selected = new HashSet<string>(StringComparer.Ordinal);
            foreach (var item in version.Split(','))
            {
                var year = item.Trim();
                if (Array.IndexOf(SupportedVersions, year) < 0 || !selected.Add(year))
                    throw new ArgumentException(message + " Use a comma-separated list without duplicates.", "version");
            }
            var ordered = new List<string>();
            foreach (var year in SupportedVersions) if (selected.Contains(year)) ordered.Add(year);
            return string.Join(",", ordered);
        }

        internal static bool IsRevitRunning()
        {
            var processes = Process.GetProcessesByName("Revit");
            try { return processes.Length != 0; }
            finally { foreach (var process in processes) process.Dispose(); }
        }

        internal static int Run(bool uninstall, string version, Action<string> report)
        {
            version = NormalizeVersionSelection(version);
            if (IsRevitRunning()) throw new InvalidOperationException("Close every Revit window, then try again.");

            var powerShell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),
                @"WindowsPowerShell\v1.0\powershell.exe");
            if (!File.Exists(powerShell)) throw new FileNotFoundException("Windows PowerShell 5.1 is required.", powerShell);

            var temporary = Path.Combine(Path.GetTempPath(), "KAMEP-Setup-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(temporary);
            try
            {
                report("Checking and extracting the bundled KA MEP files...");
                ExtractPayload(temporary);
                if (IsRevitRunning()) throw new InvalidOperationException("Revit opened during setup. Close it, then try again.");
                var script = Path.Combine(temporary, "scripts", uninstall ? "Uninstall.ps1" : "Install.ps1");
                var start = new ProcessStartInfo
                {
                    FileName = powerShell,
                    Arguments = "-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File " + QuoteArgument(script)
                        + " -RevitVersion " + QuoteArgument(version),
                    WorkingDirectory = temporary,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    StandardOutputEncoding = Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage),
                    StandardErrorEncoding = Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage)
                };
                report((uninstall ? "Removing" : "Installing") + " KA MEP for " +
                    "Revit " + version.Replace(",", ", ") + "...");
                using (var process = new Process { StartInfo = start })
                {
                    process.OutputDataReceived += (sender, args) => { if (args.Data != null) report(args.Data); };
                    process.ErrorDataReceived += (sender, args) => { if (args.Data != null) report(args.Data); };
                    if (!process.Start()) throw new InvalidOperationException("Windows PowerShell could not be started.");
                    process.BeginOutputReadLine();
                    process.BeginErrorReadLine();
                    process.WaitForExit();
                    return process.ExitCode;
                }
            }
            finally
            {
                try { Directory.Delete(temporary, true); }
                catch (IOException error) { report("Temporary files could not be removed: " + error.Message); }
                catch (UnauthorizedAccessException error) { report("Temporary files could not be removed: " + error.Message); }
            }
        }

        internal static void ExtractPayload(string destination)
        {
            var assembly = Assembly.GetExecutingAssembly();
            using (var resource = assembly.GetManifestResourceStream("KAMEP.Setup.payload.zip"))
            using (var checksum = assembly.GetManifestResourceStream("KAMEP.Setup.payload.sha256"))
            {
                if (resource == null || checksum == null) throw new InvalidDataException("The installer payload is missing.");
                string expectedHash;
                using (var reader = new StreamReader(checksum, Encoding.UTF8)) expectedHash = reader.ReadToEnd().Trim();
                using (var buffer = new MemoryStream())
                {
                    resource.CopyTo(buffer);
                    buffer.Position = 0;
                    string actualHash;
                    using (var hash = SHA256.Create()) actualHash = BitConverter.ToString(hash.ComputeHash(buffer)).Replace("-", "");
                    if (!string.Equals(expectedHash, actualHash, StringComparison.OrdinalIgnoreCase))
                        throw new InvalidDataException("The installer payload checksum is invalid. Download KA MEP Setup again.");
                    buffer.Position = 0;
                    ExtractArchive(buffer, destination);
                }
            }
        }

        internal static void ExtractArchive(Stream payload, string destination)
        {
            var root = Path.GetFullPath(destination).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)
                + Path.DirectorySeparatorChar;
            if ((File.GetAttributes(destination) & FileAttributes.ReparsePoint) != 0)
                throw new IOException("The installer extraction folder must not be a link or junction.");
            var remaining = new HashSet<string>(PayloadFiles, StringComparer.Ordinal);
            using (var archive = new ZipArchive(payload, ZipArchiveMode.Read, true))
            {
                if (archive.Entries.Count != PayloadFiles.Length) throw new InvalidDataException("Unexpected installer payload contents.");
                foreach (var entry in archive.Entries)
                {
                    if (!remaining.Remove(entry.FullName)) throw new InvalidDataException("Unexpected or duplicate installer payload file.");
                    if (entry.Length < 1 || entry.Length > 50L * 1024 * 1024)
                        throw new InvalidDataException("Invalid installer payload file size.");
                    var path = Path.GetFullPath(Path.Combine(root, entry.FullName.Replace('/', Path.DirectorySeparatorChar)));
                    if (!path.StartsWith(root, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Unsafe installer payload path.");
                    Directory.CreateDirectory(Path.GetDirectoryName(path));
                    var parent = new DirectoryInfo(Path.GetDirectoryName(path));
                    while (parent != null && parent.FullName.Length >= root.TrimEnd(Path.DirectorySeparatorChar).Length)
                    {
                        if ((parent.Attributes & FileAttributes.ReparsePoint) != 0)
                            throw new IOException("The installer extraction path must not contain a link or junction.");
                        parent = parent.Parent;
                    }
                    using (var input = entry.Open())
                    using (var output = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    {
                        var block = new byte[81920];
                        long written = 0;
                        int count;
                        while ((count = input.Read(block, 0, block.Length)) > 0)
                        {
                            written += count;
                            if (written > entry.Length) throw new InvalidDataException("Installer file exceeds its declared size.");
                            output.Write(block, 0, count);
                        }
                        if (written != entry.Length) throw new InvalidDataException("The installer payload contains a truncated file.");
                    }
                }
            }
            if (remaining.Count != 0) throw new InvalidDataException("The installer payload is incomplete.");
        }

        // Implements the CommandLineToArgvW rules, including trailing backslashes.
        internal static string QuoteArgument(string value)
        {
            var result = new StringBuilder("\"");
            var backslashes = 0;
            foreach (var character in value)
            {
                if (character == '\\') { backslashes++; continue; }
                if (character == '"') { result.Append('\\', backslashes * 2 + 1); result.Append('"'); }
                else { result.Append('\\', backslashes); result.Append(character); }
                backslashes = 0;
            }
            result.Append('\\', backslashes * 2);
            result.Append('"');
            return result.ToString();
        }
    }
}
