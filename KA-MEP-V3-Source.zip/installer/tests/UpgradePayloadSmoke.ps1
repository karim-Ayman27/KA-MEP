#requires -Version 7.0
[CmdletBinding()]
param([Parameter(Mandatory = $true)][string] $BaselinePayload)

# Runs the real baseline and current payloads through isolated copies of their install
# scripts. It does not touch a user's AppData and is not a Windows runtime test.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$currentPayload = Join-Path $root 'installer/generated/payload.zip'
$props = [xml](Get-Content -LiteralPath (Join-Path $root 'Directory.Build.props') -Raw)
$expected = [string]$props.Project.PropertyGroup.Version
$expectedBuild = [string]$props.Project.PropertyGroup.BuildId
$supported = @('2022', '2023', '2024', '2025', '2026', '2027')
$sandbox = Join-Path ([IO.Path]::GetTempPath()) ('KA MEP actual upgrade-' + [Guid]::NewGuid().ToString('N'))
$checks = 0
function Check([bool] $Condition, [string] $Message) {
    if (-not $Condition) { throw "FAIL: $Message" }
    $script:checks++
}
function Unblock-File { param([string] $LiteralPath) }
try {
    [void][IO.Directory]::CreateDirectory($sandbox)
    $fakeAppData = Join-Path $sandbox 'appdata'
    $packages = @((Join-Path $sandbox 'baseline'), (Join-Path $sandbox 'current'))
    $archives = @([IO.Path]::GetFullPath($BaselinePayload), $currentPayload)
    for ($index = 0; $index -lt 2; $index++) {
        [IO.Compression.ZipFile]::ExtractToDirectory($archives[$index], $packages[$index])
        $install = Join-Path $packages[$index] 'scripts/Install.ps1'
        $text = [IO.File]::ReadAllText($install)
        $guard = "(?s)if \(\[Environment\]::OSVersion\.Platform -ne \[PlatformID\]::Win32NT\) \{.*?\}"
        Check ([regex]::IsMatch($text, $guard)) 'production Windows guard exists'
        $text = [regex]::Replace($text, $guard, '# Windows guard removed only from this isolated test copy.')
        $needle = '$appData = [Environment]::GetFolderPath([Environment+SpecialFolder]::ApplicationData)'
        Check ($text.Contains($needle)) 'test AppData substitution point exists'
        $text = $text.Replace($needle, ('$appData = ''' + $fakeAppData.Replace("'", "''") + "'"))
        [IO.File]::WriteAllText($install, $text)
    }
    $beforeHashes = @{}
    $manifests = @{}
    $baselineYears = @(Get-ChildItem -LiteralPath (Join-Path $packages[0] 'release') -Directory | ForEach-Object { $_.Name })
    Check ($baselineYears.Count -gt 0) 'baseline contains real release folders'
    $baselineVersion = [Reflection.AssemblyName]::GetAssemblyName((Join-Path $packages[0] "release/$($baselineYears[0])/KAMEP.Revit.dll")).Version.ToString(3)
    & (Join-Path $packages[0] 'scripts/Install.ps1') -RevitVersion All 6>$null | Out-Null
    foreach ($year in $supported) {
        $targetRoot = Join-Path $fakeAppData "Autodesk/Revit/Addins/$year"
        [void][IO.Directory]::CreateDirectory($targetRoot)
        [IO.File]::WriteAllText((Join-Path $targetRoot 'Unrelated.addin'), 'preserve unrelated add-in')
    }
    foreach ($year in $baselineYears) {
        $targetRoot = Join-Path $fakeAppData "Autodesk/Revit/Addins/$year"
        $manifests[$year] = [IO.File]::ReadAllText((Join-Path $targetRoot 'KAMEP.addin'))
        foreach ($dll in @('KAMEP.Revit.dll', 'KAMEP.Core.dll')) {
            $target = Join-Path $targetRoot "KAMEP/$dll"
            Check ([Reflection.AssemblyName]::GetAssemblyName($target).Version.ToString(3) -eq $baselineVersion) "baseline $year $dll has consistent version"
            $beforeHashes["$year/$dll"] = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
        }
    }
    & (Join-Path $packages[1] 'scripts/Install.ps1') -RevitVersion All 6>$null | Out-Null
    foreach ($year in $supported) {
        $targetRoot = Join-Path $fakeAppData "Autodesk/Revit/Addins/$year"
        $manifest = [xml]([IO.File]::ReadAllText((Join-Path $targetRoot 'KAMEP.addin')))
        Check ([string]$manifest.RevitAddIns.AddIn.AddInId -eq 'CC1AD833-5F88-45E1-9C5F-BB0A4B3A0DBE') "stable KA MEP registration identity $year"
        Check ([string]$manifest.RevitAddIns.AddIn.Assembly -eq (Join-Path $targetRoot 'KAMEP/KAMEP.Revit.dll')) "exact per-user assembly path $year"
        if ($manifests.ContainsKey($year)) {
            Check ([IO.File]::ReadAllText((Join-Path $targetRoot 'KAMEP.addin')) -eq $manifests[$year]) "same registration identity/path $year"
        }
        Check ([IO.File]::ReadAllText((Join-Path $targetRoot 'Unrelated.addin')) -eq 'preserve unrelated add-in') "unrelated add-in preserved $year"
        foreach ($dll in @('KAMEP.Revit.dll', 'KAMEP.Core.dll', 'KAMEP.Mcp.Server.exe')) {
            $target = Join-Path $targetRoot "KAMEP/$dll"
            $hash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
            Check ([Reflection.AssemblyName]::GetAssemblyName($target).Version.ToString(3) -eq $expected) "upgraded $year $dll has current version"
            Check ([Diagnostics.FileVersionInfo]::GetVersionInfo($target).ProductVersion -eq "$expected+$expectedBuild") "installed $year $dll has current build"
            if ($beforeHashes.ContainsKey("$year/$dll")) {
                Check ($hash -ne $beforeHashes["$year/$dll"]) "old binary replaced $year $dll"
            }
            Check ($hash -eq (Get-FileHash -LiteralPath (Join-Path $packages[1] "release/$year/$dll") -Algorithm SHA256).Hash) "installed bytes equal current payload $year $dll"
        }
        $config = Join-Path $targetRoot 'KAMEP/KAMEP.Mcp.Server.exe.config'
        Check ((Get-FileHash -LiteralPath $config -Algorithm SHA256).Hash -eq (Get-FileHash -LiteralPath (Join-Path $packages[1] "release/$year/KAMEP.Mcp.Server.exe.config") -Algorithm SHA256).Hash) "helper runtime config equals current payload $year"
    }
    Write-Host "PASS: $checks actual-payload upgrade checks ($baselineVersion -> $expected+$expectedBuild, six Revit versions, isolated filesystem; not Windows/Revit execution)."
}
finally {
    if (Test-Path -LiteralPath $sandbox) { Remove-Item -LiteralPath $sandbox -Recurse -Force }
}
