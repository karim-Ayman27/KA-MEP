using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Text;
using KAMEP.Setup;

internal static class Program
{
    private static int assertions;

    private static void Main(string[] args)
    {
        if (args.Length > 1 || (args.Length == 1 && args[0] != "--logic-only"))
            throw new ArgumentException("Usage: KAMEP.Setup.Tests [--logic-only]");
        var logicOnly = args.Length == 1;
        Run(logicOnly);
    }

    private static void Run(bool logicOnly)
    {
        Check(InstallerEngine.QuoteArgument("") == "\"\"", "empty argument");
        Check(InstallerEngine.QuoteArgument("All") == "\"All\"", "version argument");
        Check(InstallerEngine.QuoteArgument(@"C:\Users\كريم أيمن\AppData\Local\Temp\setup.ps1") == "\"C:\\Users\\كريم أيمن\\AppData\\Local\\Temp\\setup.ps1\"", "Arabic and spaces");
        Check(InstallerEngine.QuoteArgument("a\"b") == "\"a\\\"b\"", "embedded quote");
        Check(InstallerEngine.QuoteArgument("C:\\folder\\") == "\"C:\\folder\\\\\"", "trailing backslash");
        Check(InstallerEngine.QuoteArgument("a\\\"b") == "\"a\\\\\\\"b\"", "backslash before quote");

        Check(InstallerEngine.NormalizeVersionSelection("All") == "2022,2023,2024,2025,2026,2027", "all six versions");
        Check(InstallerEngine.NormalizeVersionSelection(" aLl ") == "2022,2023,2024,2025,2026,2027", "all ignores case and outside whitespace");
        for (var mask = 1; mask < (1 << InstallerEngine.SupportedVersions.Length); mask++)
        {
            var selected = InstallerEngine.SupportedVersions.Where((year, index) => (mask & (1 << index)) != 0).ToArray();
            var expected = string.Join(",", selected);
            Check(InstallerEngine.NormalizeVersionSelection(string.Join(",", selected.Reverse())) == expected, "exact subset " + expected);
            Check(InstallerEngine.NormalizeVersionSelection(" " + string.Join(" , ", selected) + " ") == expected, "trim subset " + expected);
        }
        foreach (var invalid in new[] { null, "", " ", "2021", "2028", "All,2026", "2024,All", "2024,2024", "2024,", ",2026", "2024,,2026", "2024;2026", "2024 2026", "2024,2028", "../../2026" })
            Throws<ArgumentException>(() => InstallerEngine.NormalizeVersionSelection(invalid), "invalid version selection " + invalid);

        Check(InstallerEngine.PayloadFiles.Length == 26, "two scripts and four files for each of six Revit releases");
        Check(InstallerEngine.PayloadFiles.Distinct(StringComparer.Ordinal).Count() == 26, "unique payload paths");
        if (!logicOnly) InFolder(folder =>
        {
            InstallerEngine.ExtractPayload(folder);
            foreach (var file in InstallerEngine.PayloadFiles)
                Check(new FileInfo(Path.Combine(folder, file)).Length > 0, "embedded payload " + file);
            Check(Directory.GetFiles(folder, "*", SearchOption.AllDirectories).Length == InstallerEngine.PayloadFiles.Length, "only expected payload files");
            foreach (var year in InstallerEngine.SupportedVersions)
            {
                var dll = Path.Combine(folder, "release", year, "KAMEP.Revit.dll");
                using (var stream = File.OpenRead(dll))
                using (var pe = new PEReader(stream))
                {
                    var reader = pe.GetMetadataReader();
                    foreach (var name in new[] { "RevitAPI", "RevitAPIUI" })
                    {
                        var matches = reader.AssemblyReferences.Select(handle => reader.GetAssemblyReference(handle))
                            .Where(reference => reader.GetString(reference.Name) == name).ToArray();
                        Check(matches.Length == 1 && matches[0].Version.Major == int.Parse(year) - 2000,
                            year + " payload references the matching " + name + " major version");
                    }
                }
                var target = int.Parse(year) <= 2024 ? ".NETFramework,Version=v4.8"
                    : year == "2027" ? ".NETCoreApp,Version=v10.0" : ".NETCoreApp,Version=v8.0";
                Check(Encoding.UTF8.GetString(File.ReadAllBytes(dll)).Contains(target), year + " payload targets the matching runtime");
                var helper = Path.Combine(folder, "release", year, "KAMEP.Mcp.Server.exe");
                using (var stream = File.OpenRead(helper))
                using (var pe = new PEReader(stream))
                {
                    var reader = pe.GetMetadataReader();
                    var references = reader.AssemblyReferences.Select(handle => reader.GetString(reader.GetAssemblyReference(handle).Name)).ToArray();
                    Check(references.Contains("KAMEP.Core"), year + " helper references the bundled Core assembly");
                    Check(!references.Any(name => name.StartsWith("RevitAPI", StringComparison.Ordinal)), year + " helper does not load Autodesk APIs");
                }
                Check(Encoding.UTF8.GetString(File.ReadAllBytes(helper)).Contains(".NETFramework,Version=v4.8"), year + " helper targets .NET Framework 4.8");
                var config = System.Xml.Linq.XDocument.Load(helper + ".config");
                var runtime = config.Root.Element("startup").Element("supportedRuntime");
                Check((string)runtime.Attribute("version") == "v4.0" && (string)runtime.Attribute("sku") == ".NETFramework,Version=v4.8", year + " helper runtime configuration");
            }
        });
        InFolder(folder =>
        {
            using (var archive = Archive(InstallerEngine.PayloadFiles)) InstallerEngine.ExtractArchive(archive, folder);
            Check(File.ReadAllText(Path.Combine(folder, "scripts", "Install.ps1")) == "payload", "valid archive extraction");
        });
        Reject(InstallerEngine.PayloadFiles.Take(InstallerEngine.PayloadFiles.Length - 1), "missing file");
        Reject(InstallerEngine.PayloadFiles.Concat(new[] { "extra.txt" }), "extra file");
        Reject(new[] { "../outside.txt" }.Concat(InstallerEngine.PayloadFiles.Skip(1)), "parent traversal");
        Reject(new[] { "/outside.txt" }.Concat(InstallerEngine.PayloadFiles.Skip(1)), "absolute path");
        Reject(new[] { "scripts\\Install.ps1" }.Concat(InstallerEngine.PayloadFiles.Skip(1)), "alternate path spelling");
        Reject(new[] { "scripts/Install.ps1" }.Concat(InstallerEngine.PayloadFiles.Take(InstallerEngine.PayloadFiles.Length - 1)), "duplicate path");
        InFolder(folder =>
        {
            Directory.CreateDirectory(Path.Combine(folder, "scripts"));
            var existing = Path.Combine(folder, "scripts", "Install.ps1");
            File.WriteAllText(existing, "preserve");
            Throws<IOException>(() => { using (var archive = Archive(InstallerEngine.PayloadFiles)) InstallerEngine.ExtractArchive(archive, folder); }, "no overwrite of existing files");
            Check(File.ReadAllText(existing) == "preserve", "existing file unchanged");
        });
        InFolder(folder =>
        {
            using (var archive = Archive(InstallerEngine.PayloadFiles, string.Empty))
                Throws<InvalidDataException>(() => InstallerEngine.ExtractArchive(archive, folder), "empty payload file");
        });
        if (!OperatingSystem.IsWindows())
        {
            InFolder(folder => InFolder(other =>
            {
                Directory.CreateSymbolicLink(Path.Combine(folder, "scripts"), other);
                Throws<IOException>(() => { using (var archive = Archive(InstallerEngine.PayloadFiles)) InstallerEngine.ExtractArchive(archive, folder); }, "linked extraction subdirectory");
                Check(Directory.GetFiles(other).Length == 0, "symlink target preserved");
            }));
        }
        Console.WriteLine("PASS: " + assertions + " installer checks" + (logicOnly ? " (logic only; embedded payload intentionally omitted)." : " (including current embedded payload)."));
    }

    private static MemoryStream Archive(IEnumerable<string> names, string content = "payload")
    {
        var stream = new MemoryStream();
        using (var archive = new ZipArchive(stream, ZipArchiveMode.Create, true))
            foreach (var name in names)
                using (var writer = new StreamWriter(archive.CreateEntry(name).Open(), new UTF8Encoding(false))) writer.Write(content);
        stream.Position = 0;
        return stream;
    }

    private static void Reject(IEnumerable<string> entries, string name)
    {
        InFolder(folder =>
        {
            using (var archive = Archive(entries)) Throws<InvalidDataException>(() => InstallerEngine.ExtractArchive(archive, folder), name);
        });
    }

    private static void InFolder(Action<string> operation)
    {
        var path = Path.Combine(Path.GetTempPath(), "KA MEP tests كريم-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(path);
        try { operation(path); }
        finally { Directory.Delete(path, true); }
    }

    private static void Throws<T>(Action operation, string name) where T : Exception
    {
        try { operation(); }
        catch (T) { assertions++; return; }
        throw new Exception("FAIL: " + name);
    }

    private static void Check(bool success, string name)
    {
        if (!success) throw new Exception("FAIL: " + name);
        assertions++;
    }
}
