#requires -Version 7.0
[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$assertions = 0
$supported = @('2022', '2023', '2024', '2025', '2026', '2027')
$ownedFiles = @('KAMEP.Revit.dll', 'KAMEP.Core.dll', 'KAMEP.Mcp.Server.exe', 'KAMEP.Mcp.Server.exe.config')
$sandbox = Join-Path ([IO.Path]::GetTempPath()) ('KA MEP script tests-' + [Guid]::NewGuid().ToString('N'))

function Check([bool] $Condition, [string] $Message) {
    if (-not $Condition) { throw "FAIL: $Message" }
    $script:assertions++
}

function Expect-Error([scriptblock] $Operation, [string] $Message) {
    $failed = $false
    try { & $Operation | Out-Null } catch { $failed = $true }
    Check $failed $Message
}

# The production scripts retain their Windows-only checks. This harness removes
# only those checks in temporary copies and substitutes a disposable AppData path.
# Unblock-File has no equivalent on Linux; it is irrelevant to selection/ownership.
function Unblock-File { param([string] $LiteralPath) }

try {
    [void][IO.Directory]::CreateDirectory($sandbox)
    foreach ($name in @('Build.ps1', 'Build-Mcp.ps1', 'Build-Installer.ps1')) {
        $tokens = $null
        $errors = $null
        [void][Management.Automation.Language.Parser]::ParseFile((Join-Path $root "scripts/$name"), [ref]$tokens, [ref]$errors)
        Check ($errors.Count -eq 0) "$name parses"
    }
    $sourceScripts = @{}
    foreach ($name in @('Install.ps1', 'Uninstall.ps1')) {
        $path = Join-Path $root "scripts/$name"
        $tokens = $null
        $errors = $null
        $ast = [Management.Automation.Language.Parser]::ParseFile($path, [ref]$tokens, [ref]$errors)
        Check ($errors.Count -eq 0) "$name parses"
        $function = $ast.Find({ param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Resolve-RevitVersionSelection' }, $true)
        Check ($null -ne $function) "$name has explicit selection parser"
        Invoke-Expression $function.Extent.Text
        Check ((@(Resolve-RevitVersionSelection 'All') -join ',') -eq '2022,2023,2024,2025,2026,2027') "$name All"
        Check ((@(Resolve-RevitVersionSelection ' aLl ') -join ',') -eq '2022,2023,2024,2025,2026,2027') "$name case and whitespace"
        for ($mask = 1; $mask -lt (1 -shl $supported.Count); $mask++) {
            $selected = @()
            for ($index = 0; $index -lt $supported.Count; $index++) { if (($mask -band (1 -shl $index)) -ne 0) { $selected += $supported[$index] } }
            $reversed = @($selected)
            [Array]::Reverse($reversed)
            $inputText = ' ' + ($reversed -join ' , ') + ' '
            Check ((@(Resolve-RevitVersionSelection $inputText) -join ',') -eq ($selected -join ',')) "$name exact sorted subset $mask"
        }
        foreach ($invalid in @('', ' ', '2021', '2028', 'All,2026', '2024,All', '2024,2024', '2024,', ',2026', '2024,,2026', '2024;2026', '2024 2026', '2024,2028', '../../2026')) {
            Expect-Error { Resolve-RevitVersionSelection $invalid } "$name rejects '$invalid'"
        }
        $sourceScripts[$name] = [IO.File]::ReadAllText($path)
    }

    for ($mask = 1; $mask -lt (1 -shl $supported.Count); $mask++) {
        $case = Join-Path $sandbox "subset-$mask"
        $package = Join-Path $case 'package'
        $fakeAppData = Join-Path $case 'appdata'
        $scripts = Join-Path $package 'scripts'
        [void][IO.Directory]::CreateDirectory($scripts)
        foreach ($name in $sourceScripts.Keys) {
            $text = $sourceScripts[$name]
            $text = [regex]::Replace($text, "(?s)if \(\[Environment\]::OSVersion\.Platform -ne \[PlatformID\]::Win32NT\) \{.*?\}", '# Windows guard removed in test copy only.')
            $text = $text.Replace('$appData = [Environment]::GetFolderPath([Environment+SpecialFolder]::ApplicationData)', ('$appData = ''' + $fakeAppData.Replace("'", "''") + "'"))
            [IO.File]::WriteAllText((Join-Path $scripts $name), $text)
        }
        $selected = @()
        for ($index = 0; $index -lt $supported.Count; $index++) {
            $year = $supported[$index]
            if (($mask -band (1 -shl $index)) -ne 0) { $selected += $year }
            $release = Join-Path $package "release/$year"
            [void][IO.Directory]::CreateDirectory($release)
            foreach ($dll in $ownedFiles) { [IO.File]::WriteAllText((Join-Path $release $dll), "$year $dll") }
            $yearRoot = Join-Path $fakeAppData "Autodesk/Revit/Addins/$year"
            [void][IO.Directory]::CreateDirectory($yearRoot)
            [IO.File]::WriteAllText((Join-Path $yearRoot 'Other.addin'), 'unrelated manifest')
        }
        $selection = $selected -join ','
        & (Join-Path $scripts 'Install.ps1') -RevitVersion $selection 6>$null | Out-Null
        foreach ($year in $supported) {
            $yearRoot = Join-Path $fakeAppData "Autodesk/Revit/Addins/$year"
            Check ((Test-Path -LiteralPath (Join-Path $yearRoot 'KAMEP.addin')) -eq ($selected -contains $year)) "install $selection targets only selected manifest $year"
            foreach ($dll in $ownedFiles) {
                $target = Join-Path $yearRoot "KAMEP/$dll"
                Check ((Test-Path -LiteralPath $target) -eq ($selected -contains $year)) "install $selection targets only selected binary $year $dll"
                if ($selected -contains $year) { Check ([IO.File]::ReadAllText($target) -eq "$year $dll") "correct per-version binary $year $dll" }
            }
            Check ([IO.File]::ReadAllText((Join-Path $yearRoot 'Other.addin')) -eq 'unrelated manifest') "install preserves unrelated manifest $year"
        }
        # An update must overwrite changed bytes, even when the public release
        # label is unchanged. The install script has no assembly-version gate.
        foreach ($year in $supported) {
            foreach ($dll in $ownedFiles) {
                [IO.File]::WriteAllText((Join-Path $package "release/$year/$dll"), "updated $year $dll")
            }
        }
        & (Join-Path $scripts 'Install.ps1') -RevitVersion $selection 6>$null | Out-Null
        foreach ($year in $supported) {
            $yearRoot = Join-Path $fakeAppData "Autodesk/Revit/Addins/$year"
            foreach ($dll in $ownedFiles) {
                $target = Join-Path $yearRoot "KAMEP/$dll"
                Check ((Test-Path -LiteralPath $target) -eq ($selected -contains $year)) "update preserves exact selected subset $selection $year $dll"
                if ($selected -contains $year) {
                    Check ([IO.File]::ReadAllText($target) -eq "updated $year $dll") "update replaces existing bytes $selection $year $dll"
                    $sourceHash = (Get-FileHash -LiteralPath (Join-Path $package "release/$year/$dll") -Algorithm SHA256).Hash
                    Check ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -eq $sourceHash) "updated binary matches source SHA256 $selection $year $dll"
                }
            }
        }
        if ($mask -eq ((1 -shl $supported.Count) - 1)) {
            # Fault injection changes a copied destination after Unblock-File,
            # exercising the production hash check and its real rollback path.
            $yearRoot = Join-Path $fakeAppData 'Autodesk/Revit/Addins/2025'
            $manifest = Join-Path $yearRoot 'KAMEP.addin'
            $originalManifest = [IO.File]::ReadAllText($manifest)
            foreach ($dll in $ownedFiles) {
                [IO.File]::WriteAllText((Join-Path $package "release/2025/$dll"), "replacement 2025 $dll")
            }
            foreach ($corruptFile in $ownedFiles) {
                $corruptScript = Join-Path $scripts 'Install-Corrupt.ps1'
                $corruptText = [IO.File]::ReadAllText((Join-Path $scripts 'Install.ps1'))
                $needle = 'Unblock-File -LiteralPath $destination'
                Check ($corruptText.Contains($needle)) 'hash mismatch injection point exists'
                $corruptText = $corruptText.Replace($needle, ($needle + "`n" + ('            if ($file -eq ''' + $corruptFile + ''') { [IO.File]::WriteAllText($destination, ''tampered after copy'') }')))
                [IO.File]::WriteAllText($corruptScript, $corruptText)
                $failure = $null
                try { & $corruptScript -RevitVersion '2025' 6>$null | Out-Null } catch { $failure = $_ }
                Check ($null -ne $failure -and $failure.Exception.Message.Contains('SHA256 verification failed')) 'installed hash mismatch is rejected'
                foreach ($year in $supported) {
                    foreach ($dll in $ownedFiles) {
                        $target = Join-Path $fakeAppData "Autodesk/Revit/Addins/$year/KAMEP/$dll"
                        Check ([IO.File]::ReadAllText($target) -eq "updated $year $dll") "hash failure restores prior bytes and preserves other versions $year $dll"
                    }
                }
                Check ([IO.File]::ReadAllText($manifest) -eq $originalManifest) 'hash failure preserves existing manifest'
                Check (@(Get-ChildItem -LiteralPath $yearRoot -Directory -Filter '.KAMEP-install-*').Count -eq 0) 'successful rollback removes staging folder'
            }
        }
        foreach ($year in $selected) {
            $keep = Join-Path $fakeAppData "Autodesk/Revit/Addins/$year/KAMEP/user-notes.txt"
            [IO.File]::WriteAllText($keep, 'preserve unrelated files in the add-in folder')
        }
        & (Join-Path $scripts 'Uninstall.ps1') -RevitVersion $selection 6>$null | Out-Null
        foreach ($year in $supported) {
            $yearRoot = Join-Path $fakeAppData "Autodesk/Revit/Addins/$year"
            Check (-not (Test-Path -LiteralPath (Join-Path $yearRoot 'KAMEP.addin'))) "uninstall selected manifest $selection $year"
            foreach ($file in $ownedFiles) {
                Check (-not (Test-Path -LiteralPath (Join-Path $yearRoot "KAMEP/$file"))) "uninstall owned file $selection $year $file"
            }
            if ($selected -contains $year) {
                Check ([IO.File]::ReadAllText((Join-Path $yearRoot 'KAMEP/user-notes.txt')) -eq 'preserve unrelated files in the add-in folder') "uninstall preserves user file $selection $year"
            }
            Check ([IO.File]::ReadAllText((Join-Path $yearRoot 'Other.addin')) -eq 'unrelated manifest') "uninstall preserves unrelated manifest $year"
        }
        # Uninstalling a subset of a complete installation must leave other versions intact.
        & (Join-Path $scripts 'Install.ps1') -RevitVersion All 6>$null | Out-Null
        & (Join-Path $scripts 'Uninstall.ps1') -RevitVersion $selection 6>$null | Out-Null
        foreach ($year in $supported) {
            $yearRoot = Join-Path $fakeAppData "Autodesk/Revit/Addins/$year"
            Check ((Test-Path -LiteralPath (Join-Path $yearRoot 'KAMEP.addin')) -eq ($selected -notcontains $year)) "subset uninstall leaves unselected installation $selection $year"
            foreach ($dll in $ownedFiles) {
                Check ((Test-Path -LiteralPath (Join-Path $yearRoot "KAMEP/$dll")) -eq ($selected -notcontains $year)) "subset uninstall leaves unselected binary $selection $year $dll"
            }
        }
    }
    Write-Host "PASS: $assertions script checks (isolated filesystem; Windows guards retained in production)."
}
finally { if (Test-Path -LiteralPath $sandbox) { Remove-Item -LiteralPath $sandbox -Recurse -Force } }
