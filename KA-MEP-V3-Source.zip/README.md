# KA MEP V3.0 — Build 20261030-01

KA MEP for Revit **2022.1+, 2023, 2024, 2025, 2026 and 2027**. This build includes all previous quantity/Excel, Tag Assistant, Sheet Parameters, Model Review and PDF/DWG tools, plus HVAC Spaces, Clash Manager and a local **read-only Claude Desktop MCP connection**.

- [Source ZIP](artifacts/source-archive/KA-MEP-V3.0-Build-20261030-01-source.zip)
- [Windows installer EXE](artifacts/KA-MEP-Setup-V3.0-Full-2022-2023-2024-2025-2026-2027-Build-20261030-01.exe)
- [Arabic installation and feature guide](README.ar.md)
- [Development/build guide](docs/DEVELOPMENT.ar.md)
- [Validation and runtime limits](docs/VALIDATION.md)

Close **Revit and Claude Desktop** before installing/updating. The installer runs for the current Windows user without administrator elevation and preserves the add-in's existing registration identity. It includes the matching Revit/Core DLLs and MCP helper/config for each year. The EXE and DLLs are **unsigned**; the user has not supplied a trusted code-signing certificate. Author/company metadata is Karim Ayman, but that alone does not resolve Unknown Publisher.

Open **KA MEP → Workspace → Claude MCP**, explicitly enable the connection, save its configuration snippet, merge that entry into Claude Desktop's existing `mcpServers`, and restart Claude Desktop. [Full instructions](docs/MCP-CLAUDE.ar.md). No Claude API key is embedded or required by this bridge. Requested model data is returned to the Claude conversation; this is not offline AI. The first version reads project identity, selection, category-filtered elements, parameters, sheets and warnings. It does not modify the model or execute arbitrary code. Closing the connection window stops access.

[HVAC Spaces](docs/HVAC-SPACES.ar.md) reports host Spaces, architectural Room identities, sampled physical clear heights and opening Size (W × H)/nominal areas. [Clash Manager](docs/CLASH-MANAGER.ar.md) imports HTML pairs, maps host/direct-link sources, opens a focused 3D view, refreshes supported hard-intersection status and exports Excel. Missing/ambiguous/unsupported cases need review; imported status is historical.

Compilation, detached tests and package verification do **not** establish native Revit/Claude/Excel behavior. Native Windows/Revit/Claude Desktop testing remains pending; use the [MCP checklist](docs/MCP-SMOKE-TEST.md), [Clash checklist](docs/CLASH-MANAGER-SMOKE-TEST.md) and [Spaces checklist](docs/HVAC-SPACES-SMOKE-TEST.md). Prior validation and the old V2 installer are preserved separately.
