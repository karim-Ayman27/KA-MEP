using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using PipeTakeoff.Core;

internal static class Program
{
    private static int assertions;
    private static int failures;
    private const string Unique1 = "11111111-2222-3333-4444-555555555555-00112233";
    private const string Unique2 = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee-22334455";

    private static int Main()
    {
        Run("Navisworks nested report", NestedReport);
        Run("Navisworks vertical properties and metadata", PropertyReport);
        Run("Nested property scopes and related identities", PropertyScopes);
        Run("Native Revit interference report", NativeReport);
        Run("Element reference identity boundaries", ReferenceBoundaries);
        Run("Unique IDs and metadata columns", UniqueIds);
        Run("Test section provenance and historical states", SectionProvenance);
        Run("Conservative test criteria and changing headers", CriteriaAndHeaders);
        Run("Manual column mapping and inspection", ManualMapping);
        Run("Block reports and duplicate handling", BlocksAndDuplicates);
        Run("Inert untrusted HTML and malformed optional tags", UntrustedHtml);
        Run("File encodings and byte provenance", FileEncodings);
        Run("Input and parser resource limits", Limits);
        Run("Clash count limit", ClashLimit);
        Console.WriteLine((failures == 0 ? "PASS " : "FAIL ") + assertions.ToString(CultureInfo.InvariantCulture) + " Clash Import assertions; " + failures.ToString(CultureInfo.InvariantCulture) + " failing groups.");
        return failures == 0 ? 0 : 1;
    }

    private static void NestedReport()
    {
        var report = Fixture("navisworks-nested.html");
        Equal(2, report.Rows.Count, "nested property tables do not create extra clash rows");
        Equal("Navisworks", report.Producer, "producer");
        Equal("Navisworks Clash Detective — Coordination", report.Title, "title");
        var first = report.Rows[0];
        Equal("Clash 001", first.Name, "clash name");
        Equal("HVAC / Structure", first.TestName, "test heading");
        Equal(ClashTestKind.Hard, first.TestKind, "explicit hard criterion");
        Equal("Resolved", first.ImportedStatus, "historical status retained");
        Equal("-0.042 m", first.DistanceText, "distance retained");
        Equal("x: 14.5; y: 3.2; z: 8.1", first.ClashPointText, "point retained");
        Equal("MEP team", first.AssignedTo, "assignment retained");
        Equal("Check riser & beam", first.Description, "entities decoded");
        Equal((long?)9000000001L, first.Element1.ElementId, "nested first 64-bit Revit id");
        Equal((long?)9000000002L, first.Element2.ElementId, "nested second 64-bit Revit id");
        Equal("Pipes", first.Element1.ReportedCategory, "nested category");
        Equal("CHW Return DN100", first.Element1.ReportedName, "nested item name");
        Equal("Hospital_MEP.rvt", first.Element1.SourceHint, "nested source");
        Equal("Hospital_Structure.nwc", first.Element2.SourceHint, "second source");
        Check(first.Element1.RawText.Contains("99201"), "original non-Revit Item ID retained");
        Check(first.ExtraFields.ContainsKey("Comments"), "original column retained");
        Equal((long?)null, report.Rows[1].Element1.ElementId, "Item ID, date and distance are not Revit IDs");
        Equal((long?)4294967297L, report.Rows[1].Element2.ElementId, "Revit ID label");
        Check(report.Notes.Any(n => n.Contains("no IDs were guessed")), "missing reference note");
        Unchecked(report);
        Equal(report.Rows[0].Key, Fixture("navisworks-nested.html").Rows[0].Key, "stable row identity on reimport");
    }

    private static void PropertyReport()
    {
        var report = Fixture("navisworks-properties.html");
        Equal(1, report.Rows.Count, "vertical clash count");
        var row = report.Rows[0];
        Equal("Access 001", row.Name, "vertical name");
        Equal("Duct maintenance zones", row.TestName, "separate metadata table test name");
        Equal(ClashTestKind.Clearance, row.TestKind, "separate metadata table criterion");
        Equal((long?)7000000001L, row.Element1.ElementId, "nested Element > ID property");
        Equal((long?)7000000002L, row.Element2.ElementId, "vertical second element");
        Equal("Ducts", row.Element1.ReportedCategory, "nested category");
        Equal("HVAC.rvt", row.Element1.SourceHint, "nested model source");
        Equal("Approved", row.ImportedStatus, "vertical status");
        Unchecked(report);
    }

    private static void NativeReport()
    {
        var report = Fixture("revit-interference.html");
        Equal("Revit interference report", report.Producer, "native producer");
        Equal(2, report.Rows.Count, "native report retains incomplete row");
        var first = report.Rows[0];
        Equal((long?)9000000003L, first.Element1.ElementId, "native 64-bit ID");
        Equal((long?)9000000004L, first.Element2.ElementId, "native other ID");
        Equal("Pipes", first.Element1.ReportedCategory, "native category");
        Equal("Pipe Types : Standard", first.Element1.ReportedName, "native description");
        Check(report.Rows.All(r => r.TestKind == ClashTestKind.Hard), "interference is an explicit hard check");
        Equal((long?)null, report.Rows[1].Element2.ElementId, "missing native ID retained as missing");
        Unchecked(report);
        var noHeaders = Import("<title>Interference Report</title><table><tr><td>Walls : Basic : id 777</td><td>Pipes : Standard : id 888</td></tr></table>");
        Equal((long?)777L, noHeaders.Rows[0].Element1.ElementId, "native descriptions without column headings");
    }

    private static void PropertyScopes()
    {
        string element = "<table><tr><td>Element</td><td><table><tr><td>Name</td><td>Supply main</td></tr><tr><td>ID</td><td>8123456789</td></tr><tr><td>Category</td><td>Ducts</td></tr></table></td></tr><tr><td>Model</td><td><table><tr><td>Name</td><td>MEP.rvt</td></tr></table></td></tr></table>";
        var row = Import(Table("Item 1", "Item 2", element, "Element ID: 456")).Rows[0];
        Equal((long?)8123456789L, row.Element1.ElementId, "Element scope ID need not be its first property");
        Equal("Ducts", row.Element1.ReportedCategory, "Element scope category");
        Equal("Supply main", row.Element1.ReportedName, "Element scope name");
        Equal("MEP.rvt", row.Element1.SourceHint, "Model scope name is source provenance");
        Check(row.Element1.RawText.Contains("8123456789") && row.Element1.RawText.Contains("MEP.rvt"), "original nested text retained");
        foreach (string group in new[] { "Item", "Geometry", "Parent", "Type" })
        {
            string unknown = "<table><tr><td>" + group + "</td><td><table><tr><td>ID</td><td>123</td></tr></table></td></tr></table>";
            Equal((long?)null, Import(Table("Item 1", "Item 2", unknown, "Element ID: 456")).Rows[0].Element1.ElementId, group + " ID is not element identity");
        }
        string related = "<table><tr><td>Parent</td><td>" + element + "</td></tr></table>";
        Equal((long?)null, Import(Table("Item 1", "Item 2", related, "Element ID: 456")).Rows[0].Element1.ElementId, "parent Element scope does not identify current element");
        string columns = "<table><tr><td>Element</td><td>ID</td><td>123</td></tr><tr><td>Model</td><td>Name</td><td>ARCH.rvt</td></tr></table>";
        row = Import(Table("Item 1", "Item 2", columns, "Element ID: 456")).Rows[0];
        Equal((long?)123L, row.Element1.ElementId, "scope/property/value columns");
        Equal("ARCH.rvt", row.Element1.SourceHint, "scope/property/value model");
    }

    private static void ReferenceBoundaries()
    {
        string[] bad = { "Item ID: 12345", "ID: 12345", "Parent Element ID: 123", "Type Element ID: 123", "Name: Element ID: 123", "Date: 2026-10-28", "Distance: 12.345", "Element ID: 2026-10-28", "Element ID: 123.45", "Element ID: 456/789", "Element ID: 123+456", "Element ID: 123 xyz", "Element ID: -123", "Element ID: 0", "Element ID: 9223372036854775808", "Element ID: 12abc", "Element ID: 111; Revit ID: 222", "Element ID: 111; Element ID: 9223372036854775808", "Walls : Basic : id 12345", "12345" };
        foreach (string raw in bad)
        {
            var row = Import(Table("Item 1", "Item 2", raw, "Element ID: 9876543210")).Rows[0];
            Equal((long?)null, row.Element1.ElementId, "no guessed ID from " + raw);
            Equal((long?)9876543210L, row.Element2.ElementId, "valid partner retained for " + raw);
            Check(row.Element1.RawText.Contains(raw), "unrecognized text retained for " + raw);
        }
        Equal((long?)long.MaxValue, Import(Table("Element ID 1", "Element ID 2", long.MaxValue.ToString(CultureInfo.InvariantCulture), "123")).Rows[0].Element1.ElementId, "full positive Int64 range");
        Equal((long?)123L, Import(Table("Revit ID 1", "Revit ID 2", "000123", "456")).Rows[0].Element1.ElementId, "explicit numeric header");
        Equal((long?)123L, Import(Table("Item 1", "Item 2", "Element ID: 123; Revit ID: 123", "Element ID: 456")).Rows[0].Element1.ElementId, "repeated consistent explicit ID");
        foreach (string malformed in new[] { "-5", "abc", "123.0", "0" })
            Equal((long?)null, Import(Table("Item 1", "Item 2", "Element ID: 123; Element ID: " + malformed, "Element ID: 456")).Rows[0].Element1.ElementId, "conflicting malformed property cannot be discarded: " + malformed);
        Equal((long?)123L, Import(Table("Item 1", "Item 2", "Element&nbsp;ID:&nbsp;123", "Element ID: 456")).Rows[0].Element1.ElementId, "nonbreaking spaces in property labels");
    }

    private static void UniqueIds()
    {
        var row = Import(Table("UniqueId 1", "UniqueId 2", Unique1, Unique2)).Rows[0];
        Equal(Unique1, row.Element1.UniqueId, "first standalone unique ID");
        Equal(Unique2, row.Element2.UniqueId, "second standalone unique ID");
        Equal((long?)null, row.Element1.ElementId, "unique IDs do not create numeric IDs");
        row = Import(Table("Item 1", "Item 2", "Unique ID: " + Unique1, "Element ID: 456")).Rows[0];
        Equal(Unique1, row.Element1.UniqueId, "unique ID property");
        row = Import(Table("Item 1", "Item 2", "Unique ID: " + Unique1 + "; Unique ID: " + Unique2, "Element ID: 456")).Rows[0];
        Equal("", row.Element1.UniqueId, "conflicting unique IDs remain unresolved");
        foreach (string suffix in new[] { "ZZ", "_extra", "/related", "-more", ".1" })
            Equal("", Import(Table("Item 1", "Item 2", "Unique ID: " + Unique1 + suffix, "Element ID: 456")).Rows[0].Element1.UniqueId, "unique ID must not truncate suffix " + suffix);
        Equal("", Import(Table("Item 1", "Item 2", "Parent Unique ID: " + Unique1, "Element ID: 456")).Rows[0].Element1.UniqueId, "parent unique ID is not element identity");
        Equal("", Import(Table("Item 1", "Item 2", "Unique ID: " + Unique1 + "; Unique ID: broken", "Element ID: 456")).Rows[0].Element1.UniqueId, "conflicting malformed unique ID cannot be discarded");
        var report = Import("<table><tr><th>Element ID 1</th><th>Element ID 2</th><th>UniqueId 1</th><th>Category 1</th><th>Element 2 Name</th><th>Source 1</th><th>File 2</th></tr><tr><td>123</td><td>456</td><td>" + Unique1 + "</td><td>Pipes</td><td>Basic Wall</td><td>MEP.rvt</td><td>ARCH.nwc</td></tr></table>");
        row = report.Rows[0];
        Equal(Unique1, row.Element1.UniqueId, "numeric and unique ID columns coexist");
        Equal("Pipes", row.Element1.ReportedCategory, "category column");
        Equal("Basic Wall", row.Element2.ReportedName, "element name column");
        Equal("MEP.rvt", row.Element1.SourceHint, "source column");
        Equal("ARCH.nwc", row.Element2.SourceHint, "file column");
        Unchecked(report);
    }

    private static void SectionProvenance()
    {
        string grid = Table("Element ID 1", "Element ID 2", "123", "456");
        var report = Import("<title>Navisworks report</title><h2>Test Name: First</h2><p>Test Type: Hard</p>" + grid + "<h2>Test Name: Second</h2><p>Test Type: Clearance</p>" + grid + "<h2>Test Name: Third</h2>" + grid);
        Equal(3, report.Rows.Count, "same pair in distinct tests preserved");
        Equal("First", report.Rows[0].TestName, "first test");
        Equal("Second", report.Rows[1].TestName, "second test");
        Equal("Third", report.Rows[2].TestName, "third test");
        Equal(ClashTestKind.Hard, report.Rows[0].TestKind, "first type");
        Equal(ClashTestKind.Clearance, report.Rows[1].TestKind, "second type");
        Equal(ClashTestKind.Unknown, report.Rows[2].TestKind, "type does not bleed into following test");
        var cases = new Dictionary<string, ClashTestKind> { { "Hard", ClashTestKind.Hard }, { "Hard (Conservative)", ClashTestKind.Hard }, { "Clearance", ClashTestKind.Clearance }, { "Duplicate", ClashTestKind.Duplicate }, { "Unknown", ClashTestKind.Unknown }, { "", ClashTestKind.Unknown } };
        foreach (var pair in cases)
        {
            report = Import("<h2>Test Name: Hard things with duplicate names</h2><table><tr><th>Element ID 1</th><th>Element ID 2</th><th>Test Type</th><th>Status</th></tr><tr><td>123</td><td>456</td><td>" + pair.Key + "</td><td>Solved</td></tr></table>");
            Equal(pair.Value, report.Rows[0].TestKind, "explicit criterion " + pair.Key);
            Equal("Solved", report.Rows[0].ImportedStatus, "solved remains historical");
            Unchecked(report);
        }
        Equal(ClashTestKind.Unknown, Import("<title>Hard clash results</title>" + grid).Rows[0].TestKind, "report title alone does not establish type");
    }

    private static void ManualMapping()
    {
        string path = FixturePath("manual-columns.html");
        Throws<InvalidDataException>(() => ClashHtmlImporter.ImportFile(path), "unsupported layout requests mapping");
        var previews = ClashHtmlImporter.InspectFile(path);
        Equal(2, previews.Count, "inspection lists selectable tables");
        Equal(1, previews[1].TableIndex, "inspection retains document table index");
        Equal("Ticket", previews[1].Headers[0], "inspection headers");
        Equal(1, previews[1].DataRowCount, "inspection data row count");
        Equal("9100000001", previews[1].PreviewRows[0][1], "inspection preview");
        var map = new ClashColumnMapping { TableIndex = 1, NameColumn = 0, Id1Column = 1, Id2Column = 2, Source1Column = 3, Source2Column = 4, Category1Column = 5, Category2Column = 6, StatusColumn = 7, TestKindColumn = 8, DescriptionColumn = 9 };
        var report = ClashHtmlImporter.ImportFile(path, map);
        var row = report.Rows[0];
        Equal((long?)9100000001L, row.Element1.ElementId, "manual numeric reference is explicit");
        Equal((long?)9100000002L, row.Element2.ElementId, "manual second reference");
        Equal("MEP.rvt", row.Element1.SourceHint, "manual model");
        Equal("Walls", row.Element2.ReportedCategory, "manual category");
        Equal("Manual mapping only", row.Description, "manual description");
        Equal(ClashTestKind.Hard, row.TestKind, "manual criterion");
        Check(report.Notes.Any(n => n.Contains("selected manually")), "manual provenance note");
        Unchecked(report);
        var headerless = ClashHtmlImporter.ImportText("<table><tr><td>123</td><td>456</td></tr></table>", "headerless.html", new ClashColumnMapping { HasHeaderRow = false, Id1Column = 0, Id2Column = 1 });
        Equal((long?)123L, headerless.Rows[0].Element1.ElementId, "headerless manual mapping");
        var unique = ClashHtmlImporter.ImportText("<table><tr><td>" + Unique1 + "</td><td>" + Unique2 + "</td></tr></table>", "unique.html", new ClashColumnMapping { HasHeaderRow = false, UniqueId1Column = 0, UniqueId2Column = 1 });
        Equal(Unique2, unique.Rows[0].Element2.UniqueId, "manual UniqueId-only mapping");
        Throws<InvalidDataException>(() => ClashHtmlImporter.ImportFile(path, new ClashColumnMapping { TableIndex = 99, Id1Column = 0, Id2Column = 1 }), "missing mapped table rejected");
        Throws<InvalidDataException>(() => ClashHtmlImporter.ImportFile(path, new ClashColumnMapping { TableIndex = 1, Id1Column = 1 }), "missing element side mapping rejected");
        Throws<InvalidDataException>(() => ClashHtmlImporter.ImportFile(path, new ClashColumnMapping { TableIndex = 1, Id1Column = 99, Id2Column = 2 }), "out-of-range reference mapping rejected");
    }

    private static void CriteriaAndHeaders()
    {
        string grid = "<table><tr><th>Element ID 1</th><th>Element ID 2</th><th>Test Type</th></tr><tr><td>123</td><td>456</td><td>Unknown</td></tr></table>";
        Equal(ClashTestKind.Unknown, Import("<h2>Test: First</h2><p>Test Type: Hard</p>" + grid).Rows[0].TestKind, "explicit unknown criterion must not inherit Hard");
        var report = Import("<title>Navisworks Clash Report</title><h2>Test Name: Revit interference clearance</h2><p>Test Type: Clearance</p>" + Table("Item 1", "Item 2", "Walls : Basic : id 123", "Pipes : Basic : id 456"));
        Equal("Navisworks", report.Producer, "test name cannot identify native Revit producer");
        Equal(ClashTestKind.Clearance, report.Rows[0].TestKind, "test name cannot force Hard criterion");
        Equal((long?)null, report.Rows[0].Element1.ElementId, "native ID syntax requires native report provenance");
        report = Import("<table><tr><th>Element ID 1</th><th>Element ID 2</th><th>Source 1</th><th>Source 2</th></tr><tr><td>123</td><td>456</td><td>MEP.rvt</td><td>ARCH.rvt</td></tr><tr><th>Element ID 2</th><th>Element ID 1</th><th>Source 2</th><th>Source 1</th></tr><tr><td>789</td><td>234</td><td>STRUCT.rvt</td><td>MEP.rvt</td></tr></table>");
        Equal(2, report.Rows.Count, "reordered repeated header retains both data rows");
        Equal((long?)234L, report.Rows[1].Element1.ElementId, "reordered first element header remaps");
        Equal("MEP.rvt", report.Rows[1].Element1.SourceHint, "reordered source header remaps");
        Equal((long?)789L, report.Rows[1].Element2.ElementId, "reordered second element header remaps");
        string metadata1 = "<table><tr><td>Test Name</td><td>First</td></tr><tr><td>Test Type</td><td>Hard</td></tr></table>";
        string metadata2 = "<table><tr><td>Test Name</td><td>Second</td></tr></table>";
        report = Import(metadata1 + Table("Element ID 1", "Element ID 2", "123", "456") + metadata2 + Table("Element ID 1", "Element ID 2", "789", "234"));
        Equal("Second", report.Rows[1].TestName, "nearest metadata table controls test name");
        Equal(ClashTestKind.Unknown, report.Rows[1].TestKind, "criterion cannot leak through a new metadata table");
        report = Import("<h2>Test: First</h2><p>Test Type: Hard</p><table><tr><th>Element ID 1</th><th>Element ID 2</th></tr><tr><td>123</td><td>456</td></tr><tr><td colspan='2'>Test: Second</td></tr><tr><td>789</td><td>234</td></tr></table>");
        Equal("Second", report.Rows[1].TestName, "inline test separator starts new scope");
        Equal(ClashTestKind.Unknown, report.Rows[1].TestKind, "inline test separator clears old criterion");
    }

    private static void BlocksAndDuplicates()
    {
        var block = Import("<h2>Test: Coordination</h2><p>Test Type: Duplicate</p><div class='clash-result'><h3>Duplicate 1</h3><p>Status: Resolved</p><p>Item 1:</p><p>Element ID: 123</p><p>Source File: MEP.rvt</p><p>Item 2:</p><p>Element ID: 456</p></div>");
        Equal(1, block.Rows.Count, "block report row");
        Equal("Duplicate 1", block.Rows[0].Name, "block heading name");
        Equal((long?)123L, block.Rows[0].Element1.ElementId, "block first reference");
        Equal((long?)456L, block.Rows[0].Element2.ElementId, "block second reference");
        Equal(ClashTestKind.Duplicate, block.Rows[0].TestKind, "block criterion");
        Unchecked(block);
        string row = "<tr><td>Clash A</td><td>123</td><td>456</td></tr>";
        var duplicates = Import("<table><tr><th>Name</th><th>Element ID 1</th><th>Element ID 2</th></tr>" + row + row + "</table>");
        Equal(1, duplicates.Rows.Count, "identical repeated rows collapse");
        Check(duplicates.Notes.Any(n => n.Contains("identical repeated")), "collapse is disclosed");
    }

    private static void UntrustedHtml()
    {
        var report = Fixture("malicious-malformed.html");
        Equal(1, report.Rows.Count, "script, style, template, comment and noscript tables ignored");
        Equal("Visible & safe", report.Rows[0].Name, "malformed optional tags preserved");
        Equal((long?)9000000005L, report.Rows[0].Element1.ElementId, "quoted greater-than in attributes");
        Equal((long?)9000000006L, report.Rows[0].Element2.ElementId, "second malformed cell");
        Check(report.Rows[0].Description.Contains("<script>plain text</script>"), "encoded markup remains plain text");
        Check(report.Rows[0].Description.Contains("&remote;"), "external entity is not resolved");
        Equal(1, ClashHtmlImporter.InspectFile(FixturePath("malicious-malformed.html")).Count, "inspection is equally inert");
        Throws<InvalidDataException>(() => Import("<html><title>Nothing to import</title><script>while(true){}</script></html>"), "scripts cannot supply records");
        Throws<InvalidDataException>(() => Import("<script></scriptx>" + Table("Element ID 1", "Element ID 2", "1", "2") + "</script>"), "closing tag prefix cannot expose script contents");
        Throws<InvalidDataException>(() => Import("<!--" + Table("Element ID 1", "Element ID 2", "1", "2")), "unterminated comment stays ignored");
        Throws<InvalidDataException>(() => Import("<table><tr><th>Element ID 1</th><th>Element ID 2</th></tr><script>" + Table("Element ID 1", "Element ID 2", "1", "2")), "unterminated script stays ignored");
        foreach (string tag in new[] { "template", "noscript", "object", "svg", "math" })
        {
            string hidden = "<" + tag + "><" + tag + "></" + tag + ">" + Table("Element ID 1", "Element ID 2", "1", "2") + "</" + tag + ">";
            Throws<InvalidDataException>(() => Import(hidden), "nested ignored container remains inert: " + tag);
            Equal(0, ClashHtmlImporter.InspectTables(hidden).Count, "nested ignored container absent from inspection: " + tag);
        }
    }

    private static void FileEncodings()
    {
        string html = "<title>Café — خدمات</title>" + Table("Element ID 1", "Element ID 2", "123", "456");
        var encodings = new Encoding[] { new UTF8Encoding(false), new UTF8Encoding(true), Encoding.Unicode, Encoding.BigEndianUnicode, new UTF32Encoding(false, true), new UTF32Encoding(true, true) };
        foreach (Encoding encoding in encodings)
        {
            byte[] bytes = encoding.GetPreamble().Concat(encoding.GetBytes(html)).ToArray();
            WithFile(bytes, path =>
            {
                var report = ClashHtmlImporter.ImportFile(path);
                Equal("Café — خدمات", report.Title, "Unicode title " + encoding.WebName);
                Equal(path, report.SourcePath, "source path preserved");
                using (var sha = SHA256.Create()) Equal(BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(), report.SourceSha256, "source hash uses actual file bytes");
                Equal(1, ClashHtmlImporter.InspectFile(path).Count, "encoded file inspection");
            });
        }
        string legacyHtml = "<meta charset='windows-1252'><title>Café — €</title>" + Table("Element ID 1", "Element ID 2", "123", "456");
        byte[] legacy = legacyHtml.Select(c => c == '—' ? (byte)0x97 : c == '€' ? (byte)0x80 : (byte)c).ToArray();
        WithFile(legacy, path => Equal("Café — €", ClashHtmlImporter.ImportFile(path).Title, "declared Windows-1252 export"));
        WithFile(legacyHtml.Replace("<meta charset='windows-1252'>", "").Select(c => c == '—' ? (byte)0x97 : c == '€' ? (byte)0x80 : (byte)c).ToArray(), path => Equal("Café — €", ClashHtmlImporter.ImportFile(path).Title, "undeclared legacy Windows export"));
        WithFile(Encoding.ASCII.GetBytes("<meta charset='utf-8'>").Concat(new byte[] { 0xff }).ToArray(), path => Throws<InvalidDataException>(() => ClashHtmlImporter.ImportFile(path), "invalid explicitly declared UTF-8 rejected"));
        WithFile(Encoding.UTF8.GetBytes("<meta charset='shift_jis'>" + html), path => Throws<InvalidDataException>(() => ClashHtmlImporter.ImportFile(path), "unsupported declared encoding rejected"));
    }

    private static void Limits()
    {
        Throws<ArgumentNullException>(() => ClashHtmlImporter.InspectTables(null), "null input rejected");
        Throws<InvalidDataException>(() => Import(""), "empty report rejected");
        Throws<InvalidDataException>(() => ClashHtmlImporter.InspectTables(new string('x', ClashHtmlImporter.MaximumFileBytes + 1)), "text byte limit");
        Throws<InvalidDataException>(() => ClashHtmlImporter.InspectTables(new string('é', ClashHtmlImporter.MaximumFileBytes / 2 + 1)), "UTF-8 byte limit counts multibyte text");
        Throws<InvalidDataException>(() => ClashHtmlImporter.InspectTables(string.Concat(Enumerable.Repeat("<div>", 129))), "nesting limit");
        Throws<InvalidDataException>(() => ClashHtmlImporter.InspectTables(string.Concat(Enumerable.Repeat("<table></table>", 4097))), "table count limit");
        Throws<InvalidDataException>(() => ClashHtmlImporter.InspectTables("<table>" + string.Concat(Enumerable.Repeat("<tr></tr>", 100001)) + "</table>"), "row count limit");
        Throws<InvalidDataException>(() => ClashHtmlImporter.InspectTables("<table><tr>" + string.Concat(Enumerable.Repeat("<td>x</td>", 129)) + "</tr></table>"), "cell count limit");
        Throws<InvalidDataException>(() => ClashHtmlImporter.InspectTables("<table><tr>" + string.Concat(Enumerable.Repeat("<span><td>x</td></span>", 129)) + "</tr></table>"), "wrapped cells cannot evade per-row limit");
        Throws<InvalidDataException>(() => ClashHtmlImporter.InspectTables(string.Concat(Enumerable.Repeat("<br>", 250001))), "node count limit");
        Throws<InvalidDataException>(() => Import(Table("Item 1", "Item 2", new string('x', 131073), "Element ID: 2")), "field text limit");
        string path = Path.Combine(Path.GetTempPath(), "clash-import-limit-" + Guid.NewGuid().ToString("N") + ".html");
        try
        {
            using (var stream = File.Create(path)) stream.SetLength(ClashHtmlImporter.MaximumFileBytes + 1L);
            Throws<InvalidDataException>(() => ClashHtmlImporter.ImportFile(path), "file byte limit before reading");
            Throws<InvalidDataException>(() => ClashHtmlImporter.InspectFile(path), "inspection file byte limit");
        }
        finally { File.Delete(path); }
    }

    private static void ClashLimit()
    {
        var html = new StringBuilder("<table><tr><th>Name</th><th>Element ID 1</th><th>Element ID 2</th></tr>");
        for (int i = 0; i <= ClashHtmlImporter.MaximumClashes; i++) html.Append("<tr><td>Clash ").Append(i.ToString(CultureInfo.InvariantCulture)).Append("</td><td>123</td><td>456</td></tr>");
        html.Append("</table>");
        Throws<InvalidDataException>(() => Import(html.ToString()), "clash count limit rejects oversized result atomically");
    }

    private static string Table(string firstHeader, string secondHeader, string first, string second)
    {
        return "<table><tr><th>" + firstHeader + "</th><th>" + secondHeader + "</th></tr><tr><td>" + first + "</td><td>" + second + "</td></tr></table>";
    }
    private static ClashReport Import(string html) { return ClashHtmlImporter.ImportText(html, "fixture.html"); }
    private static string FixturePath(string name) { return Path.Combine(AppContext.BaseDirectory, "fixtures", name); }
    private static ClashReport Fixture(string name) { return ClashHtmlImporter.ImportFile(FixturePath(name)); }
    private static void Unchecked(ClashReport report)
    {
        Check(report.Rows.All(r => r.State == ClashState.Unchecked && r.CheckedAt == null && r.CheckBasis == ""), "imported rows never inherit live solved state");
    }
    private static void WithFile(byte[] bytes, Action<string> action)
    {
        string path = Path.Combine(Path.GetTempPath(), "clash-import-" + Guid.NewGuid().ToString("N") + ".html");
        try { File.WriteAllBytes(path, bytes); action(path); }
        finally { File.Delete(path); }
    }
    private static void Run(string name, Action action)
    {
        try { action(); Console.WriteLine("PASS " + name); }
        catch (Exception ex) { failures++; Console.Error.WriteLine("FAIL " + name + ": " + ex); }
    }
    private static void Check(bool condition, string message)
    {
        assertions++;
        if (!condition) throw new Exception(message);
    }
    private static void Equal<T>(T expected, T actual, string message)
    {
        assertions++;
        if (!EqualityComparer<T>.Default.Equals(expected, actual)) throw new Exception(message + "; expected [" + expected + "], actual [" + actual + "]");
    }
    private static void Throws<T>(Action action, string message) where T : Exception
    {
        assertions++;
        try { action(); }
        catch (T) { return; }
        throw new Exception(message + "; expected " + typeof(T).Name);
    }
}
