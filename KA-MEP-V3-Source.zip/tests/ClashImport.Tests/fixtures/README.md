# Clash importer fixtures

These are synthetic, realistic report examples written for importer regression tests. They are not Autodesk-certified exports or customer project data. Names, identifiers, model paths and coordinates are fictional.

- `navisworks-nested.html`: Navisworks-style clash table with nested item property tables, 64-bit Revit IDs, source models, categories, historical statuses and report metadata.
- `navisworks-properties.html`: One vertical properties table per clash and test metadata in a separate table.
- `revit-interference.html`: Native Revit interference element descriptions ending in `: id N`, including a missing reference.
- `manual-columns.html`: An unsupported column layout which requires explicit user mapping.
- `malicious-malformed.html`: Inert scripts, remote resource URLs, an external entity declaration, encoded text and omitted optional closing tags. No resource is needed or fetched by the tests.

Additional generated cases exercise bounds, encodings, misleading numbers, duplicates and unsupported layouts. They also cover nested Element/Model property scopes, related parent/type identities, malformed conflicting identifiers, changing repeated column headers, explicit unknown test criteria, metadata section boundaries, nested ignored containers, and wrapped-cell limits. The test executable compiles the production importer and models as linked sources; it does not load Revit or a browser.
