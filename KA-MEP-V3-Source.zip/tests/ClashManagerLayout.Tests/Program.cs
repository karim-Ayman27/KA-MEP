using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using PipeTakeoff.Core;
using PipeTakeoff.Revit;

internal static class Program
{
    [STAThread]
    private static int Main(string[] args)
    {
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        string only = Arg(args, "--case="), screenshots = Arg(args, "--screenshots=");
        if (screenshots != null) Directory.CreateDirectory(screenshots);
        int passed = 0, total = 0;
        foreach (var test in new[] { new Case(1366,728,1), new Case(1280,680,1.5F), new Case(1280,680,2),
            new Case(1024,600,1), new Case(1024,600,1.5F), new Case(1024,600,2),
            new Case(876,571,1), new Case(876,571,1.5F), new Case(876,571,2) })
        {
            if (only != null && only != test.Name) continue;
            total++; var errors = new List<string>();
            try { Check(test, screenshots, errors); } catch (Exception ex) { errors.Add(ex.ToString()); }
            Console.WriteLine((errors.Count == 0 ? "PASS " : "FAIL ") + test.Name);
            foreach (string error in errors.Distinct()) Console.WriteLine("  " + error);
            if (errors.Count == 0) passed++;
        }
        Console.WriteLine("RESULT: " + passed + "/" + total + " Clash Manager UI cases passed; " + (total-passed) + " failed.");
        Console.WriteLine("Actual detached production form under Mono/Xvfb with simulated font/control scaling; not Windows DPI or live Revit.");
        return total > 0 && total == passed ? 0 : 1;
    }

    private static void Check(Case test, string screenshots, List<string> errors)
    {
        using (var form = new ClashManagerForm())
        {
            ShowScaled(form, test);
            var tabs = Find<TabControl>(form, "ClashTabs");
            var export = Find<Button>(form, "ClashExportExcel");
            var refreshVisible = Find<Button>(form, "ClashRefreshVisible");
            var refreshSelected = Find<Button>(form, "ClashRefreshSelected");
            var close = Find<Button>(form, "ClashClose");
            var grid = Find<DataGridView>(form, "ClashGrid");
            var search = Find<TextBox>(form, "ClashSearch");
            var status = Find<ComboBox>(form, "ClashStatusFilter");
            var testFilter = Find<ComboBox>(form, "ClashTestFilter");
            var source1 = Find<ComboBox>(form, "ClashSource1");
            var source2 = Find<ComboBox>(form, "ClashSource2");
            var apply = Find<Button>(form, "ClashApplySources");
            var assumeHard = Find<CheckBox>(form, "ClashAssumeHard");
            var details = Find<TextBox>(form, "ClashDetails");
            var focus = Find<Button>(form, "ClashFocus");
            var margin = Find<NumericUpDown>(form, "ClashMargin");
            var isolate = Find<CheckBox>(form, "ClashIsolate");
            var cancel = Find<Button>(form, "ClashCancel");
            var browse = Find<Button>(form, "ClashBrowse");
            grid.DataError += (sender,e) => errors.Add("Grid data error: " + e.Exception.Message);
            Require(form.Icon != null, "Branded window icon missing", errors);
            Require(!assumeHard.Checked && !form.ReadCheckOptions().AssumeHardForUnknown, "Unknown test defaults to hard clash without opt-in", errors);
            Require(!export.Enabled && !refreshVisible.Enabled, "Empty report enables export or refresh", errors);
            Require(!Descendants(form).Any(c => c is WebBrowser), "HTML is hosted in an executable browser", errors);
            foreach (var button in new[] { browse, export, refreshVisible, cancel, close }) { Visible(button, errors); ButtonTextFits(button, errors); }
            CheckDropGuards(form, errors);

            var report = Fixture();
            form.SetSources(new[] {
                new ClashModelSource { Key = "host", DisplayName = "Current model — MEP coordination", DocumentTitle = "MEP coordination" },
                new ClashModelSource { Key = "link:5000000001", DisplayName = "Architecture [5000000001]", DocumentTitle = "Architecture", LinkInstanceId = 5000000001L }
            });
            form.SetReport(report); Pump(form);
            Require(grid.Rows.Count == 4 && export.Enabled, "Imported report is not displayed/exportable", errors);
            Require(form.VisibleRows.Count == 4 && form.Report.Rows.Count == 4, "Canonical or visible import row count incorrect", errors);
            Require(source1.Items.Count == 3 && source2.Items.Count == 3, "Host/link source choices or Auto choice missing", errors);
            Require(source1.SelectedIndex == 0 && source2.SelectedIndex == 0, "Initial source resolution does not default to Auto", errors);
            Require(grid.Columns["ImportedStatus"] != null && grid.Columns["State"] != null, "Imported status and checked status conflated", errors);
            Require(Convert.ToString(Row(grid, "solved").Cells["Id1"].Value).Contains("9000000001"), "Element identity narrowed to 32 bits", errors);
            Require(Convert.ToString(Row(grid, "review").Cells["ImportedStatus"].Value) == "Approved", "Original status was overwritten by calculated status", errors);
            CheckStatusCells(grid, errors); GridTextFits(grid, errors);
            Save(form, screenshots, test.Name + "_results");

            int exports = 0, refreshes = 0, focuses = 0, cancelled = 0, sourceChanges = 0;
            ClashReport exported = null; string exportedFilter = null;
            IList<ClashRecord> refreshed = null; ClashCheckOptions checkOptions = null;
            ClashRecord focused = null; double focusedMargin = 0; bool focusedIsolate = false;
            form.ExportRequested += (rows,filter) => { exports++; exported = rows; exportedFilter = filter; };
            form.RefreshRequested += (rows,options) => { refreshes++; refreshed = rows; checkOptions = options; };
            form.FocusRequested += (row,metres,temporary) => { focuses++; focused = row; focusedMargin = metres; focusedIsolate = temporary; };
            form.CancelRequested += () => cancelled++;
            form.SourcesChanged += () => sourceChanges++;

            Select(grid, "solved"); Pump(form); export.PerformClick();
            Require(exports == 1 && exported != null && exported.Rows.Count == 4, "Export silently limits output to selected rows", errors);
            Require(exported != null && exported.Rows.Any(r => r.State == ClashState.Unchecked) && exported.Rows.Any(r => r.State == ClashState.NeedsReview), "Export excludes unchecked or review rows", errors);
            Require(exported != null && exported.SourceSha256 == report.SourceSha256 && exported.SourcePath == report.SourcePath && exported.ImportedAt == report.ImportedAt,
                "Visible export loses import provenance", errors);
            Require(exportedFilter != null && exportedFilter.IndexOf("selection", StringComparison.OrdinalIgnoreCase) >= 0, "Export scope does not explain selection behavior", errors);
            Require(details.Text.Contains("9000000001") && details.Text.Contains("Ducts"), "Selected pair detail omits ID/category", errors);
            tabs.SelectedIndex = 1; Pump(form);
            refreshSelected.PerformClick();
            Require(refreshes == 1 && refreshed.Count == 1 && refreshed[0].Key == "solved", "Refresh selected includes another row", errors);
            tabs.SelectedIndex = 0; Pump(form);

            foreach (ClashState state in Enum.GetValues(typeof(ClashState)))
            {
                status.SelectedIndex = (int)state + 1; Pump(form);
                Require(form.VisibleRows.Count == 1 && form.VisibleRows[0].State == state,
                    "Status filter selects the wrong current state: " + state, errors);
            }
            status.SelectedIndex = 4; Pump(form);
            Require(grid.Rows.Count == 1 && form.VisibleRows[0].Key == "review", "Needs review filter incorrect", errors);
            export.PerformClick();
            Require(exports == 2 && exported.Rows.Count == 1 && exported.Rows[0].Key == "review", "Filtered export does not follow visible review rows", errors);
            status.SelectedIndex = 0; testFilter.SelectedItem = "HVAC vs Structure"; Pump(form);
            Require(grid.Rows.Count == 2, "Test filter incorrect", errors);
            refreshVisible.PerformClick();
            Require(refreshes == 2 && refreshed.Count == 2 && refreshed.All(r => r.TestName == "HVAC vs Structure"), "Refresh visible ignores filters", errors);
            testFilter.SelectedIndex = 0; search.Text = "غرفة"; Pump(form);
            Require(grid.Rows.Count == 1 && form.VisibleRows[0].Key == "review", "Unicode clash search incorrect", errors);
            search.Text = "no-such-clash"; Pump(form);
            Require(grid.Rows.Count == 0 && !export.Enabled && !refreshVisible.Enabled, "Empty filter permits export/refresh", errors);
            search.Clear(); Pump(form);
            Require(form.Report.Rows.Count == 4, "Filtering mutates imported report", errors);

            Select(grid, "solved"); tabs.SelectedIndex = 1; Pump(form);
            foreach (var reference in new[] { report.Rows[0].Element1, report.Rows[0].Element2 })
            {
                reference.ResolvedSourceKey = "old-source"; reference.ResolvedSourceName = "Old source";
                reference.ResolvedElementId = 7000000001L; reference.ResolvedUniqueId = "old-unique-id";
                reference.ResolvedCategory = "Old category"; reference.ResolvedName = "Old name"; reference.ResolutionNote = "Old resolution";
            }
            source1.SelectedIndex = 2; source2.SelectedIndex = 1; apply.PerformClick(); Pump(form);
            Require(sourceChanges == 1, "Applying source mappings does not notify controller", errors);
            Require(report.Rows[0].Element1.SourceOverrideKey == "link:5000000001" && report.Rows[0].Element2.SourceOverrideKey == "host", "Selected pair source mapping was not applied", errors);
            Require(report.Rows[0].State == ClashState.Unchecked && !report.Rows[0].CheckedAt.HasValue, "Changing source mapping retains stale green result", errors);
            foreach (var reference in new[] { report.Rows[0].Element1, report.Rows[0].Element2 })
                Require(reference.ResolvedSourceKey == "" && reference.ResolvedSourceName == "" && !reference.ResolvedElementId.HasValue &&
                    reference.ResolvedUniqueId == "" && reference.ResolvedCategory == "" && reference.ResolvedName == "" && reference.ResolutionNote == "",
                    "Changing source mapping retains a resolved identity from the previous source", errors);
            Require(report.Rows[1].Element1.SourceOverrideKey == "", "Source mapping silently changes unselected rows", errors);
            source1.SelectedIndex = 0; source2.SelectedIndex = 0; apply.PerformClick(); Pump(form);
            Require(report.Rows[0].Element1.SourceOverrideKey == "" && report.Rows[0].Element2.SourceOverrideKey == "", "Auto does not clear explicit source mappings", errors);
            margin.Value = Math.Min(margin.Maximum, Math.Max(margin.Minimum, 1.25M)); isolate.Checked = true;
            focus.PerformClick();
            Require(focuses == 1 && focused != null && focused.Key == "solved" && Math.Abs(focusedMargin - (double)margin.Value) < .0001 && focusedIsolate,
                "3D focus event loses selected row, margin or isolate option", errors);
            var pairOptions = Find<Panel>(form, "ClashPairOptions");
            foreach (var input in new Control[] { source1, source2, assumeHard, margin, isolate })
            {
                Reachable(pairOptions, input, form); Visible(input, errors);
            }
            foreach (var button in new[] { apply, refreshSelected, focus })
            {
                Reachable(pairOptions, button, form); Visible(button, errors); ButtonTextFits(button, errors);
            }
            Save(form, screenshots, test.Name + "_details");

            assumeHard.Checked = true; tabs.SelectedIndex = 0; Pump(form); refreshVisible.PerformClick();
            Require(checkOptions != null && checkOptions.AssumeHardForUnknown, "Explicit hard-clash assumption is not passed to refresh", errors);
            Require(report.Rows.Single(r => r.Key == "review").TestKind == ClashTestKind.Clearance, "Hard-clash opt-in overwrites report clearance criteria", errors);
            assumeHard.Checked = false; Pump(form);
            report.Rows[0].State = ClashState.Solved; report.Rows[0].CheckedAt = DateTime.Now; report.Rows[0].CheckBasis = "Known stale test geometry";
            form.RefreshRows(); form.InvalidateResults("The model geometry changed; refresh required."); Pump(form);
            Require(report.Rows.All(r => r.State == ClashState.Unchecked && !r.CheckedAt.HasValue && r.CheckBasis == ""), "Model change leaves solved status/time/basis available", errors);
            Require(report.Rows.All(r => r.CheckNote.Contains("geometry changed")), "Model change drops stale-status reason", errors);
            export.PerformClick();
            Require(exported.Rows.Count == 4 && exported.Rows.All(r => r.State == ClashState.Unchecked), "Stale export presents old green results", errors);
            Require(export.Enabled, "Unchecked report cannot be exported for review", errors);

            form.SetBusy(true, "Checking clashes", 1, 4); Pump(form);
            Require(!refreshVisible.Enabled && !refreshSelected.Enabled && !export.Enabled && cancel.Enabled, "Pending check permits competing action or blocks cancellation", errors);
            cancel.PerformClick(); Require(cancelled == 1, "Cancel event not dispatched", errors);
            foreach (var button in new[] { export, refreshVisible, close }) Visible(button, errors);
            form.SetBusy(false, "Check cancelled."); Pump(form);
            Require(export.Enabled && refreshVisible.Enabled, "Idle actions not restored after check", errors);
            form.ShowStatus(string.Join(" ", Enumerable.Repeat("A long report filename and status detail.", 80))); Pump(form);
            var statusLabel = Find<Label>(form, "ClashStatus");
            Require(statusLabel.Height <= statusLabel.Font.Height * 3 + 12, "Long status expands fixed footer", errors);
            foreach (TabPage tab in tabs.TabPages)
            {
                tabs.SelectedTab = tab; Pump(form);
                foreach (var button in new[] { browse, export, refreshVisible, cancel, close }) { Visible(button, errors); ButtonTextFits(button, errors); }
                Require(tabs.ClientRectangle.Contains(tabs.GetTabRect(tabs.TabPages.IndexOf(tab))), "Tab header inaccessible: " + tab.Text, errors);
            }
            tabs.SelectedIndex = 0; Pump(form);
            foreach (var input in new Control[] { grid, search, status, testFilter }) Visible(input, errors);
            GridTextFits(grid, errors);
            int usableHeight = grid.ColumnHeadersHeight + grid.Rows.Cast<DataGridViewRow>().Take(2).Sum(r => r.Height) + SystemInformation.HorizontalScrollBarHeight;
            Require(grid.Height >= usableHeight && grid.Width > 500, "Result grid cannot display its header and two rows: " + grid.Height + "px / " + usableHeight + "px needed", errors);
            Require(grid.ScrollBars == ScrollBars.Both && grid.ColumnHeadersDefaultCellStyle.WrapMode == DataGridViewTriState.False, "Grid lacks horizontal scrolling or uses wrapped headers", errors);
            Save(form, screenshots, test.Name + "_final");
        }
        CheckMapping(test, screenshots, errors);
    }

    private static void CheckMapping(Case test, string screenshots, List<string> errors)
    {
        var fields = typeof(ClashColumnMapping).GetProperties().Where(property => property.Name.EndsWith("Column", StringComparison.Ordinal)).ToArray();
        var tables = new[] {
            new ClashTablePreview { TableIndex = 2, Headers = fields.Select(property => property.Name).ToList(),
                PreviewRows = new List<List<string>> { fields.Select(property => "First " + property.Name).ToList() }, DataRowCount = 1 },
            new ClashTablePreview { TableIndex = 7, Headers = fields.Select(property => "Other " + property.Name).ToList(),
                PreviewRows = new List<List<string>> { fields.Select(property => "Second " + property.Name).ToList() }, DataRowCount = 1 }
        };
        using (var form = new ClashMappingForm(tables))
        {
            ShowScaled(form, test);
            var table = Find<ComboBox>(form, "ClashMappingTable");
            var headers = Find<CheckBox>(form, "ClashMappingHeaders");
            var preview = Find<DataGridView>(form, "ClashMappingPreview");
            var viewport = Find<Panel>(form, "ClashMappingOptions");
            var apply = Find<Button>(form, "ClashMappingApply");
            var cancel = Find<Button>(form, "ClashMappingCancel");
            var error = Find<Label>(form, "ClashMappingError");
            Require(fields.Length == 18 && fields.All(property => Descendants(form).Any(control => control.Name == "ClashMapping" + property.Name)),
                "Mapping dialog omits a supported column field", errors);
            Require(!Descendants(form).Any(control => control is WebBrowser), "Mapping preview hosts executable HTML", errors);
            table.SelectedIndex = 1; Pump(form);
            Require(preview.Columns.Count == fields.Length && Convert.ToString(preview.Rows[0].Cells[0].Value).StartsWith("Second ", StringComparison.Ordinal),
                "Mapping table selection keeps another table's preview", errors);
            apply.PerformClick(); Pump(form);
            Require(form.Mapping == null && error.Text.Contains("each element"), "Missing mapped identifiers are accepted", errors);
            var firstId = Find<ComboBox>(form, "ClashMappingId1Column");
            var secondId = Find<ComboBox>(form, "ClashMappingId2Column");
            firstId.SelectedIndex = 1; secondId.SelectedIndex = 1; apply.PerformClick(); Pump(form);
            Require(form.Mapping == null && error.Text.Contains("different"), "The same mapped identifier column is accepted for both elements", errors);
            for (int i = 0; i < fields.Length; i++) Find<ComboBox>(form, "ClashMapping" + fields[i].Name).SelectedIndex = i + 1;
            headers.Checked = false; Pump(form);
            Require(preview.Rows.Count == 2 && Convert.ToString(preview.Rows[0].Cells[0].Value).StartsWith("Other ", StringComparison.Ordinal),
                "Headerless mapping preview hides the first data row", errors);
            Require(preview.Columns[0].HeaderText == "Column 1", "Headerless preview still treats data as a column heading", errors);
            foreach (var input in new Control[] { firstId, Find<ComboBox>(form, "ClashMappingDescriptionColumn") })
            {
                Reachable(viewport, input, form); Visible(input, errors);
            }
            foreach (var button in new[] { apply, cancel }) { Visible(button, errors); ButtonTextFits(button, errors); }
            Visible(table, errors); Visible(headers, errors); Visible(preview, errors); GridTextFits(preview, errors);
            Save(form, screenshots, test.Name + "_mapping");
            apply.PerformClick();
            Require(form.Mapping != null && form.Mapping.TableIndex == 7 && !form.Mapping.HasHeaderRow, "Mapping loses selected table or header setting", errors);
            if (form.Mapping != null)
                for (int i = 0; i < fields.Length; i++) Require((int)fields[i].GetValue(form.Mapping, null) == i, "Mapping loses selected " + fields[i].Name, errors);
        }
        using (var form = new ClashMappingForm(tables))
        {
            ShowScaled(form, test);
            Find<ComboBox>(form, "ClashMappingUniqueId1Column").SelectedIndex = 1;
            Find<ComboBox>(form, "ClashMappingUniqueId2Column").SelectedIndex = 2;
            Find<Button>(form, "ClashMappingApply").PerformClick();
            Require(form.Mapping != null && form.Mapping.Id1Column == -1 && form.Mapping.Id2Column == -1 &&
                form.Mapping.UniqueId1Column == 0 && form.Mapping.UniqueId2Column == 1, "Unique ID alternatives require numeric ID mappings", errors);
        }
    }

    private static void CheckDropGuards(ClashManagerForm form, List<string> errors)
    {
        string folder = Path.Combine(Path.GetTempPath(), "KAMEP-Clash-UI-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(folder);
        try
        {
            string valid = Path.Combine(folder, "report.HTML"), invalid = Path.Combine(folder, "report.txt"), large = Path.Combine(folder, "large.htm");
            File.WriteAllText(valid, "<table><tr><td>Plain preview only</td></tr></table>"); File.WriteAllText(invalid, "No HTML");
            using (var stream = File.Create(large)) stream.SetLength(16L * 1024 * 1024 + 1);
            string path;
            Require(ClashManagerForm.IsSupportedDrop(DropData(valid), out path) && path == valid, "One local HTML file is rejected", errors);
            Require(!ClashManagerForm.IsSupportedDrop(DropData(invalid), out path), "Non-HTML file is accepted", errors);
            Require(!ClashManagerForm.IsSupportedDrop(DropData(valid, valid), out path), "Multiple dropped files are accepted", errors);
            Require(!ClashManagerForm.IsSupportedDrop(DropData(large), out path), "HTML above 16 MiB is accepted", errors);
            Require(!ClashManagerForm.IsSupportedDrop(DropData(folder), out path), "Directory drop is accepted", errors);
            Require(!ClashManagerForm.IsSupportedDrop(DropData(Path.Combine(folder, "missing.htm")), out path), "Missing file drop is accepted", errors);
            Require(!ClashManagerForm.IsSupportedDrop(new DataObject(DataFormats.Text, "https://example.invalid/report.html"), out path), "Remote text URL is accepted as local report", errors);
            int imports = 0; string importedPath = null;
            form.ImportRequested += value => { imports++; importedPath = value; };
            Require(InvokeDrag(form, "OnDragEnter", DropData(valid)).Effect == DragDropEffects.Copy, "Valid HTML drag does not show copy affordance", errors);
            Require(InvokeDrag(form, "OnDragEnter", DropData(invalid)).Effect == DragDropEffects.None, "Invalid file drag shows copy affordance", errors);
            InvokeDrag(form, "OnDragDrop", DropData(valid));
            Require(imports == 1 && importedPath == valid, "Dropping a valid HTML file does not dispatch import", errors);
            InvokeDrag(form, "OnDragDrop", DropData(invalid));
            Require(imports == 1, "Rejected drag payload dispatches import", errors);
            form.SetBusy(true, "Checking a model batch.");
            Require(InvokeDrag(form, "OnDragEnter", DropData(valid)).Effect == DragDropEffects.None, "Busy model check accepts a competing drag", errors);
            InvokeDrag(form, "OnDragDrop", DropData(valid));
            Require(imports == 1, "Busy model check dispatches a competing import", errors);
            form.SetBusy(false, "Ready.");
        }
        finally { Directory.Delete(folder, true); }
    }
    private static DataObject DropData(params string[] files) { return new DataObject(DataFormats.FileDrop, files); }
    private static DragEventArgs InvokeDrag(Control control, string method, IDataObject data)
    {
        var args = new DragEventArgs(data, 0, 0, 0, DragDropEffects.Copy, DragDropEffects.None);
        typeof(Control).GetMethod(method, BindingFlags.Instance | BindingFlags.NonPublic).Invoke(control, new object[] { args });
        return args;
    }
    private static void CheckStatusCells(DataGridView grid, List<string> errors)
    {
        var colors = new List<Color>();
        foreach (var pair in new[] { new { Key = "solved", Text = "Solved" }, new { Key = "unsolved", Text = "Unsolved" }, new { Key = "review", Text = "review" }, new { Key = "unchecked", Text = "Unchecked" } })
        {
            var cell = Row(grid, pair.Key).Cells["State"];
            Require(Convert.ToString(cell.Value).IndexOf(pair.Text, StringComparison.OrdinalIgnoreCase) >= 0, "Status has no readable label for " + pair.Key, errors);
            colors.Add(cell.InheritedStyle.ForeColor);
        }
        Require(colors.Select(c => c.ToArgb()).Distinct().Count() == 4, "Four checked status labels do not have distinct color indicators", errors);
        Require(colors[0].G > colors[0].R && colors[1].R > colors[1].G && colors[2].R > colors[2].B, "Solved/unsolved/review indicators do not use green/red/amber semantics", errors);
    }

    private static ClashReport Fixture()
    {
        var report = new ClashReport { Title = "ILLUSTRATIVE Clash Manager UI fixture", SourcePath = "C:\\Coordination\\Coordination report.html", SourceSha256 = new string('a',64), Producer = "UI fixture", ImportedAt = new DateTime(2026,10,28,9,30,0) };
        var rows = new[] {
            new { Key = "solved", Name = "Duct crossing beam", Test = "HVAC vs Structure", Kind = ClashTestKind.Hard, State = ClashState.Solved, Imported = "Active" },
            new { Key = "unsolved", Name = "Pipe crossing slab", Test = "HVAC vs Structure", Kind = ClashTestKind.Hard, State = ClashState.Unsolved, Imported = "New" },
            new { Key = "review", Name = "غرفة mechanical clearance", Test = "Maintenance clearance", Kind = ClashTestKind.Clearance, State = ClashState.NeedsReview, Imported = "Approved" },
            new { Key = "unchecked", Name = "Imported unresolved identity", Test = "Unknown criteria", Kind = ClashTestKind.Unknown, State = ClashState.Unchecked, Imported = "Resolved" }
        };
        for (int i=0;i<rows.Length;i++)
        {
            var row = rows[i];
            report.Rows.Add(new ClashRecord { Key = row.Key, Name = row.Name, TestName = row.Test, TestKind = row.Kind, State = row.State, ImportedStatus = row.Imported,
                CheckedAt = row.State == ClashState.Unchecked ? (DateTime?)null : new DateTime(2026,10,28,10,0,0), CheckNote = "Illustrative detached result; no Revit geometry has been checked.", CheckBasis = row.State == ClashState.Unchecked ? "" : "UI fixture", DistanceText = "25 mm", AssignedTo = "Coordination team",
                Element1 = new ClashElementReference { ElementId = 9000000001L + i, UniqueId = "00000000-0000-0000-0000-000000000001-00000001", ReportedCategory = "Ducts", ReportedName = "Supply air duct", SourceHint = "MEP coordination.rvt" },
                Element2 = new ClashElementReference { ElementId = 8000000001L + i, UniqueId = "00000000-0000-0000-0000-000000000002-00000002", ReportedCategory = "Structural Framing", ReportedName = "Concrete beam", SourceHint = "Architecture.rvt" } });
        }
        report.Notes.Add("Simulated UI data only; actual Revit geometry and ExternalEvent execution are not exercised."); return report;
    }
    private static DataGridViewRow Row(DataGridView grid, string key) { return grid.Rows.Cast<DataGridViewRow>().Single(row => ((ClashRecord)row.Tag).Key == key); }
    private static void Select(DataGridView grid, string key) { var row = Row(grid, key); grid.ClearSelection(); grid.CurrentCell = row.Cells[0]; row.Selected = true; }
    private static void ShowScaled(Form form, Case test)
    {
        form.StartPosition = FormStartPosition.Manual; form.Location = new Point(10,10); form.Show(); Pump(form); form.AutoScaleMode = AutoScaleMode.None;
        var fonts = Descendants(form).Select(c => new FontInfo(c)).ToArray(); form.Scale(new SizeF(test.Scale,test.Scale));
        foreach (var item in fonts) item.Control.Font = new Font(item.Name,item.Size*test.Scale,item.Style,item.Unit);
        form.MinimumSize = Size.Empty; form.ClientSize = new Size(test.Width,test.Height); form.Location = new Point(10,10); Pump(form);
    }
    private static void Visible(Control control, List<string> errors)
    {
        var bounds = control.RectangleToScreen(control.ClientRectangle);
        Require(control.Visible && bounds.Width>0 && bounds.Height>0, control.Name+" hidden or empty", errors);
        for (Control ancestor=control.Parent;ancestor!=null;ancestor=ancestor.Parent)
            Require(ancestor.RectangleToScreen(ancestor.ClientRectangle).Contains(bounds),control.Name+" clipped by "+ancestor.GetType().Name+" at "+bounds,errors);
    }
    private static void Reachable(Panel panel, Control input, Form form)
    {
        panel.ScrollControlIntoView(input); Pump(form);
        // Mono can overshoot nested controls after successive ScrollControlIntoView calls.
        // Move the actual scroll position, then still assert the complete on-screen bounds.
        for (int i = 0; i < 3; i++)
        {
            Rectangle bounds = panel.RectangleToClient(input.RectangleToScreen(input.ClientRectangle));
            int dx = bounds.Left < 0 ? bounds.Left : Math.Max(0, bounds.Right - panel.ClientSize.Width);
            int dy = bounds.Top < 0 ? bounds.Top : Math.Max(0, bounds.Bottom - panel.ClientSize.Height);
            if (dx == 0 && dy == 0) return;
            panel.AutoScrollPosition = new Point(Math.Max(0, -panel.AutoScrollPosition.X + dx), Math.Max(0, -panel.AutoScrollPosition.Y + dy)); Pump(form);
        }
    }
    private static void ButtonTextFits(Button button, List<string> errors)
    {
        Size preferred = button.GetPreferredSize(Size.Empty);
        Require(button.Height >= preferred.Height && button.Width >= preferred.Width,
            button.Name + " cannot fit native button text: " + button.Size + " / preferred " + preferred, errors);
    }
    private static void GridTextFits(DataGridView grid, List<string> errors)
    {
        int textHeight = TextRenderer.MeasureText("Clash 001", grid.Font, Size.Empty, TextFormatFlags.SingleLine).Height;
        Require(Math.Abs(grid.DefaultCellStyle.Font.SizeInPoints - grid.Font.SizeInPoints) < .1F && Math.Abs(grid.ColumnHeadersDefaultCellStyle.Font.SizeInPoints - grid.Font.SizeInPoints) < .1F,
            "Cell/header text did not follow scaled grid font", errors);
        foreach (DataGridViewRow row in grid.Rows)
            Require(row.Height >= textHeight + row.Cells[0].InheritedStyle.Padding.Vertical + 6, "Clash row text clipped at scaled font height", errors);
        Require(grid.ColumnHeadersHeight >= textHeight + grid.ColumnHeadersDefaultCellStyle.Padding.Vertical + 6, "Clash grid header text clipped at scaled font height", errors);
    }
    private static void Save(Form form,string folder,string name) { if(folder==null)return; form.Refresh(); Application.DoEvents(); using(var image=new Bitmap(form.Width,form.Height)) { using(var graphics=Graphics.FromImage(image))graphics.CopyFromScreen(form.Location,Point.Empty,form.Size); image.Save(Path.Combine(folder,name+".png")); } }
    private static void Pump(Control control) { for(int i=0;i<2;i++) { foreach(var child in Descendants(control).Reverse())child.PerformLayout(); Application.DoEvents(); } }
    private static IEnumerable<Control> Descendants(Control root) { yield return root; foreach(Control child in root.Controls)foreach(Control nested in Descendants(child))yield return nested; }
    private static T Find<T>(Control root,string name) where T:Control { return Descendants(root).OfType<T>().Single(c=>c.Name==name); }
    private static string Arg(string[] args,string prefix) { var found=args.FirstOrDefault(s=>s.StartsWith(prefix,StringComparison.Ordinal)); return found==null?null:found.Substring(prefix.Length); }
    private static void Require(bool condition,string reason,List<string> errors) { if(!condition)errors.Add(reason); }
    private sealed class Case { public int Width,Height; public float Scale; public Case(int width,int height,float scale){Width=width;Height=height;Scale=scale;} public string Name {get{return Width+"x"+Height+"_"+(int)(Scale*100);}} }
    private sealed class FontInfo { public Control Control;public string Name;public float Size;public FontStyle Style;public GraphicsUnit Unit;public FontInfo(Control control){Control=control;Name=control.Font.FontFamily.Name;Size=control.Font.Size;Style=control.Font.Style;Unit=control.Font.Unit;} }
}
