using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using PipeTakeoff.Revit;

internal static class Program
{
    private sealed class Case
    {
        internal int W,H; internal float Scale;
        internal Case(int w,int h,float scale) { W=w;H=h;Scale=scale; }
        internal string Name { get { return W+"x"+H+"_"+(int)(Scale*100); } }
    }
    [STAThread]
    private static int Main(string[] args)
    {
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        string only=Arg(args,"--case="), screenshots=Arg(args,"--screenshots=");
        if(screenshots!=null)Directory.CreateDirectory(screenshots);
        int passed=0,total=0;
        foreach(var test in new[]{new Case(1366,728,1),new Case(1280,680,1.5F),new Case(1280,680,2),new Case(1024,600,1),new Case(1024,600,1.5F),new Case(1024,600,2),new Case(876,571,1),new Case(876,571,1.5F),new Case(876,571,2)})
        {
            if(only!=null && only!=test.Name)continue;
            total++; var errors=new List<string>();
            try { Check(test,screenshots,errors); } catch(Exception ex){ errors.Add(ex.ToString()); }
            Console.WriteLine((errors.Count==0?"PASS ":"FAIL ")+test.Name);
            foreach(var error in errors.Distinct())Console.WriteLine("  "+error);
            if(errors.Count==0)passed++;
        }
        Console.WriteLine("RESULT: "+passed+"/"+total+" Sheet Parameters UI cases passed; "+(total-passed)+" failed.");
        Console.WriteLine("Actual linked production forms under Mono/Xvfb; simulated control/font scaling, not native Windows DPI or live Revit.");
        return total>0&&passed==total?0:1;
    }
    private static void Check(Case test,string screenshots,List<string> errors)
    {
        var snapshot=Fixture();
        using(var form=new SheetEditorForm(snapshot))
        {
            Find<DataGridView>(form,"SheetParameterGrid").DataError += (sender,e)=>errors.Add("Parameter grid data/formatting error: "+e.Exception.Message);
            ShowScaled(form,test);Save(form,screenshots,test.Name+"_initial");
            var sheets=Find<DataGridView>(form,"SheetListGrid"); var parameters=Find<DataGridView>(form,"SheetParameterGrid");
            var revisions=Find<DataGridView>(form,"SheetRevisionGrid"); var review=Find<DataGridView>(form,"SheetReviewGrid");
            var tabs=Find<TabControl>(form,"SheetEditorTabs"); var apply=Find<Button>(form,"SheetApplyButton");
            var cancel=Find<Button>(form,"SheetCancelButton");var reset=Find<Button>(form,"SheetResetButton");
            var search=Find<TextBox>(form,"SheetSearch");var parameterSearch=Find<TextBox>(form,"SheetParameterSearch");
            Require(form.Icon!=null,"Brand icon missing",errors);
            Require(tabs.TabCount==3,"Three editing/review tabs required",errors);
            Require(!apply.Enabled,"Empty drafts allow Apply",errors);
            Require(ReferenceEquals(form.CancelButton,cancel),"Escape not bound to Cancel",errors);
            Require(sheets.Rows.Count==3,"Not all fixture sheets listed",errors);
            Require(ParamRow(parameters,"current-revision").Cells[2].ReadOnly,"Computed revision is editable",errors);
            Require(Convert.ToString(ParamRow(parameters,"name").Cells[0].FormattedValue)=="Sheet Name","Parameter name is not rendered",errors);
            Require(Convert.ToString(ParamRow(parameters,"name").Cells[2].FormattedValue)=="Mechanical plan","Proposed text value is not rendered",errors);
            Require(ParamRow(parameters,"approved").Cells[2] is DataGridViewCheckBoxCell,"Yes/No lacks checkbox",errors);
            Require(Convert.ToString(ParamRow(parameters,"approved").Cells[3].Value).Contains("YesNo"),"Yes/No row lost its type/group label",errors);
            ParamRow(parameters,"approved").Cells[2].Value=CheckState.Checked;Pump(form);
            Require(snapshot.Sheets[0].Parameters.First(p=>p.Key=="approved").Value=="Yes","Choosing Yes does not stage the boolean value",errors);
            Require(Convert.ToString(ParamRow(parameters,"custom-note-1").Cells[0].Value)!=Convert.ToString(ParamRow(parameters,"custom-note-2").Cells[0].Value),"Same-name parameters lack distinguishable identities",errors);
            Require(ParamRow(parameters,"custom-note-1").Cells[0].ToolTipText.Contains("custom-note-1"),"Parameter tooltip omits exact identity",errors);
            Edit(parameters,"custom-note-1","First only",form);
            Require(snapshot.Sheets[0].Parameters.First(p=>p.Key=="custom-note-2").Value=="Second note","Duplicate-name edit changed wrong key",errors);
            Edit(parameters,"name","Mechanical — تعديل اللوحة",form);
            Require(snapshot.Sheets[0].Parameters[1].Value=="Mechanical — تعديل اللوحة","Inline text edit not staged",errors);
            Require(snapshot.Sheets[0].Name=="Mechanical plan"&&snapshot.Sheets[0].Parameters[1].OriginalValue=="Mechanical plan","Draft changed original metadata",errors);
            Require(apply.Enabled,"Valid staged edit cannot apply",errors);
            sheets.CurrentCell=sheets.Rows[1].Cells[1];Pump(form);
            sheets.CurrentCell=sheets.Rows[0].Cells[1];Pump(form);
            Require(Convert.ToString(ParamRow(parameters,"name").Cells[2].Value)=="Mechanical — تعديل اللوحة","Switching sheets loses draft",errors);
            parameterSearch.Text="Current Revision";Pump(form);
            Require(parameters.Rows.Count==1,"Parameter search does not narrow rows",errors);
            parameterSearch.Text="";Pump(form);
            var editable=Find<CheckBox>(form,"SheetEditableOnly");editable.Checked=true;Pump(form);
            Require(parameters.Rows.Cast<DataGridViewRow>().All(r=>!r.Cells[2].ReadOnly),"Editable filter retains read-only row",errors);
            editable.Checked=false;Pump(form);
            Find<Button>(form,"SheetCheckVisible").PerformClick();Pump(form);
            Require(sheets.Rows.Cast<DataGridViewRow>().All(r=>Convert.ToBoolean(r.Cells[0].Value)),"Check visible did not check all",errors);
            search.Text="A102";Pump(form);search.Text="";Pump(form);
            Require(sheets.Rows.Cast<DataGridViewRow>().All(r=>Convert.ToBoolean(r.Cells[0].Value)),"Search loses checked sheets",errors);
            sheets.CurrentCell=sheets.Rows[0].Cells[1];Pump(form);
            parameters.CurrentCell=ParamRow(parameters,"drawn").Cells[2];Pump(form);
            TestBatchModal(form,"KA",errors);
            Require(snapshot.Sheets[0].Parameters.First(p=>p.Key=="drawn").Value=="KA"&&snapshot.Sheets[1].Parameters.First(p=>p.Key=="drawn").Value=="KA","Batch value did not stage eligible checked sheets",errors);
            Require(snapshot.Sheets[2].Parameters.First(p=>p.Key=="drawn").Value=="Initial","Batch value changed read-only parameter",errors);
            Edit(parameters,"number","A102",form);
            Require(!apply.Enabled,"Duplicate sheet number allows Apply",errors);
            tabs.SelectedIndex=2;Pump(form);
            Require(Find<TextBox>(form,"SheetValidationErrors").Visible,"Duplicate numbers have no visible validation",errors);
            Require(review.Rows.Count>=3,"Review omits pending drafts",errors);
            tabs.SelectedIndex=0;Pump(form);Edit(parameters,"number","A201",form);
            Require(apply.Enabled,"Corrected sheet number remains blocked",errors);
            tabs.SelectedIndex=1;Pump(form);
            var cloud=RevisionRow(revisions,12);var issued=RevisionRow(revisions,13);
            Require(cloud.Cells[0].ReadOnly&&Convert.ToBoolean(cloud.Cells[0].Value),"Cloud revision not visibly required/locked",errors);
            Require(issued.Cells[0].ReadOnly,"Issued revision editable",errors);
            revisions.CurrentCell=RevisionRow(revisions,11).Cells[3];Pump(form);
            Find<Button>(form,"SheetBatchRevisionAdd").PerformClick();Pump(form);
            Require(snapshot.Sheets[0].AdditionalRevisionIds.Contains(11)&&snapshot.Sheets[2].AdditionalRevisionIds.Contains(11),"Revision batch does not add eligible sheets",errors);
            Require(!snapshot.Sheets[1].AdditionalRevisionIds.Contains(11),"Revision batch changed cloud-required assignment",errors);
            Find<Button>(form,"SheetBatchRevisionRemove").PerformClick();Pump(form);
            Require(!snapshot.Sheets[0].AdditionalRevisionIds.Contains(11)&&!snapshot.Sheets[2].AdditionalRevisionIds.Contains(11),"Revision batch removal did not stage",errors);
            RevisionRow(revisions,11).Cells[0].Value=true;Pump(form);
            Require(snapshot.Sheets[0].AdditionalRevisionIds.Contains(11),"Individual revision checkbox not staged",errors);
            for(int t=0;t<tabs.TabCount;t++)
            {
                tabs.SelectedIndex=t;Pump(form);
                Visible(apply,errors);Visible(cancel,errors);Visible(reset,errors);
                Reachable(sheets,form,errors);
                var grid=t==0?parameters:t==1?revisions:review;
                Reachable(grid,form,errors);
                Require(grid.Height>=Math.Min(95,grid.ColumnHeadersHeight+grid.Font.Height+8),tabs.TabPages[t].Text+": grid too short to use ("+grid.Height+")",errors);
                foreach(var button in Descendants(tabs.TabPages[t]).OfType<Button>())Reachable(button,form,errors);
                ResetScroll(tabs.TabPages[t]);Pump(form);
                Save(form,screenshots,test.Name+"_tab"+(t+1));
            }
            tabs.SelectedIndex=0;Pump(form);Find<Button>(form,"SheetClearChecks").PerformClick();Pump(form);
            Require(snapshot.Sheets.Any(s=>s.Changed),"Clearing batch checks discarded staged edits",errors);
            reset.PerformClick();Pump(form);
            Require(snapshot.Sheets.All(s=>!s.Changed)&&!apply.Enabled&&review.Rows.Count==0,"Reset does not restore all drafts",errors);
            Edit(parameters,"name","Final reviewed name",form);
            tabs.SelectedIndex=2;Pump(form);Save(form,screenshots,test.Name+"_review");
            apply.PerformClick();Pump(form);
            Require(form.DialogResult==DialogResult.OK,"Valid Apply does not accept staged snapshot",errors);
        }
        using(var batch=new SheetBatchValueForm(snapshot.Sheets[0].Parameters.First(p=>p.Key=="drawn"),snapshot,new long[]{1,2,3}))
        {
            ShowScaled(batch,new Case(Math.Min(700,test.W),Math.Min(480,test.H),test.Scale));
            Visible(Find<Button>(batch,"SheetBatchStage"),errors);Visible(Find<Button>(batch,"SheetBatchCancel"),errors);
            Reachable(Find<TextBox>(batch,"SheetBatchText"),batch,errors);
            Require(Find<Label>(batch,"SheetBatchSummary").Text.Contains("2 eligible"),"Batch eligible counts incorrect",errors);
            Require(Find<TextBox>(batch,"SheetBatchSkippedReasons").Text.Contains("read-only"),"Batch skips lack reasons",errors);
            Save(batch,screenshots,test.Name+"_batch");batch.Close();
        }
    }
    private static void TestBatchModal(Form owner,string value,List<string> errors)
    {
        bool seen=false;var timer=new Timer{Interval=30};int ticks=0;
        timer.Tick+=delegate{
            ticks++;var modal=Application.OpenForms.Cast<Form>().OfType<SheetBatchValueForm>().FirstOrDefault();
            if(modal!=null){seen=true;Find<TextBox>(modal,"SheetBatchText").Text=value;Find<Button>(modal,"SheetBatchStage").PerformClick();timer.Stop();}
            if(ticks>100){timer.Stop();errors.Add("Batch value dialog never appeared");}
        };
        try{timer.Start();Find<Button>(owner,"SheetBatchParameter").PerformClick();}finally{timer.Stop();timer.Dispose();}
        Require(seen,"Batch button did not open value dialog",errors);Pump(owner);
    }
    private static void Edit(DataGridView grid,string key,string text,Form form)
    {
        grid.CurrentCell=ParamRow(grid,key).Cells[2];grid.BeginEdit(true);Pump(form);
        var editor=grid.EditingControl as TextBox;
        if(editor==null)throw new Exception("No text edit control for "+key);
        editor.Text=text;grid.EndEdit();Pump(form);
    }
    private static DataGridViewRow ParamRow(DataGridView grid,string key){return grid.Rows.Cast<DataGridViewRow>().Single(r=>((SheetEditorParameter)r.Tag).Key==key);}
    private static DataGridViewRow RevisionRow(DataGridView grid,long id){return grid.Rows.Cast<DataGridViewRow>().Single(r=>((SheetEditorRevision)r.Tag).Id==id);}
    private static SheetEditorSnapshot Fixture()
    {
        var snapshot=new SheetEditorSnapshot{ProjectTitle="MEP Coordination — مشروع اختبار"};
        snapshot.Revisions.AddRange(new[]{new SheetEditorRevision{Id=11,Sequence=1,Description="Design coordination",Date="2026-10-20",Number="A"},new SheetEditorRevision{Id=12,Sequence=2,Description="Cloud-required update",Date="2026-10-21",Number="B"},new SheetEditorRevision{Id=13,Sequence=3,Description="Issued for construction",Date="2026-10-22",Number="C",Issued=true}});
        for(int i=0;i<3;i++)
        {
            string name=i==0?"Mechanical plan":i==1?"Electrical plan":"Plumbing — مخطط صحي";
            var sheet=new SheetEditorSheet{Id=i+1,UniqueId="sheet-"+i,Number="A10"+(i+1),Name=name,IsPlaceholder=i==2};
            sheet.Parameters.Add(P("number","Sheet Number",sheet.Number,SheetParameterKind.Text));sheet.Parameters[0].IsSheetNumber=true;
            sheet.Parameters.Add(P("name","Sheet Name",name,SheetParameterKind.Text));sheet.Parameters[1].IsSheetName=true;
            sheet.Parameters.Add(P("drawn","Drawn By","Initial",SheetParameterKind.Text));
            if(i==2){sheet.Parameters[2].IsReadOnly=true;sheet.Parameters[2].ReadOnlyReason="Parameter is read-only in this sheet.";}
            sheet.Parameters.Add(P("approved","Approved for issue","No",SheetParameterKind.YesNo));
            sheet.Parameters.Add(P("count","Copies","2",SheetParameterKind.Integer));
            sheet.Parameters.Add(P("dimension","Coordination margin","20 mm",SheetParameterKind.Number));
            sheet.Parameters.Add(P("custom-note-1","Coordination note","First note",SheetParameterKind.Text));
            sheet.Parameters.Add(P("custom-note-2","Coordination note","Second note",SheetParameterKind.Text));
            for(int p=0;p<25;p++)sheet.Parameters.Add(P("extra-"+p,"Shared field "+p,new string('L',180)+" — قيمة طويلة",SheetParameterKind.Text));
            var current=P("current-revision","Current Revision","B",SheetParameterKind.Text);current.IsReadOnly=true;current.ReadOnlyReason="Computed by Revit from sheet revision membership.";sheet.Parameters.Add(current);
            sheet.CloudRevisionIds.Add(i==1?11:12);sheet.OriginalAllRevisionIds.UnionWith(sheet.CloudRevisionIds);
            sheet.RevisionNumbers[12]="B";
            snapshot.Sheets.Add(sheet);
        }
        return snapshot;
    }
    private static SheetEditorParameter P(string key,string name,string value,SheetParameterKind kind){return new SheetEditorParameter{Key=key,Name=name,OriginalValue=value,Value=value,Kind=kind,Group="Identity Data",UnitHint=kind==SheetParameterKind.Number?"Use project units, for example 20 mm.":null};}
    private static void ShowScaled(Form form,Case test)
    {
        form.Show();Pump(form);form.AutoScaleMode=AutoScaleMode.None;
        var fonts=Descendants(form).Select(c=>new{Control=c,Family=c.Font.FontFamily,Size=c.Font.Size,Style=c.Font.Style,Unit=c.Font.Unit}).ToArray();
        form.Scale(new SizeF(test.Scale,test.Scale));foreach(var f in fonts)f.Control.Font=new Font(f.Family,f.Size*test.Scale,f.Style,f.Unit);
        form.MinimumSize=Size.Empty;form.ClientSize=new Size(test.W,test.H);form.Location=new Point(20,20);Pump(form);
    }
    private static void Visible(Control c,List<string> errors)
    {
        if(!c.Visible||c.Width<=0||c.Height<=0){errors.Add(c.Name+": not visible");return;}
        var box=c.RectangleToScreen(c.ClientRectangle);
        for(Control p=c.Parent;p!=null;p=p.Parent)
        {
            if(!p.RectangleToScreen(p.ClientRectangle).Contains(box)){errors.Add(c.Name+": clipped by "+p.Name+" ("+c.Bounds+")");break;}
        }
    }
    private static void Reachable(Control c,Form form,List<string> errors)
    {
        for(Control p=c.Parent;p!=null;p=p.Parent)
        {
            var scroll=p as ScrollableControl;if(scroll==null||!scroll.AutoScroll)continue;
            scroll.ScrollControlIntoView(c);Pump(form);
            // Mono may stop at a nested layout container; exercise the scrollbar itself.
            for(int attempt=0;attempt<3;attempt++)
            {
                var box=scroll.RectangleToClient(c.RectangleToScreen(c.ClientRectangle));
                int dx=box.Left<0?box.Left:Math.Max(0,box.Right-scroll.ClientSize.Width);
                int dy=box.Top<0?box.Top:Math.Max(0,box.Bottom-scroll.ClientSize.Height);
                if(dx==0&&dy==0)break;
                scroll.AutoScrollPosition=new Point(Math.Max(0,-scroll.AutoScrollPosition.X+dx),Math.Max(0,-scroll.AutoScrollPosition.Y+dy));Pump(form);
            }
        }
        Pump(form);Visible(c,errors);
    }
    private static void ResetScroll(Control root){foreach(var scroll in Descendants(root).OfType<ScrollableControl>().Where(s=>s.AutoScroll))scroll.AutoScrollPosition=Point.Empty;}
    private static IEnumerable<Control> Descendants(Control root){yield return root;foreach(Control child in root.Controls)foreach(var item in Descendants(child))yield return item;}
    private static T Find<T>(Control root,string name)where T:Control{return Descendants(root).OfType<T>().Single(c=>c.Name==name);}
    private static void Pump(Form form){for(int i=0;i<4;i++){form.PerformLayout();Application.DoEvents();}}
    private static void Require(bool value,string message,List<string> errors){if(!value)errors.Add(message);}
    private static string Arg(string[] args,string prefix){return args.FirstOrDefault(a=>a.StartsWith(prefix,StringComparison.Ordinal))?.Substring(prefix.Length);}
    private static void Save(Form form,string dir,string name){if(dir==null)return;using(var bitmap=new Bitmap(form.Width,form.Height)){using(var graphics=Graphics.FromImage(bitmap))graphics.CopyFromScreen(form.Location,Point.Empty,bitmap.Size);bitmap.Save(Path.Combine(dir,name+".png"));}}
}
