# Sheet Parameters UI regression checks

This .NET Framework 4.8 harness links the production `SheetEditorForm`, `SheetEditorModels`, `KaTheme` and branding assets. It supplies detached fixtures and never edits a Revit model or runs an installer.

The nine cases use 1366×728 at 100%, 1280×680 at 150%/200%, and 1024×600 and 876×571 at 100%/150%/200% control and font scales. Each case checks the main editor and its batch-value dialog. Run cases in separate Mono processes with an isolated Xvfb display to avoid accumulated graphics resources or overlapping screenshots.

```sh
dotnet build tests/SheetEditorLayout.Tests/SheetEditorLayout.Tests.csproj -c Release
mono tests/SheetEditorLayout.Tests/bin/Release/net48/KAMEP.SheetEditorLayout.Tests.exe --case=1366x728_100 --screenshots=/tmp/sheet-editor-shots
```

Checks cover fixed Apply/Cancel/Reset controls, reachable grids and batch actions, inline text editing, Yes/No checkbox staging, unchanged originals, persistent drafts across sheet/filter switches, persistent checked targets, exact identity for duplicate parameter names, read-only computed fields, editable-only filtering, batch eligibility/skips, duplicate-number validation, correction/review/reset, cloud/issued revision locks, additional-revision batch changes and accepting a valid draft. Fixture data includes Unicode, placeholder sheets, long values and 34 parameters per sheet.

Scrolling is exercised when the viewport cannot contain the full workspace. This checks explicit control/font scaling under Mono, not native Windows per-monitor DPI. Actual Revit parameter writes, unit parsing, worksharing, transaction commit/rollback and Undo require the Windows/Revit smoke checklist.
