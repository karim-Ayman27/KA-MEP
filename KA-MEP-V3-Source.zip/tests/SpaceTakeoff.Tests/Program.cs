using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using PipeTakeoff.Core;

internal static class Program
{
    private static int checks;
    private static int Main()
    {
        try
        {
            CheckOptions();
            CheckIntersections();
            CheckHeights();
            CheckAggregation();
            Console.WriteLine("PASS " + checks + " Space takeoff geometry/model checks (including 100 transformed/sloped cases). Native Revit extraction is not exercised.");
            return 0;
        }
        catch (Exception ex) { Console.Error.WriteLine(ex); return 1; }
    }

    private static void CheckOptions()
    {
        var options = Options();
        options.Validate();
        Check(!options.IncludeHostGeometry && options.IncludeLinkedGeometry, "Linked architecture is the default geometry scope");
        Equal(-1L, options.SelectedLinkInstanceId, "Default includes loaded links rather than choosing an arbitrary instance");
        options.SelectedLinkInstanceId = 9000000001L;
        var copy = options.Copy(); copy.MaximumHeightMeters = 8;
        Equal(12.0, options.MaximumHeightMeters, "Options copy is detached");
        Equal(9000000001L, copy.SelectedLinkInstanceId, "Options preserve exact selected link ID");
        Throws(() => new SpaceTakeoffOptions { IncludeHostGeometry = false, IncludeLinkedGeometry = false }.Validate(), "At least one source required");
        Throws(() => new SpaceTakeoffOptions { FloorSearchToleranceMeters = double.NaN }.Validate(), "NaN floor search rejected");
        Throws(() => new SpaceTakeoffOptions { MaximumHeightMeters = double.PositiveInfinity }.Validate(), "Infinite search rejected");
        Throws(() => new SpaceTakeoffOptions { SampleGridSize = 10000 }.Validate(), "Sampling count bounded");
        Throws(() => new SpaceTakeoffOptions { HeightVariationToleranceMeters = 0 }.Validate(), "Height tolerance positive");
        Throws(() => new SpaceTakeoffOptions { SelectedLinkInstanceId = -2 }.Validate(), "Invalid negative link selector rejected");
        var identity = new SpaceTakeoffRow { SpaceId = 9000000002L, SpaceName = "Office space", RoomName = "مكتب", SpaceNumber = "S-01", RoomNumber = "001" };
        Check(identity.RoomName != identity.SpaceName && identity.RoomNumber != identity.SpaceNumber, "Room and Space identities remain distinct");
        Equal("001", identity.RoomNumber, "Leading zero room numbers remain strings");
        Check(identity.NeedsReview && identity.ClearHeightMeters == null, "New rows have no invented clear height");
    }

    private static void CheckIntersections()
    {
        var floor = Source(10);
        var tris = Patch(0, 0, 4, 4, 0, SpaceSurfaceKind.FloorTop, floor).ToList();
        var index = new SpaceSurfaceIndex(tris);
        Equal(1, index.Query(2, 2, -1, 1, SpaceSurfaceKind.FloorTop).Count, "Shared triangle diagonal is counted once per source");
        Equal(1, index.Query(4, 4, -1, 1, SpaceSurfaceKind.FloorTop).Count, "Boundary point included deterministically");
        Equal(0, index.Query(4.1, 4.1, -1, 1, SpaceSurfaceKind.FloorTop).Count, "Outside triangle is not a bounding-box hit");
        Equal(0, index.Query(1, 1, 1, 2, SpaceSurfaceKind.FloorTop).Count, "Elevation interval honored");
        Equal(0, index.Query(1, 1, -1, 1, SpaceSurfaceKind.CeilingBottom).Count, "Surface kinds isolated");
        var secondInstance = Source(10, 22);
        tris.AddRange(Patch(0, 0, 4, 4, 0, SpaceSurfaceKind.FloorTop, secondInstance));
        Equal(2, new SpaceSurfaceIndex(tris).Query(2, 2, -1, 1, SpaceSurfaceKind.FloorTop).Count, "Repeated link instances retain distinct source identities");

        var ring = new List<SpaceSurfaceTriangle>();
        ring.AddRange(Patch(0, 0, 1, 4, 0, SpaceSurfaceKind.FloorTop, floor));
        ring.AddRange(Patch(3, 0, 4, 4, 0, SpaceSurfaceKind.FloorTop, floor));
        ring.AddRange(Patch(1, 0, 3, 1, 0, SpaceSurfaceKind.FloorTop, floor));
        ring.AddRange(Patch(1, 3, 3, 4, 0, SpaceSurfaceKind.FloorTop, floor));
        var hole = new SpaceSurfaceIndex(ring);
        Equal(0, hole.Query(2, 2, -1, 1, SpaceSurfaceKind.FloorTop).Count, "Triangulated floor opening remains a hole");
        Equal(1, hole.Query(.5, 2, -1, 1, SpaceSurfaceKind.FloorTop).Count, "Floor around opening remains measurable");
        var vertical = new SpaceSurfaceTriangle(new SpacePoint3(0, 0, 0), new SpacePoint3(0, 1, 0), new SpacePoint3(0, 1, 3), SpaceSurfaceKind.FloorTop, floor);
        Equal(0, new SpaceSurfaceIndex(new[] { vertical }).Query(0, .5, -1, 4, SpaceSurfaceKind.FloorTop).Count, "Vertical faces do not produce floor hits");
        Throws(() => new SpaceSurfaceIndex(new SpaceSurfaceTriangle[] { null }), "Null surface rejected");
        Throws(() => new SpaceSurfaceIndex(new[] { new SpaceSurfaceTriangle(new SpacePoint3(double.NaN, 0, 0), new SpacePoint3(1, 0, 0), new SpacePoint3(0, 1, 0), SpaceSurfaceKind.FloorTop, floor) }), "Nonfinite geometry rejected");
        Throws(() => index.Query(double.NaN, 0, -1, 1, SpaceSurfaceKind.FloorTop), "Invalid query point rejected");
        Throws(() => index.Query(0, 0, 2, 1, SpaceSurfaceKind.FloorTop), "Reversed interval rejected");
        var large = new SpaceSurfaceIndex(Patch(-1000, -1000, 1000, 1000, 2, SpaceSurfaceKind.FloorTop, floor));
        Equal(1, large.Query(900, 900, 1, 3, SpaceSurfaceKind.FloorTop).Count, "Large-triangle fallback stays spatially accurate");

        var random = new Random(27026);
        for (int i = 0; i < 100; i++)
        {
            double dx = random.NextDouble() * 10000 - 5000, dy = random.NextDouble() * 10000 - 5000;
            double angle = random.NextDouble() * Math.PI * 2, mirror = i % 2 == 0 ? -1 : 1;
            Func<double, double, double, SpacePoint3> transform = (x, y, z) => new SpacePoint3(dx + mirror * x * Math.Cos(angle) - y * Math.Sin(angle), dy + mirror * x * Math.Sin(angle) + y * Math.Cos(angle), z);
            var t = new SpaceSurfaceTriangle(transform(0, 0, 1), transform(4, 0, 3), transform(0, 4, 5), SpaceSurfaceKind.FloorTop, floor);
            var point = transform(1, 1, 0);
            var hits = new SpaceSurfaceIndex(new[] { t }).Query(point.X, point.Y, -10, 10, SpaceSurfaceKind.FloorTop);
            if (hits.Count != 1 || Math.Abs(hits[0].ElevationMeters - 2.5) > 1e-7) throw new Exception("Rotated/reflected/translated sloped face interpolation failed");
        }
        Check(true, "100 transformed and sloped triangle cases");
    }

    private static void CheckHeights()
    {
        var options = Options();
        var geometry = new List<SpaceSurfaceTriangle>();
        geometry.AddRange(Patch(0, 0, 4, 4, 0, SpaceSurfaceKind.FloorTop, Source(1)));
        geometry.AddRange(Patch(0, 0, 4, 4, -.3, SpaceSurfaceKind.SlabBottom, Source(1)));
        geometry.AddRange(Patch(0, 0, 4, 4, 3, SpaceSurfaceKind.CeilingBottom, Source(2)));
        geometry.AddRange(Patch(0, 0, 4, 4, 3.7, SpaceSurfaceKind.SlabBottom, Source(3)));
        var sample = Measure(geometry, options);
        Near(3, sample.HeightMeters, "Clear height uses physical ceiling underside");
        Equal(SpaceHeightBasis.Ceiling, sample.HeightBasis, "Ceiling basis explicit");
        Equal(2L, sample.OverheadSource.ElementId, "Overhead provenance retained");
        geometry.RemoveAll(t => t.Kind == SpaceSurfaceKind.CeilingBottom);
        sample = Measure(geometry, options);
        Near(3.7, sample.HeightMeters, "No ceiling falls back to slab underside, not its top");
        Equal(SpaceHeightBasis.Slab, sample.HeightBasis, "Slab basis explicit");
        geometry.AddRange(Patch(0, 0, 4, 4, 6.5, SpaceSurfaceKind.CeilingBottom, Source(4)));
        sample = Measure(geometry, options);
        Near(3.7, sample.HeightMeters, "Next-storey ceiling cannot override intervening slab");
        Check(sample.Notes.Contains("intervening"), "Ignored ceiling explained");
        options.MaximumHeightMeters = 3;
        sample = Measure(geometry, options);
        Equal(SpaceMeasurementStatus.MissingOverhead, sample.Status, "Maximum overhead search honored");
        Check(sample.HeightMeters == null, "Missing overhead stays blank");
        options.MaximumHeightMeters = 12;
        sample = SpaceHeightEngine.MeasureSample(new SpaceSurfaceIndex(geometry), 2, 2, 2, options);
        Equal(SpaceMeasurementStatus.MissingFloor, sample.Status, "Space base is not silently treated as physical floor");
        Check(sample.HeightMeters == null, "Missing floor stays blank");

        // Separate architectural finish Floor over a structural support Floor.
        geometry.RemoveAll(t => t.Kind == SpaceSurfaceKind.CeilingBottom);
        geometry.AddRange(Patch(0, 0, 4, 4, .1, SpaceSurfaceKind.FloorTop, Source(5)));
        geometry.AddRange(Patch(0, 0, 4, 4, 0, SpaceSurfaceKind.SlabBottom, Source(5)));
        sample = Measure(geometry, options);
        Near(3.6, sample.HeightMeters, "Continuous separate finish Floor uses highest walking surface");
        Equal(5L, sample.FloorSource.ElementId, "Chosen finish-floor source retained");
        Check(sample.Notes.Contains("support/finish"), "Layer choice disclosed");
        geometry.AddRange(Patch(0, 0, 4, 4, .8, SpaceSurfaceKind.FloorTop, Source(6)));
        geometry.AddRange(Patch(0, 0, 4, 4, .6, SpaceSurfaceKind.SlabBottom, Source(6)));
        sample = Measure(geometry, options);
        Equal(SpaceMeasurementStatus.NeedsReview, sample.Status, "Floating mezzanine within base band is ambiguous");
        Check(sample.HeightMeters == null && sample.FloorSource == null, "Ambiguous floor cannot leak a nominal height");
        geometry.RemoveAll(t => t.Source.ElementId == 6);
        geometry.RemoveAll(t => t.Source.ElementId == 5 && t.Kind == SpaceSurfaceKind.SlabBottom);
        Equal(SpaceMeasurementStatus.NeedsReview, Measure(geometry, options).Status, "Unproven finish layer is review rather than assumed support");

        var same = Patch(0, 0, 4, 4, 0, SpaceSurfaceKind.FloorTop, Source(9)).ToList();
        same.AddRange(Patch(0, 0, 4, 4, 2, SpaceSurfaceKind.SlabBottom, Source(9)));
        Equal(SpaceMeasurementStatus.MissingOverhead, Measure(same, options).Status, "Selected floor's own bottom cannot count as overhead");
        same.AddRange(Patch(0, 0, 4, 4, 0, SpaceSurfaceKind.FloorTop, Source(9, 42)));
        same.AddRange(Patch(0, 0, 4, 4, 3, SpaceSurfaceKind.CeilingBottom, Source(12)));
        Equal(SpaceMeasurementStatus.Measured, Measure(same, options).Status, "Coincident floor seams/instances are not false height ambiguity");
    }

    private static void CheckAggregation()
    {
        var options = Options();
        var row = new SpaceTakeoffRow { Samples = { Sample(3), Sample(3.01) } };
        SpaceHeightEngine.Aggregate(row, options);
        Equal(SpaceMeasurementStatus.Measured, row.Status, "Consistent complete samples produce measured result");
        Near(3, row.ClearHeightMeters, "Single height is sampled minimum, not average");
        Near(3.01, row.MaxHeightMeters, "Actual sampled range retained");
        Equal(2, row.SamplesAttempted, "Sampling denominator explicit");
        row.Samples.Add(Sample(3.4)); SpaceHeightEngine.Aggregate(row, options);
        Equal(SpaceMeasurementStatus.VariableHeight, row.Status, "Sloped/stepped clearance marks variable height");
        Check(row.ClearHeightMeters == null, "Variable heights do not retain stale nominal value");
        Near(3.4, row.MaxHeightMeters, "Variable upper range retained");
        row.Samples[2] = new SpaceHeightSample { Status = SpaceMeasurementStatus.MissingOverhead };
        SpaceHeightEngine.Aggregate(row, options);
        Equal(SpaceMeasurementStatus.PartialCoverage, row.Status, "Missing point marks partial measurement");
        Equal(2, row.SamplesMeasured, "Only complete point measurements counted");
        Check(row.ClearHeightMeters == null, "Incomplete sampling never assigned nominal height");
        row.Samples.RemoveAt(2); SpaceHeightEngine.Aggregate(row, options, false);
        Equal(SpaceMeasurementStatus.PartialCoverage, row.Status, "Reader geometry failures invalidate complete-looking samples");
        row.Samples[1].HeightBasis = SpaceHeightBasis.Slab;
        SpaceHeightEngine.Aggregate(row, options);
        Equal(SpaceMeasurementStatus.MixedOverhead, row.Status, "Partial suspended ceiling mixed with slab reports mixed basis");
        Check(row.ClearHeightMeters == null && row.MinHeightMeters.HasValue, "Mixed basis keeps range but no nominal height");
        row.Samples.Clear(); row.Status = SpaceMeasurementStatus.Unplaced;
        SpaceHeightEngine.Aggregate(row, options);
        Equal(SpaceMeasurementStatus.Unplaced, row.Status, "Unplaced rows retain their reason");
        Check(row.MinHeightMeters == null && row.MaxHeightMeters == null, "Reaggregation clears stale ranges");
        row.Status = SpaceMeasurementStatus.Unmeasured;
        SpaceHeightEngine.Aggregate(row, options);
        Equal(SpaceMeasurementStatus.GeometryUnavailable, row.Status, "No interior samples reports unavailable geometry");
        row.Samples.Add(new SpaceHeightSample { Status = SpaceMeasurementStatus.MissingFloor });
        SpaceHeightEngine.Aggregate(row, options);
        Equal(SpaceMeasurementStatus.MissingFloor, row.Status, "Uniform missing reason surfaced");
        row.Samples.Clear(); row.Samples.Add(Sample(double.NaN));
        Throws(() => SpaceHeightEngine.Aggregate(row, options), "Nonfinite sample height rejected");
        row.Samples.Clear(); row.Samples.Add(Sample(-1));
        Throws(() => SpaceHeightEngine.Aggregate(row, options), "Negative height rejected");
        var source = Source(9000000000L, 9000000001L);
        row.Samples.Clear(); row.Samples.Add(new SpaceHeightSample { FloorSource = source });
        Check(row.FloorSources.Contains("9000000000") && row.FloorSources.Contains("9000000001"), "Sources preserve exact 64-bit element and link IDs");
    }

    private static SpaceTakeoffOptions Options() { return new SpaceTakeoffOptions(); }
    private static SpaceSurfaceSource Source(long id, long link = 11)
    { return new SpaceSurfaceSource { DocumentTitle = "Architecture", LinkInstanceId = link, ElementId = id, ElementName = "Surface " + id.ToString(CultureInfo.InvariantCulture) }; }
    private static SpaceHeightSample Sample(double height)
    { return new SpaceHeightSample { HeightMeters = height, FloorElevationMeters = 0, OverheadElevationMeters = height, HeightBasis = SpaceHeightBasis.Ceiling, Status = SpaceMeasurementStatus.Measured, FloorSource = Source(1), OverheadSource = Source(2) }; }
    private static SpaceHeightSample Measure(IEnumerable<SpaceSurfaceTriangle> triangles, SpaceTakeoffOptions options)
    { return SpaceHeightEngine.MeasureSample(new SpaceSurfaceIndex(triangles), 2, 2, 0, options); }
    private static IEnumerable<SpaceSurfaceTriangle> Patch(double x1, double y1, double x2, double y2, double z, SpaceSurfaceKind kind, SpaceSurfaceSource source)
    {
        var a = new SpacePoint3(x1, y1, z); var b = new SpacePoint3(x2, y1, z);
        var c = new SpacePoint3(x2, y2, z); var d = new SpacePoint3(x1, y2, z);
        yield return new SpaceSurfaceTriangle(a, b, c, kind, source);
        yield return new SpaceSurfaceTriangle(a, c, d, kind, source);
    }
    private static void Equal<T>(T expected, T actual, string label) { Check(Equals(expected, actual), label + " [expected " + expected + ", actual " + actual + "]"); }
    private static void Near(double expected, double? actual, string label) { Check(actual.HasValue && Math.Abs(expected - actual.Value) < 1e-8, label); }
    private static void Check(bool condition, string label) { if (!condition) throw new Exception("FAIL " + label); checks++; Console.WriteLine("PASS " + label); }
    private static void Throws(Action action, string label)
    {
        try { action(); } catch (ArgumentException) { Check(true, label); return; } catch (InvalidOperationException) { Check(true, label); return; }
        throw new Exception("FAIL " + label);
    }
}
