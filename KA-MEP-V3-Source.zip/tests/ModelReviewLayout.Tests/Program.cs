using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using PipeTakeoff.Revit;

internal static class Program
{
    private sealed class Case
    {
        internal int W,H; internal float Scale;
        internal Case(int w,int h,float scale) { W=w;H=h;Scale=scale; }
        internal string Name { get { return W+"x"+H+"_"+(int)(Scale*100); } }
    }
    [STAThread]
    private static int Main(string[] args)
    {
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        string only=Arg(args,"--case="), screenshots=Arg(args,"--screenshots=");
        if(screenshots!=null)Directory.CreateDirectory(screenshots);
        int passed=0,total=0;
        foreach(var test in new[]{new Case(1366,728,1),new Case(1280,680,1.5F),new Case(1280,680,2),new Case(1024,600,1),new Case(1024,600,1.5F),new Case(1024,600,2),new Case(876,571,1),new Case(876,571,1.5F),new Case(876,571,2)})
        {
            if(only!=null && only!=test.Name)continue;
            total++;var errors=new List<string>();
            try{Check(test,screenshots,errors);CheckCleanup(test,screenshots,errors);}catch(Exception ex){errors.Add(ex.ToString());}
            Console.WriteLine((errors.Count==0?"PASS ":"FAIL ")+test.Name);
            foreach(var error in errors.Distinct())Console.WriteLine("  "+error);
            if(errors.Count==0)passed++;
        }
        Console.WriteLine("RESULT: "+passed+"/"+total+" Model Review UI cases passed; "+(total-passed)+" failed.");
        Console.WriteLine("Actual linked production form under Mono/Xvfb; simulated font/control scaling, not Windows DPI or live Revit.");
        return total>0&&total==passed?0:1;
    }
    private static void Check(Case test,string screenshots,List<string> errors)
    {
        using(var form=new ModelReviewForm(Fixture()))
        {
            var grid=Find<DataGridView>(form,"ReviewFindingGrid");
            grid.DataError+=(sender,e)=>errors.Add("Grid data error: "+e.Exception.Message);
            ShowScaled(form,test);Save(form,screenshots,test.Name+"_overview");
            Reachable(grid,form,errors);Pump(form);Save(form,screenshots,test.Name+"_summary_grid");
            ResetScroll(form);Pump(form);
            var refresh=Find<Button>(form,"ReviewRefreshButton");var cleanup=Find<Button>(form,"ReviewCleanupButton");
            var inspect=Find<Button>(form,"ReviewInspectButton");var export=Find<Button>(form,"ReviewExportButton");
            var close=Find<Button>(form,"ReviewCloseButton");var score=Find<Label>(form,"ReviewHealthScore");
            var kind=Find<ComboBox>(form,"ReviewKindFilter");var search=Find<TextBox>(form,"ReviewSearch");
            int refreshes=0,exports=0;IList<string> inspected=null,cleaned=null;
            form.RefreshRequested+=()=>refreshes++;form.ExportRequested+=()=>exports++;
            form.InspectRequested+=keys=>inspected=keys;form.CleanupRequested+=keys=>cleaned=keys;
            Require(form.Icon!=null,"Brand icon missing",errors);
            Require(grid.Rows.Count==5,"Repeated findings were not grouped into five issue rows",errors);
            Require(grid.Rows.Cast<DataGridViewRow>().All(r=>r.Tag is ReviewIssueGroup),"Summary exposes raw findings",errors);
            Require(score.Text=="82 / 100","Grouped presentation changed the underlying health score",errors);
            Require(Find<Label>(form,"ReviewCounts").Text.Contains("8 occurrences"),"Original occurrence count absent",errors);
            Require(!cleanup.Enabled,"Cleanup enabled with no checked rows",errors);
            Require(!grid.Columns["Checked"].Visible&&grid.Columns["Occurrences"].Visible,"Summary shows cleanup checks or hides occurrence counts",errors);
            Require(!Find<Button>(form,"ReviewCheckCandidates").Visible,"Summary permits bulk cleanup selection",errors);
            Require(Find<TabControl>(form,"ReviewDetailTabs").TabCount==2,"Details or coverage tab missing",errors);
            var cadGroup=GroupRow(grid,ReviewKind.CadImport);
            Require(Convert.ToString(cadGroup.Cells[2].FormattedValue)=="Imported CAD files","Summary issue title not renderable",errors);
            Require(Convert.ToInt32(cadGroup.Cells[3].Value)==2&&Convert.ToInt32(cadGroup.Cells[4].Value)==2,"Grouped counts do not retain repeated CAD findings",errors);
            grid.CurrentCell=cadGroup.Cells[2];Pump(form);inspect.PerformClick();
            Require(inspected!=null&&inspected.OrderBy(x=>x).SequenceEqual(new[]{"cad","cad2"}),"Summary inspection does not include every issue member",errors);
            cleanup.PerformClick();Require(cleaned==null,"Summary initiated cleanup",errors);
            search.Text="101";Pump(form);
            Require(grid.Rows.Count==1&&Convert.ToInt32(grid.Rows[0].Cells[3].Value)==2,"Summary search truncates full issue counts",errors);
            search.Clear();Pump(form);grid.CurrentCell=GroupRow(grid,ReviewKind.CadImport).Cells[2];Pump(form);
            Find<Button>(form,"ReviewOpenDetails").PerformClick();Pump(form);
            Require(grid.Rows.Count==2&&grid.Rows.Cast<DataGridViewRow>().All(r=>r.Tag is ReviewFinding),"Issue drilldown does not show individual CAD findings",errors);
            Require(grid.Columns["Checked"].Visible&&!grid.Columns["Occurrences"].Visible,"Detail columns incorrect",errors);
            grid.CurrentCell=Row(grid,"cad").Cells[2];Pump(form);
            Require(Find<TextBox>(form,"ReviewFindingDetails").Text.Contains("101"),"Individual detail IDs absent",errors);
            Find<Button>(form,"ReviewCheckCandidates").PerformClick();Pump(form);
            Require(cleanup.Enabled,"Explicitly checked eligible details cannot preview cleanup",errors);
            cleanup.PerformClick();Require(cleaned!=null&&cleaned.OrderBy(x=>x).SequenceEqual(new[]{"cad","cad2"}),"Issue cleanup includes findings outside the reviewed group",errors);
            search.Text="101";Pump(form);
            Require(grid.Rows.Count==1&&!cleanup.Enabled&&grid.Rows.Cast<DataGridViewRow>().All(r=>!Convert.ToBoolean(r.Cells[0].Value)),"Filtering retained hidden cleanup selections",errors);
            Find<Button>(form,"ReviewCheckCandidates").PerformClick();Pump(form);cleanup.PerformClick();
            Require(cleaned!=null&&cleaned.SequenceEqual(new[]{"cad"}),"Filtered cleanup selected a hidden finding",errors);
            Find<Button>(form,"ReviewOpenDetails").PerformClick();Pump(form);
            Require(!cleanup.Enabled&&!grid.Columns["Checked"].Visible,"Returning to summary retained cleanup permission",errors);
            search.Clear();Pump(form);Find<Button>(form,"ReviewAllDetails").PerformClick();Pump(form);
            Require(grid.Rows.Count==8,"All individual findings view omits occurrences",errors);
            grid.CurrentCell=Row(grid,"dup").Cells[2];Pump(form);inspect.PerformClick();
            Require(inspected!=null&&inspected.SequenceEqual(new[]{"dup"}),"Current duplicate finding cannot be inspected",errors);
            Require(Find<TextBox>(form,"ReviewFindingDetails").Text.Contains("301, 302"),"Duplicate members omitted from details",errors);
            Row(grid,"dup").Cells[0].Value=true;Pump(form);
            Require(!cleanup.Enabled,"Review-only duplicate enables cleanup",errors);
            Find<Button>(form,"ReviewCheckCandidates").PerformClick();Pump(form);cleanup.PerformClick();
            Require(cleaned!=null&&cleaned.OrderBy(x=>x).SequenceEqual(new[]{"cad","cad2","view","view2"}),"Cleanup includes review-only finding or omits an explicit candidate",errors);
            Save(form,screenshots,test.Name+"_issue_details");
            Reachable(grid,form,errors);Pump(form);Save(form,screenshots,test.Name+"_individual_grid");
            ResetScroll(form);Pump(form);
            kind.SelectedIndex=2;Pump(form);
            Require(grid.Rows.Count==1&&((ReviewFinding)grid.Rows[0].Tag).Key=="link","CAD link filter inaccurate",errors);
            Require(!cleanup.Enabled,"Kind filter retained hidden cleanup checks",errors);
            inspect.PerformClick();Require(inspected!=null&&inspected.SequenceEqual(new[]{"link"}),"Filtered inspection includes stale hidden checks",errors);
            kind.SelectedIndex=0;search.Text="302";Pump(form);
            Require(grid.Rows.Count==1&&((ReviewFinding)grid.Rows[0].Tag).Key=="dup","Element ID search inaccurate",errors);
            search.Text="";Pump(form);Find<Button>(form,"ReviewClearChecks").PerformClick();Pump(form);
            Require(grid.Rows.Cast<DataGridViewRow>().All(r=>!Convert.ToBoolean(r.Cells[0].Value)),"Clear checks incomplete",errors);
            refresh.PerformClick();export.PerformClick();Require(refreshes==1&&exports==1,"Refresh/export request not raised",errors);
            form.SetBusy(true,"Scanning model…");Pump(form);
            Require(!refresh.Enabled&&!inspect.Enabled&&!export.Enabled&&!cleanup.Enabled&&!grid.Enabled,"Busy mode allows a competing operation",errors);
            Require(close.Enabled,"Close blocked while busy",errors);
            form.SetBusy(false,"Ready");
            var next=Fixture();next.Findings.RemoveAt(0);form.SetSnapshot(next);Pump(form);
            Require(score.Text=="87 / 100","Refresh did not recalculate score",errors);
            Require(Find<Label>(form,"ReviewScannedAt").Text.Contains("+5"),"Refresh score change missing",errors);
            Require(!cleanup.Enabled,"Refresh retained stale checks",errors);
            Require(grid.Rows.Cast<DataGridViewRow>().All(r=>r.Tag is ReviewIssueGroup),"Refresh did not return to a fresh issue summary",errors);
            var partial=Fixture();partial.IsComplete=false;partial.Notes.Add("A category could not be scanned.");form.SetSnapshot(partial);Pump(form);
            Require(score.Text=="Unavailable","Partial scan displays a misleading score",errors);
            Require(!Find<Button>(form,"ReviewCheckCandidates").Enabled,"Incomplete scan allows bulk cleanup checks",errors);
            form.ShowFailure("Document was closed. Open a model and reopen this tool.");Pump(form);
            Require(Find<Label>(form,"ReviewStatus").Text.Contains("Document was closed"),"Failure reason lost",errors);
            form.ShowFailure(string.Join(" ",Enumerable.Repeat("A long Revit error message with an element path and explanatory details.",70)));Pump(form);
            foreach(var button in new[]{refresh,inspect,cleanup,export,close})Visible(button,errors);
            Require(Find<Label>(form,"ReviewStatus").Height<=Find<Label>(form,"ReviewStatus").Font.Height*3+2,"Long error expanded footer",errors);
            form.SetSnapshot(Fixture());form.SetBusy(false,"Ready");Pump(form);
            foreach(var button in new[]{refresh,inspect,cleanup,export,close})Visible(button,errors);
            Reachable(kind,form,errors);Reachable(search,form,errors);
            Require(grid.Width>400&&grid.Height>=80,"Finding grid unusably small",errors);
            var tabs=Find<TabControl>(form,"ReviewDetailTabs");tabs.SelectedIndex=1;
            Reachable(tabs,form,errors);Pump(form);
            Require(Find<TextBox>(form,"ReviewCoverage").Text.Contains("not an Autodesk"),"Scoring limitation absent",errors);
            Save(form,screenshots,test.Name+"_coverage");
            ResetScroll(form);Pump(form);Save(form,screenshots,test.Name+"_final");
            form.Close();
        }
    }
    private static void CheckCleanup(Case test,string screenshots,List<string> errors)
    {
        var plan=new ReviewCleanupPlan{RequestedIds=new List<long>{101,201},AffectedIds=Enumerable.Range(101,180).Select(x=>(long)x).ToList()};
        plan.Lines=plan.AffectedIds.Select(id=>(plan.RequestedIds.Contains(id)?"SELECTED  ":"DEPENDENT  ")+"["+id+"] Annotation — actual dependent element to review").ToList();
        using(var form=new ModelReviewCleanupForm(plan))
        {
            ShowScaled(form,test);
            var list=Find<TextBox>(form,"CleanupImpactList");var text=Find<TextBox>(form,"CleanupConfirmation");
            var cancel=Find<Button>(form,"CleanupCancel");var apply=Find<Button>(form,"CleanupApply");
            Require(list.ReadOnly&&list.Lines.Length==180,"Cleanup preview omits dependent elements",errors);
            Require(list.Text.Contains("[280]"),"Last dependent element absent",errors);
            Require(list.ScrollBars==ScrollBars.Both,"Deletion list lacks both scrollbars",errors);
            Require(list.Height>=100,"Deletion preview list unusably small",errors);
            Require(form.AcceptButton==cancel&&form.CancelButton==cancel,"Cancel is not default and Escape action",errors);
            Require(!apply.Enabled,"Delete enabled before typed confirmation",errors);
            text.Text="delete";Pump(form);Require(!apply.Enabled,"Lowercase confirmation accepted",errors);
            text.Text="DELETE ";Pump(form);Require(!apply.Enabled,"Nonexact confirmation accepted",errors);
            text.Text="DELETE";Pump(form);Require(apply.Enabled,"Exact confirmation does not enable Delete",errors);
            foreach(var control in new Control[]{text,cancel,apply})Visible(control,errors);
            Reachable(list,form,errors);list.SelectionStart=list.Text.Length;list.ScrollToCaret();Pump(form);
            Save(form,screenshots,test.Name+"_cleanup_end");
            ResetScroll(form);list.SelectionStart=0;list.ScrollToCaret();Pump(form);Save(form,screenshots,test.Name+"_cleanup");
            apply.PerformClick();Require(form.DialogResult==DialogResult.OK,"Confirm does not return explicit approval",errors);
        }
    }
    private static ReviewSnapshot Fixture()
    {
        var result=new ReviewSnapshot{ProjectTitle="MEP Coordination — مشروع اختبار",ScannedAt=new DateTime(2026,10,20,10,30,0,DateTimeKind.Utc),ModelElementCount=15501,IsComplete=true};
        result.Findings.Add(F("cad",ReviewKind.CadImport,"Site survey.dwg",true,101));
        result.Findings.Add(F("cad2",ReviewKind.CadImport,"Site survey repeated.dwg",true,103));
        result.Findings.Add(F("link",ReviewKind.CadLink,"Architectural link.dwg",false,102));
        result.Findings.Add(F("view",ReviewKind.UnplacedView,"Level 02 — Mechanical coordination",true,201));
        result.Findings.Add(F("view2",ReviewKind.UnplacedView,"Level 03 — Mechanical coordination",true,202));
        result.Findings.Add(F("dup",ReviewKind.PotentialDuplicate,"Potential duplicate pipe group",false,301,302));
        result.Findings.Add(F("warning",ReviewKind.RevitWarning,"Disconnected mechanical system",false,401));
        result.Findings.Add(F("warning2",ReviewKind.RevitWarning,"Disconnected mechanical system",false,402));
        result.Notes.Add("Host document only. Links are listed separately; linked model contents are not scanned.");
        return result;
    }
    private static ReviewFinding F(string key,ReviewKind kind,string title,bool clean,params long[] ids)
    {
        return new ReviewFinding{Key=key,Kind=kind,Title=title,CanClean=clean,ElementIds=ids.ToList(),Detail="Inspect this finding in the model before deciding whether it should change. معلومات المراجعة",CleanupBlockReason=clean?"":"Review only; resolve manually after inspection."};
    }
    private static DataGridViewRow Row(DataGridView grid,string key){return grid.Rows.Cast<DataGridViewRow>().Single(r=>r.Tag is ReviewFinding&&((ReviewFinding)r.Tag).Key==key);}
    private static DataGridViewRow GroupRow(DataGridView grid,ReviewKind kind){return grid.Rows.Cast<DataGridViewRow>().Single(r=>r.Tag is ReviewIssueGroup&&((ReviewIssueGroup)r.Tag).Kind==kind);}
    private static void ShowScaled(Form form,Case test)
    {
        form.Show();Pump(form);form.AutoScaleMode=AutoScaleMode.None;
        var fonts=Descendants(form).Select(c=>new{Control=c,Family=c.Font.FontFamily,Size=c.Font.Size,Style=c.Font.Style,Unit=c.Font.Unit}).ToArray();
        form.Scale(new SizeF(test.Scale,test.Scale));foreach(var f in fonts)f.Control.Font=new Font(f.Family,f.Size*test.Scale,f.Style,f.Unit);
        form.MinimumSize=Size.Empty;form.ClientSize=new Size(test.W,test.H);form.Location=new Point(20,20);Pump(form);
    }
    private static void Visible(Control c,List<string> errors)
    {
        if(!c.Visible||c.Width<=0||c.Height<=0){errors.Add(c.Name+": not visible");return;}
        var box=c.RectangleToScreen(c.ClientRectangle);
        for(Control p=c.Parent;p!=null;p=p.Parent)
            if(!p.RectangleToScreen(p.ClientRectangle).Contains(box)){errors.Add(c.Name+": clipped by "+p.Name+" ("+c.Bounds+")");break;}
    }
    private static void Reachable(Control c,Form form,List<string> errors)
    {
        for(Control p=c.Parent;p!=null;p=p.Parent)
        {
            var scroll=p as ScrollableControl;if(scroll==null||!scroll.AutoScroll)continue;
            scroll.ScrollControlIntoView(c);Pump(form);
            for(int attempt=0;attempt<3;attempt++)
            {
                var box=scroll.RectangleToClient(c.RectangleToScreen(c.ClientRectangle));
                int dx=box.Left<0?box.Left:Math.Max(0,box.Right-scroll.ClientSize.Width);
                int dy=box.Top<0?box.Top:Math.Max(0,box.Bottom-scroll.ClientSize.Height);
                if(dx==0&&dy==0)break;
                scroll.AutoScrollPosition=new Point(Math.Max(0,-scroll.AutoScrollPosition.X+dx),Math.Max(0,-scroll.AutoScrollPosition.Y+dy));Pump(form);
            }
        }
        Pump(form);Visible(c,errors);
    }
    private static void ResetScroll(Control root){foreach(var scroll in Descendants(root).OfType<ScrollableControl>().Where(s=>s.AutoScroll))scroll.AutoScrollPosition=Point.Empty;}
    private static IEnumerable<Control> Descendants(Control root){yield return root;foreach(Control child in root.Controls)foreach(var item in Descendants(child))yield return item;}
    private static T Find<T>(Control root,string name)where T:Control{return Descendants(root).OfType<T>().Single(c=>c.Name==name);}
    private static void Pump(Form form){for(int i=0;i<4;i++){form.PerformLayout();Application.DoEvents();}}
    private static void Require(bool value,string message,List<string> errors){if(!value)errors.Add(message);}
    private static string Arg(string[] args,string prefix){return args.FirstOrDefault(a=>a.StartsWith(prefix,StringComparison.Ordinal))?.Substring(prefix.Length);}
    private static void Save(Form form,string dir,string name){if(dir==null)return;using(var bitmap=new Bitmap(form.Width,form.Height)){using(var graphics=Graphics.FromImage(bitmap))graphics.CopyFromScreen(form.Location,Point.Empty,bitmap.Size);bitmap.Save(Path.Combine(dir,name+".png"));}}
}
