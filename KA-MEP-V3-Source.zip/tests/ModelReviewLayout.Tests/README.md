# Model Review layout checks

This harness links the production `ModelReviewForm`, `ModelReviewCleanupForm`, detached models and theme. It does not load the Revit API or change a document.

The final run passed **9/9 cases**, each exercising both windows: 1366×728 at100%; 1280×680 at150%/200%; 1024×600 and876×571 at100%/150%/200%. Evidence is retained in `docs/MODEL-REVIEW-LAYOUT-RESULTS.txt`.

The checks cover finding text and filters, checked selection across hidden rows, review-only duplicate inspection, eligible cleanup scope, Refresh and Excel requests, busy state, score delta, partial-scan score suppression, long error messages, fixed action buttons and reachable scroll content. Cleanup checks retain all180 affected-element lines, reach the last line, require exact `DELETE`, keep Cancel as default/Escape, and return explicit confirmation only after the action button is pressed.

Screenshots from100% and the smallest200% case were visually inspected to check actual text rendering and button visibility. Small windows intentionally scroll the main content while actions remain fixed.

Build with:

```sh
dotnet build tests/ModelReviewLayout.Tests/ModelReviewLayout.Tests.csproj -c Release
```

Run on Windows or Mono with a display server:

```sh
mono tests/ModelReviewLayout.Tests/bin/Release/net48/KAMEP.ModelReviewLayout.Tests.exe --case=1366x728_100 --screenshots=/tmp/ka-mep-review-ui
```

The `--case` argument is optional; omit it to exercise every case. The retained environment runner is `/workspace/.ka-mep-layout-runtime/run-model-review-v2.py` and uses a fresh process for each case under one Xvfb server. Screenshots and raw logs are in `/workspace/.ka-mep-layout-runtime/model-review-v2-final`.

Mono tests use explicit font/control scaling and do not certify Windows per-monitor DPI, modeless integration in Revit, transaction behavior, or live deletion. See `docs/MODEL-REVIEW-SMOKE-TEST.md` for native runtime checks.
