using System;
using PipeTakeoff.Core;
using PipeTakeoff.Revit;

internal static class Program
{
    private static int checks;

    private static int Main()
    {
        try
        {
            VerifySourceProvenance();
            VerifyResolutionGuards();
            VerifyCriteria();
            VerifyIntersectionDecisions();
            Console.WriteLine("PASS " + checks + " detached clash verification policy checks. Revit geometry and view behavior require native acceptance testing.");
            return 0;
        }
        catch (Exception ex) { Console.Error.WriteLine(ex); return 1; }
    }

    private static void VerifyResolutionGuards()
    {
        var automatic = new ClashElementReference { ElementId = 42 };
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireSourceCandidates(automatic, 0, false), "An absent source cannot resolve an element");
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireSourceCandidates(automatic, 2, true), "A loaded numeric-ID match cannot disambiguate an unloaded possible source");
        ClashVerificationPolicy.RequireSourceCandidates(automatic, 2, false);
        ClashVerificationPolicy.RequireSingleMatch(1);
        Check(true, "Without report provenance, one identity match across all loaded sources is permitted");
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireSingleMatch(0), "A missing or deleted element never establishes a clear result");
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireSingleMatch(2), "Matching host and linked numeric IDs need explicit mapping");

        var named = new ClashElementReference { ElementId = 42, SourceHint = "Structure.rvt" };
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireSourceCandidates(named, 2, false), "A repeated model name remains ambiguous even before element lookup");
        ClashVerificationPolicy.RequireSourceCandidates(named, 1, false);
        Check(true, "A single exact source name is permitted");
        var mapped = new ClashElementReference { ElementId = 42, SourceHint = "Old export name", SourceOverrideKey = "link:placement-a" };
        ClashVerificationPolicy.RequireSourceCandidates(mapped, 1, false);
        Check(true, "An explicit loaded placement resolves ambiguous report provenance");
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireSourceCandidates(mapped, 0, false), "A deleted placement mapping cannot fall back to a reused numeric link ID");
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireSourceCandidates(mapped, 1, true), "Explicit mapping cannot make an unloaded placement available");
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireSourceCandidates(mapped, 2, false), "Duplicate explicit source keys fail closed");

        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireReportedIdentity(null), "A missing reference is not a resolvable identity");
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireReportedIdentity(new ClashElementReference()), "A report needs an Element ID or UniqueId");
        foreach (long id in new[] { 0L, -1L, long.MinValue })
            Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireReportedIdentity(new ClashElementReference { ElementId = id, UniqueId = "uid-a" }), "A supplied invalid numeric identity cannot be ignored: " + id);
        ClashVerificationPolicy.RequireConsistentIdentity(automatic, 42, "uid-a", "host");
        ClashVerificationPolicy.RequireConsistentIdentity(new ClashElementReference { UniqueId = " uid-a " }, 42, "uid-a", "host");
        ClashVerificationPolicy.RequireConsistentIdentity(new ClashElementReference { ElementId = long.MaxValue }, long.MaxValue, "uid-large", "host");
        Check(true, "Numeric, trimmed UniqueId-only, and 64-bit identities are supported");
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireConsistentIdentity(automatic, 43, "uid-a", "host"), "An element-ID mismatch cannot be accepted");
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireConsistentIdentity(new ClashElementReference { ElementId = 42, UniqueId = "uid-b" }, 42, "uid-a", "host"), "Supplied numeric and unique identities must agree");
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireConsistentIdentity(automatic, 42, "", "host"), "An unavailable current UniqueId cannot establish exact identity");
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireConsistentIdentity(automatic, 42, "uid-a", ""), "An unavailable current source identity cannot establish exact identity");

        // These fields are the production identity pin retained across failed refreshes.
        automatic.ResolvedElementId = 42;
        automatic.ResolvedUniqueId = "uid-a";
        automatic.ResolvedSourceKey = "link:placement-a";
        ClashVerificationPolicy.RequireConsistentIdentity(automatic, 42, "uid-a", "link:placement-a");
        Check(true, "The exact previously resolved physical element remains usable");
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireSingleMatch(0), "Deletion after verification still requires review");
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireConsistentIdentity(automatic, 42, "uid-replacement", "link:placement-a"), "A newly created element reusing the numeric ID cannot inherit verified identity");
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireConsistentIdentity(automatic, 42, "uid-a", "link:placement-b"), "An identical linked model in a different placement is a different physical source");
        Check(automatic.ResolvedUniqueId == "uid-a" && automatic.ResolvedSourceKey == "link:placement-a", "Failed identity checks preserve the original pin");
        automatic.ResolvedUniqueId = "";
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireConsistentIdentity(automatic, 42, "uid-a", "link:placement-a"), "An incomplete prior identity pin cannot silently reset verification");

        ClashVerificationPolicy.RequireConsistentCategory("  PIPE\tFittings\r\n", "Pipe Fittings");
        ClashVerificationPolicy.RequireConsistentCategory("", "Pipes");
        ClashVerificationPolicy.RequireConsistentCategory(null, null);
        Check(true, "Reported categories normalize case and whitespace; an absent category adds no claim");
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireConsistentCategory("Pipes", "Walls"), "A contradictory category can indicate an ID reused before the first pin and requires review");
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireConsistentCategory("Pipe", "Pipes"), "Similar category names are not guessed to be equivalent");
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireConsistentCategory("Pipes", "(No category)"), "A missing current category cannot confirm a reported category");
        Throws<InvalidOperationException>(() => ClashVerificationPolicy.RequireConsistentCategory("Pipes", "Rohrleitungen"), "A possible localized category mismatch remains explicit review");
    }

    private static void VerifySourceProvenance()
    {
        string[] names = { "Structure", @"C:\Projects\Tower A\Structure.rvt", "Structure.rvt : 2" };
        Check(ClashVerificationPolicy.MatchesSource("Structure", names), "Exact document title matches");
        Check(ClashVerificationPolicy.MatchesSource("structure.RVT", names), "File comparison follows case-insensitive Windows model names");
        Check(ClashVerificationPolicy.MatchesSource("Structure.nwc", names), "Exported NWC filename identifies its RVT stem");
        Check(ClashVerificationPolicy.MatchesSource(" C:/Projects/Tower A/Structure.nwc ", names), "An exact full cache path matches the originating model path");
        Check(ClashVerificationPolicy.MatchesSource("\"C:\\Projects\\Tower A\\Structure.rvt\"", names), "Quoted paths preserve provenance");
        Check(!ClashVerificationPolicy.MatchesSource(@"C:\Projects\Tower B\Structure.rvt", names), "A different directory never falls back to a colliding basename");
        Check(!ClashVerificationPolicy.MatchesSource(@"D:\Projects\Tower A\Structure.nwc", names), "A different drive never falls back to the basename");
        Check(!ClashVerificationPolicy.MatchesSource("../Tower A/Structure.rvt", names), "An unestablished relative path requires explicit mapping");
        Check(!ClashVerificationPolicy.MatchesSource(@"C:\Projects\Tower A\Structure.rvt", new[] { "Structure" }), "An unavailable model path cannot be inferred from title alone");
        Check(!ClashVerificationPolicy.MatchesSource("Struct", names), "Source matching does not use substrings");
        Check(!ClashVerificationPolicy.MatchesSource("Structure.nwd", names), "A federation snapshot is not assumed to be its similarly named RVT");
        Check(!ClashVerificationPolicy.MatchesSource("Structure.rfa", names), "A family filename is not treated as a project source");
        Check(ClashVerificationPolicy.MatchesSource("Structure.rvt : 2", names), "An exact instance name remains usable");
        Check(!ClashVerificationPolicy.MatchesSource("", names), "An empty hint provides no identity");
        Check(!ClashVerificationPolicy.MatchesSource(null, names), "A missing hint provides no identity");
        Check(!ClashVerificationPolicy.MatchesSource("Structure", null), "Missing source names do not match");
        Check(!ClashVerificationPolicy.MatchesSource("Structure", new[] { "", null }), "Blank source names do not match");
        Check(ClashVerificationPolicy.MatchesSource(@"\\server\share\Structure.nwc", new[] { "//server/share/Structure.rvt" }), "UNC separators normalize without discarding the share");
        Check(!ClashVerificationPolicy.MatchesSource(@"\\server\other\Structure.nwc", new[] { "//server/share/Structure.rvt" }), "UNC shares remain part of source identity");
    }

    private static void VerifyCriteria()
    {
        Check(ClashVerificationPolicy.SupportsCriterion(ClashTestKind.Hard, false), "A reported Hard criterion is supported");
        Check(ClashVerificationPolicy.SupportsCriterion(ClashTestKind.Hard, true), "The unknown assumption does not disable a known Hard criterion");
        Check(!ClashVerificationPolicy.SupportsCriterion(ClashTestKind.Unknown, false), "Unknown criteria require the explicit assumption");
        Check(ClashVerificationPolicy.SupportsCriterion(ClashTestKind.Unknown, true), "The explicit assumption permits Unknown as Hard");
        foreach (var kind in new[] { ClashTestKind.Clearance, ClashTestKind.Duplicate, (ClashTestKind)999 })
        {
            Check(!ClashVerificationPolicy.SupportsCriterion(kind, false), "Unsupported criteria remain reviewable: " + kind);
            Check(!ClashVerificationPolicy.SupportsCriterion(kind, true), "The Hard assumption cannot override unsupported criteria: " + kind);
        }
        foreach (double value in new[] { 0.0, 1.0, 1000000.0 })
            Check(ClashVerificationPolicy.IsValidTolerance(value), "Supported tolerance: " + value);
        foreach (double value in new[] { -1.0, 1000000.1, double.NaN, double.PositiveInfinity, double.NegativeInfinity })
        {
            Check(!ClashVerificationPolicy.IsValidTolerance(value), "Invalid tolerance fails closed: " + value);
            Throws<ArgumentOutOfRangeException>(() => new ClashIntersectionEvidence(value), "Invalid tolerance cannot create geometry evidence");
        }
    }

    private static void VerifyIntersectionDecisions()
    {
        var empty = new ClashIntersectionEvidence(1);
        Check(empty.GetState(false) == ClashState.NeedsReview, "Missing geometry coverage cannot produce Solved");
        Check(empty.GetState(true) == ClashState.Solved, "Complete coverage with no intersecting bounds is clear");

        var touching = new ClashIntersectionEvidence(0);
        touching.Record(0);
        Check(touching.GetState(false) == ClashState.NeedsReview, "A touching pair does not prove unprocessed pairs clear");
        Check(touching.GetState(true) == ClashState.Solved, "Zero-volume contact is clear under the stated hard-clash criterion");
        touching.Record(0.0000001);
        Check(touching.GetState(false) == ClashState.Unsolved, "A positive witness exceeds a zero tolerance immediately");

        var below = new ClashIntersectionEvidence(1);
        below.Record(0.25); below.Record(0.25);
        Check(below.GetState(false) == ClashState.NeedsReview, "Partial sub-tolerance evidence stays NeedsReview");
        Check(below.GetState(true) == ClashState.Solved, "A complete upper bound below tolerance proves clear");
        below.Record(0.5);
        Check(below.GetState(true) == ClashState.Solved, "Tolerance is inclusive at its exact boundary");
        below.Record(0.125);
        Check(below.GetState(true) == ClashState.NeedsReview, "Multiple small overlapping intersections cannot be added to assert Unsolved");
        Check(below.TotalUpperBound == 1.125 && below.Largest == 0.5, "Evidence retains the accumulated upper bound and largest witness");

        var witness = new ClashIntersectionEvidence(1);
        witness.Record(1.0001);
        Check(witness.GetState(false) == ClashState.Unsolved, "A single above-tolerance intersection proves the clash remains");
        Check(witness.GetState(true) == ClashState.Unsolved, "Completing coverage cannot clear a witnessed clash");

        foreach (double value in new[] { -1.0, double.NaN, double.PositiveInfinity, double.NegativeInfinity })
            Throws<InvalidOperationException>(() => new ClashIntersectionEvidence(1).Record(value), "Invalid measured volume aborts verification: " + value);
        var overflow = new ClashIntersectionEvidence(1);
        overflow.Record(double.MaxValue);
        Throws<InvalidOperationException>(() => overflow.Record(double.MaxValue), "An overflowing upper bound aborts verification");
    }

    private static void Check(bool condition, string name)
    {
        if (!condition) throw new InvalidOperationException(name);
        checks++;
    }

    private static void Throws<T>(Action action, string name) where T : Exception
    {
        try { action(); }
        catch (T) { checks++; return; }
        throw new InvalidOperationException(name);
    }
}
