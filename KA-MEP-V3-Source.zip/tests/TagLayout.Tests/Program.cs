using System;
using System.Collections.Generic;
using System.Linq;
using PipeTakeoff.Core;

internal static class Program
{
    private static int passed;
    private static IEnumerable<TagLayoutPattern> LegacyPatterns()
    { return new[] { TagLayoutPattern.HorizontalRow, TagLayoutPattern.VerticalColumn, TagLayoutPattern.TwoColumns, TagLayoutPattern.StaggeredRows, TagLayoutPattern.DiagonalRow }; }
    private static int Main()
    {
        try
        {
            Check("Empty input returns an empty plan", Empty);
            Check("Every pattern accepts a single tag on both sides", Singles);
            Check("Horizontal labels retain source order and real width spacing", Horizontal);
            Check("Vertical labels retain descending view Y and real height spacing", Vertical);
            Check("Two columns use balanced source-side banks and opposite shoulders", TwoColumns);
            Check("Staggered rows use the chosen columns with an alternating half-step", Staggered);
            Check("Diagonal heads follow chosen angles and retain projection ordering", Diagonal);
            Check("Manual origins override automatic offsets", ManualOrigin);
            Check("View-plane coordinates remain translation equivariant", Translation);
            Check("Translated unequal-size diagonal banks preserve normal clearance near axis angles", TranslatedDiagonal);
            Check("Supplied obstacles report affected keys without moving tags", Obstacles);
            Check("Obstacle reports are capped with an accurate remainder", ObstacleSummary);
            Check("Input enumeration order never changes a keyed placement", Permutation);
            Check("Zero-gap variable-size layouts remain disjoint at large negative coordinates", LargeCoordinates);
            Check("Randomized patterns preserve rectangles, associations and parallel shoulders", Randomized);
            Check("Extreme aspect ratios and near-axis diagonal angles remain disjoint", ExtremeAspects);
            Check("Options reject invalid numeric values and enum casts", InvalidOptions);
            Check("Items reject duplicate keys, nulls and invalid dimensions", InvalidItems);
            Check("Invalid obstacles and unrepresentable output bounds are rejected", InvalidBounds);
            Check("Over-limit operation rejects before layout", Limit);
            Check("Near-host placement stays local across distant drawing clusters", NearHostLocal);
            Check("Near-host skips crowded candidates rather than spreading far away", NearHostCrowded);
            Check("Near-host routes around supplied obstacles with clear spacing", NearHostObstacles);
            Check("Near-host labels and elbows stay inside annotation bounds", NearHostCrop);
            Check("Near-host respects host footprints and never covers other supplied hosts", NearHostFootprints);
            Check("Near-host handles impossible labels and bounds with explicit skip keys", NearHostImpossible);
            Check("Near-host selection order and translations remain deterministic", NearHostStable);
            Check("Near-host validation rejects invalid bounds, distance and shared origin", NearHostValidation);
            Check("Near-host random dense scenes preserve distance, crop and collision constraints", NearHostRandomized);
            Check("Near-host bounded search handles 500 tags and 500 obstacles", NearHostBatch);
            Check("Right-angle leaders preserve every pattern's heads, bounds and skipped hosts", OrthogonalPatterns);
            Check("Right-angle geometry uses actual endpoints and supports aligned or coincident endpoints", OrthogonalEndpoints);
            Check("Right-angle geometry remains exact after translations and rejects invalid inputs", OrthogonalTranslation);
            Check("Out-of-crop orthogonal elbows warn without moving aligned heads", OrthogonalCrop);
            Console.WriteLine("PASS: " + passed + " Tag Assistant layout tests.");
            return 0;
        }
        catch (Exception ex) { Console.Error.WriteLine(ex.ToString()); return 1; }
    }

    private static void Check(string title, Action body) { body(); passed++; Console.WriteLine("PASS " + title); }
    private static TagLayoutItem Item(string key, double x, double y, double width = 4, double height = 2)
    { return new TagLayoutItem(key, new TagPoint(x, y), width, height); }
    private static TagLayoutOptions Options(TagLayoutPattern pattern, TagLayoutSide side = TagLayoutSide.Positive)
    { return new TagLayoutOptions { Pattern = pattern, Side = side, Spacing = 2, Offset = 5, Shoulder = 3, Columns = 3 }; }
    private static TagLayoutItem[] Sample()
    {
        return new[] { Item("a", -10, 6, 5, 2), Item("b", -4, -2, 12, 1), Item("c", 1, 1, 2, 6),
            Item("d", 3, -10, 7, 5), Item("e", 6, 4, 11, 2), Item("f", 8, 0, 3, 4), Item("g", 8, 0, 8, 3) };
    }

    private static void Empty()
    {
        var result = TagLayoutEngine.Arrange(new TagLayoutItem[0], new TagLayoutOptions());
        Assert(result.Placements.Count == 0 && result.Warnings.Count == 0, "Empty plan");
    }
    private static void Singles()
    {
        foreach (TagLayoutPattern pattern in LegacyPatterns())
        foreach (TagLayoutSide side in Enum.GetValues(typeof(TagLayoutSide)))
        {
            var result = TagLayoutEngine.Arrange(new[] { Item("single", -100, -200, 8, 4) }, Options(pattern, side));
            VerifyPlan(result, new[] { Item("single", -100, -200, 8, 4) }, 3);
            Assert(result.Placements.Count == 1 && result.Placements[0].Bank == (side == TagLayoutSide.Positive ? 1 : -1), "Single bank");
        }
    }
    private static void Horizontal()
    {
        var data = new[] { Item("c", 30, 1, 4, 2), Item("a", 10, -5, 2, 4), Item("b", 20, 0, 6, 3) };
        var plan = TagLayoutEngine.Arrange(data, Options(TagLayoutPattern.HorizontalRow));
        Assert(string.Join(",", plan.Placements.Select(x => x.Key)) == "a,b,c", "Left-to-right order");
        Near(plan.Placements[0].Head.X, 13); Near(plan.Placements[1].Head.X, 19); Near(plan.Placements[2].Head.X, 26);
        foreach (var placement in plan.Placements) { Near(placement.Head.Y, 8); Near(placement.Elbow.Y, 5); }
        VerifyPlan(plan, data, 3);
    }
    private static void Vertical()
    {
        var data = new[] { Item("bottom", -5, -30, 8, 6), Item("top", -1, -10, 2, 2), Item("middle", -2, -20, 5, 4) };
        var plan = TagLayoutEngine.Arrange(data, Options(TagLayoutPattern.VerticalColumn, TagLayoutSide.Negative));
        Assert(string.Join(",", plan.Placements.Select(x => x.Key)) == "top,middle,bottom", "Top-to-bottom order");
        Near(plan.Placements[0].Head.Y, -13); Near(plan.Placements[1].Head.Y, -18); Near(plan.Placements[2].Head.Y, -25);
        foreach (var placement in plan.Placements) { Near(placement.Head.X, -14); Near(placement.Elbow.X, -11); }
        VerifyPlan(plan, data, 3);
    }
    private static void TwoColumns()
    {
        var data = Sample(); var plan = TagLayoutEngine.Arrange(data, Options(TagLayoutPattern.TwoColumns));
        Assert(plan.Placements.Count(x => x.Bank == -1) == 4 && plan.Placements.Count(x => x.Bank == 1) == 3, "Balanced banks");
        foreach (var placement in plan.Placements)
        {
            if (placement.Bank == -1) Assert(placement.Bounds.Right <= -15 + 1e-9, "Left bank outside anchors");
            else Assert(placement.Bounds.Left >= 13 - 1e-9, "Right bank outside anchors");
            Near(placement.Elbow.X - placement.Head.X, -placement.Bank * 3);
        }
        VerifyPlan(plan, data, 3);
    }
    private static void Staggered()
    {
        var data = Enumerable.Range(0, 8).Select(i => Item(i.ToString(), i, 100 - i, 4, 2)).ToArray();
        var plan = TagLayoutEngine.Arrange(data, Options(TagLayoutPattern.StaggeredRows));
        Near(plan.Placements[1].Head.X - plan.Placements[0].Head.X, 6);
        Near(plan.Placements[3].Head.X - plan.Placements[0].Head.X, 3);
        Near(plan.Placements[3].Head.Y - plan.Placements[0].Head.Y, -4);
        Near(plan.Placements[6].Head.X, plan.Placements[0].Head.X);
        Assert(plan.Placements.Min(x => x.Bounds.Bottom) >= 105 - 1e-8, "Grid outside source anchors");
        var oneColumn = Options(TagLayoutPattern.StaggeredRows); oneColumn.Columns = 1;
        var narrow = TagLayoutEngine.Arrange(data, oneColumn);
        foreach (var tag in narrow.Placements) Near(tag.Head.X, narrow.Placements[0].Head.X);
        VerifyPlan(plan, data, 3); VerifyPlan(narrow, data, 3);
    }
    private static void Diagonal()
    {
        foreach (double angle in new[] { -180.0, -90, -45, 0, 15, 45, 90, 135, 180 })
        foreach (TagLayoutSide side in Enum.GetValues(typeof(TagLayoutSide)))
        {
            var data = Sample(); var options = Options(TagLayoutPattern.DiagonalRow, side); options.AngleDegrees = angle;
            var plan = TagLayoutEngine.Arrange(data, options);
            double radians = angle * Math.PI / 180, dx = Math.Cos(radians), dy = Math.Sin(radians);
            double lastSource = double.NegativeInfinity, lastHead = double.NegativeInfinity;
            double normal = -dy * plan.Placements[0].Head.X + dx * plan.Placements[0].Head.Y;
            double sourceEdge = side == TagLayoutSide.Positive ? data.Max(x => -dy * x.Anchor.X + dx * x.Anchor.Y) : data.Min(x => -dy * x.Anchor.X + dx * x.Anchor.Y);
            foreach (var tag in plan.Placements)
            {
                double sourceProjection = dx * tag.Anchor.X + dy * tag.Anchor.Y, headProjection = dx * tag.Head.X + dy * tag.Head.Y;
                Assert(sourceProjection >= lastSource && headProjection > lastHead, "Projected source and head order");
                Near(-dy * tag.Head.X + dx * tag.Head.Y, normal);
                double radius = (Math.Abs(dy) * tag.Bounds.Width + Math.Abs(dx) * tag.Bounds.Height) / 2;
                if (side == TagLayoutSide.Positive) Assert(normal - radius >= sourceEdge + 5 - 1e-8, "Positive normal clearance");
                else Assert(normal + radius <= sourceEdge - 5 + 1e-8, "Negative normal clearance");
                lastSource = sourceProjection; lastHead = headProjection;
            }
            VerifyPlan(plan, data, 3);
        }
    }
    private static void ManualOrigin()
    {
        foreach (TagLayoutPattern pattern in LegacyPatterns())
        {
            var options = Options(pattern); options.Origin = new TagPoint(500, -600);
            var a = TagLayoutEngine.Arrange(Sample(), options);
            options.Origin = new TagPoint(503, -596);
            var b = TagLayoutEngine.Arrange(Sample(), options);
            for (int i = 0; i < a.Placements.Count; i++)
            { Near(b.Placements[i].Head.X - a.Placements[i].Head.X, 3); Near(b.Placements[i].Head.Y - a.Placements[i].Head.Y, 4); }
            if (pattern != TagLayoutPattern.TwoColumns)
            {
                options.Offset = 12345;
                var c = TagLayoutEngine.Arrange(Sample(), options);
                for (int i = 0; i < b.Placements.Count; i++) Same(b.Placements[i].Head, c.Placements[i].Head, 1e-7);
            }
        }
    }
    private static void Translation()
    {
        foreach (TagLayoutPattern pattern in LegacyPatterns())
        {
            var source = Sample(); var moved = source.Select(x => Item(x.Key, x.Anchor.X - 1100, x.Anchor.Y + 900, x.Width, x.Height)).ToArray();
            var a = TagLayoutEngine.Arrange(source, Options(pattern)); var b = TagLayoutEngine.Arrange(moved, Options(pattern));
            for (int i = 0; i < a.Placements.Count; i++)
            { Near(b.Placements[i].Head.X - a.Placements[i].Head.X, -1100); Near(b.Placements[i].Head.Y - a.Placements[i].Head.Y, 900); }
        }
    }
    private static void Obstacles()
    {
        var options = Options(TagLayoutPattern.HorizontalRow);
        var baseline = TagLayoutEngine.Arrange(Sample(), options);
        var box = baseline.Placements[2].Bounds;
        var obstacles = new[] { new TagRectangle(box.Left + .1, box.Bottom + .1, box.Right - .1, box.Top - .1) };
        var result = TagLayoutEngine.Arrange(Sample(), options, obstacles);
        Assert(result.Warnings.Count == 1 && result.Warnings[0].Contains("'" + baseline.Placements[2].Key + "'"), "Correct obstacle key");
        for (int i = 0; i < baseline.Placements.Count; i++) Same(result.Placements[i].Head, baseline.Placements[i].Head);
        var touching = new TagRectangle(box.Right, box.Bottom, box.Right + .5, box.Top);
        Assert(!box.Intersects(touching), "Touching is not an intersection");
    }
    private static void TranslatedDiagonal()
    {
        var data = Sample().Select(x => Item(x.Key, x.Anchor.X - 1e7, x.Anchor.Y + 2e7, x.Width, x.Height)).ToArray();
        foreach (double angle in new[] { -90.00001, -89.99999, -.00001, .00001, 89.99999, 90.00001 })
        foreach (TagLayoutSide side in Enum.GetValues(typeof(TagLayoutSide)))
        {
            var options = Options(TagLayoutPattern.DiagonalRow, side); options.AngleDegrees = angle;
            var plan = TagLayoutEngine.Arrange(data, options);
            double nx = -Math.Sin(angle * Math.PI / 180), ny = Math.Cos(angle * Math.PI / 180);
            double edge = side == TagLayoutSide.Positive ? data.Max(x => nx * x.Anchor.X + ny * x.Anchor.Y) : data.Min(x => nx * x.Anchor.X + ny * x.Anchor.Y);
            foreach (var tag in plan.Placements)
            {
                double nearest = nx * tag.Head.X + ny * tag.Head.Y;
                double radius = (Math.Abs(nx) * tag.Bounds.Width + Math.Abs(ny) * tag.Bounds.Height) / 2;
                if (side == TagLayoutSide.Positive) Assert(nearest - radius >= edge + options.Offset - 1e-7, "Translated positive bank clearance");
                else Assert(nearest + radius <= edge - options.Offset + 1e-7, "Translated negative bank clearance");
            }
            VerifyPlan(plan, data, options.Shoulder, 1e-7);
        }
    }
    private static void ObstacleSummary()
    {
        var data = Enumerable.Range(0, 25).Select(i => Item(i.ToString(), i, 0)).ToArray();
        var result = TagLayoutEngine.Arrange(data, Options(TagLayoutPattern.HorizontalRow), new[] { new TagRectangle(-1000, -1000, 1000, 1000) });
        Assert(result.Warnings.Count == 21 && result.Warnings.Last().StartsWith("5 additional"), "Bounded accurate warning summary");
    }
    private static void Permutation()
    {
        foreach (TagLayoutPattern pattern in LegacyPatterns())
        {
            var options = Options(pattern); var data = Sample(); var a = TagLayoutEngine.Arrange(data, options);
            var b = TagLayoutEngine.Arrange(data.Reverse(), options);
            var c = TagLayoutEngine.Arrange(data.OrderBy(x => x.Key, StringComparer.Ordinal).Skip(3).Concat(data.OrderBy(x => x.Key, StringComparer.Ordinal).Take(3)), options);
            for (int i = 0; i < a.Placements.Count; i++)
            { Assert(a.Placements[i].Key == b.Placements[i].Key && a.Placements[i].Key == c.Placements[i].Key, "Stable enumeration"); Same(a.Placements[i].Head, b.Placements[i].Head, 0); Same(a.Placements[i].Head, c.Placements[i].Head, 0); }
        }
    }
    private static void LargeCoordinates()
    {
        var data = Enumerable.Range(0, 60).Select(i => Item(i.ToString(), -1e9 + i, -2e9 - i, .0002 + i % 3, .0003 + i % 7)).ToArray();
        foreach (TagLayoutPattern pattern in LegacyPatterns())
        {
            var options = Options(pattern); options.Spacing = 0; options.Offset = 0; options.Shoulder = 0;
            VerifyPlan(TagLayoutEngine.Arrange(data, options), data, 0, 1e-6);
        }
    }
    private static void Randomized()
    {
        var random = new Random(30717);
        for (int pass = 0; pass < 30; pass++)
        {
            var data = Enumerable.Range(0, 60).Select(i => Item(i.ToString(), random.Next(-500, 501), random.Next(-500, 501), .01 + random.NextDouble() * 30, .01 + random.NextDouble() * 12)).ToArray();
            foreach (TagLayoutPattern pattern in LegacyPatterns())
            foreach (TagLayoutSide side in Enum.GetValues(typeof(TagLayoutSide)))
            {
                var options = Options(pattern, side); options.Spacing = pass % 3 == 0 ? 0 : random.NextDouble() * 3; options.Columns = pass % 9 + 1; options.AngleDegrees = random.NextDouble() * 360 - 180;
                VerifyPlan(TagLayoutEngine.Arrange(data, options), data, 3);
            }
        }
    }
    private static void ExtremeAspects()
    {
        var data = Enumerable.Range(0, 20).Select(i => Item(i.ToString(), -100 + i, -200 + i, i % 2 == 0 ? 10000 : .0001, i % 2 == 0 ? .0001 : 10000)).ToArray();
        foreach (double angle in new[] { -179.999, -90.001, -89.999, -.001, 0, .001, 44.99, 89.999, 90.001, 179.999 })
        {
            var options = Options(TagLayoutPattern.DiagonalRow); options.AngleDegrees = angle; options.Spacing = 0;
            VerifyPlan(TagLayoutEngine.Arrange(data, options), data, 3);
        }
    }
    private static void InvalidOptions()
    {
        foreach (double invalid in new[] { -1, double.NaN, double.PositiveInfinity, double.NegativeInfinity, 1e13 })
        {
            Throws(() => TagLayoutEngine.Arrange(Sample(), new TagLayoutOptions { Spacing = invalid }));
            Throws(() => TagLayoutEngine.Arrange(Sample(), new TagLayoutOptions { Offset = invalid }));
            Throws(() => TagLayoutEngine.Arrange(Sample(), new TagLayoutOptions { Shoulder = invalid }));
        }
        foreach (double invalid in new[] { -181, 181, double.NaN, double.PositiveInfinity }) Throws(() => TagLayoutEngine.Arrange(Sample(), new TagLayoutOptions { AngleDegrees = invalid }));
        Throws(() => TagLayoutEngine.Arrange(Sample(), new TagLayoutOptions { Columns = 0 }));
        Throws(() => TagLayoutEngine.Arrange(Sample(), new TagLayoutOptions { Pattern = (TagLayoutPattern)100 }));
        Throws(() => TagLayoutEngine.Arrange(Sample(), new TagLayoutOptions { Side = (TagLayoutSide)100 }));
        Throws(() => TagLayoutEngine.Arrange(Sample(), new TagLayoutOptions { Origin = new TagPoint(double.NaN, 0) }));
        Throws(() => TagLayoutEngine.Arrange(Sample(), null));
    }
    private static void InvalidItems()
    {
        Throws(() => TagLayoutEngine.Arrange(null, new TagLayoutOptions()));
        Throws(() => TagLayoutEngine.Arrange(new TagLayoutItem[] { null }, new TagLayoutOptions()));
        Throws(() => TagLayoutEngine.Arrange(new[] { Item("", 0, 0) }, new TagLayoutOptions()));
        Throws(() => TagLayoutEngine.Arrange(new[] { Item("a", 0, 0), Item("a", 1, 1) }, new TagLayoutOptions()));
        foreach (double invalid in new[] { 0, -1, double.NaN, double.PositiveInfinity, 1e13 })
        {
            Throws(() => TagLayoutEngine.Arrange(new[] { Item("a", 0, 0, invalid, 1) }, new TagLayoutOptions()));
            Throws(() => TagLayoutEngine.Arrange(new[] { Item("a", 0, 0, 1, invalid) }, new TagLayoutOptions()));
        }
        Throws(() => TagLayoutEngine.Arrange(new[] { Item("a", double.NaN, 0) }, new TagLayoutOptions()));
        Throws(() => TagLayoutEngine.Arrange(new[] { Item("a", 0, 1e13) }, new TagLayoutOptions()));
    }
    private static void InvalidBounds()
    {
        Throws(() => TagLayoutEngine.Arrange(Sample(), new TagLayoutOptions(), new[] { new TagRectangle(0, 0, 0, 1) }));
        Throws(() => TagLayoutEngine.Arrange(Sample(), new TagLayoutOptions(), new[] { new TagRectangle(0, 0, 1, double.NaN) }));
        Throws(() => TagLayoutEngine.Arrange(new[] { Item("a", 1e12, 1e12) }, new TagLayoutOptions()));
        Throws(() => TagLayoutEngine.Arrange(new[] { Item("a", 0, 0, double.Epsilon, double.Epsilon) }, new TagLayoutOptions { Origin = new TagPoint(1e9, 1e9) }));
    }
    private static void Limit()
    {
        Throws(() => TagLayoutEngine.Arrange(Enumerable.Range(0, TagLayoutEngine.MaximumItems + 1).Select(i => Item(i.ToString(), 0, 0)), new TagLayoutOptions()));
        Throws(() => TagLayoutEngine.Arrange(Sample(), new TagLayoutOptions(), Enumerable.Repeat(new TagRectangle(0, 0, 1, 1), TagLayoutEngine.MaximumObstacles + 1)));
    }

    private static TagLayoutOptions LocalOptions()
    {
        return new TagLayoutOptions { Pattern = TagLayoutPattern.NearHost, Spacing = 1, Offset = 3, Shoulder = 2, MaximumDistance = 20 };
    }
    private static void NearHostLocal()
    {
        var source = new[] { Item("a", 0, 0, 25, 4), Item("b", 10000, 10000, 25, 4), Item("c", -10000, -10000, 25, 4) };
        var options = LocalOptions();
        var result = TagLayoutEngine.Arrange(source, options);
        Assert(result.Placements.Count == 3 && result.SkippedKeys.Count == 0, "Separated host tags all fit");
        VerifyLocal(result, source, options);
        foreach (var tag in result.Placements) { Near(tag.Head.X, tag.Anchor.X); Near(tag.Head.Y - tag.Anchor.Y, 5, 1e-7); }
        options.Side = TagLayoutSide.Negative;
        result = TagLayoutEngine.Arrange(source, options);
        foreach (var tag in result.Placements) { Near(tag.Head.Y - tag.Anchor.Y, -5, 1e-7); Assert(tag.Bank == -1, "Preferred negative bank"); }
    }
    private static void NearHostCrowded()
    {
        var source = Enumerable.Range(0, 40).Select(i => Item(i.ToString("D2"), 0, 0, 8, 2)).ToArray();
        var options = LocalOptions(); options.MaximumDistance = 10;
        var result = TagLayoutEngine.Arrange(source, options);
        Assert(result.Placements.Count > 0 && result.SkippedKeys.Count > 0, "Crowding creates explicit skips");
        VerifyLocal(result, source, options);
        Assert(result.Warnings.Any(w => w.Contains("skipped")), "Skip explanation");
    }
    private static void NearHostObstacles()
    {
        var source = new[] { Item("a", 0, 0, 8, 2) }; var options = LocalOptions();
        var clear = TagLayoutEngine.Arrange(source, options);
        var obstacle = clear.Placements.Single().Bounds;
        var result = TagLayoutEngine.Arrange(source, options, new[] { obstacle });
        Assert(result.Placements.Count == 1, "Nearby alternate placement exists");
        Assert(result.Placements[0].Head.Y < 0, "Nearest alternate below blocked upper location");
        VerifyLocal(result, source, options, new[] { obstacle });
    }
    private static void NearHostCrop()
    {
        var options = LocalOptions(); options.AllowedBounds = new TagRectangle(-20, -20, 20, 20);
        var source = new[] { Item("upper-right", 19, 19, 10, 2), Item("lower-left", -19, -19, 10, 2) };
        var result = TagLayoutEngine.Arrange(source, options);
        Assert(result.Placements.Count == 2, "Both corner tags fit using inward alternatives");
        VerifyLocal(result, source, options);
        var impossible = new[] { Item("too-wide", 0, 0, 50, 2) };
        result = TagLayoutEngine.Arrange(impossible, options);
        Assert(result.Placements.Count == 0 && result.SkippedKeys.Single() == "too-wide", "Crop cannot fit label width");
    }
    private static void NearHostFootprints()
    {
        var source = new[] {
            new TagLayoutItem("equipment", new TagPoint(0, 0), 8, 2) { HostBounds = new TagRectangle(-5, -3, 5, 3) },
            new TagLayoutItem("terminal", new TagPoint(0, 7), 8, 2) { HostBounds = new TagRectangle(-4, 6, 4, 8) }
        };
        var options = LocalOptions(); var result = TagLayoutEngine.Arrange(source, options);
        Assert(result.Placements.Count == 2, "Equipment and terminal have safe nearby locations");
        VerifyLocal(result, source, options, source.Select(x => x.HostBounds.Value).ToArray());
        source[0].HostBounds = new TagRectangle(-40, -40, 40, 40);
        result = TagLayoutEngine.Arrange(source, options);
        Assert(result.SkippedKeys.Count == 2, "Large equipment footprint blocks both unsafe local labels");
    }
    private static void NearHostImpossible()
    {
        var source = Enumerable.Range(0, 25).Select(i => Item(i.ToString(), 0, 0, 10, 4)).ToArray();
        var options = LocalOptions(); var obstacles = new[] { new TagRectangle(-100, -100, 100, 100) };
        var result = TagLayoutEngine.Arrange(source, options, obstacles);
        Assert(result.Placements.Count == 0 && result.SkippedKeys.Count == 25, "Blocked scene has no forced placements");
        Assert(result.Warnings.Count == 21 && result.Warnings.Last().StartsWith("5 additional"), "Skip warning limit retains accurate remainder");
        VerifyLocal(result, source, options, obstacles);
        options.MaximumDistance = 1;
        result = TagLayoutEngine.Arrange(new[] { Item("far", 0, 0) }, options);
        Assert(result.Placements.Count == 0 && result.SkippedKeys.Single() == "far", "No distance fallback");
    }
    private static void NearHostStable()
    {
        var source = Sample(); var options = LocalOptions();
        var a = TagLayoutEngine.Arrange(source, options); var b = TagLayoutEngine.Arrange(source.Reverse(), options);
        Assert(string.Join(",", a.SkippedKeys) == string.Join(",", b.SkippedKeys), "Stable skip ordering");
        for (int i = 0; i < a.Placements.Count; i++)
        { Assert(a.Placements[i].Key == b.Placements[i].Key, "Stable placement ordering"); Same(a.Placements[i].Head, b.Placements[i].Head, 0); }
        var translated = source.Select(x => Item(x.Key, x.Anchor.X + 1000, x.Anchor.Y - 500, x.Width, x.Height)).ToArray();
        b = TagLayoutEngine.Arrange(translated, options);
        Assert(string.Join(",", a.Placements.Select(p => p.Key)) == string.Join(",", b.Placements.Select(p => p.Key)), "Stable translated candidates");
        for (int i = 0; i < a.Placements.Count; i++)
        { Near(b.Placements[i].Head.X - a.Placements[i].Head.X, 1000, 1e-7); Near(b.Placements[i].Head.Y - a.Placements[i].Head.Y, -500, 1e-7); }
    }
    private static void NearHostValidation()
    {
        var source = new[] { Item("a", 0, 0) };
        foreach (var invalid in new[] { 0, -1, double.NaN, double.PositiveInfinity, 1e13 })
        { var options = LocalOptions(); options.MaximumDistance = invalid; Throws(() => TagLayoutEngine.Arrange(source, options)); }
        var origin = LocalOptions(); origin.Origin = new TagPoint(0, 0); Throws(() => TagLayoutEngine.Arrange(source, origin));
        var crop = LocalOptions(); crop.AllowedBounds = new TagRectangle(0, 0, 0, 20); Throws(() => TagLayoutEngine.Arrange(source, crop));
        source[0].HostBounds = new TagRectangle(0, 0, 2, double.NaN); Throws(() => TagLayoutEngine.Arrange(source, LocalOptions()));
    }
    private static void NearHostRandomized()
    {
        var random = new Random(20261021);
        for (int pass = 0; pass < 60; pass++)
        {
            var options = LocalOptions(); options.Spacing = random.NextDouble() * 2; options.Offset = random.NextDouble() * 4;
            options.MaximumDistance = 5 + random.NextDouble() * 20; options.AllowedBounds = new TagRectangle(-60, -60, 60, 60);
            options.Side = pass % 2 == 0 ? TagLayoutSide.Positive : TagLayoutSide.Negative;
            var source = Enumerable.Range(0, 60).Select(i => Item(i.ToString(), random.Next(-60, 61), random.Next(-60, 61), 2 + random.NextDouble() * 18, 1 + random.NextDouble() * 5)).ToArray();
            var obstacles = Enumerable.Range(0, 12).Select(i => { double x = random.Next(-50, 51), y = random.Next(-50, 51); return new TagRectangle(x, y, x + 5, y + 3); }).ToArray();
            var result = TagLayoutEngine.Arrange(source, options, obstacles);
            VerifyLocal(result, source, options, obstacles);
        }
    }
    private static void NearHostBatch()
    {
        var source = Enumerable.Range(0, 500).Select(i => Item(i.ToString(), (i % 25) * 40, (i / 25) * 40, 8, 2)).ToArray();
        var obstacles = source.Select(x => new TagRectangle(x.Anchor.X - 4, x.Anchor.Y + 3, x.Anchor.X + 4, x.Anchor.Y + 5)).ToArray();
        var options = LocalOptions(); var watch = System.Diagnostics.Stopwatch.StartNew();
        var result = TagLayoutEngine.Arrange(source, options, obstacles);
        Assert(result.Placements.Count == 500, "500 independent host neighborhoods fit");
        VerifyLocal(result, source, options, obstacles);
        Console.WriteLine("  500-host bounded layout elapsed: " + watch.ElapsedMilliseconds + " ms");
    }
    private static void OrthogonalPatterns()
    {
        foreach (TagLayoutPattern pattern in Enum.GetValues(typeof(TagLayoutPattern)))
        foreach (TagLayoutSide side in Enum.GetValues(typeof(TagLayoutSide)))
        {
            var options = Options(pattern, side);
            var plain = TagLayoutEngine.Arrange(Sample(), options);
            options.OrthogonalLeaders = true;
            var rightAngle = TagLayoutEngine.Arrange(Sample(), options);
            Assert(plain.SkippedKeys.SequenceEqual(rightAngle.SkippedKeys), "Leader style cannot change eligibility");
            Assert(plain.Placements.Count == rightAngle.Placements.Count, "Same head count");
            for (int i = 0; i < plain.Placements.Count; i++)
            {
                var old = plain.Placements[i]; var p = rightAngle.Placements[i];
                Assert(old.Key == p.Key && old.Bank == p.Bank, "Same host and bank");
                Same(old.Head, p.Head); Same(old.Anchor, p.Anchor);
                Near(old.Bounds.Left, p.Bounds.Left); Near(old.Bounds.Right, p.Bounds.Right);
                Near(old.Bounds.Top, p.Bounds.Top); Near(old.Bounds.Bottom, p.Bounds.Bottom);
                VerifyRightAngle(p.Anchor, p.Elbow, p.Head);
            }
        }
    }

    private static void OrthogonalEndpoints()
    {
        foreach (TagLayoutPattern pattern in Enum.GetValues(typeof(TagLayoutPattern)))
        foreach (var head in new[] { new TagPoint(12, 19), new TagPoint(-12, 19), new TagPoint(12, -19), new TagPoint(-12, -19), new TagPoint(5, 19), new TagPoint(12, 7), new TagPoint(5, 7) })
        {
            var end = new TagPoint(5, 7); var elbow = TagLayoutEngine.OrthogonalElbow(end, head, pattern);
            VerifyRightAngle(end, elbow, head);
            Assert(elbow.X >= Math.Min(end.X, head.X) && elbow.X <= Math.Max(end.X, head.X) &&
                elbow.Y >= Math.Min(end.Y, head.Y) && elbow.Y <= Math.Max(end.Y, head.Y), "Bend never overshoots endpoints");
        }
    }

    private static void OrthogonalTranslation()
    {
        foreach (TagLayoutPattern pattern in Enum.GetValues(typeof(TagLayoutPattern)))
        {
            var a = TagLayoutEngine.OrthogonalElbow(new TagPoint(1, 3), new TagPoint(-5, 8), pattern);
            var b = TagLayoutEngine.OrthogonalElbow(new TagPoint(100001, -299997), new TagPoint(99995, -299992), pattern);
            Same(new TagPoint(a.X + 100000, a.Y - 300000), b);
        }
        Throws(() => TagLayoutEngine.OrthogonalElbow(new TagPoint(double.NaN, 0), new TagPoint(), TagLayoutPattern.NearHost));
        Throws(() => TagLayoutEngine.OrthogonalElbow(new TagPoint(), new TagPoint(double.PositiveInfinity, 0), TagLayoutPattern.NearHost));
        Throws(() => TagLayoutEngine.OrthogonalElbow(new TagPoint(), new TagPoint(), (TagLayoutPattern)1234));
    }

    private static void OrthogonalCrop()
    {
        var data = new[] { Item("outside-anchor", -1, 5, 1, 1) };
        var options = new TagLayoutOptions { Pattern = TagLayoutPattern.NearHost, Offset = 1, Spacing = 0.1, Shoulder = 0,
            MaximumDistance = 10, AllowedBounds = new TagRectangle(0, 0, 10, 10) };
        var original = TagLayoutEngine.Arrange(data, options);
        options.OrthogonalLeaders = true;
        var converted = TagLayoutEngine.Arrange(data, options);
        Assert(original.Placements.Count == 1 && converted.Placements.Count == 1, "Fixture has a nearby head inside crop");
        Same(original.Placements[0].Head, converted.Placements[0].Head);
        Assert(converted.Placements[0].Elbow.X < 0 && converted.Warnings.Any(w => w.Contains("right-angle leader elbows")), "Outside elbow must warn");
    }

    private static void VerifyRightAngle(TagPoint end, TagPoint elbow, TagPoint head)
    {
        Assert(end.X == elbow.X || end.Y == elbow.Y, "Endpoint leg is axis aligned");
        Assert(head.X == elbow.X || head.Y == elbow.Y, "Head leg is axis aligned");
        Near((end.X - elbow.X) * (head.X - elbow.X) + (end.Y - elbow.Y) * (head.Y - elbow.Y), 0);
    }

    private static void VerifyLocal(TagLayoutResult result, IList<TagLayoutItem> source, TagLayoutOptions options, IList<TagRectangle> obstacles = null)
    {
        var keys = result.Placements.Select(x => x.Key).Concat(result.SkippedKeys).ToList();
        Assert(keys.Count == source.Count && keys.Distinct().Count() == source.Count && source.All(x => keys.Contains(x.Key)), "Each candidate is placed once or explicitly skipped");
        foreach (var placement in result.Placements)
        {
            var item = source.Single(x => x.Key == placement.Key); Same(placement.Anchor, item.Anchor);
            Near(placement.Bounds.Width, item.Width, 1e-7); Near(placement.Bounds.Height, item.Height, 1e-7);
            double dx = placement.Head.X - placement.Anchor.X, dy = placement.Head.Y - placement.Anchor.Y;
            Assert(dx * dx + dy * dy <= options.MaximumDistance * options.MaximumDistance, "Hard anchor-distance limit");
            Near(placement.Elbow.Y, placement.Head.Y); Near(placement.Elbow.X - placement.Head.X, -placement.Bank * options.Shoulder, 1e-7);
            if (options.AllowedBounds.HasValue)
            {
                var crop = options.AllowedBounds.Value;
                Assert(placement.Bounds.Left >= crop.Left && placement.Bounds.Right <= crop.Right && placement.Bounds.Bottom >= crop.Bottom && placement.Bounds.Top <= crop.Top, "Label within crop");
                Assert(placement.Elbow.X >= crop.Left && placement.Elbow.X <= crop.Right && placement.Elbow.Y >= crop.Bottom && placement.Elbow.Y <= crop.Top, "Elbow within crop");
            }
            foreach (var obstacle in (obstacles ?? new TagRectangle[0]).Concat(result.Placements.Where(x => x.Key != placement.Key).Select(x => x.Bounds)))
            {
                var b = placement.Bounds;
                bool overlapWithGap = b.Left < obstacle.Right + options.Spacing && b.Right > obstacle.Left - options.Spacing && b.Bottom < obstacle.Top + options.Spacing && b.Top > obstacle.Bottom - options.Spacing;
                Assert(!overlapWithGap, "Local label collision or insufficient spacing: " + placement.Key);
            }
        }
    }

    private static void VerifyPlan(TagLayoutResult plan, IEnumerable<TagLayoutItem> source, double shoulder, double tolerance = 1e-8)
    {
        var byKey = source.ToDictionary(x => x.Key, StringComparer.Ordinal);
        Assert(plan.Placements.Count == byKey.Count, "Exactly one placement per source");
        Assert(plan.Placements.Select(x => x.Key).Distinct(StringComparer.Ordinal).Count() == byKey.Count, "No duplicate placements");
        var bankShoulders = new Dictionary<int, TagPoint>();
        foreach (var tag in plan.Placements)
        {
            var original = byKey[tag.Key]; Same(tag.Anchor, original.Anchor);
            Near(tag.Bounds.Width, original.Width, tolerance); Near(tag.Bounds.Height, original.Height, tolerance);
            Near((tag.Bounds.Left + tag.Bounds.Right) / 2, tag.Head.X, tolerance); Near((tag.Bounds.Bottom + tag.Bounds.Top) / 2, tag.Head.Y, tolerance);
            var vector = new TagPoint(tag.Elbow.X - tag.Head.X, tag.Elbow.Y - tag.Head.Y);
            Near(Math.Sqrt(vector.X * vector.X + vector.Y * vector.Y), shoulder, tolerance);
            TagPoint first;
            if (bankShoulders.TryGetValue(tag.Bank, out first)) Same(vector, first, tolerance); else bankShoulders.Add(tag.Bank, vector);
        }
        for (int i = 0; i < plan.Placements.Count; i++)
        for (int j = i + 1; j < plan.Placements.Count; j++)
            Assert(!plan.Placements[i].Bounds.Intersects(plan.Placements[j].Bounds), "Text overlap: " + plan.Placements[i].Key + "/" + plan.Placements[j].Key);
    }
    private static void Assert(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
    private static void Near(double actual, double expected, double tolerance = 1e-8)
    { if (double.IsNaN(actual) || Math.Abs(actual - expected) > tolerance) throw new InvalidOperationException("Expected " + expected + ", got " + actual + " (tolerance " + tolerance + ")."); }
    private static void Same(TagPoint actual, TagPoint expected, double tolerance = 1e-8) { Near(actual.X, expected.X, tolerance); Near(actual.Y, expected.Y, tolerance); }
    private static void Throws(Action action)
    { try { action(); } catch (ArgumentException) { return; } throw new InvalidOperationException("Expected an argument validation failure."); }
}
