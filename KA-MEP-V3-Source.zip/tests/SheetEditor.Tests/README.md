# Sheet Editor detached model tests

Run with the .NET 8 SDK:

```sh
dotnet run --project tests/SheetEditor.Tests/SheetEditor.Tests.csproj -c Release
```

The console harness links the actual detached `SheetEditorModels.cs`; it requires neither Revit nor external test packages. Cases cover checked-sheet scope, parameter identity, staged values and original fingerprints, type validation, required sheet labels, final-number collisions and swaps, protected revision assignments, review rows, and reset behavior.

These tests do not execute Autodesk transactions or Revit's unit parsing. Unit-bearing numeric input is deliberately retained by the detached model for the service's Revit API preflight. Live Revit smoke testing remains required for parameter writes, worksharing ownership, revision-cloud membership, and transaction rollback.
