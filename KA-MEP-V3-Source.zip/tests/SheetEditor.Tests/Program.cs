using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using PipeTakeoff.Revit;

internal static class Program
{
    private static int passed;
    private static int failed;

    private static int Main()
    {
        Run("Staging changes detached values and preserves original identity and fingerprints", OriginalValues);
        Run("Parameter keys distinguish duplicate display names and shared identities", ParameterIdentity);
        Run("Staging is confined to checked sheet IDs and ignores repeated IDs", CheckedScope);
        Run("Mixed batch reports eligible, unchanged, missing and locked sheets accurately", MixedBatch);
        Run("Empty and null checked scopes never expand to all sheets", EmptyScope);
        Run("String whitespace, Unicode, line breaks and literal symbols are preserved", LiteralStrings);
        Run("Null text becomes an empty value and matches an original empty value", NullText);
        Run("Read-only parameters cannot be staged", ReadOnlyStaging);
        Run("Tampering with a read-only value is caught again during final validation", ReadOnlyValidation);
        Run("Locked sheets reject value and revision changes, including direct mutation", LockedSheets);
        Run("Element reference, unsupported and unknown kinds require a specialized editor", UnsupportedKinds);
        Run("Integer boundaries accept signed 32-bit values", IntegerBoundaries);
        Run("Invalid, fractional, empty and overflowing integer input is rejected", InvalidIntegers);
        Run("Boolean aliases normalize to Yes or No", BooleanAliases);
        Run("Boolean no-ops use the canonical value", BooleanNoOp);
        Run("Unrecognized and empty boolean inputs are rejected without mutation", InvalidBooleans);
        Run("Non-finite number literals and blank numeric values are rejected", InvalidNumbers);
        Run("Unit-bearing numeric text is preserved for Revit unit-aware preflight", NumberUnits);
        Run("Sheet names and sheet numbers cannot be cleared", RequiredSheetLabels);
        Run("Invalid values injected after staging remain invalid at final validation", TamperedValues);
        Run("An edited sheet number is checked against untouched sheets", DuplicateWithUntouched);
        Run("Sheet number conflicts are case-insensitive", CaseInsensitiveDuplicates);
        Run("Final staged numbers permit two-sheet swaps and three-sheet cycles", NumberSwaps);
        Run("An unchanged sheet without a number parameter still participates in conflicts", NumberFallback);
        Run("Batching one sheet number onto multiple sheets is rejected before apply", BatchNumberConflict);
        Run("Unrelated edits do not reject an unchanged number inventory", NoNumberEdit);
        Run("Revision inclusion and removal preserve original assignments", RevisionStaging);
        Run("Repeated revision additions and removals are idempotent", RevisionIdempotence);
        Run("Issued revision assignments cannot be added or removed", IssuedRevisions);
        Run("Cloud-required revisions cannot be removed or explicitly staged", CloudRevisions);
        Run("Unknown revision IDs are skipped and injected assignments are rejected", UnknownRevisions);
        Run("Protected revision changes injected after staging are caught by validation", TamperedRevisions);
        Run("Mixed revision batches honor checked scope and report skipped locks", RevisionBatch);
        Run("Changes contain original and proposed values with sheet identity", ChangeReview);
        Run("Revision changes have meaningful before and after labels", RevisionChangeReview);
        Run("Undoing staged values and revision changes removes no-op review rows", RevertedChanges);
        Run("Selective reset only restores the requested sheets", SelectiveReset);
        Run("Empty reset scope leaves all staged changes intact", EmptyReset);
        Run("Full reset restores independent original revision sets and all values", FullReset);
        Console.WriteLine("RESULT: " + passed + "/" + (passed + failed) + " detached Sheet Editor behavior cases passed; " + failed + " failed.");
        return failed == 0 ? 0 : 1;
    }

    private static void OriginalValues()
    {
        var snapshot = Snapshot(); var sheet = snapshot.Sheets[0]; var parameter = Param(sheet, "name");
        var result = Stage(snapshot, "name", "Revised plan", sheet.Id);
        Counts(result, 1, 0, 0);
        Equal("Revised plan", parameter.Value); Equal("Level 01", parameter.OriginalValue);
        Equal("fingerprint-name-1", parameter.OriginalFingerprint);
        Equal("Level 01", sheet.Name); Equal("A-001", sheet.Number); Equal("sheet-1", sheet.UniqueId);
        Assert(parameter.Changed && sheet.Changed, "Staged change was not recognized"); Valid(snapshot);
    }

    private static void ParameterIdentity()
    {
        var snapshot = Snapshot(); var sheet = snapshot.Sheets[0];
        sheet.Parameters.Add(Text("shared:111", "same name", "First"));
        sheet.Parameters.Add(Text("shared:222", "same name", "Second"));
        sheet.Parameters.Add(Text("id:333", "same name", "Third"));
        Counts(Stage(snapshot, "shared:222", "Only this one", sheet.Id), 1, 0, 0);
        Equal("First", Param(sheet, "shared:111").Value);
        Equal("Only this one", Param(sheet, "shared:222").Value);
        Equal("Third", Param(sheet, "id:333").Value);
        Counts(Stage(snapshot, "same name", "Unsafe name lookup", sheet.Id), 0, 0, 1);
    }

    private static void CheckedScope()
    {
        var snapshot = Snapshot();
        Counts(Stage(snapshot, "drawn", "KA", 1, 1, 999), 1, 0, 0);
        Equal("KA", Param(snapshot.Sheets[0], "drawn").Value);
        Equal("Original", Param(snapshot.Sheets[1], "drawn").Value);
        Equal("Original", Param(snapshot.Sheets[2], "drawn").Value);
    }

    private static void MixedBatch()
    {
        var snapshot = Snapshot();
        Param(snapshot.Sheets[1], "drawn").OriginalValue = Param(snapshot.Sheets[1], "drawn").Value = "KA";
        snapshot.Sheets[2].Parameters.Remove(Param(snapshot.Sheets[2], "drawn"));
        var locked = Sheet(4); locked.ReadOnlyReason = "Owned by another user"; snapshot.Sheets.Add(locked);
        var readOnly = Sheet(5); Param(readOnly, "drawn").IsReadOnly = true; snapshot.Sheets.Add(readOnly);
        var result = Stage(snapshot, "drawn", "KA", 1, 2, 3, 4, 5);
        Counts(result, 1, 1, 3);
        Equal("1 staged, 1 unchanged, 3 skipped.", result.Summary);
        Assert(result.Skipped.Any(s => s.Contains("A-003")) && result.Skipped.Any(s => s.Contains("Owned by another user")), "Skipped rows need a sheet and reason");
        Equal("Original", Param(locked, "drawn").Value); Equal("Original", Param(readOnly, "drawn").Value);
    }

    private static void EmptyScope()
    {
        var snapshot = Snapshot();
        Counts(Stage(snapshot, "drawn", "New"), 0, 0, 0);
        Counts(SheetEditorModel.StageValue(snapshot, null, "drawn", "New"), 0, 0, 0);
        Counts(SheetEditorModel.StageRevision(snapshot, null, 10, true), 0, 0, 0);
        Equal(0, SheetEditorModel.Changes(snapshot).Count);
    }

    private static void LiteralStrings()
    {
        var snapshot = Snapshot();
        const string value = "  كريم أيمن — مخطط كهرباء\n楼层 ٠١ / ' & < > $()  ";
        Counts(Stage(snapshot, "drawn", value, 1), 1, 0, 0);
        Equal(value, Param(snapshot.Sheets[0], "drawn").Value); Valid(snapshot);
        Counts(Stage(snapshot, "drawn", "  ", 1), 1, 0, 0); Equal("  ", Param(snapshot.Sheets[0], "drawn").Value);
    }

    private static void NullText()
    {
        var snapshot = Snapshot(); var parameter = Param(snapshot.Sheets[0], "drawn");
        Counts(Stage(snapshot, "drawn", null, 1), 1, 0, 0); Equal("", parameter.Value);
        parameter.OriginalValue = null;
        Assert(!parameter.Changed, "Null original and empty current text should be equivalent");
        Counts(Stage(snapshot, "drawn", null, 1), 0, 1, 0);
    }

    private static void ReadOnlyStaging()
    {
        var snapshot = Snapshot(); var parameter = Param(snapshot.Sheets[0], "drawn");
        parameter.IsReadOnly = true; parameter.ReadOnlyReason = "Calculated by Revit";
        var result = Stage(snapshot, "drawn", "New", 1); Counts(result, 0, 0, 1);
        Assert(result.Skipped[0].Contains("Calculated by Revit"), "Read-only explanation omitted");
        Equal("Original", parameter.Value); Valid(snapshot);
        parameter.ReadOnlyReason = null; Counts(Stage(snapshot, "drawn", "New", 1), 0, 0, 1);
    }

    private static void ReadOnlyValidation()
    {
        var snapshot = Snapshot(); var parameter = Param(snapshot.Sheets[0], "drawn");
        parameter.IsReadOnly = true; parameter.Value = "Injected value";
        Invalid(snapshot, "Read-only");
    }

    private static void LockedSheets()
    {
        var snapshot = Snapshot(); var sheet = snapshot.Sheets[0]; sheet.ReadOnlyReason = "Sheet unavailable";
        Counts(Stage(snapshot, "drawn", "New", 1), 0, 0, 1);
        Counts(SheetEditorModel.StageRevision(snapshot, new long[] { 1 }, 10, true), 0, 0, 1);
        Equal("Original", Param(sheet, "drawn").Value); Assert(!sheet.AdditionalRevisionIds.Contains(10), "Locked revision set was changed");
        Param(sheet, "drawn").Value = "Injected"; sheet.AdditionalRevisionIds.Add(10);
        Invalid(snapshot, "Sheet unavailable");
    }

    private static void UnsupportedKinds()
    {
        foreach (var kind in new[] { SheetParameterKind.ElementReference, SheetParameterKind.Unsupported, (SheetParameterKind)99 })
        {
            var snapshot = Snapshot(); var parameter = Param(snapshot.Sheets[0], "drawn"); parameter.Kind = kind;
            Counts(Stage(snapshot, "drawn", "New", 1), 0, 0, 1);
            parameter.Value = "Injected"; Invalid(snapshot, "specific editor");
        }
    }

    private static void IntegerBoundaries()
    {
        foreach (string value in new[] { "0", "+1", "-1", "2147483647", "-2147483648", " 42 " })
        {
            var snapshot = Snapshot(); var parameter = Param(snapshot.Sheets[0], "drawn"); parameter.Kind = SheetParameterKind.Integer;
            Counts(Stage(snapshot, "drawn", value, 1), 1, 0, 0); Equal(value, parameter.Value); Valid(snapshot);
        }
    }

    private static void InvalidIntegers()
    {
        foreach (string value in new[] { null, "", " ", "2147483648", "-2147483649", "1.5", "1e3", "twelve", "NaN", "∞" })
        {
            var snapshot = Snapshot(); var parameter = Param(snapshot.Sheets[0], "drawn"); parameter.Kind = SheetParameterKind.Integer;
            Counts(Stage(snapshot, "drawn", value, 1), 0, 0, 1); Equal("Original", parameter.Value);
        }
    }

    private static void BooleanAliases()
    {
        foreach (string value in new[] { "Yes", "YES", " true ", "1", "No", "no", "FALSE", "0" })
        {
            var snapshot = Snapshot(); var parameter = Param(snapshot.Sheets[0], "drawn"); parameter.Kind = SheetParameterKind.YesNo;
            bool expected; Assert(SheetEditorModel.TryYesNo(value, out expected), "Boolean alias was rejected");
            Counts(Stage(snapshot, "drawn", value, 1), 1, 0, 0); Equal(expected ? "Yes" : "No", parameter.Value); Valid(snapshot);
        }
    }

    private static void BooleanNoOp()
    {
        var snapshot = Snapshot(); var parameter = Param(snapshot.Sheets[0], "drawn");
        parameter.Kind = SheetParameterKind.YesNo; parameter.OriginalValue = parameter.Value = "Yes";
        Counts(Stage(snapshot, "drawn", " TRUE ", 1), 0, 1, 0); Equal(0, SheetEditorModel.Changes(snapshot).Count);
        Counts(Stage(snapshot, "drawn", "0", 1), 1, 0, 0); Equal("No", parameter.Value);
        Counts(Stage(snapshot, "drawn", "yes", 1), 1, 0, 0); Equal(0, SheetEditorModel.Changes(snapshot).Count);
    }

    private static void InvalidBooleans()
    {
        foreach (string value in new[] { null, "", " ", "2", "-1", "yes please", "Y", "N", "نعم" })
        {
            var snapshot = Snapshot(); var parameter = Param(snapshot.Sheets[0], "drawn"); parameter.Kind = SheetParameterKind.YesNo;
            Counts(Stage(snapshot, "drawn", value, 1), 0, 0, 1); Equal("Original", parameter.Value);
        }
    }

    private static void InvalidNumbers()
    {
        foreach (string value in new[] { null, "", "\t ", "NaN", " nan ", "Infinity", "+Infinity", "-Infinity", "∞", "+∞", "-∞" })
        {
            var snapshot = Snapshot(); var parameter = Param(snapshot.Sheets[0], "drawn"); parameter.Kind = SheetParameterKind.Number;
            Counts(Stage(snapshot, "drawn", value, 1), 0, 0, 1); Equal("Original", parameter.Value);
        }
    }

    private static void NumberUnits()
    {
        foreach (string value in new[] { "0", "-2.5", "300 mm", "2' 6\"", "12.5 m²", "1,25 m" })
        {
            var snapshot = Snapshot(); var parameter = Param(snapshot.Sheets[0], "drawn"); parameter.Kind = SheetParameterKind.Number;
            Counts(Stage(snapshot, "drawn", value, 1), 1, 0, 0); Equal(value, parameter.Value); Valid(snapshot);
        }
    }

    private static void RequiredSheetLabels()
    {
        foreach (string key in new[] { "name", "number" })
        foreach (string value in new[] { null, "", "  ", "\t\n" })
        {
            var snapshot = Snapshot(); var parameter = Param(snapshot.Sheets[0], key); var before = parameter.Value;
            Counts(Stage(snapshot, key, value, 1), 0, 0, 1); Equal(before, parameter.Value);
        }
    }

    private static void TamperedValues()
    {
        foreach (var pair in new[] { Tuple.Create(SheetParameterKind.Integer, "1.5"), Tuple.Create(SheetParameterKind.YesNo, "maybe"), Tuple.Create(SheetParameterKind.Number, "NaN") })
        {
            var snapshot = Snapshot(); var parameter = Param(snapshot.Sheets[0], "drawn"); parameter.Kind = pair.Item1; parameter.Value = pair.Item2;
            Invalid(snapshot);
        }
        var emptyName = Snapshot(); Param(emptyName.Sheets[0], "name").Value = "  "; Invalid(emptyName, "empty");
        var emptyNumber = Snapshot(); Param(emptyNumber.Sheets[0], "number").Value = ""; Invalid(emptyNumber, "empty");
    }

    private static void DuplicateWithUntouched()
    {
        var snapshot = Snapshot(); Counts(Stage(snapshot, "number", "A-002", 1), 1, 0, 0);
        Invalid(snapshot, "Duplicate final sheet number"); Equal("A-002", Param(snapshot.Sheets[1], "number").OriginalValue);
    }

    private static void CaseInsensitiveDuplicates()
    {
        var snapshot = Snapshot(); Stage(snapshot, "number", "a-002", 1); Invalid(snapshot, "Duplicate");
    }

    private static void NumberSwaps()
    {
        var snapshot = Snapshot(); Stage(snapshot, "number", "A-002", 1); Stage(snapshot, "number", "A-001", 2); Valid(snapshot);
        Equal(2, SheetEditorModel.Changes(snapshot).Count);
        snapshot = Snapshot(); Stage(snapshot, "number", "A-002", 1); Stage(snapshot, "number", "A-003", 2); Stage(snapshot, "number", "A-001", 3); Valid(snapshot);
    }

    private static void NumberFallback()
    {
        var snapshot = Snapshot(); snapshot.Sheets[1].Parameters.Remove(Param(snapshot.Sheets[1], "number"));
        Stage(snapshot, "number", "A-002", 1); Invalid(snapshot, "Duplicate");
    }

    private static void BatchNumberConflict()
    {
        var snapshot = Snapshot(); Counts(Stage(snapshot, "number", "MEP-101", 1, 2), 2, 0, 0); Invalid(snapshot, "Duplicate");
    }

    private static void NoNumberEdit()
    {
        var snapshot = Snapshot(); snapshot.Sheets[1].Number = "A-001";
        Param(snapshot.Sheets[1], "number").OriginalValue = Param(snapshot.Sheets[1], "number").Value = "A-001";
        Stage(snapshot, "drawn", "KA", 1); Valid(snapshot);
    }

    private static void RevisionStaging()
    {
        var snapshot = Snapshot(); var sheet = snapshot.Sheets[0];
        Counts(SheetEditorModel.StageRevision(snapshot, new long[] { 1 }, 10, true), 1, 0, 0);
        SetEqual(new long[] { 10, 20 }, sheet.AdditionalRevisionIds); SetEqual(new long[] { 20 }, sheet.OriginalAdditionalRevisionIds);
        Assert(sheet.RevisionsChanged && sheet.Changed, "Added revision was not recognized"); Valid(snapshot);
        Counts(SheetEditorModel.StageRevision(snapshot, new long[] { 1 }, 20, false), 1, 0, 0);
        SetEqual(new long[] { 10 }, sheet.AdditionalRevisionIds); SetEqual(new long[] { 20 }, sheet.OriginalAdditionalRevisionIds); Valid(snapshot);
    }

    private static void RevisionIdempotence()
    {
        var snapshot = Snapshot();
        Counts(SheetEditorModel.StageRevision(snapshot, new long[] { 1, 1 }, 10, true), 1, 0, 0);
        Counts(SheetEditorModel.StageRevision(snapshot, new long[] { 1 }, 10, true), 0, 1, 0);
        Counts(SheetEditorModel.StageRevision(snapshot, new long[] { 1 }, 10, false), 1, 0, 0);
        Counts(SheetEditorModel.StageRevision(snapshot, new long[] { 1 }, 10, false), 0, 1, 0);
        Equal(0, SheetEditorModel.Changes(snapshot).Count);
    }

    private static void IssuedRevisions()
    {
        var snapshot = Snapshot(); var sheet = snapshot.Sheets[0];
        Counts(SheetEditorModel.StageRevision(snapshot, new long[] { 1 }, 30, true), 0, 0, 1);
        sheet.OriginalAdditionalRevisionIds.Add(30); sheet.AdditionalRevisionIds.Add(30);
        Counts(SheetEditorModel.StageRevision(snapshot, new long[] { 1 }, 30, false), 0, 0, 1);
        Assert(sheet.AdditionalRevisionIds.Contains(30), "Issued revision was removed"); Valid(snapshot);
    }

    private static void CloudRevisions()
    {
        var snapshot = Snapshot(); var sheet = snapshot.Sheets[0];
        Counts(SheetEditorModel.StageRevision(snapshot, new long[] { 1 }, 40, false), 0, 0, 1);
        Counts(SheetEditorModel.StageRevision(snapshot, new long[] { 1 }, 40, true), 0, 0, 1);
        SetEqual(new long[] { 40 }, sheet.CloudRevisionIds); Equal(0, SheetEditorModel.Changes(snapshot).Count);
    }

    private static void UnknownRevisions()
    {
        var snapshot = Snapshot(); var result = SheetEditorModel.StageRevision(snapshot, new long[] { 1, 2 }, 999, true);
        Counts(result, 0, 0, 2); Assert(result.Skipped.All(s => s.Contains("no longer exists")), "Unknown revision should be explained");
        snapshot.Sheets[0].AdditionalRevisionIds.Add(999); Invalid(snapshot, "Unknown revision");
        Assert(SheetEditorModel.Changes(snapshot).Single().Parameter.Contains("999"), "Unknown change review needs the revision identity");
        snapshot = Snapshot(); snapshot.Sheets[0].OriginalAdditionalRevisionIds.Add(999); Invalid(snapshot, "Unknown revision");
    }

    private static void TamperedRevisions()
    {
        var snapshot = Snapshot(); snapshot.Sheets[0].AdditionalRevisionIds.Add(30); Invalid(snapshot, "Issued");
        snapshot = Snapshot(); snapshot.Sheets[0].AdditionalRevisionIds.Add(40); Invalid(snapshot, "revision clouds");
        snapshot = Snapshot(); snapshot.Sheets[0].OriginalAdditionalRevisionIds.Add(30); Invalid(snapshot, "Issued");
        snapshot = Snapshot(); snapshot.Sheets[0].OriginalAdditionalRevisionIds.Add(40); Invalid(snapshot, "revision clouds");
    }

    private static void RevisionBatch()
    {
        var snapshot = Snapshot(); snapshot.Sheets[1].AdditionalRevisionIds.Add(10); snapshot.Sheets[1].OriginalAdditionalRevisionIds.Add(10);
        snapshot.Sheets[2].CloudRevisionIds.Add(10);
        var locked = Sheet(4); locked.ReadOnlyReason = "Locked"; snapshot.Sheets.Add(locked);
        var untouched = Sheet(5); snapshot.Sheets.Add(untouched);
        Counts(SheetEditorModel.StageRevision(snapshot, new long[] { 1, 2, 3, 4 }, 10, true), 1, 1, 2);
        Assert(!untouched.AdditionalRevisionIds.Contains(10), "Unchecked sheet was changed");
        Assert(!locked.AdditionalRevisionIds.Contains(10), "Locked sheet was changed"); Valid(snapshot);
    }

    private static void ChangeReview()
    {
        var snapshot = Snapshot(); Stage(snapshot, "drawn", "KA", 1); Stage(snapshot, "name", "Updated title", 1);
        var changes = SheetEditorModel.Changes(snapshot); Equal(2, changes.Count);
        var drawn = changes.Single(c => c.Parameter == "Drawn By");
        Equal(1L, drawn.SheetId); Equal("A-001 — Level 01", drawn.Sheet); Equal("Original", drawn.Before); Equal("KA", drawn.After);
        var name = changes.Single(c => c.Parameter == "Sheet Name"); Equal("Level 01", name.Before); Equal("Updated title", name.After);
    }

    private static void RevisionChangeReview()
    {
        var snapshot = Snapshot(); SheetEditorModel.StageRevision(snapshot, new long[] { 1 }, 10, true); SheetEditorModel.StageRevision(snapshot, new long[] { 1 }, 20, false);
        var changes = SheetEditorModel.Changes(snapshot); Equal(2, changes.Count);
        var added = changes.Single(c => c.Parameter.Contains("Design update")); Equal("Not additional", added.Before); Equal("Included", added.After);
        var removed = changes.Single(c => c.Parameter.Contains("Coordination")); Equal("Included", removed.Before); Equal("Not additional", removed.After);
    }

    private static void RevertedChanges()
    {
        var snapshot = Snapshot(); Stage(snapshot, "drawn", "KA", 1); Stage(snapshot, "drawn", "Original", 1);
        SheetEditorModel.StageRevision(snapshot, new long[] { 1 }, 20, false); SheetEditorModel.StageRevision(snapshot, new long[] { 1 }, 20, true);
        Assert(!snapshot.Sheets[0].Changed, "Restored state is still marked changed"); Equal(0, SheetEditorModel.Changes(snapshot).Count); Valid(snapshot);
    }

    private static void SelectiveReset()
    {
        var snapshot = Snapshot(); Stage(snapshot, "drawn", "KA", 1, 2); SheetEditorModel.StageRevision(snapshot, new long[] { 1, 2 }, 10, true);
        SheetEditorModel.Reset(snapshot, new long[] { 1, 999 });
        Assert(!snapshot.Sheets[0].Changed, "Selected sheet not reset"); Assert(snapshot.Sheets[1].Changed, "Unselected sheet reset");
        Equal("KA", Param(snapshot.Sheets[1], "drawn").Value); Assert(snapshot.Sheets[1].AdditionalRevisionIds.Contains(10), "Unselected revision reset");
        Equal(2, SheetEditorModel.Changes(snapshot).Count);
    }

    private static void EmptyReset()
    {
        var snapshot = Snapshot(); Stage(snapshot, "drawn", "KA", 1); SheetEditorModel.Reset(snapshot, new long[0]);
        Equal("KA", Param(snapshot.Sheets[0], "drawn").Value); Equal(1, SheetEditorModel.Changes(snapshot).Count);
    }

    private static void FullReset()
    {
        var snapshot = Snapshot(); Stage(snapshot, "drawn", "KA", 1, 2, 3); SheetEditorModel.StageRevision(snapshot, new long[] { 1, 2, 3 }, 10, true);
        SheetEditorModel.Reset(snapshot); Equal(0, SheetEditorModel.Changes(snapshot).Count); Valid(snapshot);
        foreach (var sheet in snapshot.Sheets)
        {
            Assert(!sheet.Changed, "Reset sheet is still changed"); Equal("Original", Param(sheet, "drawn").Value);
            Assert(!ReferenceEquals(sheet.OriginalAdditionalRevisionIds, sheet.AdditionalRevisionIds), "Reset aliases original revision set");
            sheet.AdditionalRevisionIds.Add(10); Assert(!sheet.OriginalAdditionalRevisionIds.Contains(10), "Original revision set was mutated after reset");
        }
    }

    private static SheetEditorSnapshot Snapshot()
    {
        return new SheetEditorSnapshot
        {
            ProjectTitle = "KA MEP — اختبار",
            Sheets = new List<SheetEditorSheet> { Sheet(1), Sheet(2), Sheet(3) },
            Revisions = new List<SheetEditorRevision>
            {
                Revision(10, "Design update"), Revision(20, "Coordination"), Revision(30, "Issued revision", true), Revision(40, "Cloud-driven revision")
            }
        };
    }

    private static SheetEditorSheet Sheet(long id)
    {
        string number = "A-" + id.ToString("000", CultureInfo.InvariantCulture);
        string name = "Level " + id.ToString("00", CultureInfo.InvariantCulture);
        var numberParameter = Text("number", "Sheet Number", number); numberParameter.IsSheetNumber = true;
        var nameParameter = Text("name", "Sheet Name", name); nameParameter.IsSheetName = true; nameParameter.OriginalFingerprint = "fingerprint-name-" + id;
        return new SheetEditorSheet
        {
            Id = id, UniqueId = "sheet-" + id, Number = number, Name = name,
            Parameters = new List<SheetEditorParameter> { numberParameter, nameParameter, Text("drawn", "Drawn By", "Original") },
            OriginalAdditionalRevisionIds = new HashSet<long> { 20 }, AdditionalRevisionIds = new HashSet<long> { 20 },
            CloudRevisionIds = new HashSet<long> { 40 }, OriginalAllRevisionIds = new HashSet<long> { 20, 40 }
        };
    }

    private static SheetEditorParameter Text(string key, string name, string value)
    { return new SheetEditorParameter { Key = key, Name = name, Kind = SheetParameterKind.Text, OriginalValue = value, Value = value }; }
    private static SheetEditorRevision Revision(long id, string description, bool issued = false)
    { return new SheetEditorRevision { Id = id, UniqueId = "rev-" + id, Sequence = (int)(id / 10), Number = "R" + id, Description = description, Date = "2026-10-19", Issued = issued }; }
    private static SheetEditorParameter Param(SheetEditorSheet sheet, string key)
    { return sheet.Parameters.Single(p => p.Key == key); }
    private static SheetEditorStageResult Stage(SheetEditorSnapshot snapshot, string key, string value, params long[] ids)
    { return SheetEditorModel.StageValue(snapshot, ids, key, value); }
    private static void Counts(SheetEditorStageResult result, int changed, int unchanged, int skipped)
    { Equal(changed, result.Changed); Equal(unchanged, result.Unchanged); Equal(skipped, result.Skipped.Count); }
    private static void SetEqual(IEnumerable<long> expected, IEnumerable<long> actual)
    { Assert(new HashSet<long>(expected).SetEquals(actual), "Unexpected revision membership"); }
    private static void Valid(SheetEditorSnapshot snapshot)
    { var errors = SheetEditorModel.Validate(snapshot); Assert(errors.Count == 0, string.Join(" | ", errors)); }
    private static void Invalid(SheetEditorSnapshot snapshot, string contains = null)
    { var errors = SheetEditorModel.Validate(snapshot); Assert(errors.Count > 0, "Expected final validation to reject this batch"); if (contains != null) Assert(errors.Any(e => e.Contains(contains)), "Expected error containing '" + contains + "'; got " + string.Join(" | ", errors)); }
    private static void Equal<T>(T expected, T actual)
    { Assert(EqualityComparer<T>.Default.Equals(expected, actual), "Expected " + expected + "; got " + actual); }
    private static void Assert(bool condition, string message)
    { if (!condition) throw new InvalidOperationException(message); }
    private static void Run(string name, Action action)
    {
        try { action(); passed++; Console.WriteLine("PASS " + name); }
        catch (Exception ex) { failed++; Console.WriteLine("FAIL " + name + ": " + ex.Message); }
    }
}
