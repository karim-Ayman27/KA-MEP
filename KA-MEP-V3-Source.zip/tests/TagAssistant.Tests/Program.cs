using System;
using System.Collections.Generic;
using System.Linq;
using PipeTakeoff.Core;
using PipeTakeoff.Revit;

internal static class Program
{
    private static int passed;
    private static int failed;

    private static int Main()
    {
        Run("Selection defaults keep unselected hosts outside the operation", SelectionDefaults);
        Run("Selected existing tags default to Arrange Existing", ExistingDefaults);
        Run("Without a selection no whole-view batch or categories are enabled", ActiveViewDefaults);
        Run("An unsupported selection never silently expands to the active view", UnsupportedSelection);
        Run("Create and arrange select separate eligible sets", OperationEligibility);
        Run("Category selection limits both operations", CategoryEligibility);
        Run("Create requires a loaded matching tag type per affected category", RequiredTagTypes);
        Run("Disabled categories do not require tag types", DisabledTypes);
        Run("Arrange preserves types without requiring a replacement family", PreserveTypes);
        Run("Arrange type replacement requires matching category types", ReplaceTypes);
        Run("Paper millimeters follow view scale and retain coordinate units", PaperUnits);
        Run("New tag orientation swaps printed width and height", NewOrientation);
        Run("Existing measured dimensions retain and rotate consistently", ExistingOrientation);
        Run("Replacing an existing type uses the replacement size estimate", ReplacementEstimate);
        Run("All six patterns use the requested candidates and anchors", AllPatterns);
        Run("Picked origin is retained in view coordinates", PickedOrigin);
        Run("The 500-item boundary passes and 501 is rejected", BatchBoundary);
        Run("Empty scopes and categories cannot apply", EmptyEligibility);
        Run("Invalid view scale and non-finite settings cannot apply", InvalidNumbers);
        Run("Distance and leader boundaries reject unusable settings", DistanceBoundaries);
        Run("Invalid operation, scope, orientation and pattern are rejected", InvalidEnums);
        Run("Invalid angle, columns and origin are rejected", InvalidLayout);
        Run("Validation reports unavailable model data without throwing", MissingModel);
        Run("Nearby defaults keep offsets small and cap the requested batch at fifty", ConservativeDefaults);
        Run("The user batch limit blocks rather than silently truncates", UserBatchLimit);
        Run("Element review retains explicitly excluded candidates and their reasons", ElementExclusions);
        Run("Short-curve filter uses paper distance and applies only to creation", ShortCurveFilter);
        Run("Unknown curve length and point elements are not silently removed", UnknownCurveLength);
        Run("Nearby preview respects crop limits and skips crowded labels", NearbyCrop);
        Run("Moving tags are not treated as fixed preview obstacles", MovingObstacles);
        Run("Unreadable existing tags block only new creation", MissingReferenceGuard);
        Run("Unsupported crop blocks only the nearby pattern", CropAvailability);
        Run("Nearby cannot use a distant picked global origin", NearbyOrigin);
        Run("Maximum distance validation applies to the nearby pattern", MaximumDistance);
        Run("Invalid short-curve threshold reports validation instead of throwing", InvalidCurveFilter);
        Run("Mixed creation selection leaves fittings and flex opt-in", MixedDetailDefaults);
        Run("A deliberate fitting-only selection remains usable", DetailOnlyDefaults);
        Run("Arranging selected fitting tags does not suppress them", ArrangeDetailDefaults);
        Run("Explicit family and type labels retain identity even when names repeat", FamilyTypeNames);
        Run("Legacy detached family/type names retain compatible display fallbacks", LegacyFamilyTypeNames);
        Run("Right-angle leaders retain label positions and allow zero shoulder", OrthogonalPreview);
        Console.WriteLine("RESULT: " + passed + "/" + (passed + failed) + " detached Tag Assistant behavior cases passed; " + failed + " failed.");
        return failed == 0 ? 0 : 1;
    }

    private static void SelectionDefaults()
    {
        var snapshot = Snapshot();
        var options = TagAssistantModel.CreateDefaults(snapshot);
        Equal(TagAssistantScope.Selection, options.Scope);
        Equal(TagAssistantMode.CreateMissing, options.Mode);
        Keys(TagAssistantModel.Candidates(snapshot, options), "host-pipe");
        Equal(1, options.EnabledCategoryKeys.Count);
        Equal(101L, options.SelectedTypeIds["pipe"]);
        Valid(snapshot, options);
    }

    private static void ExistingDefaults()
    {
        var snapshot = Snapshot();
        foreach (var candidate in snapshot.Candidates) candidate.IsSelected = candidate.ExistingTagId != 0;
        var options = TagAssistantModel.CreateDefaults(snapshot);
        Equal(TagAssistantMode.ArrangeExisting, options.Mode);
        Equal(TagAssistantScope.Selection, options.Scope);
        Keys(TagAssistantModel.Candidates(snapshot, options), "tag-pipe");
        Valid(snapshot, options);
    }

    private static void ActiveViewDefaults()
    {
        var snapshot = Snapshot();
        foreach (var candidate in snapshot.Candidates) candidate.IsSelected = false;
        var options = TagAssistantModel.CreateDefaults(snapshot);
        Equal(TagAssistantScope.Selection, options.Scope);
        Equal(0, options.EnabledCategoryKeys.Count);
        Equal(2, options.SelectedTypeIds.Count);
        Keys(TagAssistantModel.Candidates(snapshot, options));
        Invalid(snapshot, options);
        options.Scope = TagAssistantScope.ActiveView;
        Invalid(snapshot, options); // Scope choice alone never enables every category.
        options.EnabledCategoryKeys.Add("pipe");
        Keys(TagAssistantModel.Candidates(snapshot, options), "host-pipe");
        Valid(snapshot, options);
    }

    private static void OperationEligibility()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.Scope = TagAssistantScope.ActiveView;
        options.EnabledCategoryKeys.Add("duct");
        Keys(TagAssistantModel.Candidates(snapshot, options), "host-duct", "host-pipe");
        options.Mode = TagAssistantMode.ArrangeExisting;
        Keys(TagAssistantModel.Candidates(snapshot, options), "tag-pipe");
        options.Scope = TagAssistantScope.Selection;
        Keys(TagAssistantModel.Candidates(snapshot, options), "tag-pipe");
    }

    private static void UnsupportedSelection()
    {
        var snapshot = Snapshot();
        snapshot.HasSelection = true;
        foreach (var candidate in snapshot.Candidates) candidate.IsSelected = false;
        var options = TagAssistantModel.CreateDefaults(snapshot);
        Equal(TagAssistantScope.Selection, options.Scope);
        Equal(0, TagAssistantModel.Candidates(snapshot, options).Count);
        Invalid(snapshot, options);
        options.Scope = TagAssistantScope.ActiveView;
        Invalid(snapshot, options);
        options.EnabledCategoryKeys.Add("pipe");
        Valid(snapshot, options);
    }

    private static void CategoryEligibility()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.Scope = TagAssistantScope.ActiveView;
        options.EnabledCategoryKeys.Add("duct");
        options.EnabledCategoryKeys.Remove("pipe");
        Keys(TagAssistantModel.Candidates(snapshot, options), "host-duct");
        options.Mode = TagAssistantMode.ArrangeExisting;
        Equal(0, TagAssistantModel.Candidates(snapshot, options).Count);
    }

    private static void RequiredTagTypes()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.SelectedTypeIds["pipe"] = 201; // A loaded duct tag is not a pipe tag.
        Invalid(snapshot, options);
        options.SelectedTypeIds.Remove("pipe");
        Invalid(snapshot, options);
        options.SelectedTypeIds["pipe"] = 101;
        snapshot.Categories.First(c => c.Key == "pipe").Types.Clear();
        Invalid(snapshot, options);
    }

    private static void DisabledTypes()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.Scope = TagAssistantScope.ActiveView;
        options.EnabledCategoryKeys.Remove("duct");
        snapshot.Categories.First(c => c.Key == "duct").Types.Clear();
        options.SelectedTypeIds.Remove("duct");
        Valid(snapshot, options);
        options.EnabledCategoryKeys.Add("duct");
        Invalid(snapshot, options);
    }

    private static void PreserveTypes()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.Mode = TagAssistantMode.ArrangeExisting;
        foreach (var category in snapshot.Categories) category.Types.Clear();
        options.SelectedTypeIds.Clear();
        Valid(snapshot, options);
    }

    private static void ReplaceTypes()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.Mode = TagAssistantMode.ArrangeExisting; options.PreserveExistingTypes = false;
        Valid(snapshot, options);
        options.SelectedTypeIds["pipe"] = 201;
        Invalid(snapshot, options);
    }

    private static void PaperUnits()
    {
        Near(1, TagAssistantModel.PaperToInternal(3.048, 100));
        Near(0.5, TagAssistantModel.PaperToInternal(3.048, 50));
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.SpacingMm = 3.048; options.OffsetMm = 6.096; options.ShoulderMm = 1.524;
        var actual = TagAssistantModel.BuildLayoutOptions(snapshot, options);
        Near(1, actual.Spacing); Near(2, actual.Offset); Near(0.5, actual.Shoulder);
        snapshot.ViewScale = 50;
        actual = TagAssistantModel.BuildLayoutOptions(snapshot, options);
        Near(0.5, actual.Spacing); Near(1, actual.Offset); Near(0.25, actual.Shoulder);
        Throws<ArgumentOutOfRangeException>(() => TagAssistantModel.PaperToInternal(2, 0));
        Throws<ArgumentOutOfRangeException>(() => TagAssistantModel.PaperToInternal(double.NaN, 100));
    }

    private static void NewOrientation()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.EstimatedWidthMm = 30.48; options.EstimatedHeightMm = 3.048;
        var label = TagAssistantModel.Preview(snapshot, options).Placements.Single();
        Near(10, label.Bounds.Width); Near(1, label.Bounds.Height);
        options.Orientation = TagTextOrientation.Vertical;
        label = TagAssistantModel.Preview(snapshot, options).Placements.Single();
        Near(1, label.Bounds.Width); Near(10, label.Bounds.Height);
    }

    private static void ExistingOrientation()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.Mode = TagAssistantMode.ArrangeExisting;
        var candidate = snapshot.Candidates.Single(c => c.ExistingTagId != 0);
        candidate.Width = 2; candidate.Height = 7; candidate.Orientation = TagTextOrientation.Vertical;
        var label = TagAssistantModel.Preview(snapshot, options).Placements.Single();
        Near(7, label.Bounds.Width); Near(2, label.Bounds.Height);
        options.Orientation = TagTextOrientation.Vertical;
        label = TagAssistantModel.Preview(snapshot, options).Placements.Single();
        Near(2, label.Bounds.Width); Near(7, label.Bounds.Height);
    }

    private static void ReplacementEstimate()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.Mode = TagAssistantMode.ArrangeExisting; options.PreserveExistingTypes = false;
        options.EstimatedWidthMm = 15.24; options.EstimatedHeightMm = 3.048;
        var label = TagAssistantModel.Preview(snapshot, options).Placements.Single();
        Near(5, label.Bounds.Width); Near(1, label.Bounds.Height);
        options.PreserveExistingTypes = true;
        var candidate = snapshot.Candidates.Single(c => c.ExistingTagId != 0);
        candidate.Width = 0; // Unavailable measurements fall back to the explicit estimate.
        label = TagAssistantModel.Preview(snapshot, options).Placements.Single();
        Near(5, label.Bounds.Width); Near(1, label.Bounds.Height);
    }

    private static void AllPatterns()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.Scope = TagAssistantScope.ActiveView;
        options.EnabledCategoryKeys.Add("duct");
        foreach (TagLayoutPattern pattern in Enum.GetValues(typeof(TagLayoutPattern)))
        {
            options.Pattern = pattern; Valid(snapshot, options);
            var labels = TagAssistantModel.Preview(snapshot, options).Placements;
            Equal(2, labels.Count);
            foreach (var label in labels)
            {
                var candidate = snapshot.Candidates.Single(c => c.Key == label.Key);
                Near(candidate.Anchor.X, label.Anchor.X); Near(candidate.Anchor.Y, label.Anchor.Y);
            }
            Assert(!labels[0].Bounds.Intersects(labels[1].Bounds), pattern + " overlaps labels");
        }
    }

    private static void PickedOrigin()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.Pattern = TagLayoutPattern.HorizontalRow;
        options.PickOrigin = true; options.Origin = new TagPoint(-123.5, 234.75);
        var label = TagAssistantModel.Preview(snapshot, options).Placements.Single();
        Near(-123.5, label.Head.X); Near(234.75, label.Head.Y);
        snapshot.ViewScale = 50;
        label = TagAssistantModel.Preview(snapshot, options).Placements.Single();
        Near(-123.5, label.Head.X); Near(234.75, label.Head.Y);
    }

    private static void BatchBoundary()
    {
        var snapshot = Snapshot(); snapshot.Candidates.Clear();
        for (int i = 0; i < 500; i++) snapshot.Candidates.Add(Candidate("item-" + i, "pipe", true, 0, i, i % 7));
        var options = TagAssistantModel.CreateDefaults(snapshot);
        options.MaximumTags = 500;
        options.Pattern = TagLayoutPattern.HorizontalRow;
        Valid(snapshot, options); Equal(500, TagAssistantModel.Preview(snapshot, options).Placements.Count);
        snapshot.Candidates.Add(Candidate("item-500", "pipe", true, 0, 501, 0));
        Invalid(snapshot, options);
        Throws<InvalidOperationException>(() => TagAssistantModel.Preview(snapshot, options));
    }

    private static void EmptyEligibility()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.EnabledCategoryKeys.Clear(); Invalid(snapshot, options);
        options.EnabledCategoryKeys.Add("duct"); Invalid(snapshot, options);
        options.Scope = TagAssistantScope.ActiveView; Valid(snapshot, options);
        options.Mode = TagAssistantMode.ArrangeExisting; Invalid(snapshot, options);
    }

    private static void InvalidNumbers()
    {
        foreach (int scale in new[] { 0, -100 })
        {
            var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
            snapshot.ViewScale = scale; Invalid(snapshot, options);
        }
        foreach (double value in new[] { double.NaN, double.PositiveInfinity, double.NegativeInfinity })
        {
            var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
            options.SpacingMm = value; Invalid(snapshot, options);
            options = TagAssistantModel.CreateDefaults(snapshot); options.EstimatedHeightMm = value; Invalid(snapshot, options);
        }
    }

    private static void DistanceBoundaries()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.SpacingMm = 0; options.OffsetMm = 0; options.LeaderStyle = TagLeaderStyle.None; options.ShoulderMm = 0;
        Valid(snapshot, options);
        options.LeaderStyle = TagLeaderStyle.Elbow; Invalid(snapshot, options);
        options.ShoulderMm = 5; options.EstimatedWidthMm = 0; Invalid(snapshot, options);
        options.EstimatedWidthMm = 25; options.SpacingMm = -1; Invalid(snapshot, options);
        options.SpacingMm = 101; Invalid(snapshot, options);
        options.SpacingMm = 3; options.OffsetMm = 501; Invalid(snapshot, options);
    }

    private static void InvalidEnums()
    {
        var snapshot = Snapshot();
        var options = TagAssistantModel.CreateDefaults(snapshot); options.Mode = (TagAssistantMode)99; Invalid(snapshot, options);
        options = TagAssistantModel.CreateDefaults(snapshot); options.Scope = (TagAssistantScope)99; Invalid(snapshot, options);
        options = TagAssistantModel.CreateDefaults(snapshot); options.Orientation = (TagTextOrientation)99; Invalid(snapshot, options);
        options = TagAssistantModel.CreateDefaults(snapshot); options.LeaderStyle = (TagLeaderStyle)99; Invalid(snapshot, options);
        options = TagAssistantModel.CreateDefaults(snapshot); options.Pattern = (TagLayoutPattern)99; Invalid(snapshot, options);
        options = TagAssistantModel.CreateDefaults(snapshot); options.Side = (TagLayoutSide)99; Invalid(snapshot, options);
    }

    private static void InvalidLayout()
    {
        var snapshot = Snapshot();
        var options = TagAssistantModel.CreateDefaults(snapshot); options.Columns = 0; Invalid(snapshot, options);
        options = TagAssistantModel.CreateDefaults(snapshot); options.AngleDegrees = 181; Invalid(snapshot, options);
        options = TagAssistantModel.CreateDefaults(snapshot); options.AngleDegrees = double.NaN; Invalid(snapshot, options);
        options = TagAssistantModel.CreateDefaults(snapshot); options.Origin = new TagPoint(double.NaN, 0); Invalid(snapshot, options);
    }

    private static void MissingModel()
    {
        Assert(TagAssistantModel.Validate(null, null).Count > 0, "Missing model should have a validation message");
        Assert(TagAssistantModel.Validate(Snapshot(), null).Count > 0, "Missing options should have a validation message");
    }

    private static void ConservativeDefaults()
    {
        var options = TagAssistantModel.CreateDefaults(Snapshot());
        Equal(TagLayoutPattern.NearHost, options.Pattern);
        Equal(50, options.MaximumTags);
        Equal(TagLeaderStyle.Straight, options.LeaderStyle);
        Near(1.5, options.SpacingMm); Near(3, options.OffsetMm); Near(2, options.ShoulderMm);
        Near(20, options.MaximumDistanceMm); Near(5, options.MinimumCurveLengthMm);
        Assert(options.SkipShortCurves, "Short segments should be filtered by default");
    }

    private static void UserBatchLimit()
    {
        var snapshot = Snapshot(); snapshot.Candidates.Clear();
        for (int i = 0; i < 51; i++) snapshot.Candidates.Add(Candidate("item-" + i, "pipe", true, 0, i * 20, 0));
        var options = TagAssistantModel.CreateDefaults(snapshot);
        Equal(51, TagAssistantModel.Candidates(snapshot, options).Count);
        Assert(TagAssistantModel.Validate(snapshot, options).Any(e => e.Contains("limit of 50")), "Chosen limit must be explained");
        Throws<InvalidOperationException>(() => TagAssistantModel.Preview(snapshot, options));
        options.MaximumTags = 51;
        Valid(snapshot, options); Equal(51, TagAssistantModel.Preview(snapshot, options).Placements.Count);
        options.MaximumTags = 0; Invalid(snapshot, options);
        options.MaximumTags = 501; Invalid(snapshot, options);
    }

    private static void ElementExclusions()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.Scope = TagAssistantScope.ActiveView; options.EnabledCategoryKeys.Add("duct");
        options.ExcludedCandidateKeys.Add("host-pipe");
        Keys(TagAssistantModel.CandidatesForReview(snapshot, options), "host-pipe", "host-duct");
        Keys(TagAssistantModel.Candidates(snapshot, options), "host-duct");
        Assert(TagAssistantModel.CandidateExclusionReason(snapshot, options, snapshot.Candidates[0]).Contains("Excluded"), "Manual reason must remain visible");
        options.Scope = TagAssistantScope.Selection; Keys(TagAssistantModel.Candidates(snapshot, options));
        options.Scope = TagAssistantScope.ActiveView; Keys(TagAssistantModel.Candidates(snapshot, options), "host-duct");
        options.ExcludedCandidateKeys.Clear(); Keys(TagAssistantModel.Candidates(snapshot, options), "host-duct", "host-pipe");
    }

    private static void ShortCurveFilter()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        var host = snapshot.Candidates.Single(c => c.Key == "host-pipe");
        host.IsCurve = true; host.CurveLengthInternal = TagAssistantModel.PaperToInternal(4.9, 100);
        Keys(TagAssistantModel.Candidates(snapshot, options));
        Keys(TagAssistantModel.CandidatesForReview(snapshot, options), "host-pipe");
        Assert(TagAssistantModel.CandidateExclusionReason(snapshot, options, host).Contains("paper mm"), "Short-curve reason must name paper units");
        snapshot.ViewScale = 50; Keys(TagAssistantModel.Candidates(snapshot, options), "host-pipe");
        snapshot.ViewScale = 100; host.CurveLengthInternal = TagAssistantModel.PaperToInternal(5, 100);
        Keys(TagAssistantModel.Candidates(snapshot, options), "host-pipe");
        host.CurveLengthInternal = 0.01; options.SkipShortCurves = false;
        Keys(TagAssistantModel.Candidates(snapshot, options), "host-pipe");
        options.SkipShortCurves = true; options.Mode = TagAssistantMode.ArrangeExisting;
        var tag = snapshot.Candidates.Single(c => c.ExistingTagId != 0); tag.IsCurve = true; tag.CurveLengthInternal = 0.01;
        Keys(TagAssistantModel.Candidates(snapshot, options), "tag-pipe");
    }

    private static void UnknownCurveLength()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        var host = snapshot.Candidates[0]; host.IsCurve = true; host.CurveLengthInternal = null;
        Keys(TagAssistantModel.Candidates(snapshot, options), "host-pipe");
        host.IsCurve = false; host.CurveLengthInternal = 0;
        Keys(TagAssistantModel.Candidates(snapshot, options), "host-pipe");
    }

    private static void NearbyCrop()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        snapshot.AllowedBounds = new TagRectangle(8, 18, 12, 22); // Label is wider than this crop.
        var result = TagAssistantModel.Preview(snapshot, options);
        Equal(0, result.Placements.Count); Equal(1, result.SkippedKeys.Count);
        Valid(snapshot, options); // Actual family measurement can still find room for a smaller label.
        Assert(result.Warnings.Count > 0, "Estimated skips must remain visible before measuring actual family sizes");
        options.Pattern = TagLayoutPattern.HorizontalRow;
        Equal(1, TagAssistantModel.Preview(snapshot, options).Placements.Count); // Advanced patterns retain their behavior.
    }

    private static void MovingObstacles()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.Mode = TagAssistantMode.ArrangeExisting;
        var tag = snapshot.Candidates.Single(c => c.ExistingTagId != 0);
        snapshot.ExistingTagBounds[tag.ExistingTagId] = new TagRectangle(30, 40, 70, 80);
        Equal(1, TagAssistantModel.Preview(snapshot, options).Placements.Count);
        snapshot.ExistingTagBounds[99999] = new TagRectangle(30, 40, 70, 80);
        Equal(0, TagAssistantModel.Preview(snapshot, options).Placements.Count);
    }

    private static void MissingReferenceGuard()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        snapshot.CanCreateMissing = false; Invalid(snapshot, options);
        options.Mode = TagAssistantMode.ArrangeExisting; Valid(snapshot, options);
    }

    private static void CropAvailability()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        snapshot.NearHostAvailable = false; snapshot.NearHostUnavailableReason = "Split crop cannot be placed safely.";
        Assert(TagAssistantModel.Validate(snapshot, options).Contains(snapshot.NearHostUnavailableReason), "Specific crop limitation must be surfaced");
        options.Pattern = TagLayoutPattern.VerticalColumn; Valid(snapshot, options);
    }

    private static void NearbyOrigin()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.PickOrigin = true; Invalid(snapshot, options);
        options.PickOrigin = false; options.Origin = new TagPoint(1000, 1000); Invalid(snapshot, options);
    }

    private static void MaximumDistance()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.MaximumDistanceMm = double.NaN; Invalid(snapshot, options);
        options.Pattern = TagLayoutPattern.HorizontalRow; Valid(snapshot, options);
        options.Pattern = TagLayoutPattern.NearHost; options.MaximumDistanceMm = 101; Invalid(snapshot, options);
        options.MaximumDistanceMm = 20;
        Near(TagAssistantModel.PaperToInternal(20, snapshot.ViewScale), TagAssistantModel.BuildLayoutOptions(snapshot, options).MaximumDistance);
    }

    private static void InvalidCurveFilter()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        snapshot.Candidates[0].IsCurve = true; snapshot.Candidates[0].CurveLengthInternal = 2;
        options.MinimumCurveLengthMm = double.NaN; Invalid(snapshot, options);
        options.MinimumCurveLengthMm = -1; Invalid(snapshot, options);
    }

    private static void MixedDetailDefaults()
    {
        var snapshot = Snapshot();
        foreach (var key in new[] { "OST_PipeFitting", "OST_DuctFitting", "OST_CableTrayFitting", "OST_ConduitFitting", "OST_FlexPipeCurves", "OST_FlexDuctCurves" })
        {
            snapshot.Categories.Add(new TagCategoryOption { Key = key, Name = key, Types = new List<TagTypeOption> { new TagTypeOption { Id = 500, Name = key } } });
            snapshot.Candidates.Add(Candidate(key, key, true, 0, 100, 100));
        }
        var options = TagAssistantModel.CreateDefaults(snapshot);
        Equal(1, options.EnabledCategoryKeys.Count);
        Keys(TagAssistantModel.Candidates(snapshot, options), "host-pipe");
        Equal(500L, options.SelectedTypeIds["OST_PipeFitting"]); // Loaded choices remain ready for explicit opt-in.
        options.EnabledCategoryKeys.Add("OST_PipeFitting");
        Keys(TagAssistantModel.Candidates(snapshot, options), "host-pipe", "OST_PipeFitting");
        Assert(TagAssistantModel.DefaultSelectionGuidance.Contains("fitting and flex"), "Default category policy must be explainable in UI");
    }

    private static void DetailOnlyDefaults()
    {
        var snapshot = Snapshot(); snapshot.Candidates.Clear(); snapshot.Categories.Clear();
        snapshot.Categories.Add(new TagCategoryOption { Key = "OST_PipeFitting", Name = "Pipe fittings", Types = new List<TagTypeOption> { new TagTypeOption { Id = 500, Name = "Fitting tag" } } });
        snapshot.Candidates.Add(Candidate("fitting", "OST_PipeFitting", true, 0, 10, 10));
        var options = TagAssistantModel.CreateDefaults(snapshot);
        Keys(TagAssistantModel.Candidates(snapshot, options), "fitting");
        Equal(TagAssistantMode.CreateMissing, options.Mode);
        Valid(snapshot, options);
    }

    private static void ArrangeDetailDefaults()
    {
        var snapshot = Snapshot();
        foreach (var candidate in snapshot.Candidates) candidate.IsSelected = candidate.ExistingTagId != 0;
        snapshot.Categories.Add(new TagCategoryOption { Key = "OST_PipeFitting", Name = "Pipe fittings" });
        snapshot.Candidates.Add(Candidate("fitting-tag", "OST_PipeFitting", true, 2002, 100, 100));
        var options = TagAssistantModel.CreateDefaults(snapshot);
        Equal(TagAssistantMode.ArrangeExisting, options.Mode);
        Keys(TagAssistantModel.Candidates(snapshot, options), "tag-pipe", "fitting-tag");
        Valid(snapshot, options);
    }

    private static void FamilyTypeNames()
    {
        var first = new TagTypeOption { Id = 1, FamilyName = "Pipe size", TypeName = "Standard", Name = "legacy" };
        var second = new TagTypeOption { Id = 2, FamilyName = "Pipe elevation", TypeName = "Standard" };
        Equal("Pipe size", first.FamilyDisplayName); Equal("Standard", first.TypeDisplayName);
        Equal("Pipe elevation", second.FamilyDisplayName); Equal("Standard", second.TypeDisplayName);
        var snapshot = Snapshot(); snapshot.Categories[0].Types = new List<TagTypeOption> { first, second };
        var options = TagAssistantModel.CreateDefaults(snapshot);
        options.SelectedTypeIds["pipe"] = second.Id;
        Valid(snapshot, options);
        options.SelectedTypeIds["pipe"] = 201; // A valid duct type cannot be selected for pipes.
        Invalid(snapshot, options);
    }

    private static void LegacyFamilyTypeNames()
    {
        var legacy = new TagTypeOption { Name = "Pipe family : Type : suffix" };
        Equal("Pipe family", legacy.FamilyDisplayName); Equal("Type : suffix", legacy.TypeDisplayName);
        legacy.Name = "Single label";
        Equal("Single label", legacy.FamilyDisplayName); Equal("Single label", legacy.TypeDisplayName);
        legacy.Name = null;
        Equal(string.Empty, legacy.FamilyDisplayName); Equal(string.Empty, legacy.TypeDisplayName);
    }

    private static void OrthogonalPreview()
    {
        var snapshot = Snapshot(); var options = TagAssistantModel.CreateDefaults(snapshot);
        options.Pattern = TagLayoutPattern.VerticalColumn;
        var initial = TagAssistantModel.Preview(snapshot, options).Placements.Single();
        options.LeaderStyle = TagLeaderStyle.Orthogonal;
        Valid(snapshot, options);
        var orthogonal = TagAssistantModel.Preview(snapshot, options).Placements.Single();
        Near(initial.Head.X, orthogonal.Head.X); Near(initial.Head.Y, orthogonal.Head.Y);
        Near(orthogonal.Anchor.X, orthogonal.Elbow.X); Near(orthogonal.Head.Y, orthogonal.Elbow.Y);
        Assert(TagAssistantModel.BuildLayoutOptions(snapshot, options).OrthogonalLeaders, "Orthogonal flag passed to engine");
        options.ShoulderMm = 0; Valid(snapshot, options);
        Equal(0, (int)TagLeaderStyle.None); Equal(1, (int)TagLeaderStyle.Straight);
        Equal(2, (int)TagLeaderStyle.Elbow); Equal(3, (int)TagLeaderStyle.Orthogonal);
    }

    private static TagAssistantSnapshot Snapshot()
    {
        return new TagAssistantSnapshot
        {
            ViewName = "Level 01 - MEP", ViewScale = 100,
            Categories = new List<TagCategoryOption>
            {
                new TagCategoryOption { Key = "pipe", Name = "Pipes", Types = new List<TagTypeOption> { new TagTypeOption { Id = 101, Name = "Pipe size : 2.5 mm" } } },
                new TagCategoryOption { Key = "duct", Name = "Ducts", Types = new List<TagTypeOption> { new TagTypeOption { Id = 201, Name = "Duct size : 2.5 mm" } } }
            },
            Candidates = new List<TagAssistantCandidate>
            {
                Candidate("host-pipe", "pipe", true, 0, 10, 20),
                Candidate("host-duct", "duct", false, 0, 30, 40),
                Candidate("tag-pipe", "pipe", true, 1001, 50, 60)
            }
        };
    }

    private static TagAssistantCandidate Candidate(string key, string category, bool selected, long tagId, double x, double y)
    {
        return new TagAssistantCandidate { Key = key, CategoryKey = category, Label = key,
            ExistingTagId = tagId, IsSelected = selected, Anchor = new TagPoint(x, y), ExistingHead = new TagPoint(x + 5, y + 5),
            Width = 4, Height = 1, Orientation = TagTextOrientation.Horizontal };
    }

    private static void Run(string name, Action action)
    {
        try { action(); passed++; Console.WriteLine("PASS " + name); }
        catch (Exception ex) { failed++; Console.WriteLine("FAIL " + name + ": " + ex.Message); }
    }
    private static void Valid(TagAssistantSnapshot snapshot, TagAssistantOptions options)
    { var errors = TagAssistantModel.Validate(snapshot, options); Assert(errors.Count == 0, string.Join(" | ", errors)); }
    private static void Invalid(TagAssistantSnapshot snapshot, TagAssistantOptions options)
    { Assert(TagAssistantModel.Validate(snapshot, options).Count > 0, "Invalid input should have been rejected"); }
    private static void Keys(IEnumerable<TagAssistantCandidate> actual, params string[] expected)
    { Assert(actual.Select(c => c.Key).OrderBy(k => k).SequenceEqual(expected.OrderBy(k => k)), "Unexpected eligible candidates"); }
    private static void Equal<T>(T expected, T actual)
    { Assert(EqualityComparer<T>.Default.Equals(expected, actual), "Expected " + expected + "; got " + actual); }
    private static void Near(double expected, double actual)
    { Assert(Math.Abs(expected - actual) <= 1e-8 * Math.Max(1, Math.Abs(expected)), "Expected " + expected + "; got " + actual); }
    private static void Assert(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
    private static void Throws<T>(Action action) where T : Exception
    { try { action(); } catch (T) { return; } throw new InvalidOperationException("Expected " + typeof(T).Name); }
}
