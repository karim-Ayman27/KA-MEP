using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using PipeTakeoff.Core;
using PipeTakeoff.Revit;

internal static class Program
{
    [STAThread]
    private static int Main(string[] args)
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        string only = Value(args, "--case=");
        string screenshots = Value(args, "--screenshots=");
        if (screenshots != null) Directory.CreateDirectory(screenshots);
        int count = 0, failed = 0;
        Console.WriteLine("Actual linked KA MEP TagAssistantForm / TagPatternPreview layout and interaction checks.");
        Console.WriteLine("Explicit control/font scaling under Mono; not Windows DPI or a live Revit test.");
        foreach (var test in new[]
        {
            new Case(1366, 728, 1), new Case(1280, 680, 1.5F), new Case(1280, 680, 2),
            new Case(1024, 600, 1), new Case(1024, 600, 1.5F), new Case(1024, 600, 2),
            new Case(876, 571, 1), new Case(876, 571, 1.5F), new Case(876, 571, 2)
        })
        {
            if (only != null && only != test.Name) continue;
            count++;
            var errors = new List<string>();
            try
            {
                using (var form = new TagAssistantForm(Snapshot())) Check(form, test, screenshots, errors);
                CheckNoSelection(test, screenshots, errors);
                CheckMissingFamilies(errors);
            }
            catch (Exception ex) { errors.Add("Unhandled check failure: " + ex); }
            Console.WriteLine((errors.Count == 0 ? "PASS " : "FAIL ") + test.Name);
            foreach (string error in errors.Distinct()) Console.WriteLine("  " + error);
            if (errors.Count > 0) failed++;
        }
        Console.WriteLine("RESULT: " + (count - failed) + "/" + count + " Tag Assistant layout cases passed; " + failed + " failed.");
        return count > 0 && failed == 0 ? 0 : 1;
    }

    private static void Check(TagAssistantForm form, Case test, string screenshots, List<string> errors)
    {
        form.StartPosition = FormStartPosition.Manual;
        form.Location = new Point(20, 20);
        form.Show(); Pump(form);
        form.AutoScaleMode = AutoScaleMode.None;
        var fonts = Descendants(form).Select(control => new FontSpec(control)).ToArray();
        form.Scale(new SizeF(test.Scale, test.Scale));
        foreach (FontSpec font in fonts) font.Control.Font = new Font(font.Family, font.Size * test.Scale, font.Style, font.Unit);
        form.MinimumSize = Size.Empty;
        form.ClientSize = test.Viewport;
        form.Location = new Point(20, 20);
        Pump(form);
        var apply = Find<Button>(form, "TagApplyButton");
        var cancel = Find<Button>(form, "TagCancelButton");
        var reset = Find<Button>(form, "TagResetButton");
        var tabs = Find<TabControl>(form, "TagSettingsTabs");
        var preview = Find<TagPatternPreview>(form, "TagPatternPreview");
        var mode = Find<ComboBox>(form, "TagMode");
        var scope = Find<ComboBox>(form, "TagScope");
        var grid = Find<DataGridView>(form, "TagCategoryTypes");
        if (tabs.TabCount != 4) errors.Add("Expected Scope / Review elements / Pattern / Leaders tabs");
        if (form.Icon == null) errors.Add("Branded title-bar icon is missing");
        if (!ReferenceEquals(form.AcceptButton, apply)) errors.Add("Enter does not target Apply");
        if (!ReferenceEquals(form.CancelButton, cancel)) errors.Add("Escape does not target Cancel");
        CheckPreview(preview, 4, true, errors);
        CheckVisibleSchematic(preview, errors);
        if (!apply.Enabled) errors.Add("Valid default selection does not enable Apply");
        if (form.Options.Scope != TagAssistantScope.Selection || form.Options.Pattern != TagLayoutPattern.NearHost) errors.Add("Selection / NearHost defaults not used");
        if (form.Options.MaximumTags != 50 || Math.Abs(form.Options.MaximumDistanceMm - 20) > 1e-9) errors.Add("Conservative count / distance defaults missing");
        if (!form.Options.SkipShortCurves) errors.Add("Short-curve filtering is not enabled by default");
        if (Find<CheckBox>(form, "TagPickOrigin").Enabled) errors.Add("NearHost allows a distant picked origin");
        CheckNearDistance(ReadPreview(preview), form.Options, errors);
        if (Find<TextBox>(form, "TagPreviewWarnings").Text.Contains("This is a group pattern")) errors.Add("Nearby layout incorrectly identifies itself as a group pattern");
        if (grid.Rows.Count != 3) errors.Add("Not all compatible categories are shown");
        var preserveLocation = Find<CheckBox>(form, "TagPreserveTypes");
        if (!Descendants(tabs.TabPages[0]).Contains(preserveLocation))
            errors.Add("The preserve-family option is not discoverable beside the family choices on Scope & types");
        foreach (DataGridViewRow row in grid.Rows)
        {
            var category = (TagCategoryOption)row.Tag;
            var familyChoices = ((DataGridViewComboBoxCell)row.Cells["TagFamily"]).DataSource as List<string>;
            if (familyChoices == null || familyChoices.Any(name => !category.Types.Any(type => type.FamilyDisplayName == name)))
                errors.Add(category.Name + ": family selector includes an incompatible category's family");
            string family = Convert.ToString(row.Cells["TagFamily"].FormattedValue, CultureInfo.InvariantCulture);
            string displayed = Convert.ToString(row.Cells["TagType"].FormattedValue, CultureInfo.InvariantCulture);
            if (!category.Types.Any(type => type.FamilyDisplayName == family && type.TypeDisplayName == displayed))
                errors.Add(category.Name + ": separate family/type cells do not display a matching loaded type (" + family + " / " + displayed + ")");
        }
        grid.Rows[0].Cells["TagType"].Value = 201L; Pump(form);
        long selectedType;
        if (!form.Options.SelectedTypeIds.TryGetValue("pipe", out selectedType) || selectedType != 201 || !apply.Enabled)
            errors.Add("Choosing an alternative compatible tag type does not update usable options");
        grid.Rows[0].Cells["TagFamily"].Value = "Pipes identification tag"; Pump(form);
        var pipeTypes = ((DataGridViewComboBoxCell)grid.Rows[0].Cells["TagType"]).DataSource as List<TagTypeOption>;
        if (pipeTypes == null || !pipeTypes.Select(type => type.Id).SequenceEqual(new long[] { 301, 401 }))
            errors.Add("Changing family does not filter type choices to that family's loaded types");
        if (!form.Options.SelectedTypeIds.TryGetValue("pipe", out selectedType) || selectedType != 301 || !apply.Enabled)
            errors.Add("Changing family does not replace the old family's type with a valid selected type");
        grid.Rows[0].Cells["TagType"].Value = 401L; Pump(form);
        if (form.Options.SelectedTypeIds["pipe"] != 401) errors.Add("Second type in the new family is not sent to the command options");
        grid.Rows[0].Cells["TagFamily"].Value = "Pipes size tag"; Pump(form);
        if (form.Options.SelectedTypeIds["pipe"] != 101) errors.Add("Returning to the original family retains a stale other-family type");

        foreach (TabPage tab in tabs.TabPages)
        {
            tabs.SelectedTab = tab; Pump(form);
            ValidateControl(apply, true, errors); ValidateControl(cancel, true, errors); ValidateControl(reset, true, errors);
            ValidateControl(preview, true, errors);
            ValidateNoOverlap(new Control[] { apply, cancel, reset }, errors);
            int tabIndex = tabs.TabPages.IndexOf(tab);
            Rectangle tabBounds = tabs.GetTabRect(tabIndex);
            if (!tabs.ClientRectangle.Contains(tabBounds)) errors.Add(tab.Text + ": tab header is clipped");
            var scrolling = tab.Controls.OfType<Panel>().SingleOrDefault(p => p.AutoScroll);
            if (scrolling == null) errors.Add(tab.Text + ": settings cannot scroll on smaller screens");
            else
            {
                var inputs = Descendants(tab).Where(c => c is ComboBox || c is NumericUpDown || c is CheckBox || c is RadioButton || c is Button).ToArray();
                foreach (Control input in inputs)
                {
                    ScrollToInput(scrolling, input, form);
                    ValidateControl(input, false, errors);
                }
                scrolling.AutoScrollPosition = Point.Empty; Pump(form);
            }
            Save(form, screenshots, test.Name + "_tab" + (tabIndex + 1));
            if (tabIndex == 0 && scrolling != null)
            {
                // Capture the category-local family/type choices even when the settings
                // page needs scrolling at high scale. This does not change production UI.
                Rectangle gridBounds = scrolling.RectangleToClient(grid.RectangleToScreen(grid.ClientRectangle));
                scrolling.AutoScrollPosition = new Point(0, Math.Max(0, -scrolling.AutoScrollPosition.Y + gridBounds.Top));
                Pump(form);
                Save(form, screenshots, test.Name + "_families");
                if (test.Scale == 2 && test.Viewport.Width == 876)
                {
                    // Narrow windows reserve enough settings width for both selectors;
                    // verify that the actual editing dropdown is fully visible.
                    grid.CurrentCell = grid.Rows[0].Cells["TagType"];
                    grid.BeginEdit(true); Pump(form);
                    var typeEditor = grid.EditingControl as ComboBox;
                    if (typeEditor == null) errors.Add("Tag type dropdown cannot open on the narrow window");
                    else
                    {
                        ValidateControl(typeEditor, true, errors);
                        typeEditor.DroppedDown = true; Pump(form);
                        Save(form, screenshots, test.Name + "_type_dropdown");
                        typeEditor.DroppedDown = false;
                    }
                    grid.EndEdit(); grid.HorizontalScrollingOffset = 0; Pump(form);
                }
                scrolling.AutoScrollPosition = Point.Empty; Pump(form);
            }
        }

        tabs.SelectedIndex = 2; Pump(form);
        var patterns = Descendants(form).OfType<TagPatternChoice>().ToArray();
        var leaders = Find<ComboBox>(form, "TagLeaderStyle");
        var shoulder = Find<NumericUpDown>(form, "TagShoulderMm");
        if (leaders.Items.Count != 4 || !Convert.ToString(leaders.Items[3]).Contains("90")) errors.Add("Explicit right-angle leader option is missing");
        if (patterns.Length != 6 || patterns.Select(p => p.Pattern).Distinct().Count() != 6) errors.Add("All six selectable pattern cards are required");
        foreach (TagPatternChoice pattern in patterns)
        {
            pattern.Checked = true; Pump(form);
            if (form.Options.Pattern != pattern.Pattern || patterns.Count(p => p.Checked) != 1)
                errors.Add(pattern.Pattern + ": pattern choice did not update the exclusive selection");
            CheckPreview(preview, 4, true, errors);
            if (!apply.Enabled) errors.Add(pattern.Pattern + ": valid pattern disabled Apply");
            var actual = ReadPreview(preview);
            if (actual != null && !PairwiseDisjoint(actual.Placements)) errors.Add(pattern.Pattern + ": preview text bounds overlap");
            if (pattern.Pattern == TagLayoutPattern.NearHost) CheckNearDistance(actual, form.Options, errors);
            if (test.Scale == 1 && test.Viewport.Width == 1366) Save(form, screenshots, test.Name + "_pattern_" + pattern.Pattern);
            leaders.SelectedIndex = (int)TagLeaderStyle.Orthogonal; Pump(form);
            var orthogonal = ReadPreview(preview);
            CheckOrthogonal(actual, orthogonal, errors);
            if (!apply.Enabled || form.Options.LeaderStyle != TagLeaderStyle.Orthogonal || shoulder.Enabled)
                errors.Add("Right-angle style is not usable or incorrectly enables the legacy shoulder setting");
            if (pattern.Pattern == TagLayoutPattern.VerticalColumn &&
                ((test.Scale == 1 && test.Viewport.Width == 1366) || (test.Scale == 2 && test.Viewport.Width == 876)))
            {
                tabs.SelectedIndex = 3; Pump(form);
                var leaderScroll = tabs.SelectedTab.Controls.OfType<Panel>().Single(p => p.AutoScroll);
                ScrollToInput(leaderScroll, leaders, form);
                Save(form, screenshots, test.Name + "_right_angle");
                leaderScroll.AutoScrollPosition = Point.Empty;
                tabs.SelectedIndex = 2; Pump(form);
            }
            leaders.SelectedIndex = (int)TagLeaderStyle.Straight; Pump(form);
        }

        tabs.SelectedIndex = 0; Pump(form);
        scope.SelectedIndex = 1; Pump(form);
        CheckPreview(preview, 7, false, errors);
        mode.SelectedIndex = 1; Pump(form);
        CheckPreview(preview, 3, false, errors);
        if (!apply.Enabled || apply.Text.IndexOf("Arrange", StringComparison.OrdinalIgnoreCase) < 0) errors.Add("Arrange mode is not available for the existing tags");
        var preserve = Find<CheckBox>(form, "TagPreserveTypes");
        if (!preserve.Enabled) errors.Add("Arrange mode does not enable preservation of existing types");
        if (grid.Rows.Cast<DataGridViewRow>().Any(row => !row.Cells["TagFamily"].ReadOnly || !row.Cells["TagType"].ReadOnly)) errors.Add("Preserving types should lock both family and type choices");
        preserve.Checked = false; Pump(form);
        if (grid.Rows.Cast<DataGridViewRow>().Any(row => row.Cells["TagFamily"].ReadOnly || row.Cells["TagType"].ReadOnly)) errors.Add("Replacing types should unlock both family and type choices");

        var clear = Find<Button>(form, "TagClearCategories");
        clear.PerformClick(); Pump(form);
        if (apply.Enabled) errors.Add("Clearing every category still permits Apply");
        if (ReadPreview(preview) != null) errors.Add("Empty category selection retains stale preview geometry");
        reset.PerformClick(); Pump(form);
        if (!apply.Enabled || form.Options.Mode != TagAssistantMode.CreateMissing || form.Options.Scope != TagAssistantScope.Selection || form.Options.Pattern != TagLayoutPattern.NearHost)
            errors.Add("Reset does not restore usable selection defaults");
        CheckPreview(preview, 4, true, errors);
        tabs.SelectedIndex = 1; Pump(form);
        var review = Find<DataGridView>(form, "TagElementReview");
        var search = Find<TextBox>(form, "TagElementSearch");
        if (review.Rows.Count != 5) errors.Add("Review grid must retain the short curve with an exclusion reason");
        var shortRow = ReviewRow(review, "host-4");
        if (Convert.ToBoolean(shortRow.Cells[0].Value) || !shortRow.Cells[0].ReadOnly) errors.Add("Short curve is not clearly unchecked and protected by the filter");
        if (string.IsNullOrWhiteSpace(Convert.ToString(shortRow.Cells[3].FormattedValue))) errors.Add("Short-curve exclusion reason missing");
        if (Convert.ToString(ReviewRow(review, "host-0").Cells[2].FormattedValue) != "Element 0") errors.Add("Review element label not rendered");
        ReviewRow(review, "host-0").Cells[0].Value = false; Pump(form);
        if (!form.Options.ExcludedCandidateKeys.Contains("host-0")) errors.Add("Unchecked element not excluded from options");
        CheckPreview(preview, 3, true, errors);
        search.Text = "Element 1"; Pump(form);
        if (review.Rows.Count != 1 || ((TagAssistantCandidate)review.Rows[0].Tag).Key != "host-1") errors.Add("Element review search does not filter the displayed rows");
        scope.SelectedIndex = 1; Pump(form); scope.SelectedIndex = 0; Pump(form);
        if (!form.Options.ExcludedCandidateKeys.Contains("host-0")) errors.Add("Changing scope/search cleared an explicit exclusion");
        search.Text = ""; Pump(form);
        CheckPreview(preview, 3, true, errors);
        Find<Button>(form, "TagIncludeVisibleButton").PerformClick(); Pump(form);
        CheckPreview(preview, 4, true, errors);
        Find<Button>(form, "TagExcludeVisibleButton").PerformClick(); Pump(form);
        if (apply.Enabled) errors.Add("Excluding all review rows still permits Apply");
        Find<Button>(form, "TagIncludeVisibleButton").PerformClick(); Pump(form);
        Find<CheckBox>(form, "TagSkipShortCurves").Checked = false; Pump(form);
        CheckPreview(preview, 5, true, errors);
        Find<CheckBox>(form, "TagSkipShortCurves").Checked = true; Pump(form);
        var maximum = Find<NumericUpDown>(form, "TagMaximumTags");
        maximum.Value = 3; Pump(form);
        if (apply.Enabled) errors.Add("Batch limit did not block an oversized selection");
        maximum.Value = 50; Pump(form);
        if (!apply.Enabled) errors.Add("Restoring a valid batch limit did not enable review");
        tabs.SelectedIndex = 1; Pump(form); Save(form, screenshots, test.Name + "_element_review");
        reset.PerformClick(); Pump(form);
        CheckPreview(preview, 4, true, errors); CheckNearDistance(ReadPreview(preview), form.Options, errors);
        Find<NumericUpDown>(form, "TagEstimatedWidthMm").Value = 200;
        Find<NumericUpDown>(form, "TagEstimatedHeightMm").Value = 100; Pump(form);
        var uncertain = ReadPreview(preview);
        if (uncertain == null || uncertain.Placements.Count != 0 || uncertain.SkippedKeys.Count != 4)
            errors.Add("Oversized estimates did not expose the expected uncertain layout");
        if (!apply.Enabled) errors.Add("Oversized estimates incorrectly block review of actual measured tag sizes");
        reset.PerformClick(); Pump(form);
        CheckPreview(preview, 4, true, errors);
        ValidateControl(apply, true, errors); ValidateControl(cancel, true, errors);
        tabs.SelectedIndex = 2; Pump(form);
        Save(form, screenshots, test.Name + "_final");
        form.Close();
    }

    private static void CheckNoSelection(Case test, string screenshots, List<string> errors)
    {
        var snapshot = Snapshot(); snapshot.HasSelection = false;
        foreach (var candidate in snapshot.Candidates) candidate.IsSelected = false;
        using (var form = new TagAssistantForm(snapshot))
        {
            form.Show(); Pump(form);
            var apply = Find<Button>(form, "TagApplyButton");
            if (form.Options.Scope != TagAssistantScope.Selection || form.Options.EnabledCategoryKeys.Count != 0 || apply.Enabled)
                errors.Add("No selection silently expands the operation to the entire view");
            Find<ComboBox>(form, "TagScope").SelectedIndex = 1; Pump(form);
            if (apply.Enabled || form.Options.EnabledCategoryKeys.Count != 0) errors.Add("Choosing Active view enables categories without explicit choice");
            Find<Button>(form, "TagSelectAllCategories").PerformClick(); Pump(form);
            if (!apply.Enabled || TagAssistantModel.Candidates(snapshot, form.Options).Count != 7)
                errors.Add("Explicit Active view + selected categories cannot be used");
            form.Close();
        }
    }

    private static DataGridViewRow ReviewRow(DataGridView grid, string key)
    { return grid.Rows.Cast<DataGridViewRow>().Single(row => ((TagAssistantCandidate)row.Tag).Key == key); }

    private static void CheckMissingFamilies(List<string> errors)
    {
        var snapshot = Snapshot();
        snapshot.Categories[0].Types.Clear();
        using (var form = new TagAssistantForm(snapshot))
        {
            form.Show(); Pump(form);
            var row = Find<DataGridView>(form, "TagCategoryTypes").Rows[0];
            var apply = Find<Button>(form, "TagApplyButton");
            if (!row.Cells["TagFamily"].ReadOnly || !row.Cells["TagType"].ReadOnly)
                errors.Add("Missing compatible families leave editable family or type selectors");
            if (!Convert.ToString(row.Cells["TagFamily"].FormattedValue).Contains("No compatible family") ||
                !Convert.ToString(row.Cells["TagType"].FormattedValue).Contains("No compatible type"))
                errors.Add("Missing compatible family/type placeholders are not visible");
            if (apply.Enabled || form.Options.SelectedTypeIds.ContainsKey("pipe"))
                errors.Add("A missing family permits creation or submits a placeholder type ID");
            Find<ComboBox>(form, "TagMode").SelectedIndex = 1; Pump(form);
            if (!apply.Enabled) errors.Add("Arranging preserved existing tags incorrectly requires a loaded replacement family");
            Find<CheckBox>(form, "TagPreserveTypes").Checked = false; Pump(form);
            if (apply.Enabled) errors.Add("Replacing existing tag types accepts a missing replacement family");
            form.Close();
        }
    }

    private static void CheckNearDistance(TagLayoutResult layout, TagAssistantOptions options, List<string> errors)
    {
        if (layout == null) return;
        double limit = TagAssistantModel.PaperToInternal(options.MaximumDistanceMm, 100);
        foreach (var placement in layout.Placements)
        {
            double dx = placement.Head.X - placement.Anchor.X, dy = placement.Head.Y - placement.Anchor.Y;
            if (Math.Sqrt(dx * dx + dy * dy) > limit + 1e-8) errors.Add("NearHost preview puts a tag beyond the selected paper distance");
        }
    }

    private static void CheckOrthogonal(TagLayoutResult reference, TagLayoutResult actual, List<string> errors)
    {
        if (reference == null || actual == null || reference.Placements.Count != actual.Placements.Count)
        { errors.Add("Right-angle choice changes or loses the aligned tag plan"); return; }
        foreach (var tag in actual.Placements)
        {
            var before = reference.Placements.Single(p => p.Key == tag.Key);
            if (Math.Abs(before.Head.X - tag.Head.X) > 1e-8 || Math.Abs(before.Head.Y - tag.Head.Y) > 1e-8)
                errors.Add("Right-angle style moves a tag head out of its chosen alignment");
            bool firstAxis = Math.Abs(tag.Anchor.X - tag.Elbow.X) <= 1e-8 || Math.Abs(tag.Anchor.Y - tag.Elbow.Y) <= 1e-8;
            bool secondAxis = Math.Abs(tag.Elbow.X - tag.Head.X) <= 1e-8 || Math.Abs(tag.Elbow.Y - tag.Head.Y) <= 1e-8;
            if (!firstAxis || !secondAxis) errors.Add("Right-angle preview contains a diagonal segment");
        }
    }

    private static TagAssistantSnapshot Snapshot()
    {
        var snapshot = new TagAssistantSnapshot { ViewName = "Level 01 – MEP Coordination", ViewScale = 100, HasSelection = true };
        string[] categories = { "pipe", "duct", "cabletray" };
        string[] names = { "Pipes", "Ducts", "Cable trays" };
        for (int i = 0; i < categories.Length; i++) snapshot.Categories.Add(new TagCategoryOption
        {
            Key = categories[i], Name = names[i], Types = new List<TagTypeOption>
            {
                new TagTypeOption { Id = 101 + i, Name = names[i] + " size tag : Size / System", FamilyName = names[i] + " size tag", TypeName = "Size / System" },
                new TagTypeOption { Id = 201 + i, Name = names[i] + " size tag : Size only", FamilyName = names[i] + " size tag", TypeName = "Size only" },
                new TagTypeOption { Id = 301 + i, Name = names[i] + " identification tag : Mark", FamilyName = names[i] + " identification tag", TypeName = "Mark" },
                new TagTypeOption { Id = 401 + i, Name = names[i] + " identification tag : Mark and system", FamilyName = names[i] + " identification tag", TypeName = "Mark and system" }
            }
        });
        for (int i = 0; i < 8; i++) snapshot.Candidates.Add(new TagAssistantCandidate
        {
            Key = "host-" + i, Label = "Element " + i, CategoryKey = categories[i % 3], HostId = i + 1,
            IsSelected = i < 5, Anchor = new TagPoint(17 + i * 11, -9 + (i % 3) * 8), Width = 6, Height = 1.2,
            IsCurve = true, CurveLengthInternal = i == 4 ? .2 : 15
        });
        for (int i = 0; i < 3; i++) snapshot.Candidates.Add(new TagAssistantCandidate
        {
            Key = "tag-" + i, Label = "Existing tag " + i, CategoryKey = categories[i], HostId = 100 + i,
            ExistingTagId = 1000 + i, IsSelected = i < 2, Anchor = new TagPoint(-30 + i * 7, 14 + i * 3),
            ExistingHead = new TagPoint(18, 17 + i * 6), Width = 6 + i, Height = 1.2
        });
        snapshot.Notes.Add("Test fixture: eight untagged hosts and three existing tags; selected subset contains five hosts and two tags.");
        return snapshot;
    }

    private static void CheckPreview(TagPatternPreview preview, int expectedCount, bool selectedOnly, List<string> errors)
    {
        var actual = ReadPreview(preview);
        if (actual == null || actual.Placements.Count != expectedCount)
        { errors.Add("Preview does not contain " + expectedCount + " eligible actual candidates"); return; }
        var source = Snapshot().Candidates.ToDictionary(c => c.Key);
        foreach (var placement in actual.Placements)
        {
            TagAssistantCandidate candidate;
            if (!source.TryGetValue(placement.Key, out candidate)) { errors.Add("Preview contains a fictitious candidate " + placement.Key); continue; }
            if (Math.Abs(placement.Anchor.X - candidate.Anchor.X) > 1e-9 || Math.Abs(placement.Anchor.Y - candidate.Anchor.Y) > 1e-9)
                errors.Add("Preview changes the source element anchor " + placement.Key);
            if (selectedOnly && !candidate.IsSelected) errors.Add("Selection preview includes an unselected element " + placement.Key);
        }
    }

    private static TagLayoutResult ReadPreview(TagPatternPreview preview)
    { return (TagLayoutResult)typeof(TagPatternPreview).GetField("_layout", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(preview); }

    private static void CheckVisibleSchematic(TagPatternPreview preview, List<string> errors)
    {
        // Inspect the rendered control so a positive-sized but blank preview cannot pass.
        // The proposed tags use a distinct pale teal fill; the white/grid background does not.
        using (var rendered = new Bitmap(preview.Width, preview.Height))
        {
            using (Graphics graphics = Graphics.FromImage(rendered))
                graphics.CopyFromScreen(preview.PointToScreen(Point.Empty), Point.Empty, preview.Size);
            int tagPixels = 0;
            for (int y = 0; y < rendered.Height; y++)
                for (int x = 0; x < rendered.Width; x++)
                {
                    Color pixel = rendered.GetPixel(x, y);
                    if (pixel.R >= 215 && pixel.R <= 229 && pixel.G >= 242 && pixel.G <= 251 && pixel.B >= 237 && pixel.B <= 247)
                        tagPixels++;
                }
            if (tagPixels < 8) errors.Add("The preview has candidate geometry but no visible proposed tag shapes at this viewport / scale");
        }
    }

    private static bool PairwiseDisjoint(IReadOnlyList<TagPlacement> placements)
    {
        for (int i = 0; i < placements.Count; i++)
            for (int j = i + 1; j < placements.Count; j++)
                if (placements[i].Bounds.Intersects(placements[j].Bounds)) return false;
        return true;
    }

    private static void ValidateControl(Control control, bool requireEnabled, List<string> errors)
    {
        Rectangle bounds = control.RectangleToScreen(control.ClientRectangle);
        string label = string.IsNullOrEmpty(control.Name) ? control.Text : control.Name;
        if (!control.Visible || (requireEnabled && !control.Enabled) || bounds.Width <= 0 || bounds.Height <= 0)
            errors.Add(label + " is hidden, disabled or empty");
        for (Control ancestor = control.Parent; ancestor != null; ancestor = ancestor.Parent)
        {
            Rectangle available = ancestor.RectangleToScreen(ancestor.ClientRectangle);
            if (!available.Contains(bounds)) errors.Add(label + " clipped by " + ancestor.GetType().Name + " available=" + available + " control=" + bounds);
        }
    }

    private static void ScrollToInput(Panel panel, Control input, Form form)
    {
        panel.ScrollControlIntoView(input); Pump(form);
        // Mono's ScrollControlIntoView can stop at a nested TableLayoutPanel. Simulate the
        // remaining scrollbar movement explicitly to test reachability rather than that API.
        for (int attempt = 0; attempt < 2; attempt++)
        {
            Rectangle bounds = panel.RectangleToClient(input.RectangleToScreen(input.ClientRectangle));
            int dx = bounds.Left < 0 ? bounds.Left : Math.Max(0, bounds.Right - panel.ClientSize.Width);
            int dy = bounds.Top < 0 ? bounds.Top : Math.Max(0, bounds.Bottom - panel.ClientSize.Height);
            if (dx == 0 && dy == 0) return;
            panel.AutoScrollPosition = new Point(Math.Max(0, -panel.AutoScrollPosition.X + dx), Math.Max(0, -panel.AutoScrollPosition.Y + dy));
            Pump(form);
        }
    }

    private static void ValidateNoOverlap(Control[] controls, List<string> errors)
    {
        for (int i = 0; i < controls.Length; i++)
            for (int j = i + 1; j < controls.Length; j++)
                if (controls[i].RectangleToScreen(controls[i].ClientRectangle).IntersectsWith(controls[j].RectangleToScreen(controls[j].ClientRectangle)))
                    errors.Add(controls[i].Name + " overlaps " + controls[j].Name);
    }

    private static void Save(Form form, string directory, string name)
    {
        if (directory == null) return;
        using (var image = new Bitmap(form.Width, form.Height))
        {
            using (Graphics graphics = Graphics.FromImage(image)) graphics.CopyFromScreen(form.Location, Point.Empty, form.Size);
            image.Save(Path.Combine(directory, name + ".png"));
        }
    }
    private static T Find<T>(Control root, string name) where T : Control
    { return Descendants(root).OfType<T>().Single(control => control.Name == name); }
    private static string Value(string[] args, string prefix)
    { string value = args.FirstOrDefault(arg => arg.StartsWith(prefix, StringComparison.Ordinal)); return value == null ? null : value.Substring(prefix.Length); }
    private static void Pump(Control root)
    {
        for (int i = 0; i < 3; i++)
        { foreach (Control control in Descendants(root).Reverse()) control.PerformLayout(); Application.DoEvents(); }
    }
    private static IEnumerable<Control> Descendants(Control root)
    { yield return root; foreach (Control child in root.Controls) foreach (Control control in Descendants(child)) yield return control; }
    private sealed class Case
    {
        public readonly Size Viewport; public readonly float Scale;
        public Case(int width, int height, float scale) { Viewport = new Size(width, height); Scale = scale; }
        public string Name { get { return Viewport.Width + "x" + Viewport.Height + "_" + (Scale * 100).ToString("0", CultureInfo.InvariantCulture); } }
    }
    private sealed class FontSpec
    {
        public readonly Control Control; public readonly string Family; public readonly float Size; public readonly FontStyle Style; public readonly GraphicsUnit Unit;
        public FontSpec(Control control) { Control = control; Family = control.Font.FontFamily.Name; Size = control.Font.Size; Style = control.Font.Style; Unit = control.Font.Unit; }
    }
}
