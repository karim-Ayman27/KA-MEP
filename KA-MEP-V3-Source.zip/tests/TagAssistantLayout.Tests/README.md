# Detached Tag Assistant UI checks

This harness links the production `TagAssistantForm`, `TagPatternPreview`, model and branding. It supplies detached fixture data; it never opens Revit, creates tags, or installs an add-in.

Checks cover visible fixed Apply/Cancel/Reset controls, four scrollable settings tabs, all six pattern choices, correct preview anchors and eligible candidate counts, active-view versus selection behavior, create versus arrange behavior, preservation/replacement of tag types, clearing categories and resetting settings. Nearby checks include selection-only defaults, no whole-view fallback, manual element exclusions across search/scope changes, short-curve reasons, maximum batch count, bounded preview distance, and access to actual-size review when estimated labels cannot fit.

The nine viewport cases use 1366×728, 1280×680, 1024×600 and 876×571 client sizes with explicit 100%, 150% and 200% control/font scales. This is a Mono layout regression check, not native Windows DPI certification. Run each case in a separate process under Xvfb to avoid accumulated Mono/libgdiplus native resource problems. `--screenshots=<directory>` captures each tab, the pattern choices in the reference case, and the final state. `--case=1280x680_200` selects one case.

Build with the .NET SDK, then run `KAMEP.TagAssistantLayout.Tests.exe` using a .NET Framework-compatible runtime with a display. Actual Revit creation, tag-family geometry, transaction behavior and Windows DPI remain separate runtime checks.
