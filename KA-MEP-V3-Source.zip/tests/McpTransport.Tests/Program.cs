using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using PipeTakeoff.Core.Mcp;

internal static class Program
{
    private const string Secret = "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
    private const string OtherSecret = "abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789";
    private static int passed, failed;

    private static async Task<int> Main()
    {
        Console.WriteLine("KA MEP MCP transport: actual IPv4 loopback sockets and production Core assembly");
        // Exercise production deadlines concurrently so their full durations do not add up.
        var deadlines = new[] {
            Run("incomplete frame expires after network deadline", NetworkDeadline),
            Run("server request deadline cancels queued handler", ServerDeadline),
            Run("client request deadline bounds silent peer", ClientDeadline)
        };
        await Run("token format and listener lifecycle", Lifecycle);
        await Run("authenticated round trip and caller isolation", RoundTrip);
        await Run("wrong, stale, missing and malformed tokens reject before dispatch", Authentication);
        await Run("zero, oversized and unsigned frame lengths reject", FrameLengths);
        await Run("truncated header and payload reject", TruncatedFrames);
        await Run("malformed JSON, null and invalid UTF-8 reject", MalformedJson);
        await Run("fragmented header and payload assemble correctly", Fragmentation);
        await Run("unsupported tools and argument bounds reject before dispatch", RequestValidation);
        await Run("request byte boundary and client oversize guard", RequestBounds);
        await Run("response byte boundary and server oversize fallback", ResponseBounds);
        await Run("server owns correlation without mutating handler response", ServerCorrelation);
        await Run("client rejects wrong correlation and protocol", ClientCorrelation);
        await Run("client rejects malformed, incomplete and oversized responses", InvalidResponses);
        await Run("handler exceptions are sanitized and listener recovers", HandlerFailure);
        await Run("caller cancellation closes socket and cancels handler", CallerCancellation);
        await Run("peer disconnect cancels handler and releases worker", PeerDisconnect);
        await Run("extra frame cancels single-call request", ExtraFrame);
        await Run("stop cancels active work and refuses new connections", Stop);
        await Run("four-worker concurrency is bounded and queued calls recover", Concurrency);
        await Run("invalid connection and pre-cancelled call fail locally", InvalidConnection);
        await Task.WhenAll(deadlines);
        Console.WriteLine("RESULT: " + passed + " passed, " + failed + " failed.");
        Console.WriteLine("Scope: transport only; no Revit API substitutes, Revit-host execution or Claude Desktop interoperability claimed.");
        return failed == 0 ? 0 : 1;
    }

    private static async Task Run(string name, Func<Task> test)
    {
        var clock = Stopwatch.StartNew();
        try { await test(); Interlocked.Increment(ref passed); Console.WriteLine("PASS " + name + " (" + clock.ElapsedMilliseconds + " ms)"); }
        catch (Exception error) { Interlocked.Increment(ref failed); Console.WriteLine("FAIL " + name + ": " + error); }
    }

    private static McpWireRequest Request(string id = "request-1", string token = null)
    {
        return new McpWireRequest { RequestId = id, Token = token, Tool = "ka_revit_project_info", Arguments = new McpArguments() };
    }
    private static McpConnection Connection(int port, string token = Secret) { return new McpConnection { Port = port, Token = token }; }
    private static McpWireResponse Ok(McpWireRequest request) { return new McpWireResponse { RequestId = request.RequestId, Success = true, PayloadJson = "{\"transport\":true}" }; }
    private static Task<McpWireResponse> Echo(McpWireRequest request, CancellationToken token) { return Task.FromResult(Ok(request)); }
    private static TaskCompletionSource<bool> Signal() { return new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously); }
    private static void Check(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
    private static async Task Within(Task task, int milliseconds = 6000)
    {
        if (await Task.WhenAny(task, Task.Delay(milliseconds)) != task) throw new TimeoutException("Test operation exceeded " + milliseconds + " ms.");
        await task;
    }
    private static async Task<T> Within<T>(Task<T> task, int milliseconds = 6000) { await Within((Task)task, milliseconds); return await task; }
    private static async Task Expect<T>(Func<Task> action) where T : Exception
    {
        try { await action(); }
        catch (T) { return; }
        throw new InvalidOperationException("Expected " + typeof(T).Name + ".");
    }
    private static async Task<TcpClient> Connect(int port)
    {
        var client = new TcpClient(AddressFamily.InterNetwork);
        try { await Within(client.ConnectAsync(IPAddress.Loopback, port)); client.NoDelay = true; return client; }
        catch { client.Dispose(); throw; }
    }
    private static byte[] Header(uint count) { return new[] { (byte)(count >> 24), (byte)(count >> 16), (byte)(count >> 8), (byte)count }; }
    private static async Task Write(NetworkStream stream, byte[] bytes) { await stream.WriteAsync(bytes, 0, bytes.Length); }
    private static async Task Send(NetworkStream stream, byte[] bytes) { await Write(stream, Header((uint)bytes.Length)); await Write(stream, bytes); }
    private static async Task ReadExactly(NetworkStream stream, byte[] bytes)
    {
        int offset = 0;
        while (offset < bytes.Length)
        {
            var count = await Within(stream.ReadAsync(bytes, offset, bytes.Length - offset));
            if (count == 0) throw new EndOfStreamException();
            offset += count;
        }
    }
    private static async Task<byte[]> Read(NetworkStream stream)
    {
        var header = new byte[4]; await ReadExactly(stream, header);
        uint count = ((uint)header[0] << 24) | ((uint)header[1] << 16) | ((uint)header[2] << 8) | header[3];
        Check(count > 0 && count <= McpLimits.MaxResponseBytes, "Unexpected response frame length.");
        var body = new byte[count]; await ReadExactly(stream, body); return body;
    }
    private static async Task<McpWireResponse> Raw(int port, byte[] body)
    {
        using (var client = await Connect(port)) { await Send(client.GetStream(), body); return McpWireCodec.Deserialize<McpWireResponse>(await Read(client.GetStream())); }
    }
    private static Task<McpWireResponse> Raw(int port, McpWireRequest request) { return Raw(port, McpWireCodec.Serialize(request)); }

    private static async Task Lifecycle()
    {
        foreach (var token in new[] { null, "", new string('a', 63), new string('a', 65), new string('z', 64) })
            using (var invalid = new McpLoopbackServer(Echo)) await Expect<ArgumentException>(() => { invalid.Start(token); return Task.CompletedTask; });
        var server = new McpLoopbackServer(Echo);
        int port = server.Start(Secret.ToUpperInvariant());
        try
        {
            await Expect<InvalidOperationException>(() => { server.Start(Secret); return Task.CompletedTask; });
            using (var client = await Connect(port)) Check(((IPEndPoint)client.Client.RemoteEndPoint).Address.Equals(IPAddress.Loopback), "Listener must use IPv4 loopback.");
            Check((await Within(McpLoopbackClient.Call(Connection(port), Request(), CancellationToken.None))).Success, "Hex tokens must match decoded bytes.");
        }
        finally { server.Dispose(); server.Dispose(); }
        await Expect<ObjectDisposedException>(() => { server.Start(Secret); return Task.CompletedTask; });
    }

    private static async Task RoundTrip()
    {
        bool tokenRemoved = false;
        using (var server = new McpLoopbackServer((request, token) => { tokenRemoved = request.Token == null; return Echo(request, token); }))
        {
            var request = Request("round-trip", "caller-owned-value");
            var response = await Within(McpLoopbackClient.Call(Connection(server.Start(Secret)), request, CancellationToken.None));
            Check(response.Success && response.RequestId == request.RequestId && response.Protocol == 1, "Authenticated response did not correlate.");
            Check(response.PayloadJson == "{\"transport\":true}" && tokenRemoved, "Handler payload or authentication isolation failed.");
            Check(request.Token == "caller-owned-value", "Client mutated its caller's request token.");
        }
    }

    private static async Task Authentication()
    {
        int calls = 0;
        using (var stale = new McpLoopbackServer(Echo)) stale.Start(OtherSecret);
        using (var server = new McpLoopbackServer((request, token) => { Interlocked.Increment(ref calls); return Echo(request, token); }))
        {
            int port = server.Start(Secret);
            foreach (var token in new[] { OtherSecret, null, "", new string('g', 64), Secret.Substring(1) })
            {
                var request = Request("must-not-be-reflected", token); request.Tool = "unsupported";
                var response = await Raw(port, request);
                Check(!response.Success && response.ErrorCode == "authentication_failed" && response.RequestId == null, "Authentication must precede semantic validation.");
                string json = McpWireCodec.Json(response);
                Check(!json.Contains(Secret) && !json.Contains(OtherSecret), "Error exposed an authentication token.");
            }
            Check(calls == 0, "Unauthenticated requests reached handler.");
            Check((await Raw(port, Request(token: Secret))).Success && calls == 1, "Listener did not recover after rejected authentication.");
        }
    }

    private static async Task FrameLengths()
    {
        int calls = 0;
        using (var server = new McpLoopbackServer((request, token) => { calls++; return Echo(request, token); }))
        {
            int port = server.Start(Secret);
            foreach (var length in new[] { 0u, (uint)McpLimits.MaxRequestBytes + 1u, uint.MaxValue, 0x80000000u })
                using (var client = await Connect(port))
                {
                    await Write(client.GetStream(), Header(length));
                    Check(McpWireCodec.Deserialize<McpWireResponse>(await Read(client.GetStream())).ErrorCode == "invalid_request", "Invalid frame length was not rejected.");
                }
            Check(calls == 0, "Invalid frame reached handler.");
        }
    }

    private static async Task TruncatedFrames()
    {
        using (var server = new McpLoopbackServer(Echo))
        {
            int port = server.Start(Secret);
            foreach (var bytes in new[] { new byte[] { 0, 0 }, Header(100).Concat(Encoding.UTF8.GetBytes("{}" )).ToArray() })
                using (var client = await Connect(port))
                {
                    var stream = client.GetStream();
                    await Write(stream, bytes); client.Client.Shutdown(SocketShutdown.Send);
                    Check(McpWireCodec.Deserialize<McpWireResponse>(await Read(stream)).ErrorCode == "invalid_request", "Incomplete frame was not rejected.");
                }
        }
    }

    private static async Task MalformedJson()
    {
        int calls = 0;
        using (var server = new McpLoopbackServer((request, token) => { calls++; return Echo(request, token); }))
        {
            int port = server.Start(Secret);
            foreach (var bytes in new[] { Encoding.UTF8.GetBytes("{"), Encoding.UTF8.GetBytes("null"), Encoding.UTF8.GetBytes("[]"), new byte[] { 0xff, 0xfe, 0xff } })
            {
                var response = await Raw(port, bytes);
                Check(!response.Success && (response.ErrorCode == "invalid_request" || response.ErrorCode == "authentication_failed"), "Malformed JSON was accepted.");
            }
            Check(calls == 0, "Malformed JSON reached handler.");
        }
    }

    private static async Task Fragmentation()
    {
        using (var server = new McpLoopbackServer(Echo))
        using (var client = await Connect(server.Start(Secret)))
        {
            var bytes = McpWireCodec.Serialize(Request(token: Secret));
            foreach (var value in Header((uint)bytes.Length)) { await Write(client.GetStream(), new[] { value }); await Task.Delay(5); }
            for (int offset = 0; offset < bytes.Length; offset += 7) await client.GetStream().WriteAsync(bytes, offset, Math.Min(7, bytes.Length - offset));
            Check(McpWireCodec.Deserialize<McpWireResponse>(await Read(client.GetStream())).Success, "Fragmented request did not assemble.");
        }
    }

    private static async Task RequestValidation()
    {
        int calls = 0;
        Action<McpWireRequest>[] invalid = {
            r => r.Protocol = 2, r => r.RequestId = null, r => r.RequestId = new string('i', 81), r => r.Tool = "delete_elements",
            r => r.Arguments = null, r => r.Arguments.Limit = 0, r => r.Arguments.Limit = 201,
            r => r.Arguments.Offset = -1, r => r.Arguments.Offset = 100001, r => r.Arguments.Query = new string('q', 161),
            r => r.Arguments.ProjectKey = new string('p', 65), r => r.Arguments.ElementId = "-1",
            r => r.Arguments.ElementId = "9223372036854775808", r => r.Arguments.UniqueId = new string('u', 129),
            r => r.Tool = "ka_revit_selection",
            r => { r.Tool = "ka_revit_find_elements"; r.Arguments.ProjectKey = "session"; r.Arguments.Category = "unsupported"; },
            r => { r.Tool = "ka_revit_element_parameters"; r.Arguments.ProjectKey = "session"; }
        };
        using (var server = new McpLoopbackServer((request, token) => { calls++; return Echo(request, token); }))
        {
            int port = server.Start(Secret);
            foreach (var change in invalid)
            {
                var request = Request(token: Secret); change(request);
                var response = await Raw(port, request);
                Check(response.ErrorCode == "invalid_request", "Invalid request arguments were not rejected.");
            }
            Check(calls == 0, "Invalid arguments reached handler.");
        }
    }

    private static async Task RequestBounds()
    {
        using (var server = new McpLoopbackServer(Echo))
        {
            int port = server.Start(Secret);
            // JSON whitespace is valid and makes the actual frame exactly the published byte bound.
            var request = McpWireCodec.Serialize(Request(token: Secret));
            var boundary = request.Concat(Enumerable.Repeat((byte)' ', McpLimits.MaxRequestBytes - request.Length)).ToArray();
            Check((await Raw(port, boundary)).Success, "Exactly 64 KiB request was rejected.");
            var oversized = Request(); oversized.Arguments.Category = new string('x', McpLimits.MaxRequestBytes);
            await Expect<IOException>(() => McpLoopbackClient.Call(Connection(port), oversized, CancellationToken.None));
        }
    }

    private static async Task ResponseBounds()
    {
        var response = new McpWireResponse { RequestId = "request-1", Success = true, PayloadJson = "" };
        int overhead = McpWireCodec.Serialize(response).Length;
        response.PayloadJson = new string('x', McpLimits.MaxResponseBytes - overhead);
        Check(McpWireCodec.Serialize(response).Length == McpLimits.MaxResponseBytes, "Boundary setup failed.");
        using (var server = new McpLoopbackServer((request, token) => Task.FromResult(response)))
        {
            int port = server.Start(Secret);
            var exact = await Within(McpLoopbackClient.Call(Connection(port), Request(), CancellationToken.None));
            Check(exact.Success && exact.PayloadJson.Length == response.PayloadJson.Length, "Exactly 1 MiB response was rejected.");
            response.PayloadJson += "x";
            var over = await Within(McpLoopbackClient.Call(Connection(port), Request(), CancellationToken.None));
            Check(!over.Success && over.ErrorCode == "response_too_large" && over.RequestId == "request-1", "Oversized response did not return a correlated bounded error.");
        }
    }

    private static async Task ServerCorrelation()
    {
        var shared = new McpWireResponse { Protocol = 9, RequestId = "handler-owned", Success = true, PayloadJson = "{}" };
        var entered = Signal();
        int active = 0;
        using (var server = new McpLoopbackServer(async (request, token) =>
        {
            if (Interlocked.Increment(ref active) == 4) entered.TrySetResult(true);
            await Within(entered.Task);
            return shared;
        }))
        {
            int port = server.Start(Secret);
            // Occupy every worker before releasing the shared response. This exercises
            // concurrent correlation without depending on the OS listen-backlog policy.
            var calls = Enumerable.Range(0, 4).Select(i => McpLoopbackClient.Call(Connection(port), Request("parallel-" + i), CancellationToken.None)).ToArray();
            var responses = await Within(Task.WhenAll(calls));
            for (int i = 0; i < responses.Length; i++) Check(responses[i].RequestId == "parallel-" + i && responses[i].Protocol == 1, "Concurrent response correlation was corrupted.");
            Check(shared.RequestId == "handler-owned" && shared.Protocol == 9, "Transport mutated shared handler response.");
        }
    }

    private static async Task AgainstPeer(Func<NetworkStream, Task> respond, Func<int, Task> call)
    {
        var listener = new TcpListener(IPAddress.Loopback, 0); listener.Start();
        try
        {
            int port = ((IPEndPoint)listener.LocalEndpoint).Port;
            var peer = Task.Run(async () => { using (var client = await listener.AcceptTcpClientAsync()) { await Read(client.GetStream()); await respond(client.GetStream()); } });
            await call(port); await Within(peer);
        }
        finally { listener.Stop(); }
    }

    private static async Task ClientCorrelation()
    {
        foreach (var response in new[] {
            new McpWireResponse { RequestId = "other-request", Success = true },
            new McpWireResponse { RequestId = "request-1", Protocol = 2, Success = true },
            new McpWireResponse { RequestId = null, Success = true }
        })
            await AgainstPeer(s => Send(s, McpWireCodec.Serialize(response)), p => Expect<IOException>(() => McpLoopbackClient.Call(Connection(p), Request(), CancellationToken.None)));
    }

    private static async Task InvalidResponses()
    {
        Func<NetworkStream, Task>[] responses = {
            s => Write(s, Header((uint)McpLimits.MaxResponseBytes + 1)), s => Write(s, Header(uint.MaxValue)), s => Write(s, Header(0)),
            s => Send(s, Encoding.UTF8.GetBytes("{")), s => Send(s, Encoding.UTF8.GetBytes("null")),
            s => Write(s, new byte[] { 0, 0 }),
            async s => { await Write(s, Header(100)); await Write(s, Encoding.UTF8.GetBytes("{}")); }
        };
        foreach (var response in responses)
            await AgainstPeer(response, p => Expect<IOException>(() => McpLoopbackClient.Call(Connection(p), Request(), CancellationToken.None)));
    }

    private static async Task HandlerFailure()
    {
        int calls = 0;
        using (var server = new McpLoopbackServer((request, token) =>
        {
            if (Interlocked.Increment(ref calls) == 1) throw new InvalidOperationException("sensitive-native-error " + Secret);
            if (calls == 2) return Task.FromResult<McpWireResponse>(null);
            return Echo(request, token);
        }))
        {
            int port = server.Start(Secret);
            for (int i = 0; i < 2; i++)
            {
                var response = await Within(McpLoopbackClient.Call(Connection(port), Request(), CancellationToken.None));
                Check(response.ErrorCode == "bridge_error" && !McpWireCodec.Json(response).Contains(Secret) && !response.Error.Contains("sensitive-native-error"), "Handler exception was exposed.");
            }
            Check((await Within(McpLoopbackClient.Call(Connection(port), Request(), CancellationToken.None))).Success, "Worker did not recover after handler failure.");
        }
    }

    private static async Task CallerCancellation()
    {
        var entered = Signal(); var cancelled = Signal();
        using (var server = new McpLoopbackServer(async (request, token) =>
        {
            entered.TrySetResult(true);
            using (token.Register(() => cancelled.TrySetResult(true))) await Task.Delay(Timeout.Infinite, token);
            return Ok(request);
        }))
        using (var cancellation = new CancellationTokenSource())
        {
            var call = McpLoopbackClient.Call(Connection(server.Start(Secret)), Request(), cancellation.Token);
            await Within(entered.Task); cancellation.Cancel();
            await Expect<OperationCanceledException>(() => Within(call)); await Within(cancelled.Task);
        }
    }

    private static async Task PeerDisconnect()
    {
        var entered = Signal(); var cancelled = Signal(); int calls = 0;
        using (var server = new McpLoopbackServer(async (request, token) =>
        {
            if (Interlocked.Increment(ref calls) == 1)
            {
                entered.TrySetResult(true);
                using (token.Register(() => cancelled.TrySetResult(true))) await Task.Delay(Timeout.Infinite, token);
            }
            return Ok(request);
        }))
        {
            int port = server.Start(Secret);
            using (var client = await Connect(port)) { await Send(client.GetStream(), McpWireCodec.Serialize(Request(token: Secret))); await Within(entered.Task); }
            await Within(cancelled.Task);
            Check((await Within(McpLoopbackClient.Call(Connection(port), Request(), CancellationToken.None))).Success, "Listener did not recover after disconnect.");
        }
    }

    private static async Task ExtraFrame()
    {
        var entered = Signal(); var cancelled = Signal();
        using (var server = new McpLoopbackServer(async (request, token) =>
        {
            entered.TrySetResult(true);
            using (token.Register(() => cancelled.TrySetResult(true))) await Task.Delay(Timeout.Infinite, token);
            return Ok(request);
        }))
        using (var client = await Connect(server.Start(Secret)))
        {
            await Send(client.GetStream(), McpWireCodec.Serialize(Request(token: Secret))); await Within(entered.Task);
            await Send(client.GetStream(), McpWireCodec.Serialize(Request("second", Secret))); await Within(cancelled.Task);
        }
    }

    private static async Task Stop()
    {
        var entered = Signal(); var cancelled = Signal();
        var server = new McpLoopbackServer(async (request, token) =>
        {
            entered.TrySetResult(true);
            using (token.Register(() => cancelled.TrySetResult(true))) await Task.Delay(Timeout.Infinite, token);
            return Ok(request);
        });
        int port = server.Start(Secret);
        var call = McpLoopbackClient.Call(Connection(port), Request(), CancellationToken.None);
        try { await Within(entered.Task); var clock = Stopwatch.StartNew(); server.Dispose(); Check(clock.ElapsedMilliseconds < 1000, "Stop blocked its caller."); await Within(cancelled.Task); await Expect<IOException>(() => Within(call)); }
        finally { server.Dispose(); }
        await Expect<IOException>(() => Within(McpLoopbackClient.Call(Connection(port), Request(), CancellationToken.None)));
    }

    private static async Task Concurrency()
    {
        int active = 0, maximum = 0, enteredCount = 0;
        var fourEntered = Signal(); var release = Signal();
        using (var server = new McpLoopbackServer(async (request, token) =>
        {
            int current = Interlocked.Increment(ref active);
            int previous;
            do { previous = maximum; if (current <= previous) break; } while (Interlocked.CompareExchange(ref maximum, current, previous) != previous);
            if (Interlocked.Increment(ref enteredCount) == 4) fourEntered.TrySetResult(true);
            try { await release.Task; token.ThrowIfCancellationRequested(); return Ok(request); }
            finally { Interlocked.Decrement(ref active); }
        }))
        {
            int port = server.Start(Secret);
            var calls = Enumerable.Range(0, 8).Select(i => McpLoopbackClient.Call(Connection(port), Request("bounded-" + i), CancellationToken.None)).ToArray();
            try
            {
                await Within(fourEntered.Task); await Task.Delay(250);
                Check(enteredCount == 4 && maximum == 4, "More than four concurrent handlers were dispatched.");
            }
            finally { release.TrySetResult(true); }
            var responses = await Within(Task.WhenAll(calls));
            Check(responses.All(r => r.Success) && enteredCount == 8 && maximum == 4 && active == 0, "Queued calls were not drained under the worker bound.");
        }
    }

    private static async Task InvalidConnection()
    {
        foreach (var connection in new[] { null, Connection(0), Connection(65536), Connection(1, "invalid"), new McpConnection { Port = 1, Token = Secret, Protocol = 2 } })
            await Expect<IOException>(() => McpLoopbackClient.Call(connection, Request(), CancellationToken.None));
        using (var cancellation = new CancellationTokenSource())
        {
            cancellation.Cancel(); await Expect<OperationCanceledException>(() => McpLoopbackClient.Call(Connection(1), Request(), cancellation.Token));
        }
    }

    private static async Task NetworkDeadline()
    {
        using (var server = new McpLoopbackServer(Echo))
        using (var client = await Connect(server.Start(Secret)))
        {
            await Write(client.GetStream(), new byte[] { 0 }); var clock = Stopwatch.StartNew();
            var buffer = new byte[1];
            try { Check(await Within(client.GetStream().ReadAsync(buffer, 0, 1), 9000) == 0, "Incomplete frame received unexpected output."); }
            catch (IOException) { }
            Check(clock.ElapsedMilliseconds >= 4000 && clock.ElapsedMilliseconds < 9000, "Network deadline was not approximately five seconds.");
        }
    }

    private static async Task ServerDeadline()
    {
        var entered = Signal(); var cancelled = Signal();
        using (var server = new McpLoopbackServer(async (request, token) =>
        {
            entered.TrySetResult(true);
            using (token.Register(() => cancelled.TrySetResult(true))) await Task.Delay(Timeout.Infinite, token);
            return Ok(request);
        }))
        using (var client = await Connect(server.Start(Secret)))
        {
            var clock = Stopwatch.StartNew(); await Send(client.GetStream(), McpWireCodec.Serialize(Request(token: Secret)));
            await Within(entered.Task); await Within(cancelled.Task, 35000);
            Check(clock.ElapsedMilliseconds >= 28000 && clock.ElapsedMilliseconds < 35000, "Server deadline was not approximately thirty seconds.");
            var buffer = new byte[1];
            try { Check(await Within(client.GetStream().ReadAsync(buffer, 0, 1)) == 0, "Timed-out server connection stayed open."); }
            catch (IOException) { }
        }
    }

    private static async Task ClientDeadline()
    {
        var listener = new TcpListener(IPAddress.Loopback, 0); listener.Start();
        try
        {
            int port = ((IPEndPoint)listener.LocalEndpoint).Port;
            var clock = Stopwatch.StartNew(); var call = McpLoopbackClient.Call(Connection(port), Request(), CancellationToken.None);
            using (var peer = await Within(listener.AcceptTcpClientAsync()))
            {
                await Read(peer.GetStream());
                try { await Within(call, 35000); throw new InvalidOperationException("Silent peer did not time out."); }
                catch (IOException error) { Check(error.Message.Contains("timed out"), "Client did not report its request deadline."); }
                Check(clock.ElapsedMilliseconds >= 28000 && clock.ElapsedMilliseconds < 35000, "Client deadline was not approximately thirty seconds.");
            }
        }
        finally { listener.Stop(); }
    }
}
