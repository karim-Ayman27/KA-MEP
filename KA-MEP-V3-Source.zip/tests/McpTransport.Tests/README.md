# MCP loopback transport tests

Run `dotnet run --project tests/McpTransport.Tests/McpTransport.Tests.csproj -c Release`.
The harness uses the production `KAMEP.Core` assembly and actual IPv4 TCP sockets.
It exercises authentication, length-prefixed framing, exact 64 KiB / 1 MiB byte
boundaries, request validation, correlation, exception sanitization, cancellation,
disconnect, stop, four-worker concurrency, and the actual five-second network and
thirty-second request deadlines. Deadline checks run concurrently; allow about
35 seconds for the suite. Any failed check produces a nonzero exit status.

Adversarial peers use actual loopback listeners to send invalid responses. The
test handler is only the transport's callback; no Revit API is substituted or
claimed to execute. Revit-host behavior and Claude Desktop interoperability
require their separate Windows/Revit acceptance checks.
