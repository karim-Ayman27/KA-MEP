using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using PipeTakeoff.Revit;

internal static class Program
{
    [STAThread]
    private static int Main(string[] args)
    {
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        string only = Arg(args, "--case="), screenshots = Arg(args, "--screenshots=");
        if (screenshots != null) Directory.CreateDirectory(screenshots);
        int passed = 0, total = 0;
        foreach (var test in new[] { new Case(1366,728,1), new Case(1280,680,1.5F), new Case(1280,680,2),
            new Case(1024,600,1), new Case(1024,600,1.5F), new Case(1024,600,2),
            new Case(876,571,1), new Case(876,571,1.5F), new Case(876,571,2) })
        {
            if (only != null && only != test.Name) continue;
            total++; var errors = new List<string>();
            try { Check(test, screenshots, errors); } catch (Exception ex) { errors.Add(ex.ToString()); }
            Console.WriteLine((errors.Count == 0 ? "PASS " : "FAIL ") + test.Name);
            foreach (string error in errors.Distinct()) Console.WriteLine("  " + error);
            if (errors.Count == 0) passed++;
        }
        Console.WriteLine("RESULT: " + passed + "/" + total + " MCP Connection UI cases passed; " + (total-passed) + " failed.");
        Console.WriteLine("Actual detached production form under Mono/Xvfb with simulated font/control scaling; not Windows DPI, Claude Desktop, or live Revit.");
        return total > 0 && total == passed ? 0 : 1;
    }

    private static void Check(Case test, string screenshots, List<string> errors)
    {
        using (var form = new McpConnectionForm())
        {
            int enables = 0, stops = 0, saves = 0;
            form.EnableRequested += () => enables++;
            form.StopRequested += () => stops++;
            form.SaveConfigRequested += () => saves++;
            ShowScaled(form, test);
            var enable = Find<Button>(form, "McpEnable");
            var stop = Find<Button>(form, "McpStop");
            var save = Find<Button>(form, "McpSaveConfig");
            var close = Find<Button>(form, "McpClose");
            var state = Find<Label>(form, "McpState");
            var project = Find<Label>(form, "McpProject");
            var activity = Find<Label>(form, "McpActivity");
            var status = Find<TextBox>(form, "McpStatus");
            var connection = Find<TextBox>(form, "McpConnectionFile");
            var helper = Find<TextBox>(form, "McpHelperPath");
            var viewport = Find<Panel>(form, "McpHelpViewport");
            Require(form.Icon != null, "Branded window icon missing", errors);
            Require(!form.EnabledConnection && state.Text == "Disabled", "Connection does not start disabled", errors);
            Require(enables == 0 && stops == 0 && saves == 0, "Opening the window performs a connection action", errors);
            Require(!enable.Enabled && !stop.Enabled && !save.Enabled, "Missing project/helper permits an action", errors);
            Require(!Descendants(form).Any(control => control is WebBrowser), "Setup instructions use an executable browser", errors);
            Require(Descendants(form).OfType<TextBox>().All(box => box.ReadOnly), "Connection form exposes editable configuration or credential fields", errors);
            Require(form.AcceptButton == null, "Enter can implicitly enable the connection", errors);
            Require(Find<Label>(form, "McpDisclosure").Text == "Requested model data is sent to your Claude conversation.", "Data disclosure missing", errors);
            Require(Find<Label>(form, "McpMode").Text.Contains("Read-only"), "Read-only session label missing", errors);
            foreach (var button in new[] { enable, stop, save, close }) { Visible(button, errors); ButtonTextFits(button, errors); }
            Visible(status, errors); Visible(activity, errors); Visible(project, errors); Visible(state, errors);

            const string projectTitle = "Coordination — HVAC & MEP — غرفة الخدمات";
            const string connectionPath = @"C:\Users\MEP Engineer\AppData\Local\KAMEP\MCP\connection-2025.json";
            const string helperPath = @"C:\ProgramData\Autodesk\Revit\Addins\2025\KAMEP\KAMEP.Mcp.Server.exe";
            form.SetContext(projectTitle, connectionPath, helperPath, true); Pump(form);
            Console.WriteLine("Rendered form font: " + form.Font.FontFamily.Name + " " + form.Font.SizeInPoints + "pt; client size: " + form.ClientSize);
            Require(enable.Enabled && save.Enabled && !stop.Enabled, "Available local connection does not enable start and config export", errors);
            Require(enables == 0 && !form.EnabledConnection, "Setting context implicitly starts the listener", errors);
            Require(project.Text.Contains(projectTitle), "Active project title lost", errors);
            Require(!project.UseMnemonic, "Project ampersands are interpreted as keyboard mnemonics", errors);
            Visible(project, errors); PaintedText(project, errors);
            Require(connection.Text == connectionPath && helper.Text == helperPath, "Connection/helper path changed", errors);
            save.PerformClick(); Require(saves == 1 && enables == 0, "Config export starts the connection or misses its event", errors);
            enable.PerformClick(); Require(enables == 1 && !form.EnabledConnection, "Enable does not defer state to the controller", errors);
            form.SetState(true, "Connected locally. Claude can request read-only data from the active project."); Pump(form);
            Require(form.EnabledConnection && state.Text == "Enabled" && !enable.Enabled && stop.Enabled, "Enabled state does not gate actions", errors);
            enable.PerformClick(); Require(enables == 1, "Enabled connection dispatches another enable", errors);
            form.SetActivity("ka_revit_project_info", "Succeeded", 1); Pump(form);
            Require(activity.Text.Contains("project_info") && activity.Text.Contains("Succeeded") && activity.Text.Contains("Completed: 1"), "Activity omits request metadata", errors);
            Require(activity.AccessibleDescription == activity.Text, "Full activity metadata inaccessible", errors);
            Require(activity.Text.Split(':').Length >= 5, "Activity omits local request time", errors);
            Save(form, screenshots, test.Name + "_enabled");
            stop.PerformClick(); Require(stops == 1, "Stop does not dispatch to the controller", errors);
            form.SetState(false, "Connection stopped."); Pump(form);
            Require(!form.EnabledConnection && enable.Enabled && !stop.Enabled, "Stopped state does not restore explicit start", errors);
            stop.PerformClick(); Require(stops == 1, "Disabled stop dispatches another stop", errors);

            form.SetContext(projectTitle, connectionPath, helperPath, false); Pump(form);
            Require(!enable.Enabled && !save.Enabled && Find<Label>(form, "McpHelperStatus").Text.Contains("Missing"), "Missing helper permits start/export or is not explained", errors);
            form.SetContext(null, connectionPath, helperPath, true); Pump(form);
            Require(!enable.Enabled && project.Text.Contains("No active project"), "No active project can enable connection", errors);
            form.SetContext(projectTitle, connectionPath, helperPath, true);
            form.SetActivity("ka_revit_element_parameters", "{\"token\":\"DO-NOT-DISPLAY\",\"model\":\"private\"}", 2);
            Require(!activity.Text.Contains("DO-NOT-DISPLAY") && !activity.Text.Contains("private") && activity.Text.Contains("Completed"), "Activity displays arbitrary request payload", errors);
            form.SetActivity("DO-NOT-DISPLAY", "Failed", -1);
            Require(!activity.Text.Contains("DO-NOT-DISPLAY") && activity.Text.Contains("Failed") && activity.Text.Contains("Completed: 0"), "Unknown tool string leaks into activity or negative counter appears", errors);
            foreach (string result in new[] { "Succeeded", "Failed", "Cancelled", "Rejected" })
            {
                form.SetActivity("ka_revit_warnings", result, 6);
                Require(activity.Text.Contains(result), "Known request outcome lost: " + result, errors);
            }
            string longStatus = string.Join(" ", Enumerable.Repeat("A long connection status remains selectable and scrollable.", 30));
            form.SetState(false, longStatus); Pump(form);
            Require(status.Text == longStatus && status.AccessibleDescription == longStatus && status.ReadOnly && status.Multiline && status.ScrollBars == ScrollBars.Vertical,
                "Long connection status is truncated or cannot be read using scrolling/accessibility", errors);
            Require(status.Height <= form.Font.Height * 2 + 12, "Long status expands the fixed footer", errors);
            foreach (var button in new[] { enable, stop, save, close }) { Visible(button, errors); ButtonTextFits(button, errors); }
            Visible(status, errors); Visible(activity, errors);
            Require(viewport.Height >= form.Font.Height * 4, "Setup viewport cannot display four text lines", errors);
            Require(viewport.AutoScroll, "Setup instructions do not scroll", errors);
            foreach (string name in new[] { "McpConnectionFile", "McpHelperPath", "McpStepEnable", "McpStepSave", "McpStepMerge", "McpStepAsk", "McpToolProject", "McpToolSelection", "McpToolFind", "McpToolParameters", "McpToolSheets", "McpToolWarnings", "McpSessionHelp" })
            {
                var control = Descendants(form).Single(item => item.Name == name);
                Reachable(viewport, control, form); Visible(control, errors);
            }
            var merge = Find<Label>(form, "McpStepMerge");
            Require(merge.Text.Contains("mcpServers") && merge.Text.Contains("preserving other servers") && merge.Text.Contains("restart"), "Guide omits config merge/preservation/restart", errors);
            Require(Find<Label>(form, "McpStepEnable").Text.Contains("window open") && Find<Label>(form, "McpSessionHelp").Text.Contains("remain active"), "Active-model/window lifecycle guidance missing", errors);
            foreach (string tool in new[] { "ka_revit_project_info", "ka_revit_selection", "ka_revit_find_elements", "ka_revit_element_parameters", "ka_revit_sheets", "ka_revit_warnings" })
                Require(Descendants(viewport).OfType<Label>().Any(label => label.Text.StartsWith(tool + " — ", StringComparison.Ordinal)), "Read-only tool missing: " + tool, errors);
            Save(form, screenshots, test.Name + "_guide");
            viewport.AutoScrollPosition = Point.Empty;
            form.SetState(true, "Connected locally. Close this window to stop the connection."); Pump(form);
            close.PerformClick();
            Require(stops == 2 && !form.EnabledConnection, "Closing enabled connection does not stop it exactly once", errors);
        }
        using (var form = new McpConnectionForm())
        {
            int stops = 0; form.StopRequested += () => stops++;
            bool cancel = true;
            form.FormClosing += (sender, e) => e.Cancel = cancel;
            form.Show(); Pump(form); form.Close();
            Require(stops == 0 && !form.IsDisposed, "Cancelled close stops or disposes the connection", errors);
            cancel = false; form.Close();
            Require(stops == 1, "Closing disabled/pending connection does not notify lifecycle owner", errors);
        }
    }

    private static void ShowScaled(Form form, Case test)
    {
        form.StartPosition = FormStartPosition.Manual; form.Location = new Point(10,10); form.Show(); Pump(form); form.AutoScaleMode = AutoScaleMode.None;
        var fonts = Descendants(form).Select(control => new FontInfo(control)).ToArray(); form.Scale(new SizeF(test.Scale,test.Scale));
        foreach (var item in fonts) item.Control.Font = new Font(item.Name,item.Size*test.Scale,item.Style,item.Unit);
        form.MinimumSize = Size.Empty; form.ClientSize = new Size(test.Width,test.Height); form.Location = new Point(10,10); Pump(form);
    }
    private static void Visible(Control control, List<string> errors)
    {
        var bounds = control.RectangleToScreen(control.ClientRectangle);
        Require(control.Visible && bounds.Width > 0 && bounds.Height > 0, control.Name + " hidden or empty", errors);
        for (Control ancestor = control.Parent; ancestor != null; ancestor = ancestor.Parent)
            Require(ancestor.RectangleToScreen(ancestor.ClientRectangle).Contains(bounds), control.Name + " clipped by " + ancestor.GetType().Name + " at " + bounds, errors);
    }
    private static void Reachable(Panel panel, Control input, Form form)
    {
        panel.ScrollControlIntoView(input); Pump(form);
        // Mono may overshoot successive nested scroll targets; verify the corrected actual viewport bounds.
        for (int i = 0; i < 3; i++)
        {
            Rectangle bounds = panel.RectangleToClient(input.RectangleToScreen(input.ClientRectangle));
            int dx = bounds.Left < 0 ? bounds.Left : Math.Max(0, bounds.Right - panel.ClientSize.Width);
            int dy = bounds.Top < 0 ? bounds.Top : Math.Max(0, bounds.Bottom - panel.ClientSize.Height);
            if (dx == 0 && dy == 0) return;
            panel.AutoScrollPosition = new Point(Math.Max(0, -panel.AutoScrollPosition.X + dx), Math.Max(0, -panel.AutoScrollPosition.Y + dy)); Pump(form);
        }
    }
    private static void ButtonTextFits(Button button, List<string> errors)
    {
        Size preferred = button.GetPreferredSize(Size.Empty);
        Require(button.Height >= preferred.Height && button.Width >= preferred.Width, button.Name + " cannot fit native button text: " + button.Size + " / preferred " + preferred, errors);
    }
    private static void PaintedText(Label label, List<string> errors)
    {
        label.Refresh(); Application.DoEvents();
        using (var image = new Bitmap(label.Width, label.Height))
        {
            using (var graphics = Graphics.FromImage(image)) graphics.CopyFromScreen(label.PointToScreen(Point.Empty), Point.Empty, label.Size);
            int background = label.BackColor.ToArgb(), ink = 0;
            for (int y = 0; y < image.Height; y++)
                for (int x = 0; x < image.Width; x++)
                    if (image.GetPixel(x, y).ToArgb() != background) ink++;
            Require(ink > 20, label.Name + " contains text but paints no visible glyphs", errors);
        }
    }
    private static void Save(Form form, string folder, string name)
    {
        if (folder == null) return;
        form.Refresh(); Application.DoEvents();
        using (var image = new Bitmap(form.Width,form.Height))
        { using (var graphics = Graphics.FromImage(image)) graphics.CopyFromScreen(form.Location,Point.Empty,form.Size); image.Save(Path.Combine(folder,name + ".png")); }
    }
    private static void Pump(Control control) { for (int i = 0; i < 2; i++) { foreach (var child in Descendants(control).Reverse()) child.PerformLayout(); Application.DoEvents(); } }
    private static IEnumerable<Control> Descendants(Control root) { yield return root; foreach (Control child in root.Controls) foreach (Control nested in Descendants(child)) yield return nested; }
    private static T Find<T>(Control root, string name) where T : Control { return Descendants(root).OfType<T>().Single(control => control.Name == name); }
    private static string Arg(string[] args, string prefix) { var found = args.FirstOrDefault(value => value.StartsWith(prefix,StringComparison.Ordinal)); return found == null ? null : found.Substring(prefix.Length); }
    private static void Require(bool condition, string reason, List<string> errors) { if (!condition) errors.Add(reason); }
    private sealed class Case { public int Width, Height; public float Scale; public Case(int width,int height,float scale) { Width=width;Height=height;Scale=scale; } public string Name { get { return Width+"x"+Height+"_"+(int)(Scale*100); } } }
    private sealed class FontInfo { public Control Control; public string Name; public float Size; public FontStyle Style; public GraphicsUnit Unit; public FontInfo(Control control) { Control=control;Name=control.Font.FontFamily.Name;Size=control.Font.Size;Style=control.Font.Style;Unit=control.Font.Unit; } }
}
