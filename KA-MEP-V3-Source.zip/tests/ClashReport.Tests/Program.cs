using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Xml.Linq;
using PipeTakeoff.Core;

internal static class Program
{
    private static readonly XNamespace S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static readonly XNamespace R = "http://schemas.openxmlformats.org/package/2006/relationships";
    private static readonly XNamespace D = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
    private static readonly XNamespace C = "http://schemas.openxmlformats.org/package/2006/content-types";
    private static int checks;

    private static int Main(string[] args)
    {
        string folder = Path.Combine(Path.GetTempPath(), "KAMEP-Clash-Report-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(folder);
        try
        {
            string path = Path.Combine(folder, "clashes.xlsx");
            VerifyWorkbook(path);
            VerifyFilteredAndEmpty(path);
            VerifyValidationAndAtomicity(path, folder);
            foreach (string arg in args.Where(value => value.StartsWith("--example=", StringComparison.Ordinal)))
            {
                string examplePath = Path.GetFullPath(arg.Substring("--example=".Length));
                Directory.CreateDirectory(Path.GetDirectoryName(examplePath));
                ClashXlsxExporter.Export(examplePath, Example(), Options());
                Console.WriteLine("SIMULATED illustrative clash workbook: " + examplePath);
            }
            Console.WriteLine("PASS " + checks.ToString(CultureInfo.InvariantCulture) + " clash report checks.");
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine(ex);
            return 1;
        }
        finally { Directory.Delete(folder, true); }
    }

    private static void VerifyWorkbook(string path)
    {
        var report = Example();
        var options = Options();
        ClashXlsxExporter.Export(path, report, options);
        using (var zip = ZipFile.OpenRead(path))
        {
            var workbook = Load(zip, "xl/workbook.xml");
            var relations = Load(zip, "xl/_rels/workbook.xml.rels");
            var content = Load(zip, "[Content_Types].xml");
            var rootRelations = Load(zip, "_rels/.rels");
            var styles = Load(zip, "xl/styles.xml");
            var summary = Load(zip, "xl/worksheets/sheet1.xml");
            var detail = Load(zip, "xl/worksheets/sheet2.xml");
            var info = Load(zip, "xl/worksheets/sheet3.xml");
            Check(string.Join(",", workbook.Descendants(S + "sheet").Select(sheet => (string)sheet.Attribute("name"))) == "Summary,Clashes,Info", "Workbook contains the three named report sheets in reading order");
            Check((string)workbook.Descendants(S + "workbookView").Single().Attribute("activeTab") == "0", "Summary is the initially selected worksheet");
            Check(content.Descendants(C + "Override").Any(item => (string)item.Attribute("PartName") == "/xl/workbook.xml" && ((string)item.Attribute("ContentType")).EndsWith("sheet.main+xml", StringComparison.Ordinal)), "Package declares an ordinary XLSX workbook");
            Check(rootRelations.Descendants(R + "Relationship").Any(item => (string)item.Attribute("Target") == "xl/workbook.xml"), "Package root points to the workbook");
            foreach (var sheet in workbook.Descendants(S + "sheet"))
            {
                string id = (string)sheet.Attribute(D + "id");
                var relationship = relations.Descendants(R + "Relationship").Single(item => (string)item.Attribute("Id") == id);
                Check(zip.GetEntry("xl/" + (string)relationship.Attribute("Target")) != null, "Each worksheet relationship resolves to an existing ZIP part");
            }
            Check(zip.Entries.All(entry => !entry.FullName.Contains("vbaProject") && !entry.FullName.Contains("externalLink")), "Workbook has no macros or external workbook links");
            Check(workbook.Descendants(S + "definedName").Count(item => (string)item.Attribute("name") == "_xlnm.Print_Titles" && item.Value.EndsWith("!$1:$5", StringComparison.Ordinal)) == 3, "All worksheets repeat their report title and table header rows when printed");
            Check(workbook.Descendants(S + "definedName").Count(item => (string)item.Attribute("name") == "_xlnm.Print_Area") == 3, "All worksheets have print areas");
            Check(BodyRows(detail).Count() == 4, "Every supplied clash is exported exactly once");
            Check(Header(detail).Count() == 30, "Clash detail has the complete 30-column report contract");
            Check(SummaryCount(summary, "Total exported") == 4, "Summary total matches the exported rows");

            var fills = new Dictionary<ClashState, string>
            {
                { ClashState.Unchecked, "FFE8EDF1" }, { ClashState.Unsolved, "FFFDE5E5" },
                { ClashState.Solved, "FFDFF1E4" }, { ClashState.NeedsReview, "FFFFF0CC" }
            };
            foreach (ClashState state in Enum.GetValues(typeof(ClashState)))
            {
                Check(SummaryCount(summary, state.ToString()) == 1, state + " summary count is numeric and exact");
                int row = 6 + report.Rows.FindIndex(clash => clash.State == state);
                var cell = ByHeader(detail, "Current status", row);
                Check(IsText(cell) && cell.Value == state.ToString(), state + " remains a readable status label");
                Check(FillColor(styles, cell) == fills[state], state + " has its semantic status fill");
                var summaryRow = BodyRows(summary).Single(item => item.Elements(S + "c").First().Value == state.ToString());
                Check(FillColor(styles, summaryRow.Elements(S + "c").First()) == fills[state], state + " summary uses the same status fill");
            }
            Check(ByHeader(detail, "Element 1 ID", 6).Value == "9223372036854775806" && IsText(ByHeader(detail, "Element 1 ID", 6)), "64-bit Element 1 ID is preserved exactly as text");
            Check(ByHeader(detail, "Element 2 ID", 6).Value == "9000000001" && IsText(ByHeader(detail, "Element 2 ID", 6)), "Element 2 ID is also text beyond the 32-bit range");
            Check(ByHeader(detail, "Name", 6).Value == report.Rows[0].Name && IsText(ByHeader(detail, "Name", 6)), "Formula-like clash name remains inert text");
            Check(ByHeader(detail, "Element 1 name", 6).Value == "0007" && IsText(ByHeader(detail, "Element 1 name", 6)), "Leading-zero element name is retained as text");
            Check(ByHeader(detail, "Name", 7).Value == "تعارض مجرى الهواء" && ByHeader(detail, "Comments", 6).Value.Contains("مراجعة تنسيق"), "Arabic clash text and comments are retained");
            Check(ByHeader(detail, "Imported status", 9).Value == "Resolved" && ByHeader(detail, "Current status", 9).Value == "Unchecked", "Imported resolution never changes the current model status");
            Check(ByHeader(detail, "Element 1 category", 6).Value == "Ducts" && ByHeader(detail, "Element 1 reported category", 6).Value == "Reported duct category", "Resolved and reported categories remain distinguishable");
            Check(ByHeader(detail, "Element 1 model", 6).Value == "Current MEP model" && ByHeader(detail, "Element 1 reported model", 6).Value == "original-mep.nwc", "Resolved and imported model provenance remain distinguishable");
            Check(ByHeader(detail, "Element 1 reported name", 6).Value == "Reported duct name", "Original name remains available beside resolved name");
            Check(ByHeader(detail, "Check note", 6).Value == report.Rows[0].CheckNote && ByHeader(detail, "Check basis", 6).Value == report.Rows[0].CheckBasis, "Current status carries its explanation and checking basis");
            Check(ByHeader(detail, "Checked at", 6).Value.Contains("2026-10-28") && ByHeader(detail, "Checked at", 9).Value.Length == 0, "Checked time is explicit while unchecked rows stay blank");
            Check(ByHeader(detail, "Test kind", 8).Value == "Clearance" && ByHeader(detail, "Current status", 8).Value == "NeedsReview", "Clearance review remains distinct from verified hard-clash results");
            Check(ByHeader(detail, "Distance (reported)", 6).Value == "-12.50 mm" && ByHeader(detail, "Clash point (reported)", 6).Value == "(1.25, 2.50, 3.75) m", "Imported distance and point retain their supplied units and text");
            Check(ByHeader(detail, "Assigned to", 6).Value == "=SUM(1,1)" && IsText(ByHeader(detail, "Assigned to", 6)), "Formula-like assignment is inert text");
            Check(ByHeader(detail, "Clash key", 6).Value == report.Rows[0].Key, "Stable clash key is available for audit");
            using (var extra = JsonDocument.Parse(ByHeader(detail, "Source extra fields", 6).Value))
            {
                Check(extra.RootElement.GetProperty("Leading zero reference").GetString() == "000042", "Source extra fields retain leading-zero text in valid JSON");
                Check(extra.RootElement.GetProperty("Quoted \"field\"").GetString() == "first line\nsecond line\\audit", "Source extra fields escape quotes, newlines and slashes without losing values");
                Check(extra.RootElement.GetProperty("Formula note").GetString() == "+SUM(1,1)", "Formula-like source extra field is preserved as inert data");
            }
            using (var audit = JsonDocument.Parse(ByHeader(detail, "Element 1 reference audit", 6).Value))
            {
                Check(audit.RootElement.ValueKind == JsonValueKind.Object && audit.RootElement.ToString().Contains("9223372036854775806") && audit.RootElement.ToString().Contains("unique-0007"), "Element reference audit is valid JSON preserving exact IDs and unique identity");
            }
            Check(info.Root.Value.Contains(report.SourcePath) && info.Root.Value.Contains(report.SourceSha256) && info.Root.Value.Contains(report.Producer), "Info preserves the original HTML path, hash and producer");
            Check(info.Root.Value.Contains("2026-10-27") && info.Root.Value.Contains("2026-10-28"), "Info preserves import and export dates");
            Check(info.Root.Value.Contains(options.ProjectTitle) && info.Root.Value.Contains(options.Release) && info.Root.Value.Contains(options.RevitVersion), "Info preserves project, release and Revit version");
            Check(info.Root.Value.Contains(options.FilterDescription), "Info discloses the active filter");
            Check(info.Root.Value.Contains("SIMULATED") && info.Root.Value.Contains(report.Notes[0]), "Simulated source coverage is clearly disclosed");
            Check(info.Root.Value.IndexOf("clearance", StringComparison.OrdinalIgnoreCase) >= 0 && info.Root.Value.IndexOf("hard", StringComparison.OrdinalIgnoreCase) >= 0, "Report explains the hard-clash and clearance status limitations");
            Check(ByHeader(detail, "Check note", 8).Value.Contains("unloaded") && FillColor(styles, ByHeader(detail, "Current status", 8)) != fills[ClashState.Solved], "A missing model remains NeedsReview and never receives a solved fill");
            foreach (var sheet in new[] { summary, detail, info })
            {
                Check((string)sheet.Descendants(S + "pane").Single().Attribute("ySplit") == "5", "Report and column headers are frozen");
                Check(sheet.Descendants(S + "autoFilter").Count() == 1, "Worksheet data has an auto filter");
                Check(sheet.Descendants(S + "mergeCell").Count() == 3, "Worksheet uses the consistent three-row report banner");
                Check((string)sheet.Descendants(S + "pageSetup").Single().Attribute("orientation") == "landscape", "Worksheet uses landscape printing");
                Check(sheet.Descendants(S + "oddHeader").Single().Value.Contains("KA MEP"), "Print header retains the product identity");
                Check(sheet.Descendants(S + "f").Count() == 0, "Worksheet contains no executable formulas");
                Check(sheet.Descendants(S + "col").All(col => (double)col.Attribute("width") >= 10), "Every report column has a deliberate readable width");
            }
            Check((string)detail.Descendants(S + "autoFilter").Single().Attribute("ref") == "A5:AD9", "Detail filter covers exactly the 30 columns and four supplied rows");
            Check((string)detail.Descendants(S + "dimension").Single().Attribute("ref") == "A1:AD9", "Detail used range matches its final row and column");
        }
        Check(report.Rows[0].State == ClashState.Solved && report.Rows[2].State == ClashState.NeedsReview, "Export does not mutate the caller's current statuses");
    }

    private static void VerifyFilteredAndEmpty(string path)
    {
        var report = Example();
        var selected = report.Rows[2];
        report.Rows = new List<ClashRecord> { selected };
        var options = Options();
        options.FilterDescription = "Current status = NeedsReview / user-visible rows only";
        ClashXlsxExporter.Export(path, report, options);
        using (var zip = ZipFile.OpenRead(path))
        {
            var summary = Load(zip, "xl/worksheets/sheet1.xml");
            var detail = Load(zip, "xl/worksheets/sheet2.xml");
            var info = Load(zip, "xl/worksheets/sheet3.xml");
            Check(BodyRows(detail).Count() == 1 && ByHeader(detail, "Clash key", 6).Value == selected.Key, "Filtered export includes only the supplied visible row");
            Check(!detail.Root.Value.Contains("unique-0007") && !detail.Root.Value.Contains("تعارض مجرى الهواء"), "Hidden rows and their reference audits do not enter the filtered workbook");
            Check(SummaryCount(summary, "Total exported") == 1 && SummaryCount(summary, "NeedsReview") == 1, "Filtered totals are recalculated from the supplied row only");
            Check(SummaryCount(summary, "Solved") == 0 && SummaryCount(summary, "Unsolved") == 0 && SummaryCount(summary, "Unchecked") == 0, "Filtered summary retains explicit numeric zero for absent statuses");
            Check(info.Root.Value.Contains(options.FilterDescription), "Filtered workbook discloses its exact filter description");
        }
        report.Rows.Clear();
        ClashXlsxExporter.Export(path, report);
        using (var zip = ZipFile.OpenRead(path))
        {
            var summary = Load(zip, "xl/worksheets/sheet1.xml");
            var detail = Load(zip, "xl/worksheets/sheet2.xml");
            Check(!BodyRows(detail).Any(), "Empty report contains no synthetic clash rows");
            Check((string)detail.Descendants(S + "autoFilter").Single().Attribute("ref") == "A5:AD5", "Empty report has a valid header-only filter");
            Check((string)detail.Descendants(S + "dimension").Single().Attribute("ref") == "A1:AD5", "Empty report has a valid used range");
            Check(SummaryCount(summary, "Total exported") == 0 && Enum.GetValues(typeof(ClashState)).Cast<ClashState>().All(state => SummaryCount(summary, state.ToString()) == 0), "Empty summary explicitly reports numeric zero for every status");
        }
    }

    private static void VerifyValidationAndAtomicity(string path, string folder)
    {
        ClashXlsxExporter.Export(path, Example(), Options());
        byte[] before = File.ReadAllBytes(path);
        Action<Action<ClashReport>, string> invalid = (change, label) =>
        {
            var report = Example(); change(report);
            ExpectFailure(() => ClashXlsxExporter.Export(path, report), label);
            Check(before.SequenceEqual(File.ReadAllBytes(path)), label + " preserves the existing workbook bytes");
        };
        ExpectFailure(() => ClashXlsxExporter.Export(path, null), "Missing report is rejected");
        invalid(report => report.Rows = null, "Missing row collection is rejected");
        invalid(report => report.Notes = null, "Missing source notes collection is rejected");
        invalid(report => report.Rows[0] = null, "Missing clash row is rejected");
        invalid(report => report.Rows[0].Element1 = null, "Missing Element 1 reference is rejected");
        invalid(report => report.Rows[0].Element2 = null, "Missing Element 2 reference is rejected");
        invalid(report => report.Rows[0].ExtraFields = null, "Missing extra-field collection is rejected");
        invalid(report => report.Rows[0].State = (ClashState)999, "Unknown status is rejected");
        invalid(report => report.Rows[0].TestKind = (ClashTestKind)999, "Unknown test kind is rejected");
        invalid(report => report.Rows[1].Key = report.Rows[0].Key, "Duplicate clash keys cannot inflate the summary");
        invalid(report => report.Rows[0].Element1.ElementId = 0, "Zero imported element ID is rejected");
        invalid(report => report.Rows[0].Element2.ElementId = -1, "Negative imported element ID is rejected");
        invalid(report => report.Rows[0].Element1.ResolvedElementId = 0, "Zero resolved element ID is rejected");
        invalid(report => report.Rows[0].Element2.ResolvedElementId = -1, "Negative resolved element ID is rejected");
        invalid(report => report.Rows[0].Element1.ResolvedSourceKey = "", "Solved clash without a resolved source is rejected");
        invalid(report => report.Rows[0].Element2.ResolvedElementId = null, "Solved clash without a resolved element is rejected");
        invalid(report => report.Rows[0].CheckedAt = null, "Solved clash without a check time is rejected");
        invalid(report => report.Rows[0].CheckBasis = "", "Solved clash without a check basis is rejected");
        ExpectFailure(() => ClashXlsxExporter.Export(Path.Combine(folder, "wrong.csv"), Example()), "Non-XLSX extension is rejected");
        ExpectFailure(() => ClashXlsxExporter.Export(Path.Combine(folder, "missing", "report.xlsx"), Example()), "Missing destination directory is rejected");
        string directory = Path.Combine(folder, "cannot-replace.xlsx");
        Directory.CreateDirectory(directory);
        ExpectFailure(() => ClashXlsxExporter.Export(directory, Example()), "A final replacement failure is surfaced");
        Check(Directory.Exists(directory), "Failed final replacement preserves the destination directory");
        Check(Directory.GetFiles(folder, "*.tmp").Length == 0, "Validation and final replacement failures leave no temporary workbook");
        Check(before.SequenceEqual(File.ReadAllBytes(path)), "All rejected exports preserve the prior valid workbook");
    }

    private static ClashReport Example()
    {
        var report = new ClashReport
        {
            Title = "SIMULATED CLASH REPORT — illustrative training fixture",
            SourcePath = @"C:\Reports\simulated-clashes.html",
            SourceSha256 = new string('a', 64),
            Producer = "Navisworks HTML — SIMULATED fixture",
            ImportedAt = new DateTime(2026, 10, 27, 14, 5, 6, DateTimeKind.Utc),
            Notes = { "SIMULATED data only. These records do not describe a verified project or real Revit model." }
        };
        report.Rows.Add(Row("simulated-solved", "=HYPERLINK(\"https://example.invalid\",\"Clash\")", ClashState.Solved));
        report.Rows.Add(Row("simulated-unsolved", "تعارض مجرى الهواء", ClashState.Unsolved));
        report.Rows.Add(Row("simulated-review", "Clearance check / missing linked model", ClashState.NeedsReview));
        report.Rows.Add(Row("simulated-unchecked", "0004", ClashState.Unchecked));
        var solved = report.Rows[0];
        solved.Element1.ElementId = long.MaxValue - 1;
        solved.Element1.ResolvedElementId = long.MaxValue - 1;
        solved.Element1.UniqueId = "unique-0007";
        solved.Element1.ResolvedUniqueId = "unique-0007";
        solved.Element1.ReportedCategory = "Reported duct category";
        solved.Element1.ReportedName = "Reported duct name";
        solved.Element1.ResolvedName = "0007";
        solved.DistanceText = "-12.50 mm";
        solved.ClashPointText = "(1.25, 2.50, 3.75) m";
        solved.AssignedTo = "=SUM(1,1)";
        solved.Description = "مراجعة تنسيق — simulated comment";
        solved.ExtraFields.Add("Leading zero reference", "000042");
        solved.ExtraFields.Add("Quoted \"field\"", "first line\nsecond line\\audit");
        solved.ExtraFields.Add("Formula note", "+SUM(1,1)");
        report.Rows[2].TestKind = ClashTestKind.Clearance;
        report.Rows[2].CheckNote = "Needs review: linked model is unloaded; clearance semantics have not been verified.";
        report.Rows[2].CheckBasis = "SIMULATED unresolved linked source; no conclusive geometry result.";
        report.Rows[2].Element2.ResolvedSourceKey = "";
        report.Rows[2].Element2.ResolvedSourceName = "";
        report.Rows[2].Element2.ResolvedElementId = null;
        report.Rows[2].Element2.SourceHint = "unloaded-architecture.rvt";
        report.Rows[3].TestKind = ClashTestKind.Unknown;
        report.Rows[3].ImportedStatus = "Resolved";
        report.Rows[3].CheckBasis = "";
        report.Rows[3].CheckedAt = null;
        report.Rows[3].CheckNote = "Not checked against the current Revit model.";
        return report;
    }

    private static ClashRecord Row(string key, string name, ClashState state)
    {
        return new ClashRecord
        {
            Key = key, Name = name, TestName = "SIMULATED duct / structure test", TestKind = ClashTestKind.Hard,
            ImportedStatus = "Active", State = state,
            CheckNote = state == ClashState.Solved ? "SIMULATED: both elements resolved; no hard-solid overlap remains." : "SIMULATED geometric check record.",
            CheckBasis = "SIMULATED hard-clash solid intersection; 1 mm³ tolerance. No live model was checked.",
            CheckedAt = new DateTime(2026, 10, 28, 10, 11, 12, DateTimeKind.Utc),
            Element1 = new ClashElementReference
            {
                ElementId = 9000000000, UniqueId = "duct-unique", SourceHint = "original-mep.nwc", ReportedCategory = "Ducts", ReportedName = "Supply duct",
                ResolvedSourceKey = "host:simulated-mep", ResolvedSourceName = "Current MEP model", ResolvedElementId = 9000000000,
                ResolvedUniqueId = "duct-unique", ResolvedCategory = "Ducts", ResolvedName = "Supply duct", ResolutionNote = "SIMULATED unique source match"
            },
            Element2 = new ClashElementReference
            {
                ElementId = 9000000001, UniqueId = "beam-unique", SourceHint = "original-structure.nwc", ReportedCategory = "Structural Framing", ReportedName = "Beam",
                ResolvedSourceKey = "link:simulated-structure:9000000200", ResolvedSourceName = "Current Structure link", ResolvedElementId = 9000000001,
                ResolvedUniqueId = "beam-unique", ResolvedCategory = "Structural Framing", ResolvedName = "Beam", ResolutionNote = "SIMULATED loaded-link unique match"
            }
        };
    }

    private static ClashExportOptions Options()
    {
        return new ClashExportOptions
        {
            ProjectTitle = "SIMULATED coordination example", RevitVersion = "2025", Release = "KA MEP V3.0 — SIMULATED example",
            FilterDescription = "All four current statuses / visible illustrative rows",
            ExportedAt = new DateTime(2026, 10, 28, 12, 13, 14, DateTimeKind.Utc)
        };
    }

    private static XDocument Load(ZipArchive zip, string path)
    {
        var entry = zip.GetEntry(path);
        if (entry == null) throw new Exception("Missing OpenXML part: " + path);
        using (var stream = entry.Open()) return XDocument.Load(stream);
    }
    private static IEnumerable<XElement> BodyRows(XDocument doc) { return doc.Descendants(S + "row").Where(row => (int)row.Attribute("r") >= 6); }
    private static IEnumerable<XElement> Header(XDocument doc) { return doc.Descendants(S + "row").Single(row => (string)row.Attribute("r") == "5").Elements(S + "c"); }
    private static XElement ByHeader(XDocument doc, string header, int row)
    {
        string address = (string)Header(doc).Single(cell => cell.Value == header).Attribute("r");
        string column = new string(address.TakeWhile(char.IsLetter).ToArray());
        return doc.Descendants(S + "c").Single(cell => (string)cell.Attribute("r") == column + row.ToString(CultureInfo.InvariantCulture));
    }
    private static int SummaryCount(XDocument summary, string status)
    {
        var row = BodyRows(summary).Single(item => item.Elements(S + "c").First().Value == status);
        var cell = ByHeader(summary, "Count", (int)row.Attribute("r"));
        if (cell.Attribute("t") != null) throw new Exception("Summary count is not a numeric cell: " + status);
        return int.Parse(cell.Value, CultureInfo.InvariantCulture);
    }
    private static bool IsText(XElement cell) { return (string)cell.Attribute("t") == "inlineStr"; }
    private static string FillColor(XDocument styles, XElement cell)
    {
        int style = (int?)cell.Attribute("s") ?? 0;
        int fill = (int)styles.Root.Element(S + "cellXfs").Elements(S + "xf").ElementAt(style).Attribute("fillId");
        var color = styles.Root.Element(S + "fills").Elements(S + "fill").ElementAt(fill).Descendants(S + "fgColor").SingleOrDefault();
        return color == null ? "" : (string)color.Attribute("rgb");
    }
    private static void Check(bool condition, string label)
    {
        if (!condition) throw new Exception("FAIL: " + label);
        checks++;
        Console.WriteLine("PASS: " + label);
    }
    private static void ExpectFailure(Action action, string label)
    {
        bool failed = false;
        try { action(); } catch (Exception) { failed = true; }
        Check(failed, label);
    }
}
