# HVAC Spaces presentation checks

This harness links the production detached `SpaceTakeoffForm` and Core data models. It tests linked architectural defaults, phase/scope/link selection, visible-row export, numeric units, room identity, per-point sources, stale settings, failed refresh, partial reports, Ctrl+E and fixed footer accessibility. Opening fixtures cover shared doors, unique totals, verified zero versus unknown counts, nominal width × height, missing-dimension subtotals, independent height/opening statuses, Room/source provenance and the Openings detail tab. Filtering preserves source scan context and canonical shared-opening associations. Failed association lookups override stale completeness flags; partial inventory details retain known associated counts while total quantities remain unknown.

Build serially with other Core-dependent projects. Under Windows, run the executable directly. Under Linux, use the existing Mono/Xvfb layout runtime with one process per case and explicit font/control scaling. The cases cover 1366×728 at 100%, 1280×680 at 150%/200%, and 1024×600 plus 876×571 at 100%/150%/200%.

Arguments: `--case=876x571_200 --screenshots=/absolute/output/folder`.

These checks do not execute the Revit API, inspect a real model, or reproduce native Windows DPI behavior.
