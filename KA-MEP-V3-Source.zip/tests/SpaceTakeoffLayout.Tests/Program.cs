using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using PipeTakeoff.Core;
using PipeTakeoff.Revit;

internal static class Program
{
    [STAThread]
    private static int Main(string[] args)
    {
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        string only = Arg(args, "--case="), screenshots = Arg(args, "--screenshots=");
        if (screenshots != null) Directory.CreateDirectory(screenshots);
        int passed = 0, total = 0;
        foreach (var test in new[] { new Case(1366,728,1), new Case(1280,680,1.5F), new Case(1280,680,2),
            new Case(1024,600,1), new Case(1024,600,1.5F), new Case(1024,600,2),
            new Case(876,571,1), new Case(876,571,1.5F), new Case(876,571,2) })
        {
            if (only != null && only != test.Name) continue;
            total++; var errors = new List<string>();
            try { Check(test, screenshots, errors); } catch (Exception ex) { errors.Add(ex.ToString()); }
            Console.WriteLine((errors.Count == 0 ? "PASS " : "FAIL ") + test.Name);
            foreach (string error in errors.Distinct()) Console.WriteLine("  " + error);
            if (errors.Count == 0) passed++;
        }
        Console.WriteLine("RESULT: " + passed + "/" + total + " HVAC Spaces UI cases passed; " + (total-passed) + " failed.");
        Console.WriteLine("Actual linked production form under Mono/Xvfb with simulated font/control scaling; not Windows DPI or live Revit.");
        return total > 0 && total == passed ? 0 : 1;
    }

    private static void Check(Case test, string screenshots, List<string> errors)
    {
        var defaults = new SpaceTakeoffOptions { PhaseId = 11 };
        using (var form = new SpaceTakeoffForm(new[] { new SpacePhaseOption { Id = 11, Name = "New construction" }, new SpacePhaseOption { Id = 12, Name = "Existing" } },
            defaults, new[] { new SpaceLinkOption { Id = 5000000001L, Name = "Architecture [5000000001]", IsLoaded = true },
                new SpaceLinkOption { Id = 5000000002L, Name = "Unloaded architecture", IsLoaded = false } }))
        {
            ShowScaled(form, test);
            var tabs = Find<TabControl>(form, "SpaceTakeoffTabs");
            var export = Find<Button>(form, "SpaceExportExcel"); var scan = Find<Button>(form, "SpaceScanRefresh"); var close = Find<Button>(form, "SpaceClose");
            var grid = Find<DataGridView>(form, "SpaceResultsGrid");
            var search = Find<TextBox>(form, "SpaceSearch"); var level = Find<ComboBox>(form, "SpaceLevelFilter");
            var status = Find<ComboBox>(form, "SpaceResultFilter"); var units = Find<ComboBox>(form, "SpaceHeightUnits");
            var links = Find<ComboBox>(form, "SpaceLinkChoice"); var host = Find<CheckBox>(form, "SpaceIncludeHost");
            var includedLinks = Find<CheckBox>(form, "SpaceIncludeLinks");
            grid.DataError += (sender,e) => errors.Add("Grid data error: " + e.Exception.Message);
            Require(form.Icon != null, "Branded window icon missing", errors);
            Require(!host.Checked && includedLinks.Checked, "Architectural link-only defaults lost", errors);
            Require(links.Items.Count == 2, "Unloaded link is offered as a usable selection", errors);
            Require(!export.Enabled && scan.Enabled, "Initial state allows empty export or blocks scan", errors);
            Require(tabs.TabCount == 3, "Scan / Spaces / Measurements tabs missing", errors);
            Visible(export, errors); Visible(scan, errors); Visible(close, errors);
            foreach (var button in new[] { export, scan, close }) ButtonTextFits(button, errors);
            Save(form, screenshots, test.Name + "_options");
            var viewport = Find<Panel>(form, "SpaceOptionsViewport");
            foreach (var combo in Descendants(viewport).OfType<ComboBox>())
            {
                Require(combo.Height >= combo.PreferredHeight, combo.Name + " initially shorter than native preferred height", errors);
                Require(combo.Parent.ClientRectangle.Contains(combo.Bounds), combo.Name + " initially clipped by option row", errors);
            }
            foreach (var control in Descendants(viewport).Where(c => c is ComboBox || c is NumericUpDown || c is CheckBox))
            { Reachable(viewport, control, form); Visible(control, errors); }
            viewport.AutoScrollPosition = Point.Empty; Pump(form);
            links.SelectedIndex = 1;
            Require(form.ReadOptions().SelectedLinkInstanceId == 5000000001L, "Specific link ID lost or narrowed to 32 bits", errors);
            int scans = 0, exports = 0; SpaceTakeoffOptions scannedOptions = null; SpaceTakeoffSnapshot exported = null; bool exportedMm = false;
            bool fail = false;
            form.ScanRequested += options =>
            {
                scans++; scannedOptions = options;
                Require(!export.Enabled && !scan.Enabled && !tabs.Enabled, "Competing action enabled during scan", errors);
                if (fail) throw new InvalidOperationException("Simulated source link became unavailable.");
                form.SetSnapshot(Fixture(options));
            };
            form.ExportRequested += (snapshot,mm,filter) =>
            {
                exports++; exported = snapshot; exportedMm = mm;
                Require(!scan.Enabled && !export.Enabled, "Competing action enabled while export is pending", errors);
                Require(filter.Contains("Visible result subset"), "Export filter scope not disclosed", errors);
                form.ShowStatus("Test export completed.");
            };
            scan.PerformClick(); Pump(form);
            Require(scans == 1 && scannedOptions.SelectedLinkInstanceId == 5000000001L, "Scan callback/options incorrect", errors);
            Require(grid.Rows.Count == 4 && export.Enabled, "Snapshot not displayed/exportable", errors);
            GridTextFits(grid, errors);
            Require(tabs.SelectedIndex == 1, "Scan does not reveal results", errors);
            Require(Convert.ToString(Row(grid, 9000000001L).Cells["RoomNumber"].Value) == "001", "Room leading-zero identity lost", errors);
            Require(Row(grid, 9000000003L).Cells["Height"].Value == null, "Variable height became a fabricated single number", errors);
            Require(Row(grid, 9000000004L).Cells["Height"].Value == null, "Missing height displayed as zero", errors);
            Require(Row(grid, 9000000004L).Cells["RoomName"].Value as string == "", "Unmatched room silently replaced by Space name", errors);
            Require(Convert.ToInt32(Row(grid, 9000000001L).Cells["DoorCount"].Value) == 1 && Convert.ToInt32(Row(grid, 9000000002L).Cells["DoorCount"].Value) == 1, "Shared door not counted once for each associated Room", errors);
            Require(Convert.ToDouble(Row(grid, 9000000001L).Cells["DoorArea"].Value) == 1.8, "Nominal door width × height area incorrect", errors);
            Require(Convert.ToInt32(Row(grid, 9000000002L).Cells["WindowCount"].Value) == 0, "Verified zero openings not shown as zero", errors);
            Require(Row(grid, 9000000004L).Cells["DoorCount"].Value == null && Row(grid, 9000000004L).Cells["WindowCount"].Value == null, "Unknown opening counts shown as zero", errors);
            Require(Row(grid, 9000000004L).Cells["DoorArea"].Value == null && Row(grid, 9000000004L).Cells["DoorKnownArea"].Value == null, "Unverified empty inventory manufactured an opening area", errors);
            Require(Convert.ToInt32(Row(grid, 9000000003L).Cells["DoorCount"].Value) == 2 && Row(grid, 9000000003L).Cells["DoorArea"].Value == null, "Missing dimensions incorrectly suppress count or manufacture total area", errors);
            Require(Convert.ToDouble(Row(grid, 9000000003L).Cells["DoorKnownArea"].Value) == 1.6, "Known opening subtotal lost with missing dimensions", errors);
            Require(Convert.ToString(Row(grid, 9000000003L).Cells["OpeningStatus"].Value).Contains("Missing dimensions"), "Missing-dimension review flag absent", errors);
            Require(grid.Columns["Status"].HeaderText == "Height status" && grid.Columns["OpeningStatus"].HeaderText == "Opening status", "Height and opening statuses conflated", errors);
            Save(form, screenshots, test.Name + "_spaces");
            export.PerformClick(); Require(exports == 1 && exported.Rows.Count == 4, "Default export omits review rows", errors);
            Require(ReferenceEquals(exported.OpeningScan, form.Snapshot.OpeningScan), "Filtered export lost source-scan provenance", errors);
            status.SelectedIndex = 1; Pump(form);
            Require(grid.Rows.Count == 2, "Needs-review filter incorrect", errors);
            units.SelectedIndex = 1; Pump(form); export.PerformClick();
            Require(exportedMm && exported.Rows.Count == 2, "Filtered export or unit option incorrect", errors);
            Require(exported.Rows.Any(r => r.Status == SpaceMeasurementStatus.VariableHeight) && exported.Rows.Any(r => r.Status == SpaceMeasurementStatus.MissingOverhead), "Review rows absent from filtered export", errors);
            Require(form.Snapshot.Rows.Count == 4, "Filtering mutated canonical snapshot", errors);
            status.SelectedIndex = 6; Pump(form);
            Require(grid.Rows.Count == 2 && form.FilteredRows.Any(row => row.SpaceId == 9000000003L), "Opening-review filter incorrect", errors);
            status.SelectedIndex = 7; Pump(form); export.PerformClick();
            Require(grid.Rows.Count == 2 && exported.Rows.Count == 2, "Complete-opening filter/export incorrect", errors);
            Require(SpaceOpeningSummary.ForUniqueOpenings(exported.Rows.SelectMany(row => row.Openings), true).DoorCount == 1, "Shared door was duplicated in unique filtered opening totals", errors);
            Require(Find<Label>(form, "SpaceResultSummary").Text.Contains("doors 1 / windows 1"), "Visible unique opening summary sums shared doors", errors);
            status.SelectedIndex = 0; level.SelectedIndex = 1; Pump(form);
            Require(grid.Rows.Count == 2, "Level filter incorrect", errors);
            level.SelectedIndex = 0; search.Text = "غرفة"; Pump(form);
            Require(grid.Rows.Count == 1, "Arabic room search incorrect", errors);
            export.PerformClick(); Require(exported.Rows.Count == 1 && exported.Rows[0].SpaceId == 9000000001L, "Export includes rows hidden by search", errors);
            Require(Convert.ToDouble(grid.Rows[0].Cells["Height"].Value) == 2800, "Millimetre display incorrect", errors);
            Require(exported.Rows[0].ClearHeightMeters == 2.8, "Unit display changed stored metre geometry", errors);
            Require(exported.Rows[0].Openings.Count == 2 && form.Snapshot.OpeningScan.Openings.Count == 6, "Visible-row export lost openings or changed canonical source scan", errors);
            Require(exported.Rows[0].Openings.First(opening => opening.Kind == SpaceOpeningKind.Door).SpaceIds.Count == 2, "Filtered export mutated shared-opening association IDs", errors);
            grid.CurrentCell = grid.Rows[0].Cells[0]; tabs.SelectedIndex = 2; Pump(form);
            Require(Find<TextBox>(form, "SpaceRowDetails").Text.Contains("5000000001"), "Linked element provenance absent", errors);
            Require(Find<DataGridView>(form, "SpaceSampleGridResults").Rows.Count == 2, "Per-point measurement details missing", errors);
            GridTextFits(Find<DataGridView>(form, "SpaceSampleGridResults"), errors);
            Save(form, screenshots, test.Name + "_measurements");
            var details = Find<TabControl>(form, "SpaceDetailTabs"); details.SelectedIndex = 1; Pump(form);
            var openingsGrid = Find<DataGridView>(form, "SpaceOpeningsGrid");
            Require(openingsGrid.Rows.Count == 2, "Per-Space opening details missing", errors);
            GridTextFits(openingsGrid, errors);
            Require(openingsGrid.Columns["Size"].HeaderText == "Size (W × H)" && openingsGrid.Columns["Size"].Index + 1 == openingsGrid.Columns["Width"].Index,
                "Explicit Size column is missing beside the numeric opening dimensions", errors);
            Require(Convert.ToString(openingsGrid.Rows[0].Cells["Size"].Value) == "900 × 2000 mm" &&
                Convert.ToString(openingsGrid.Rows[1].Cells["Size"].Value) == "1200 × 1000 mm", "Door and window Size labels do not follow selected millimetres", errors);
            Require(Convert.ToDouble(openingsGrid.Rows[0].Cells["Width"].Value) == 900 && Convert.ToDouble(openingsGrid.Rows[0].Cells["Height"].Value) == 2000, "Opening dimension unit conversion incorrect", errors);
            Require(Convert.ToString(openingsGrid.Rows[0].Cells["Shared"].Value) == "Yes", "Shared opening detail flag missing", errors);
            Require(Convert.ToString(openingsGrid.Rows[0].Cells["Source"].Value).Contains("5000000001") && Convert.ToString(openingsGrid.Rows[0].Cells["Rooms"].Value).Contains("7002"), "Opening source/associated Room provenance missing", errors);
            Require(Find<TextBox>(form, "SpaceOpeningDetails").Text.Contains("width × height"), "Nominal-area basis not disclosed", errors);
            Visible(openingsGrid, errors); Visible(export, errors); Save(form, screenshots, test.Name + "_openings");
            units.SelectedIndex = 0; Pump(form);
            Require(Convert.ToString(openingsGrid.Rows[0].Cells["Size"].Value) == .9.ToString("0.###", CultureInfo.CurrentCulture) + " × 2 m" &&
                Convert.ToDouble(openingsGrid.Rows[0].Cells["Width"].Value) == .9, "Switching to metres did not refresh Size and its numeric dimensions together", errors);
            Require(form.Snapshot.Rows[0].Openings[0].WidthMeters == .9, "Size display conversion mutated stored dimensions", errors);
            units.SelectedIndex = 1; Pump(form);
            details.SelectedIndex = 2; Pump(form);
            Require(Find<TextBox>(form, "SpaceScanNotes").Text.Contains("unassociated openings in scanned sources: 1"), "Sourcewide unassociated opening coverage absent", errors);
            details.SelectedIndex = 0;
            tabs.SelectedIndex = 1; search.Text = "not-a-space"; Pump(form);
            Require(grid.Rows.Count == 0 && !export.Enabled, "Empty result filter permits export", errors);
            search.Clear(); Pump(form);
            grid.CurrentCell = Row(grid, 9000000003L).Cells[0]; tabs.SelectedIndex = 2; details.SelectedIndex = 1; Pump(form);
            Require(openingsGrid.Rows.Count == 2 && Convert.ToString(openingsGrid.Rows[0].Cells["Size"].Value) == "800 × 2000 mm" &&
                Convert.ToString(openingsGrid.Rows[1].Cells["Size"].Value) == "Unknown × 2000 mm", "One Space's different opening sizes were collapsed or missing width became zero", errors);
            Require(openingsGrid.Rows[1].Cells["Width"].Value == null && openingsGrid.Rows[1].Cells["Area"].Value == null,
                "Partial Size fabricated numeric dimensions or area", errors);
            tabs.SelectedIndex = 1; Pump(form);
            int exportsBeforeShortcut = exports;
            var method = typeof(SpaceTakeoffForm).GetMethod("ProcessCmdKey", BindingFlags.Instance | BindingFlags.NonPublic);
            object[] keyArgs = { new Message(), Keys.Control | Keys.E };
            method.Invoke(form, keyArgs);
            Require(exports == exportsBeforeShortcut + 1, "Ctrl+E does not export current filtered rows", errors);
            tabs.SelectedIndex = 0; links.SelectedIndex = 0; Pump(form);
            Require(!export.Enabled && Find<Label>(form, "SpaceStatus").Text.Contains("settings changed"), "Changing linked source permits stale export", errors);
            export.PerformClick(); Require(exports == exportsBeforeShortcut + 1, "Disabled export dispatched stale results", errors);
            scan.PerformClick(); Pump(form); Require(export.Enabled, "Successful refresh does not restore export", errors);
            host.Checked = false; includedLinks.Checked = false; Pump(form); scan.PerformClick();
            Require(scans == 2 && !export.Enabled && form.Snapshot == null && grid.Rows.Count == 0, "Invalid source options scanned or retained old results", errors);
            includedLinks.Checked = true; fail = true; scan.PerformClick(); Pump(form);
            Require(form.Snapshot == null && grid.Rows.Count == 0 && !export.Enabled, "Failed refresh leaves stale data exportable", errors);
            Require(Find<TextBox>(form, "SpaceScanNotes").Text.Contains("unavailable") || Find<TextBox>(form, "SpaceScanNotes").Text.Contains("result"), "Scan failure reason absent", errors);
            Require(openingsGrid.Rows.Count == 0 && Find<TextBox>(form, "SpaceOpeningDetails").Text.StartsWith("Select a Space", StringComparison.Ordinal), "Failed scan retained old opening details", errors);
            fail = false; scan.PerformClick(); Pump(form);
            var partial = Fixture(form.ReadOptions()); partial.IsComplete = false; partial.Notes.Add("Partial geometry coverage is explicit."); form.SetSnapshot(partial); Pump(form);
            Require(export.Enabled && Find<Label>(form, "SpaceStatus").Text.Contains("incomplete"), "Partial scan not identified or review report unavailable", errors);
            export.PerformClick(); Require(!exported.IsComplete && exported.Notes.Any(n => n.Contains("Partial geometry")), "Partial scan provenance lost from exported snapshot", errors);
            var lookupFailed = Fixture(form.ReadOptions());
            lookupFailed.Rows[0].Openings[0].AssociationStatus = SpaceOpeningAssociationStatus.LookupFailed;
            lookupFailed.Rows[0].Openings[0].AssociationNotes = "One Room association could not be read; the known Room association remains available.";
            lookupFailed.Rows[3].OpeningsComplete = true;
            form.SetSnapshot(lookupFailed); Pump(form);
            Require(Row(grid, 9000000001L).Cells["DoorCount"].Value == null && Row(grid, 9000000001L).Cells["DoorArea"].Value == null,
                "Failed association lookup displayed complete opening totals from a stale flag", errors);
            Require(Convert.ToString(Row(grid, 9000000001L).Cells["OpeningStatus"].Value).Contains("Incomplete"),
                "Failed association lookup does not flag opening coverage for review", errors);
            Require(Row(grid, 9000000004L).Cells["DoorCount"].Value == null && Row(grid, 9000000004L).Cells["DoorKnownArea"].Value == null,
                "Unverified Room with a stale completeness flag manufactured zero quantities", errors);
            grid.CurrentCell = Row(grid, 9000000001L).Cells[0]; Pump(form);
            Require(Find<TextBox>(form, "SpaceOpeningDetails").Text.Contains("Known associated openings found: doors 1 / windows 1"),
                "Incomplete source scan lost known associated opening counts", errors);
            status.SelectedIndex = 7; Pump(form);
            Require(grid.Rows.Count == 0 && !export.Enabled, "Complete-opening filter admitted an incomplete association lookup", errors);
            status.SelectedIndex = 6; Pump(form);
            Require(grid.Rows.Count == 4, "Opening-review filter omitted failed association lookup or unverified Room", errors);
            form.SetSnapshot(partial); Pump(form);
            form.ShowStatus(string.Join(" ", Enumerable.Repeat("A long export destination and review note.", 100))); Pump(form);
            Require(Find<Label>(form, "SpaceStatus").Height <= Find<Label>(form, "SpaceStatus").Font.Height*2+9, "Long status expands fixed footer", errors);
            foreach (TabPage tab in tabs.TabPages)
            {
                tabs.SelectedTab = tab; Pump(form);
                Visible(export, errors); Visible(scan, errors); Visible(close, errors);
                foreach (var button in new[] { export, scan, close }) ButtonTextFits(button, errors);
                Rectangle header = tabs.GetTabRect(tabs.TabPages.IndexOf(tab));
                Require(tabs.ClientRectangle.Contains(header), "Selected tab header inaccessible: " + tab.Text, errors);
            }
            tabs.SelectedIndex = 1; Pump(form);
            Visible(grid, errors); Visible(level, errors); Visible(status, errors); Visible(search, errors); Visible(units, errors);
            int usableGridHeight = grid.ColumnHeadersHeight + grid.Rows.Cast<DataGridViewRow>().Take(2).Sum(row => row.Height) + SystemInformation.HorizontalScrollBarHeight;
            Require(grid.Height >= usableGridHeight && grid.Width > 500,
                "Space result grid cannot show its header and two rows: " + grid.Height + "px available / " + usableGridHeight + "px needed", errors);
            Save(form, screenshots, test.Name + "_final");
        }
    }

    private static SpaceTakeoffSnapshot Fixture(SpaceTakeoffOptions options)
    {
        var source = new SpaceSurfaceSource { DocumentTitle = "Architecture", LinkInstanceId = 5000000001L, ElementId = 8000000001L, ElementName = "Floor" };
        var overhead = new SpaceSurfaceSource { DocumentTitle = "Architecture", LinkInstanceId = 5000000001L, ElementId = 8000000002L, ElementName = "Ceiling" };
        var snapshot = new SpaceTakeoffSnapshot { ProjectTitle = "ILLUSTRATIVE UI FIXTURE — مشروع اختبار", RevitVersion = "Test", Release = "V3", ScopeLabel = "Selected phase; architectural link", Options = options.Copy(), ScannedAt = new DateTime(2026,10,27,10,0,0) };
        snapshot.Rows.Add(new SpaceTakeoffRow { SpaceId = 9000000001L, SpaceNumber = "S001", SpaceName = "MEP Office", RoomNumber = "001", RoomName = "غرفة المكتب", RoomIdentitySource = "Architecture / link 5000000001 / Room [7001]", LevelName = "Level 01", PhaseName = "New construction", AreaSquareMeters = 24.5, ClearHeightMeters = 2.8, MinHeightMeters = 2.8, MaxHeightMeters = 2.8, HeightBasis = SpaceHeightBasis.Ceiling, Status = SpaceMeasurementStatus.Measured,
            Samples = new List<SpaceHeightSample> { Sample(1, 2.8, source, overhead), Sample(2, 2.8, source, overhead) } });
        snapshot.Rows.Add(new SpaceTakeoffRow { SpaceId = 9000000002L, SpaceNumber = "S002", SpaceName = "Store", RoomNumber = "002", RoomName = "Store room", RoomIdentitySource = "Architecture / Room 7002", LevelName = "Level 01", AreaSquareMeters = 12, ClearHeightMeters = 3.2, MinHeightMeters = 3.2, MaxHeightMeters = 3.2, HeightBasis = SpaceHeightBasis.Slab, Status = SpaceMeasurementStatus.Measured });
        snapshot.Rows.Add(new SpaceTakeoffRow { SpaceId = 9000000003L, SpaceNumber = "S003", SpaceName = "Sloped hall", RoomNumber = "003", RoomName = "Hall", LevelName = "Level 02", AreaSquareMeters = 20, MinHeightMeters = 2.5, MaxHeightMeters = 3.1, HeightBasis = SpaceHeightBasis.Ceiling, Status = SpaceMeasurementStatus.VariableHeight, Notes = { "A single clear height is intentionally blank." } });
        snapshot.Rows.Add(new SpaceTakeoffRow { SpaceId = 9000000004L, SpaceNumber = "S004", SpaceName = "Unmatched space", RoomIdentitySource = "No matching architectural Room", LevelName = "Level 02", AreaSquareMeters = 11.25, Status = SpaceMeasurementStatus.MissingOverhead });
        var rooms = new List<SpaceOpeningRoomIdentity>();
        for (int i = 0; i < 3; i++)
        {
            var row = snapshot.Rows[i];
            row.RoomSource = new SpaceSurfaceSource { DocumentTitle = "Architecture", LinkInstanceId = 5000000001L, ElementId = 7001 + i, ElementName = "Room" };
            row.RoomUniqueId = "room-" + (i + 1);
            rooms.Add(new SpaceOpeningRoomIdentity { Source = row.RoomSource, UniqueId = row.RoomUniqueId, Number = row.RoomNumber, Name = row.RoomName });
        }
        var shared = Opening(8100000001L, SpaceOpeningKind.Door, .9, 2, rooms[0], rooms[1]);
        var window = Opening(8100000002L, SpaceOpeningKind.Window, 1.2, 1, rooms[0]);
        var known = Opening(8100000003L, SpaceOpeningKind.Door, .8, 2, rooms[2]);
        var missing = Opening(8100000004L, SpaceOpeningKind.Door, null, 2, rooms[2]);
        missing.DimensionNotes = "Nominal width is unavailable; total area is intentionally blank.";
        snapshot.Rows[2].OpeningNotes.Add("One door is missing its nominal width. Known area is a subtotal only.");
        snapshot.Rows[3].OpeningNotes.Add("Room association is unverified; opening quantities are unknown.");
        var outside = Opening(8100000005L, SpaceOpeningKind.Window, 1, 1, new SpaceOpeningRoomIdentity {
            Source = new SpaceSurfaceSource { DocumentTitle = "Architecture", LinkInstanceId = 5000000001L, ElementId = 7099, ElementName = "Room" },
            UniqueId = "room-outside", Number = "099", Name = "Outside result scope" });
        var orphan = Opening(8100000006L, SpaceOpeningKind.Door, .7, 2);
        snapshot.OpeningScan = new SpaceOpeningScanResult { Complete = true, Openings = new List<SpaceOpeningRecord> { shared, window, known, missing, outside, orphan } };
        snapshot.OpeningScan.Notes.Add("Opening inventory is simulated; the shared door is associated with two Rooms.");
        SpaceOpeningAssociation.Assign(snapshot.Rows, snapshot.OpeningScan.Openings, true);
        snapshot.Notes.Add("This is simulated UI data. Heights are sampled; no native Revit model was scanned."); return snapshot;
    }
    private static SpaceOpeningRecord Opening(long id, SpaceOpeningKind kind, double? width, double? height, params SpaceOpeningRoomIdentity[] rooms)
    {
        return new SpaceOpeningRecord { Kind = kind, Source = new SpaceSurfaceSource { DocumentTitle = "Architecture", LinkInstanceId = 5000000001L, ElementId = id, ElementName = kind.ToString() },
            UniqueId = "opening-" + id, FamilyName = kind == SpaceOpeningKind.Door ? "Single flush door" : "Fixed window", TypeName = "Illustrative nominal type",
            WidthMeters = width, HeightMeters = height, DimensionSource = "Verified nominal type dimensions", Rooms = rooms.ToList() };
    }
    private static SpaceHeightSample Sample(int number, double height, SpaceSurfaceSource floor, SpaceSurfaceSource top) { return new SpaceHeightSample { SampleNumber = number, FloorElevationMeters = 0.1, OverheadElevationMeters = height + .1, HeightMeters = height, HeightBasis = SpaceHeightBasis.Ceiling, Status = SpaceMeasurementStatus.Measured, FloorSource = floor, OverheadSource = top }; }
    private static DataGridViewRow Row(DataGridView grid, long id) { return grid.Rows.Cast<DataGridViewRow>().Single(r => ((SpaceTakeoffRow)r.Tag).SpaceId == id); }
    private static void ShowScaled(Form form, Case test)
    {
        form.StartPosition = FormStartPosition.Manual; form.Location = new Point(10,10); form.Show(); Pump(form); form.AutoScaleMode = AutoScaleMode.None;
        var fonts = Descendants(form).Select(c => new FontInfo(c)).ToArray(); form.Scale(new SizeF(test.Scale,test.Scale));
        foreach (var item in fonts) item.Control.Font = new Font(item.Name,item.Size*test.Scale,item.Style,item.Unit);
        form.MinimumSize = Size.Empty; form.ClientSize = new Size(test.Width,test.Height); form.Location = new Point(10,10); Pump(form);
    }
    private static void Reachable(Panel panel, Control input, Form form)
    {
        panel.ScrollControlIntoView(input); Pump(form);
        for (int i=0;i<3;i++)
        {
            Rectangle bounds = panel.RectangleToClient(input.RectangleToScreen(input.ClientRectangle));
            int dx = bounds.Left < 0 ? bounds.Left : Math.Max(0,bounds.Right-panel.ClientSize.Width), dy = bounds.Top < 0 ? bounds.Top : Math.Max(0,bounds.Bottom-panel.ClientSize.Height);
            if (dx == 0 && dy == 0) return;
            panel.AutoScrollPosition = new Point(Math.Max(0,-panel.AutoScrollPosition.X+dx),Math.Max(0,-panel.AutoScrollPosition.Y+dy)); Pump(form);
        }
    }
    private static void Visible(Control control, List<string> errors)
    {
        var bounds = control.RectangleToScreen(control.ClientRectangle);
        Require(control.Visible && bounds.Width>0 && bounds.Height>0, control.Name+" hidden or empty", errors);
        for (Control ancestor=control.Parent;ancestor!=null;ancestor=ancestor.Parent)
            Require(ancestor.RectangleToScreen(ancestor.ClientRectangle).Contains(bounds),control.Name+" clipped by "+ancestor.GetType().Name+" at "+bounds,errors);
    }
    private static void ButtonTextFits(Button button, List<string> errors)
    {
        Size preferred = button.GetPreferredSize(Size.Empty);
        Require(button.Height >= preferred.Height && button.Width >= preferred.Width,
            button.Name + " cannot fit native button text: " + button.Size + " / preferred " + preferred, errors);
    }
    private static void GridTextFits(DataGridView grid, List<string> errors)
    {
        int textHeight = TextRenderer.MeasureText("Room 001", grid.Font, Size.Empty, TextFormatFlags.SingleLine).Height;
        Require(Math.Abs(grid.DefaultCellStyle.Font.SizeInPoints - grid.Font.SizeInPoints) < .1F &&
            Math.Abs(grid.ColumnHeadersDefaultCellStyle.Font.SizeInPoints - grid.Font.SizeInPoints) < .1F,
            grid.Name + " cell/header text did not follow its scaled font", errors);
        foreach (DataGridViewRow row in grid.Rows)
            Require(row.Height >= textHeight + row.Cells[0].InheritedStyle.Padding.Vertical + 6,
                grid.Name + " row text is clipped at scaled font height", errors);
        Require(grid.ColumnHeadersHeight >= textHeight + grid.ColumnHeadersDefaultCellStyle.Padding.Vertical + 6,
            grid.Name + " header text is clipped at scaled font height", errors);
    }
    private static void Save(Form form,string folder,string name) { if(folder==null)return; form.Refresh(); Application.DoEvents(); using(var image=new Bitmap(form.Width,form.Height)) { using(var graphics=Graphics.FromImage(image))graphics.CopyFromScreen(form.Location,Point.Empty,form.Size); image.Save(Path.Combine(folder,name+".png")); } }
    private static void Pump(Control control) { for(int i=0;i<2;i++) { foreach(var child in Descendants(control).Reverse())child.PerformLayout(); Application.DoEvents(); } }
    private static IEnumerable<Control> Descendants(Control root) { yield return root; foreach(Control child in root.Controls)foreach(Control nested in Descendants(child))yield return nested; }
    private static T Find<T>(Control root,string name) where T:Control { return Descendants(root).OfType<T>().Single(c=>c.Name==name); }
    private static string Arg(string[] args,string prefix) { var found=args.FirstOrDefault(s=>s.StartsWith(prefix,StringComparison.Ordinal)); return found==null?null:found.Substring(prefix.Length); }
    private static void Require(bool condition,string reason,List<string> errors) { if(!condition)errors.Add(reason); }
    private sealed class Case { public int Width,Height; public float Scale; public Case(int width,int height,float scale){Width=width;Height=height;Scale=scale;} public string Name {get{return Width+"x"+Height+"_"+(int)(Scale*100);}} }
    private sealed class FontInfo { public Control Control;public string Name;public float Size;public FontStyle Style;public GraphicsUnit Unit;public FontInfo(Control control){Control=control;Name=control.Font.FontFamily.Name;Size=control.Font.Size;Style=control.Font.Style;Unit=control.Font.Unit;} }
}
