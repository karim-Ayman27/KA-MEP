using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Xml.Linq;
using PipeTakeoff.Core;

internal static class Program
{
    private static readonly XNamespace S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static int checks;

    private static int Main(string[] args)
    {
        string folder = Path.Combine(Path.GetTempPath(), "KA-MEP-SpaceReport-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(folder);
        try
        {
            string path = Path.Combine(folder, "spaces.xlsx");
            var snapshot = Example();
            SpaceTakeoffXlsxExporter.Export(path, snapshot, new SpaceTakeoffExportOptions { FilterDescription = "Level 01 / all measurement statuses" });
            using (var zip = ZipFile.OpenRead(path))
            {
                Check(zip.Entries.Count == 10, "Exact five-sheet package without Office dependencies");
                var book = Load(zip, "xl/workbook.xml");
                Check(string.Join(",", book.Descendants(S + "sheet").Select(x => (string)x.Attribute("name"))) == "Spaces,Summary,Measurements,Openings,Info", "Report worksheets have stable descriptive names");
                Check((string)book.Descendants(S + "workbookView").Single().Attribute("activeTab") == "1", "Summary opens first");
                Check(book.Descendants(S + "definedName").Count() == 10, "Print areas and repeated titles for all five worksheets");
                Check(book.Descendants(S + "definedName").Where(x => (string)x.Attribute("name") == "_xlnm.Print_Titles").All(x => x.Value.EndsWith("$1:$5")), "Branding and data headers repeat on printed pages");
                var spaces = Load(zip, "xl/worksheets/sheet1.xml");
                var summary = Load(zip, "xl/worksheets/sheet2.xml");
                var samples = Load(zip, "xl/worksheets/sheet3.xml");
                var openings = Load(zip, "xl/worksheets/sheet4.xml");
                var info = Load(zip, "xl/worksheets/sheet5.xml");
                Check(Cell(spaces, "A6").Value == "001-A" && IsText(Cell(spaces, "A6")), "Room numbers retain leading zeros as text");
                Check(Cell(spaces, "C6").Value == "0007", "Space number remains independent from Room number");
                Check(Cell(spaces, "B6").Value == "غرفة اجتماعات" && Cell(spaces, "D6").Value == "HVAC Meeting Space", "Arabic Room name and independent Space name retained");
                Check(Cell(spaces, "N6").Value == "9223372036854775806" && IsText(Cell(spaces, "N6")), "Exact 64-bit Space ID is text");
                Check(Cell(spaces, "G6").Value == "24.5" && !IsText(Cell(spaces, "G6")), "Area is numeric square metres");
                Check(Cell(spaces, "H6").Value == "2.8" && !IsText(Cell(spaces, "H6")), "Accepted clear height is numeric metres");
                Check(Cell(spaces, "H7").Value.Length == 0 && Cell(spaces, "I7").Value == "2.6" && Cell(spaces, "J7").Value == "3.2", "Variable height exports a blank single height and real range");
                Check(Cell(spaces, "H8").Value.Length == 0 && Cell(spaces, "G8").Value.Length == 0, "Missing height and unavailable area are blank, not zero");
                Check(Cell(spaces, "L7").Value.Contains("Variable") && Cell(spaces, "L8").Value.Contains("Floor"), "Review reasons remain explicit");
                Check(Cell(spaces, "M6").Value == "2 / 2" && Cell(spaces, "M8").Value == "0 / 1", "Sample coverage counts include failures");
                Check(Cell(spaces, "K6").Value == "Ceiling underside" && Cell(spaces, "K7").Value == "Slab underside", "Ceiling and slab height bases are separate");
                Check(Cell(spaces, "O6").Value.Contains("Architecture"), "Room mapping source is exported");
                Check(Cell(spaces, "P6").Value.Contains("\uFFFD"), "Illegal XML characters sanitized without corrupting report");
                Check(Cell(spaces, "B7").Value.StartsWith("=HYPERLINK") && spaces.Descendants(S + "f").Count() == 0, "Formula-like names are inert text");
                Check(Cell(summary, "D6").Value == "3" && Cell(summary, "E6").Value == "41.75", "Summary counts and areas cover every exported row");
                Check(Cell(summary, "F6").Value == "1", "Unknown area is counted separately from known-area total");
                Check(Cell(summary, "G6").Value == "1" && Cell(summary, "H6").Value == "2", "Only accepted uniform heights count as measured");
                Check(Cell(summary, "I6").Value == "1" && Cell(summary, "J6").Value == "1" && Cell(summary, "K6").Value == "1", "Summary separates Ceiling, Slab and missing basis counts");
                int existing = SummaryRow(summary, "Level 01", "Existing");
                int construction = SummaryRow(summary, "Level 01", "New Construction");
                Check(Cell(summary, "D" + existing).Value == "1" && Cell(summary, "D" + construction).Value == "2", "Level and phase totals do not collapse different phases");
                Check(Cell(summary, "G" + construction).Value == "1" && Cell(summary, "H" + construction).Value == "1", "Height-review totals remain independent of opening dimension review");
                Check(Cell(samples, "H6").Value == "0.15" && Cell(samples, "I6").Value == "2.95" && Cell(samples, "J6").Value == "2.8", "Physical floor/overhead elevation and difference are retained");
                Check(Cell(samples, "G6").Value == "0", "Analytical space base is separately labelled, never substituted for floor top");
                Check(Cell(samples, "N6").Value == "9000000001" && IsText(Cell(samples, "N6")), "Linked instance ID preserves exact digits as text");
                Check(Cell(samples, "O6").Value == "9000000002" && Cell(samples, "S6").Value == "9000000003", "Floor and overhead element IDs remain distinct");
                Check(Cell(samples, "M6").Value == "Architecture" && Cell(samples, "Q6").Value == "Architecture", "Source documents are identified");
                Check(samples.Descendants(S + "row").Count() == 9, "All five physical or failed samples are exported");
                Check(Cell(spaces, "Q6").Value == "1" && Cell(spaces, "U6").Value == "2", "Verified Room counts include each associated door and window");
                Check(Numeric(Cell(spaces, "R6"), 2.1) && Numeric(Cell(spaces, "S6"), 2.1), "Door nominal area is width times height in square metres");
                Check(Cell(spaces, "V6").Value.Length == 0 && Numeric(Cell(spaces, "W6"), 1.8) && Cell(spaces, "X6").Value == "1", "Missing window dimensions leave total area blank and preserve known subtotal and missing count");
                Check(Cell(spaces, "T6").Value == "0" && Cell(spaces, "U7").Value == "1" && Numeric(Cell(spaces, "V7"), 3), "Complete opening dimensions retain numeric zero missing count and real area");
                Check(Cell(spaces, "Q8").Value.Length == 0 && Cell(spaces, "U8").Value.Length == 0 && Cell(spaces, "R8").Value.Length == 0 && Cell(spaces, "V8").Value.Length == 0, "Unverified Room opening counts and total areas stay blank");
                Check(Cell(spaces, "Y6").Value.Length > 0 && Cell(spaces, "Y8").Value != Cell(spaces, "Y6").Value, "Opening coverage distinguishes verified and unverified Rooms");
                Check(Cell(spaces, "Z6").Value.Contains("missing height"), "Opening review notes retain dimension caveats");
                Check(Cell(spaces, "AA6").Value == "Architecture" && Cell(spaces, "AB6").Value == "9000000001" && IsText(Cell(spaces, "AB6")), "Linked Room document and instance provenance stay exact");
                Check(Cell(spaces, "AC6").Value == "9223372036854775804" && IsText(Cell(spaces, "AC6")) && Cell(spaces, "AD6").Value == "room-a", "Exact Room element and unique IDs are exported as text");
                Check(Cell(summary, "M6").Value == "2" && Cell(summary, "N6").Value == "3", "Summary labels and counts room associations independently of unique inventory");
                Check(Numeric(Cell(summary, "O6"), 4.2) && Numeric(Cell(summary, "P6"), 4.8), "Room association area subtotals count the shared door for each Room");
                Check(Cell(summary, "Q6").Value.Length == 0 && Cell(summary, "R6").Value.Length == 0 && Cell(summary, "AA6").Value == "1", "Unverified exported Room prevents misleading complete unique counts");
                Check(Cell(summary, "S6").Value == "1" && Cell(summary, "T6").Value == "3", "Unique observed inventory deduplicates the shared door by source identity");
                Check(Cell(summary, "U6").Value.Length == 0 && Cell(summary, "V6").Value.Length == 0 && Numeric(Cell(summary, "W6"), 2.1) && Numeric(Cell(summary, "X6"), 4.8), "Unique known area subtotals remain available while complete totals are unknown");
                Check(Cell(summary, "Y6").Value == "0" && Cell(summary, "Z6").Value == "1", "Unique missing-dimension counts do not duplicate a shared opening");
                Check(Cell(summary, "M5").Value.IndexOf("room", StringComparison.OrdinalIgnoreCase) >= 0 && Cell(summary, "S5").Value.IndexOf("unique", StringComparison.OrdinalIgnoreCase) >= 0, "Room-association and unique-opening totals have distinct headers");
                int doorRow = OpeningRow(openings, "9223372036854775806", "9223372036854775805");
                Check(CellByHeader(openings, "Space element ID", doorRow).Value == "9223372036854775806" && IsText(CellByHeader(openings, "Space element ID", doorRow)), "Opening audit preserves exact 64-bit Space ID as text");
                Check(CellByHeader(openings, "Room number", doorRow).Value == "001-A" && CellByHeader(openings, "Room name", doorRow).Value == "غرفة اجتماعات" && CellByHeader(openings, "Space number", doorRow).Value == "0007", "Opening audit preserves Room and Space identity independently");
                Check(CellByHeader(openings, "Room document", doorRow).Value == "Architecture" && CellByHeader(openings, "Room element ID", doorRow).Value == "9223372036854775804" && CellByHeader(openings, "Room unique ID", doorRow).Value == "room-a", "Opening audit includes exact linked Room provenance");
                Check(CellByHeader(openings, "Opening kind", doorRow).Value == "Door" && CellByHeader(openings, "Opening link instance ID", doorRow).Value == "9000000001" && IsText(CellByHeader(openings, "Opening element ID", doorRow)) && CellByHeader(openings, "Opening unique ID", doorRow).Value == "door-shared", "Opening kind and exact source identity are retained");
                Check(CellByHeader(openings, "Family", doorRow).Value == "=SUM(1,1)" && IsText(CellByHeader(openings, "Family", doorRow)) && CellByHeader(openings, "Type", doorRow).Value == "باب مشترك", "Formula-like family and Arabic type names remain inert text");
                Check(CellByHeader(openings, "Size (W × H)", doorRow).Value == "1 × 2.1 m" && IsText(CellByHeader(openings, "Size (W × H)", doorRow)), "Door Size is a readable width × height label with explicit units");
                Check(Numeric(CellByHeader(openings, "Width (m)", doorRow), 1) && Numeric(CellByHeader(openings, "Height (m)", doorRow), 2.1) && Numeric(CellByHeader(openings, "Nominal area (m²)", doorRow), 2.1), "Opening dimensions and nominal product are numeric metres and square metres");
                Check(CellByHeader(openings, "Shared opening", doorRow).Value.StartsWith("Yes", StringComparison.OrdinalIgnoreCase), "Door associated with two Rooms is marked shared");
                Check(CellByHeader(openings, "Association status", doorRow).Value.Contains("Associated") && CellByHeader(openings, "Association source / notes", doorRow).Value.Contains("FromRoom / ToRoom"), "Opening audit states association status and method");
                Check(CellByHeader(openings, "Dimension source", doorRow).Value.Contains("Type") && CellByHeader(openings, "Dimension notes", doorRow).Value.Contains("Nominal"), "Opening audit identifies dimension source and limitations");
                int missingRow = OpeningRow(openings, "9223372036854775806", "9000000012");
                Check(CellByHeader(openings, "Width (m)", missingRow).Value == "1.2" && CellByHeader(openings, "Height (m)", missingRow).Value.Length == 0 && CellByHeader(openings, "Nominal area (m²)", missingRow).Value.Length == 0, "Unknown dimension and nominal area stay blank in opening detail");
                Check(CellByHeader(openings, "Size (W × H)", missingRow).Value == "1.2 × Unknown m", "Partial window Size identifies the missing side without inventing zero");
                int knownWindowRow = OpeningRow(openings, "9223372036854775806", "9000000011");
                Check(CellByHeader(openings, "Size (W × H)", knownWindowRow).Value == "1.5 × 1.2 m" && knownWindowRow != missingRow, "Different windows in one Space retain their individual Size records");
                Check(openings.Descendants(S + "row").Count() == 9, "Openings audit contains five exported Room associations including the shared door twice");
                Check(!openings.Root.Value.Contains("outside-hidden") && !openings.Root.Value.Contains("unassociated-scan"), "Source scan openings outside exported rows cannot enter detail quantities");
                Check(info.Root.Value.IndexOf("nominal", StringComparison.OrdinalIgnoreCase) >= 0 && info.Root.Value.IndexOf("shared", StringComparison.OrdinalIgnoreCase) >= 0, "Info explains nominal opening areas and shared-opening counting");
                Check(info.Root.Value.Contains("Level 01 / all measurement statuses"), "Export filter is disclosed");
                Check(info.Root.Value.Contains("not guaranteed extrema") && info.Root.Value.Contains("No analytical Space height"), "Finite sampling and physical basis are disclosed");
                Check(info.Root.Value.Contains("Version 3.0") && info.Root.Value.Contains("01032638143"), "V3 build metadata and creator information included");
                Check(info.Root.Value.Contains("simulated fixture"), "Scan notes retained");
                foreach (var sheet in new[] { spaces, summary, samples, openings, info })
                {
                    Check((string)sheet.Descendants(S + "pane").Single().Attribute("ySplit") == "5", "Five header rows frozen");
                    Check((string)sheet.Descendants(S + "autoFilter").Single().Attribute("ref") != null, "Data filter available");
                    Check(sheet.Descendants(S + "mergeCell").Count() == 3, "Consistent three-row report banner");
                    Check(sheet.Descendants(S + "oddHeader").Single().Value.Contains("KA MEP V3.0"), "Printed version is V3.0");
                    Check((string)sheet.Descendants(S + "pageSetup").Single().Attribute("orientation") == "landscape", "Landscape print setup");
                    Check(sheet.Descendants(S + "f").Count() == 0, "Workbook contains no executable cell formulas");
                }
                Check((string)spaces.Descendants(S + "autoFilter").Single().Attribute("ref") == "A5:AD8", "Spaces filter excludes title banners and covers every exported space");
                Check((string)samples.Descendants(S + "pageSetup").Single().Attribute("fitToWidth") == "2", "Wide audit data prints over two pages rather than becoming unreadable");
            }

            SpaceTakeoffXlsxExporter.Export(path, snapshot, new SpaceTakeoffExportOptions { HeightsInMillimeters = true });
            using (var zip = ZipFile.OpenRead(path))
            {
                var spaces = Load(zip, "xl/worksheets/sheet1.xml"); var samples = Load(zip, "xl/worksheets/sheet3.xml");
                Check(Cell(spaces, "H5").Value.Contains("mm") && Cell(spaces, "H6").Value == "2800", "Millimetre option converts and labels clear heights");
                Check(Cell(spaces, "I7").Value == "2600" && Cell(spaces, "J7").Value == "3200", "Millimetre option converts sampled ranges");
                Check(Cell(samples, "J6").Value == "2800" && Cell(samples, "H6").Value == "0.15", "Sample height converts while labelled coordinate elevations stay metres");
                Check(Cell(spaces, "G6").Value == "24.5", "Height units never change area units");
                var openings = Load(zip, "xl/worksheets/sheet4.xml");
                int doorRow = OpeningRow(openings, "9223372036854775806", "9223372036854775805");
                Check(CellByHeader(openings, "Size (W × H)", doorRow).Value == "1 × 2.1 m", "Opening Size stays in metres consistently with numeric dimensions when heights use millimetres");
                Check(Numeric(CellByHeader(openings, "Width (m)", doorRow), 1) && Numeric(CellByHeader(openings, "Height (m)", doorRow), 2.1), "Opening dimensions remain explicitly metres under the height millimetre option");
                Check(Numeric(Cell(spaces, "R6"), 2.1) && Numeric(CellByHeader(openings, "Nominal area (m²)", doorRow), 2.1), "Height unit option never changes opening square-metre areas");

            }

            // A filtered snapshot is the complete export contract, including its totals and samples.
            snapshot = Example(); snapshot.Rows.RemoveRange(1, 2);
            SpaceTakeoffXlsxExporter.Export(path, snapshot);
            using (var zip = ZipFile.OpenRead(path))
            {
                Check(Cell(Load(zip, "xl/worksheets/sheet2.xml"), "D6").Value == "1", "Filtered snapshot totals exclude hidden rows");
                Check(Load(zip, "xl/worksheets/sheet3.xml").Descendants(S + "row").Count() == 6, "Filtered snapshot audit excludes hidden samples");
                var summary = Load(zip, "xl/worksheets/sheet2.xml");
                Check(Cell(summary, "M6").Value == "1" && Cell(summary, "N6").Value == "2" && Cell(summary, "Q6").Value == "1" && Cell(summary, "R6").Value == "2", "Filtered opening counts use only exported Rooms, with complete counts available for verified coverage");
                Check(Cell(summary, "S6").Value == "1" && Cell(summary, "T6").Value == "2" && Numeric(Cell(summary, "U6"), 2.1) && Cell(summary, "V6").Value.Length == 0, "Filtered unique totals exclude scan extras and hidden Room windows");
                var openings = Load(zip, "xl/worksheets/sheet4.xml");
                Check(openings.Descendants(S + "row").Count() == 7 && !openings.Root.Value.Contains("window-second"), "Filtered opening detail excludes hidden Room associations");
                Check(CellByHeader(openings, "Shared opening", OpeningRow(openings, "9223372036854775806", "9223372036854775805")).Value.StartsWith("Yes", StringComparison.OrdinalIgnoreCase), "Shared flag survives filtering out the other associated Room");

            }
            snapshot.Rows[0].OpeningsComplete = false;
            snapshot.Rows[0].Openings[0].AssociationStatus = SpaceOpeningAssociationStatus.LookupFailed;
            SpaceTakeoffXlsxExporter.Export(path, snapshot);
            using (var zip = ZipFile.OpenRead(path))
            {
                var spaces = Load(zip, "xl/worksheets/sheet1.xml");
                var summary = Load(zip, "xl/worksheets/sheet2.xml");
                Check(Cell(spaces, "Q6").Value.Length == 0 && Cell(spaces, "U6").Value.Length == 0 && Cell(spaces, "R6").Value.Length == 0 && Numeric(Cell(spaces, "S6"), 2.1), "Partial opening scan keeps counts and total areas blank while retaining observed known area");
                Check(Cell(summary, "Q6").Value.Length == 0 && Cell(summary, "R6").Value.Length == 0 && Cell(summary, "S6").Value == "1" && Cell(summary, "AA6").Value == "1", "Partial scan retains observed unique inventory without claiming a complete count");
                Check(Cell(summary, "M6").Value == "1" && Cell(summary, "N6").Value == "2" && Cell(summary, "T6").Value == "2", "A failed second Room lookup never erases the known observed opening associations");
            }
            snapshot.Rows[0].OpeningsComplete = true;
            SpaceTakeoffXlsxExporter.Export(path, snapshot);
            using (var zip = ZipFile.OpenRead(path))
            {
                var spaces = Load(zip, "xl/worksheets/sheet1.xml");
                var summary = Load(zip, "xl/worksheets/sheet2.xml");
                Check(Cell(spaces, "Q6").Value.Length == 0 && Cell(spaces, "Y6").Value.StartsWith("Partial", StringComparison.Ordinal), "Failed Room lookup overrides a stale complete flag in both counts and coverage text");
                Check(Cell(summary, "Q6").Value.Length == 0 && Cell(summary, "AA6").Value == "1" && Cell(summary, "AB6").Value.StartsWith("Incomplete", StringComparison.Ordinal), "Summary incomplete-Room count and coverage agree with failed opening lookup");
            }
            snapshot = Example(); snapshot.Rows.RemoveRange(1, 2); snapshot.Rows[0].Openings.Clear();
            SpaceTakeoffXlsxExporter.Export(path, snapshot);
            using (var zip = ZipFile.OpenRead(path))
            {
                var spaces = Load(zip, "xl/worksheets/sheet1.xml");
                var summary = Load(zip, "xl/worksheets/sheet2.xml");
                Check(Cell(spaces, "Q6").Value == "0" && Cell(spaces, "U6").Value == "0" && Cell(spaces, "R6").Value == "0" && Cell(spaces, "V6").Value == "0", "Verified complete Room with no openings exports known numeric zero counts and areas");
                Check(Cell(summary, "Q6").Value == "0" && Cell(summary, "R6").Value == "0" && Cell(summary, "S6").Value == "0", "Complete empty opening inventory remains zero despite full source-scan records");
                Check((string)Load(zip, "xl/worksheets/sheet4.xml").Descendants(S + "autoFilter").Single().Attribute("ref") == "A5:X5", "Empty opening audit uses a header-only filter covering Size and numeric dimensions");
            }
            snapshot.IsComplete = false; snapshot.Rows.Clear();
            SpaceTakeoffXlsxExporter.Export(path, snapshot);
            using (var zip = ZipFile.OpenRead(path))
            {
                var spaces = Load(zip, "xl/worksheets/sheet1.xml");
                Check(Cell(spaces, "A3").Value.StartsWith("INCOMPLETE SCAN"), "Partial source coverage remains prominently visible");
                Check((string)spaces.Descendants(S + "autoFilter").Single().Attribute("ref") == "A5:AD5", "Empty report uses valid header-only filter");
                Check(Cell(Load(zip, "xl/worksheets/sheet2.xml"), "D6").Value == "0", "Empty report has numeric zero space count");
            }

            byte[] before = File.ReadAllBytes(path);
            snapshot = Example(); snapshot.Rows[0].AreaSquareMeters = double.NaN;
            Fails(() => SpaceTakeoffXlsxExporter.Export(path, snapshot), "Nonfinite area rejected");
            Check(before.SequenceEqual(File.ReadAllBytes(path)), "Validation failure preserves destination bytes");
            snapshot = Example(); snapshot.Rows[0].Samples[0].FloorElevationMeters = double.PositiveInfinity;
            Fails(() => SpaceTakeoffXlsxExporter.Export(path, snapshot), "Nonfinite sample elevation rejected");
            snapshot = Example(); snapshot.Rows[0].ClearHeightMeters = null;
            Fails(() => SpaceTakeoffXlsxExporter.Export(path, snapshot), "Measured status without physical height rejected");
            snapshot = Example(); snapshot.Rows[0].MaxHeightMeters = 1;
            Fails(() => SpaceTakeoffXlsxExporter.Export(path, snapshot), "Inverted sampled height range rejected");
            snapshot = Example(); snapshot.Rows.Add(snapshot.Rows[0]);
            Fails(() => SpaceTakeoffXlsxExporter.Export(path, snapshot), "Duplicate space rows cannot inflate report totals");
            snapshot = Example(); snapshot.Rows[0].Samples.Add(null);
            Fails(() => SpaceTakeoffXlsxExporter.Export(path, snapshot), "Missing sample rejected");
            snapshot = Example(); snapshot.Rows[0].Samples = null;
            Fails(() => SpaceTakeoffXlsxExporter.Export(path, snapshot), "Missing sample collection rejected");
            snapshot = Example(); snapshot.Options.MaximumHeightMeters = double.NaN;
            Fails(() => SpaceTakeoffXlsxExporter.Export(path, snapshot), "Invalid measurement settings rejected");
            snapshot = Example(); snapshot.Rows[0].Openings[0].WidthMeters = double.NaN;
            Fails(() => SpaceTakeoffXlsxExporter.Export(path, snapshot), "Nonfinite opening width rejected");
            Check(before.SequenceEqual(File.ReadAllBytes(path)), "Opening validation failure preserves destination bytes");
            snapshot = Example(); snapshot.Rows[0].Openings[0].HeightMeters = double.PositiveInfinity;
            Fails(() => SpaceTakeoffXlsxExporter.Export(path, snapshot), "Nonfinite opening height rejected");
            snapshot = Example(); snapshot.Rows[0].Openings[0].WidthMeters = -1;
            Fails(() => SpaceTakeoffXlsxExporter.Export(path, snapshot), "Negative nominal opening dimension rejected");
            snapshot = Example(); snapshot.Rows[0].Openings[0].Source = null;
            Fails(() => SpaceTakeoffXlsxExporter.Export(path, snapshot), "Opening without source identity rejected");
            snapshot = Example(); snapshot.Rows[0].Openings[0].Kind = (SpaceOpeningKind)999;
            Fails(() => SpaceTakeoffXlsxExporter.Export(path, snapshot), "Invalid opening kind rejected");
            snapshot = Example(); snapshot.Rows[0].Openings[0].AssociationStatus = (SpaceOpeningAssociationStatus)999;
            Fails(() => SpaceTakeoffXlsxExporter.Export(path, snapshot), "Invalid opening association status rejected");
            snapshot = Example(); snapshot.Rows[0].Openings.Add(null);
            Fails(() => SpaceTakeoffXlsxExporter.Export(path, snapshot), "Missing opening record rejected");
            snapshot = Example(); snapshot.Rows[0].Openings = null;
            Fails(() => SpaceTakeoffXlsxExporter.Export(path, snapshot), "Missing opening collection rejected");
            snapshot = Example(); snapshot.Rows[0].Openings.Add(snapshot.Rows[0].Openings[0]);
            Fails(() => SpaceTakeoffXlsxExporter.Export(path, snapshot), "Duplicate opening source cannot inflate one Room's report quantities");
            snapshot = Example(); snapshot.Rows[0].AreaSquareMeters = double.MaxValue; snapshot.Rows[1].AreaSquareMeters = double.MaxValue;
            Fails(() => SpaceTakeoffXlsxExporter.Export(path, snapshot), "Nonfinite aggregate area rejected even when individual inputs are finite");
            Check(before.SequenceEqual(File.ReadAllBytes(path)), "Aggregate overflow failure preserves destination bytes");
            Fails(() => SpaceTakeoffXlsxExporter.Export(Path.Combine(folder, "bad.csv"), Example()), "Incorrect output extension rejected");
            string directory = Path.Combine(folder, "cannot-replace.xlsx"); Directory.CreateDirectory(directory);
            Fails(() => SpaceTakeoffXlsxExporter.Export(directory, Example()), "Final rename failure surfaced");
            Check(Directory.Exists(directory), "Failed overwrite preserves existing destination directory");
            Check(Directory.GetFiles(folder, "*.tmp").Length == 0, "Failed export leaves no temporary workbook");

            foreach (var arg in args.Where(a => a.StartsWith("--example=", StringComparison.Ordinal)))
            {
                string example = Path.GetFullPath(arg.Substring("--example=".Length));
                Directory.CreateDirectory(Path.GetDirectoryName(example));
                var illustrative = Example();
                illustrative.Rows[0].Notes[0] = "Illustrative clear height measured above floor finish.";
                illustrative.Rows[1].RoomName = "غرفة الخدمات";
                foreach (var opening in illustrative.Rows.SelectMany(row => row.Openings))
                {
                    if (opening.Kind == SpaceOpeningKind.Door) opening.FamilyName = "Single-Leaf Door";
                    foreach (var room in opening.Rooms.Where(room => room.Number == "002")) room.Name = illustrative.Rows[1].RoomName;
                }
                SpaceTakeoffXlsxExporter.Export(example, illustrative);
                Console.WriteLine("Illustrative workbook: " + example);
            }
            Console.WriteLine("PASS " + checks.ToString(CultureInfo.InvariantCulture) + " HVAC Space report checks.");
            return 0;
        }
        catch (Exception ex) { Console.Error.WriteLine(ex); return 1; }
        finally { Directory.Delete(folder, true); }
    }

    private static SpaceTakeoffSnapshot Example()
    {
        var floor = new SpaceSurfaceSource { DocumentTitle = "Architecture", LinkInstanceId = 9000000001L, ElementId = 9000000002L, ElementName = "Floor finish" };
        var ceiling = new SpaceSurfaceSource { DocumentTitle = "Architecture", LinkInstanceId = 9000000001L, ElementId = 9000000003L, ElementName = "Suspended ceiling" };
        var slab = new SpaceSurfaceSource { DocumentTitle = "Structure", LinkInstanceId = 9000000004L, ElementId = 9000000005L, ElementName = "Upper slab" };
        var snapshot = new SpaceTakeoffSnapshot
        {
            ProjectTitle = "ILLUSTRATIVE SAMPLE — simulated HVAC spaces, not a Revit project",
            Release = "Version 3.0 / illustrative report", RevitVersion = "Illustrative fixture",
            ScannedAt = new DateTime(2026, 10, 26, 9, 0, 0, DateTimeKind.Utc), ScopeLabel = "Illustrative host Spaces / linked architecture and structure",
            Options = new SpaceTakeoffOptions { PhaseId = 501, IncludeLinkedGeometry = true },
            Notes = { "Illustrative simulated fixture. Sample values demonstrate formatting; no live Revit model was scanned." }
        };
        snapshot.Rows.Add(new SpaceTakeoffRow
        {
            SpaceId = 9223372036854775806L, SpaceUniqueId = "sample-a", RoomNumber = "001-A", RoomName = "غرفة اجتماعات", SpaceNumber = "0007", SpaceName = "HVAC Meeting Space",
            RoomIdentitySource = "Architecture / linked Room 001-A", LevelName = "Level 01", PhaseName = "New Construction", AreaSquareMeters = 24.5,
            BaseElevationMeters = 0, ClearHeightMeters = 2.8, MinHeightMeters = 2.8, MaxHeightMeters = 2.8, HeightBasis = SpaceHeightBasis.Ceiling, Status = SpaceMeasurementStatus.Measured,
            Notes = { "Illustrative clear height measured above floor finish.\u0001" },
            Samples = { Sample(1, 2.8, floor, ceiling, SpaceHeightBasis.Ceiling), Sample(2, 2.8, floor, ceiling, SpaceHeightBasis.Ceiling) }
        });
        snapshot.Rows.Add(new SpaceTakeoffRow
        {
            SpaceId = 12002, RoomNumber = "002", RoomName = "=HYPERLINK(\"https://example.invalid\",\"inert sample\")", SpaceNumber = "0008", SpaceName = "HVAC service space",
            RoomIdentitySource = "Architecture / linked Room 002", LevelName = "Level 01", PhaseName = "New Construction", AreaSquareMeters = 17.25,
            BaseElevationMeters = 0, MinHeightMeters = 2.6, MaxHeightMeters = 3.2, HeightBasis = SpaceHeightBasis.Slab, Status = SpaceMeasurementStatus.VariableHeight,
            Notes = { "Variable sampled slab height. Review the room before using a single height." },
            Samples = { Sample(1, 2.6, floor, slab, SpaceHeightBasis.Slab), Sample(2, 3.2, floor, slab, SpaceHeightBasis.Slab) }
        });
        snapshot.Rows.Add(new SpaceTakeoffRow
        {
            SpaceId = 12003, RoomNumber = "003", RoomName = "Office", SpaceNumber = "0009", SpaceName = "HVAC Office Space", LevelName = "Level 01", PhaseName = "Existing",
            BaseElevationMeters = 0, HeightBasis = SpaceHeightBasis.None, Status = SpaceMeasurementStatus.MissingFloor,
            Notes = { "No floor found within configured tolerance; height left blank." },
            Samples = { new SpaceHeightSample { SampleNumber = 1, X = 9, Y = 9, Status = SpaceMeasurementStatus.MissingFloor, Notes = "Floor geometry missing in illustrative sample." } }
        });
        var firstRoom = new SpaceOpeningRoomIdentity
        {
            Source = new SpaceSurfaceSource { DocumentTitle = "Architecture", LinkInstanceId = 9000000001L, ElementId = 9223372036854775804L, ElementName = "غرفة اجتماعات" },
            UniqueId = "room-a", Number = "001-A", Name = "غرفة اجتماعات"
        };
        var secondRoom = new SpaceOpeningRoomIdentity
        {
            Source = new SpaceSurfaceSource { DocumentTitle = "Architecture", LinkInstanceId = 9000000001L, ElementId = 9000000008L, ElementName = "Service Room" },
            UniqueId = "room-b", Number = "002", Name = snapshot.Rows[1].RoomName
        };
        snapshot.Rows[0].RoomSource = firstRoom.Source; snapshot.Rows[0].RoomUniqueId = firstRoom.UniqueId; snapshot.Rows[0].OpeningsComplete = true;
        snapshot.Rows[1].RoomSource = secondRoom.Source; snapshot.Rows[1].RoomUniqueId = secondRoom.UniqueId; snapshot.Rows[1].OpeningsComplete = true;
        snapshot.Rows[0].OpeningNotes.Add("One window has missing height; only its known peer contributes to the nominal area subtotal.");
        snapshot.Rows[2].OpeningNotes.Add("Linked Room could not be verified. Opening counts are unavailable.");
        var sharedDoor = Opening(SpaceOpeningKind.Door, 9223372036854775805L, "door-shared", 1, 2.1);
        sharedDoor.FamilyName = "=SUM(1,1)"; sharedDoor.TypeName = "باب مشترك";
        sharedDoor.Rooms.Add(firstRoom); sharedDoor.Rooms.Add(secondRoom);
        sharedDoor.SpaceIds.Add(snapshot.Rows[0].SpaceId); sharedDoor.SpaceIds.Add(snapshot.Rows[1].SpaceId);
        var knownWindow = Opening(SpaceOpeningKind.Window, 9000000011L, "window-known", 1.5, 1.2);
        knownWindow.Rooms.Add(firstRoom); knownWindow.SpaceIds.Add(snapshot.Rows[0].SpaceId);
        var unknownWindow = Opening(SpaceOpeningKind.Window, 9000000012L, "window-missing", 1.2, null);
        unknownWindow.DimensionNotes = "Height parameter unavailable; nominal area remains unknown.";
        unknownWindow.Rooms.Add(firstRoom); unknownWindow.SpaceIds.Add(snapshot.Rows[0].SpaceId);
        var secondWindow = Opening(SpaceOpeningKind.Window, 9000000013L, "window-second", 2, 1.5);
        secondWindow.Rooms.Add(secondRoom); secondWindow.SpaceIds.Add(snapshot.Rows[1].SpaceId);
        snapshot.Rows[0].Openings.AddRange(new[] { sharedDoor, knownWindow, unknownWindow });
        snapshot.Rows[1].Openings.AddRange(new[] { sharedDoor, secondWindow });
        snapshot.OpeningScan.Complete = true;
        snapshot.OpeningScan.Openings.AddRange(new[] { sharedDoor, knownWindow, unknownWindow, secondWindow });
        var outside = Opening(SpaceOpeningKind.Door, 9000000099L, "outside-hidden", 4, 5);
        outside.AssociationStatus = SpaceOpeningAssociationStatus.OutsideExportedRooms;
        outside.SpaceIds.Add(19999);
        snapshot.OpeningScan.Openings.Add(outside);
        var unassociated = Opening(SpaceOpeningKind.Window, 9000000098L, "unassociated-scan", 3, 4);
        unassociated.AssociationStatus = SpaceOpeningAssociationStatus.Unassociated;
        snapshot.OpeningScan.Openings.Add(unassociated);
        snapshot.OpeningScan.Notes.Add("Illustrative source scan contains one outside-exported-Room door and one unassociated window; neither belongs in exported Room quantities.");
        return snapshot;
    }

    private static SpaceOpeningRecord Opening(SpaceOpeningKind kind, long elementId, string uniqueId, double? width, double? height)
    {
        return new SpaceOpeningRecord
        {
            Kind = kind, Source = new SpaceSurfaceSource { DocumentTitle = "Architecture", LinkInstanceId = 9000000001L, ElementId = elementId, ElementName = uniqueId },
            UniqueId = uniqueId, FamilyName = "Illustrative " + kind, TypeName = "Nominal dimensions", WidthMeters = width, HeightMeters = height,
            DimensionSource = "Type width / height parameters", DimensionNotes = "Nominal width × height, not certified clear opening or glazing area.",
            AssociationStatus = SpaceOpeningAssociationStatus.Associated, AssociationNotes = "FromRoom / ToRoom in matched linked phase"
        };
    }

    private static SpaceHeightSample Sample(int number, double height, SpaceSurfaceSource floor, SpaceSurfaceSource overhead, SpaceHeightBasis basis)
    {
        return new SpaceHeightSample { SampleNumber = number, X = 2 + number, Y = 4 + number, BaseElevationMeters = 0, FloorElevationMeters = 0.15,
            OverheadElevationMeters = Math.Round(0.15 + height, 8), HeightMeters = height, HeightBasis = basis, Status = SpaceMeasurementStatus.Measured, FloorSource = floor, OverheadSource = overhead };
    }
    private static XDocument Load(ZipArchive zip, string name) { using (var stream = zip.GetEntry(name).Open()) return XDocument.Load(stream); }
    private static XElement Cell(XDocument sheet, string address) { return sheet.Descendants(S + "c").Single(x => (string)x.Attribute("r") == address); }
    private static XElement CellByHeader(XDocument sheet, string header, int row)
    {
        var headerCell = sheet.Descendants(S + "row").Single(x => (int)x.Attribute("r") == 5)
            .Elements(S + "c").Single(x => x.Value == header);
        string address = (string)headerCell.Attribute("r");
        return Cell(sheet, address.Substring(0, address.Length - 1) + row.ToString(CultureInfo.InvariantCulture));
    }
    private static bool Numeric(XElement cell, double expected)
    {
        double value;
        return !IsText(cell) && double.TryParse(cell.Value, NumberStyles.Float, CultureInfo.InvariantCulture, out value) && Math.Abs(value - expected) < 1e-9;
    }
    private static int OpeningRow(XDocument sheet, string spaceId, string openingId)
    {
        return sheet.Descendants(S + "row").Select(row => (int)row.Attribute("r")).Where(row => row >= 6)
            .Single(row => CellByHeader(sheet, "Space element ID", row).Value == spaceId && CellByHeader(sheet, "Opening element ID", row).Value == openingId);
    }
    private static int SummaryRow(XDocument sheet, string level, string phase)
    {
        return sheet.Descendants(S + "row").Select(row => (int)row.Attribute("r")).Where(row => row >= 7)
            .Single(row => Cell(sheet, "A" + row).Value == "Level / phase" && Cell(sheet, "B" + row).Value == level && Cell(sheet, "C" + row).Value == phase);
    }
    private static bool IsText(XElement cell) { return (string)cell.Attribute("t") == "inlineStr"; }
    private static void Check(bool condition, string label) { if (!condition) throw new Exception("FAIL " + label); checks++; Console.WriteLine("PASS " + label); }
    private static void Fails(Action action, string label)
    {
        try { action(); }
        catch (ArgumentException) { Check(true, label); return; }
        catch (IOException) { Check(true, label); return; }
        catch (UnauthorizedAccessException) { Check(true, label); return; }
        throw new Exception("FAIL " + label);
    }
}
