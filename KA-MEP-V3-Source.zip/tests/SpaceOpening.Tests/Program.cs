using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using PipeTakeoff.Core;

internal static class Program
{
    private static int checks;

    private static int Main()
    {
        try
        {
            SharedDoorAndSameRoom();
            ExactIdentityAndRepeatedPlacements();
            UnknownIsNotZero();
            InvalidScanRecords();
            RowCompletenessAndPhysicalStatus();
            NominalDimensions();
            NominalSizeLabels();
            MissingDimensionsAndSubtotals();
            SourceScopeAndExportedScope();
            Console.WriteLine("PASS " + checks + " detached Space opening association, quantity and dimension checks. Native Revit extraction is not exercised.");
            return 0;
        }
        catch (Exception ex) { Console.Error.WriteLine(ex); return 1; }
    }

    private static void SharedDoorAndSameRoom()
    {
        var office = Room(101, "room-office", "001", "Office");
        var corridor = Room(102, "room-corridor", "002", "Corridor");
        var officeSpace = Space(201, office);
        var corridorSpace = Space(202, corridor);
        var sharedDoor = Opening(301, SpaceOpeningKind.Door, 1, 2.1, office, corridor);
        var sameRoomDoor = Opening(302, SpaceOpeningKind.Door, .9, 2, office, office);
        var window = Opening(303, SpaceOpeningKind.Window, 1.5, 1.2, office);
        var openings = new[] { sharedDoor, sameRoomDoor, window };
        SpaceOpeningAssociation.Assign(new[] { officeSpace, corridorSpace }, openings, true);

        Equal(2, officeSpace.OpeningTotals.DoorCount, "Office receives each physical door once, including repeated From/To Room");
        Equal(1, corridorSpace.OpeningTotals.DoorCount, "Shared door belongs to both associated Spaces");
        Equal(1, officeSpace.OpeningTotals.WindowCount, "Window belongs to its exact architectural Room");
        Equal(0, corridorSpace.OpeningTotals.WindowCount, "Complete corridor association gives a true zero windows");
        Equal(2, sharedDoor.SpaceIds.Count, "Shared opening retains both Space associations");
        Equal(1, sameRoomDoor.SpaceIds.Count, "Same Room in both opening directions produces one Space association");
        Near(3.9, officeSpace.OpeningTotals.DoorAreaSquareMeters, "Space door nominal area sums its distinct physical doors");

        var totals = SpaceOpeningSummary.ForUniqueOpenings(officeSpace.Openings.Concat(corridorSpace.Openings), true);
        Equal(2, totals.DoorCount, "Overall physical door total is not the sum of per-Space counts");
        Equal(1, totals.WindowCount, "Overall physical window total remains distinct");
        Near(3.9, totals.DoorAreaSquareMeters, "Shared door area counts once in overall physical total");
        Near(1.8, totals.WindowAreaSquareMeters, "Window area is nominal width times height");

        SpaceOpeningAssociation.Assign(new[] { officeSpace, corridorSpace }, openings, true);
        Equal(3, officeSpace.Openings.Count, "Re-association replaces prior Space results without accumulating duplicates");
        Equal(2, sharedDoor.SpaceIds.Count, "Re-association does not accumulate duplicate Space IDs");
    }

    private static void ExactIdentityAndRepeatedPlacements()
    {
        const long largeRoom = 9000000101L;
        const long largeLink = 9000000201L;
        const long largeOpening = 9000000301L;
        var firstRoom = Room(largeRoom, "same-room-uid", "001", "Office", largeLink);
        var secondRoom = Room(largeRoom, "same-room-uid", "001", "Office", largeLink + 1);
        var firstSpace = Space(9000000401L, firstRoom);
        var secondSpace = Space(9000000402L, secondRoom);
        var sameTextRoom = Room(largeRoom + 1, "different-room-uid", "001", "Office", largeLink);
        var sameTextSpace = Space(9000000403L, sameTextRoom);
        var wrongUniqueIdRoom = Room(largeRoom, "different-uid-same-element", "001", "Office", largeLink);
        var wrongUniqueIdSpace = Space(9000000404L, wrongUniqueIdRoom);
        var firstDoor = Opening(largeOpening, SpaceOpeningKind.Door, 1, 2, firstRoom);
        var secondDoor = Opening(largeOpening, SpaceOpeningKind.Door, 1, 2, secondRoom);
        var duplicateFirstDoor = Opening(largeOpening, SpaceOpeningKind.Door, 1, 2, firstRoom);
        var openings = new[] { firstDoor, secondDoor, duplicateFirstDoor };
        SpaceOpeningAssociation.Assign(new[] { firstSpace, secondSpace, sameTextSpace, wrongUniqueIdSpace }, openings, true);

        Equal(1, firstSpace.OpeningTotals.DoorCount, "Repeated input of one physical source cannot duplicate a Space count");
        Equal(1, secondSpace.OpeningTotals.DoorCount, "Second placement associates only through its own link instance");
        Equal(0, sameTextSpace.OpeningTotals.DoorCount, "Equal Room number and name do not substitute for source identity");
        Equal(0, wrongUniqueIdSpace.OpeningTotals.DoorCount, "Room unique ID must agree even when the numeric Room ID agrees");
        Check(firstDoor.SpaceIds.SequenceEqual(new[] { 9000000401L }), "Association retains exact 64-bit Space ID");
        Check(firstDoor.Source.Key.Contains("9000000201") && firstDoor.Source.Key.Contains("9000000301"), "Source key retains exact 64-bit link and element IDs");
        var totals = SpaceOpeningSummary.ForUniqueOpenings(openings, true);
        Equal(2, totals.DoorCount, "Repeated architectural placements remain two physical openings while duplicate records collapse");
        Near(4, totals.DoorAreaSquareMeters, "Repeated placements each contribute their nominal area");

        var alternateDocument = Room(largeRoom, "same-room-uid", "001", "Office", largeLink, "Architecture B");
        var otherDoor = Opening(largeOpening, SpaceOpeningKind.Door, 1, 2, alternateDocument);
        var otherSpace = Space(9000000405L, alternateDocument);
        SpaceOpeningAssociation.Assign(new[] { firstSpace, otherSpace }, new[] { firstDoor, otherDoor }, true);
        Equal(1, firstSpace.OpeningTotals.DoorCount, "Document identity prevents cross-document Room association");
        Equal(1, otherSpace.OpeningTotals.DoorCount, "Same IDs in another document retain their own association");
        Equal(2, SpaceOpeningSummary.ForUniqueOpenings(new[] { firstDoor, otherDoor }, true).DoorCount, "Document identity prevents overall physical-source collisions");
    }

    private static void UnknownIsNotZero()
    {
        var verified = Space(201, Room(101, "verified", "001", "Office"));
        var textOnly = new SpaceTakeoffRow { SpaceId = 202, RoomNumber = "001", RoomName = "Office" };
        SpaceOpeningAssociation.Assign(new[] { verified, textOnly }, new SpaceOpeningRecord[0], true);
        Check(verified.OpeningsComplete, "Verified identity and complete empty scan establish zero");
        Equal(0, verified.OpeningTotals.DoorCount, "Verified empty Room has zero doors");
        Equal(0, verified.OpeningTotals.WindowCount, "Verified empty Room has zero windows");
        Near(0, verified.OpeningTotals.DoorAreaSquareMeters, "Complete empty Room has zero nominal door area");
        Check(!textOnly.OpeningsComplete && !textOnly.OpeningTotals.DoorCount.HasValue && !textOnly.OpeningTotals.WindowCount.HasValue,
            "Text-only Room identity leaves counts unknown");
        Check(!textOnly.OpeningTotals.DoorAreaSquareMeters.HasValue, "Unverified association leaves nominal total unknown");

        var door = Opening(301, SpaceOpeningKind.Door, 1, 2, Room(101, "verified", "001", "Office"));
        SpaceOpeningAssociation.Assign(new[] { verified }, new[] { door }, false);
        Equal(1, verified.Openings.Count, "Incomplete scan preserves the known associated physical opening detail");
        Check(!verified.OpeningsComplete && !verified.OpeningTotals.DoorCount.HasValue && !verified.OpeningTotals.WindowCount.HasValue,
            "Partial source scan does not present available opening counts as complete");
        Check(!verified.OpeningTotals.DoorAreaSquareMeters.HasValue, "Partial scan leaves complete nominal total blank");
        Near(2, verified.OpeningTotals.DoorKnownAreaSquareMeters, "Partial scan exposes its known nominal area subtotal");

        door.AssociationStatus = SpaceOpeningAssociationStatus.LookupFailed;
        SpaceOpeningAssociation.Assign(new[] { verified }, new[] { door }, false);
        Equal(SpaceOpeningAssociationStatus.LookupFailed, door.AssociationStatus, "Known association does not hide a failed other Room lookup");
        Check(!verified.OpeningTotals.DoorCount.HasValue, "A partially failed Room lookup cannot become a trusted count");
    }

    private static void NominalDimensions()
    {
        Near(.9144, SpaceOpeningDimensions.PositiveLengthMeters(3, 4), "Valid instance length takes precedence over family type length");
        Near(1.2192, SpaceOpeningDimensions.PositiveLengthMeters(null, 4), "Missing instance length uses family type length");
        foreach (double invalid in new[] { 0, -1, double.NaN, double.PositiveInfinity, double.NegativeInfinity })
        {
            Near(.6096, SpaceOpeningDimensions.PositiveLengthMeters(invalid, 2), "Invalid instance dimension falls back to positive finite type length");
            Check(!SpaceOpeningDimensions.PositiveLengthMeters(null, invalid).HasValue, "Invalid type dimension cannot become a measured length");
            Check(!SpaceOpeningDimensions.NominalArea(invalid, 2).HasValue, "Invalid nominal width cannot become an area");
            Check(!SpaceOpeningDimensions.NominalArea(2, invalid).HasValue, "Invalid nominal height cannot become an area");
        }
        Check(!SpaceOpeningDimensions.PositiveLengthMeters(null, null).HasValue, "No dimension parameters means unknown length");
        Check(!SpaceOpeningDimensions.PositiveLengthMeters(double.Epsilon, null).HasValue, "A dimension that underflows to zero metres remains unavailable");
        Near(.3048, SpaceOpeningDimensions.PositiveLengthMeters(double.Epsilon, 1), "Underflowed instance length falls back to a valid type length");
        Check(!SpaceOpeningDimensions.NominalArea(null, 2).HasValue, "Missing width leaves nominal area blank");
        Check(!SpaceOpeningDimensions.NominalArea(2, null).HasValue, "Missing height leaves nominal area blank");
        Check(!SpaceOpeningDimensions.NominalArea(double.MaxValue, 2).HasValue, "Overflowed nominal area is unavailable");
        Near(1.89, SpaceOpeningDimensions.NominalArea(.9, 2.1), "Nominal opening area is width times height in square metres");
    }

    private static void NominalSizeLabels()
    {
        var invariant = CultureInfo.InvariantCulture;
        Equal("0.9 × 2.1 m", SpaceOpeningDimensions.FormatSize(.9, 2.1, false, invariant), "Size displays nominal width before height and explicit metre units");
        Equal("900 × 2100 mm", SpaceOpeningDimensions.FormatSize(.9, 2.1, true, invariant), "Size converts both dimensions to millimetres");
        Equal("0,9 × 2,1 m", SpaceOpeningDimensions.FormatSize(.9, 2.1, false, CultureInfo.GetCultureInfo("fr-FR")), "Size follows the requested display culture");
        Equal("Unknown × 2.1 m", SpaceOpeningDimensions.FormatSize(null, 2.1, false, invariant), "Missing width retains the known height without inventing a zero");
        Equal("900 × Unknown mm", SpaceOpeningDimensions.FormatSize(.9, null, true, invariant), "Missing height retains the known width in selected units");
        Equal("Unknown × Unknown m", SpaceOpeningDimensions.FormatSize(null, null, false, invariant), "Completely missing size is explicitly unknown");
        foreach (double invalid in new[] { 0, -1, double.NaN, double.PositiveInfinity, double.NegativeInfinity })
        {
            Equal("Unknown × 2 m", SpaceOpeningDimensions.FormatSize(invalid, 2, false, invariant), "Invalid width is not presented as a valid size");
            Equal("1000 × Unknown mm", SpaceOpeningDimensions.FormatSize(1, invalid, true, invariant), "Invalid height is not presented as a valid size");
        }
        Check(!SpaceOpeningDimensions.FormatSize(.0001, .0001, false, invariant).StartsWith("0 ×", StringComparison.Ordinal),
            "Small positive nominal dimensions are not rounded to a fabricated zero size");
        Equal("Unknown × 2000 mm", SpaceOpeningDimensions.FormatSize(double.MaxValue, 2, true, invariant), "Overflowed unit conversion remains unavailable");
    }

    private static void InvalidScanRecords()
    {
        var room = Room(101, "verified", "001", "Office");
        var row = Space(201, room);
        var missingSource = Opening(301, SpaceOpeningKind.Door, 1, 2, room);
        missingSource.Source = null;
        var lookupFailed = Opening(302, SpaceOpeningKind.Window, 1, 2, room);
        lookupFailed.AssociationStatus = SpaceOpeningAssociationStatus.LookupFailed;
        foreach (var invalid in new[] { null, missingSource, lookupFailed })
        {
            var records = new[] { invalid };
            var totals = SpaceOpeningSummary.ForUniqueOpenings(records, true);
            Check(!totals.Complete && !totals.DoorCount.HasValue && !totals.WindowCount.HasValue,
                "Invalid physical identity or failed association overrides an asserted complete summary");
            SpaceOpeningAssociation.Assign(new[] { row }, records, true);
            Check(!row.OpeningsComplete && !row.OpeningTotals.DoorCount.HasValue && !row.OpeningTotals.WindowCount.HasValue,
                "Invalid source record prevents an apparently empty Room becoming a trusted zero");
        }
        Check(!row.OpeningTotals.WindowAreaSquareMeters.HasValue, "Known partial association cannot produce a complete nominal area");
        Near(2, row.OpeningTotals.WindowKnownAreaSquareMeters, "Known size survives a partial association failure as subtotal");
    }

    private static void RowCompletenessAndPhysicalStatus()
    {
        var unverified = new SpaceTakeoffRow
        {
            SpaceId = 201, RoomNumber = "001", RoomName = "Office",
            OpeningsComplete = true, Status = SpaceMeasurementStatus.Measured, ClearHeightMeters = 2.8
        };
        Check(!unverified.OpeningTotals.Complete && !unverified.OpeningTotals.DoorCount.HasValue &&
            !unverified.OpeningTotals.WindowCount.HasValue,
            "An asserted complete scan cannot establish zero counts without a verified Room identity");
        Check(!unverified.OpeningTotals.DoorAreaSquareMeters.HasValue && !unverified.OpeningTotals.WindowAreaSquareMeters.HasValue,
            "Unverified Room identity leaves both nominal area totals unavailable");
        Check(unverified.NeedsReview, "Measured Space with unverified Room identity still needs opening review");
        Equal(SpaceMeasurementStatus.Measured, unverified.Status, "Unverified Room identity does not overwrite physical height status");
        Near(2.8, unverified.ClearHeightMeters, "Unverified Room identity preserves measured physical height");

        var room = Room(101, "verified", "001", "Office");
        var verified = Space(202, room);
        verified.OpeningsComplete = true;
        verified.Status = SpaceMeasurementStatus.Measured;
        verified.ClearHeightMeters = 3.1;
        var opening = Opening(301, SpaceOpeningKind.Door, 1, 2, room);
        opening.AssociationStatus = SpaceOpeningAssociationStatus.LookupFailed;
        verified.Openings.Add(opening);
        Check(verified.OpeningsComplete && !verified.OpeningTotals.Complete,
            "Failed Room lookup overrides the raw complete flag in effective opening totals");
        Check(!verified.OpeningTotals.DoorCount.HasValue && !verified.OpeningTotals.WindowCount.HasValue,
            "Failed Room lookup leaves complete counts unknown despite a known opening record");
        Check(verified.NeedsReview, "Measured Space with a failed opening lookup requires review even when its raw complete flag is true");
        Equal(SpaceMeasurementStatus.Measured, verified.Status, "Opening lookup failure does not overwrite physical height status");
        Near(3.1, verified.ClearHeightMeters, "Opening lookup failure preserves measured physical height");
        Near(2, verified.OpeningTotals.DoorKnownAreaSquareMeters, "Opening lookup failure retains the known nominal area subtotal");
    }

    private static void MissingDimensionsAndSubtotals()
    {
        var knownDoor = Opening(301, SpaceOpeningKind.Door, .9, 2.1);
        var unknownDoor = Opening(302, SpaceOpeningKind.Door, null, 2.1);
        var knownWindow = Opening(303, SpaceOpeningKind.Window, 1.5, 1.2);
        var unknownWindow = Opening(304, SpaceOpeningKind.Window, 1.5, null);
        var totals = SpaceOpeningSummary.ForSpace(new[] { knownDoor, unknownDoor, knownWindow, unknownWindow }, true);
        Equal(2, totals.DoorCount, "Missing door dimensions do not erase a complete door count");
        Equal(2, totals.WindowCount, "Missing window dimensions do not erase a complete window count");
        Check(!totals.DoorAreaSquareMeters.HasValue && !totals.WindowAreaSquareMeters.HasValue, "Incomplete dimensions cannot produce apparently complete nominal areas");
        Near(1.89, totals.DoorKnownAreaSquareMeters, "Known door nominal area remains an explicit subtotal");
        Near(1.8, totals.WindowKnownAreaSquareMeters, "Known window nominal area remains an explicit subtotal");
        Equal(1, totals.DoorMissingDimensionCount, "Missing door size is counted once per physical opening");
        Equal(1, totals.WindowMissingDimensionCount, "Missing window size is counted once per physical opening");
        Check(!unknownDoor.AreaSquareMeters.HasValue && !unknownWindow.AreaSquareMeters.HasValue, "Individual records preserve unknown area");
        Equal(1, SpaceOpeningSummary.ForSpace(new[] { unknownDoor, unknownDoor }, true).DoorMissingDimensionCount, "Duplicate references cannot inflate missing-size count");
        unknownDoor.WidthMeters = .8;
        Near(1.68, unknownDoor.AreaSquareMeters, "Record nominal area follows its detached dimension values");
    }

    private static void SourceScopeAndExportedScope()
    {
        var exportedRoom = Room(101, "exported-room", "001", "Office");
        var outsideRoom = Room(102, "outside-room", "002", "Storage");
        var row = Space(201, exportedRoom);
        var exported = Opening(301, SpaceOpeningKind.Door, 1, 2, exportedRoom);
        var outside = Opening(302, SpaceOpeningKind.Window, 2, 1, outsideRoom);
        var unassociated = Opening(303, SpaceOpeningKind.Window, 1, 1);
        SpaceOpeningAssociation.Assign(new[] { row }, new[] { exported, outside, unassociated }, true);
        Equal(SpaceOpeningAssociationStatus.Associated, exported.AssociationStatus, "Matched opening is associated to exported Spaces");
        Equal(SpaceOpeningAssociationStatus.OutsideExportedRooms, outside.AssociationStatus, "Known Room outside the exported set is explicit");
        Equal(SpaceOpeningAssociationStatus.Unassociated, unassociated.AssociationStatus, "Opening with no Room remains a source-scope unassociated opening");
        Equal(0, outside.SpaceIds.Count, "Known outside Room does not acquire an exported Space ID");
        Equal(0, unassociated.SpaceIds.Count, "Unassociated opening is not guessed into an exported Space");

        var scan = new SpaceOpeningScanResult { Complete = true, Openings = new List<SpaceOpeningRecord> { exported, outside, unassociated } };
        Equal(1, scan.UnassociatedOpenings.Count(), "Source-scope review list retains unassociated opening");
        Equal(1, scan.OutsideExportedRooms.Count(), "Known outside-export Rooms remain separate from unassociated review");
        Equal(1, scan.Totals.DoorCount, "Exported overall count excludes source-scope outside and unknown openings");
        Equal(0, scan.Totals.WindowCount, "Source-scope windows cannot leak into exported Space totals");
        Near(2, scan.Totals.DoorAreaSquareMeters, "Exported overall nominal area uses associated physical sources only");
        var failed = Opening(304, SpaceOpeningKind.Door, 1, 2);
        failed.AssociationStatus = SpaceOpeningAssociationStatus.LookupFailed;
        scan.Openings.Add(failed);
        scan.Complete = false;
        Equal(2, scan.UnassociatedOpenings.Count(), "Source-scope review list includes unassociated and failed lookups");
        Check(!scan.Totals.DoorCount.HasValue && !scan.Totals.WindowCount.HasValue, "Incomplete scan summary preserves unknown counts");
    }

    private static SpaceOpeningRoomIdentity Room(long id, string uniqueId, string number, string name, long link = 11, string document = "Architecture")
    {
        return new SpaceOpeningRoomIdentity
        {
            Source = new SpaceSurfaceSource { DocumentTitle = document, LinkInstanceId = link, ElementId = id, ElementName = name },
            UniqueId = uniqueId, Number = number, Name = name
        };
    }

    private static SpaceTakeoffRow Space(long id, SpaceOpeningRoomIdentity room)
    {
        return new SpaceTakeoffRow { SpaceId = id, RoomSource = room.Source, RoomUniqueId = room.UniqueId, RoomNumber = room.Number, RoomName = room.Name };
    }

    private static SpaceOpeningRecord Opening(long id, SpaceOpeningKind kind, double? width, double? height, params SpaceOpeningRoomIdentity[] rooms)
    {
        var roomSource = rooms.Length == 0 ? null : rooms[0].Source;
        return new SpaceOpeningRecord
        {
            Source = new SpaceSurfaceSource { DocumentTitle = roomSource == null ? "Architecture" : roomSource.DocumentTitle,
                LinkInstanceId = roomSource == null ? 11 : roomSource.LinkInstanceId, ElementId = id, ElementName = kind.ToString() },
            UniqueId = "opening-" + id, Kind = kind, WidthMeters = width, HeightMeters = height,
            Rooms = new List<SpaceOpeningRoomIdentity>(rooms)
        };
    }

    private static void Equal<T>(T expected, T actual, string label)
    { Check(Equals(expected, actual), label + " [expected " + expected + ", actual " + actual + "]"); }

    private static void Near(double expected, double? actual, string label)
    { Check(actual.HasValue && Math.Abs(expected - actual.Value) < 1e-8, label); }

    private static void Check(bool condition, string label)
    {
        if (!condition) throw new Exception("FAIL " + label);
        checks++;
        Console.WriteLine("PASS " + label);
    }
}
