using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Xml.Linq;
using PipeTakeoff.Core;

internal static class Program
{
    private static readonly XNamespace S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static int checks;

    private static int Main(string[] args)
    {
        string folder = Path.Combine(Path.GetTempPath(), "KAMEP-Review-Report-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(folder);
        try
        {
            string path = Path.Combine(folder, "review.xlsx");
            var report = Example();
            ModelReviewXlsxExporter.Export(path, report);
            using (var zip = ZipFile.OpenRead(path))
            {
                Check(zip.Entries.Count == 8, "Workbook has exact workbook, relationships, styles and three worksheets");
                var workbook = Load(zip, "xl/workbook.xml");
                Check(string.Join(",", workbook.Descendants(S + "sheet").Select(x => (string)x.Attribute("name"))) == "Detail,Summary,Info", "Named sheets");
                Check((string)workbook.Descendants(S + "workbookView").Single().Attribute("activeTab") == "1", "Summary initially selected");
                Check(workbook.Descendants(S + "definedName").Count() == 6, "Print areas and repeat header rows");
                var detail = Load(zip, "xl/worksheets/sheet1.xml");
                var summary = Load(zip, "xl/worksheets/sheet2.xml");
                var info = Load(zip, "xl/worksheets/sheet3.xml");
                Check(detail.Descendants(S + "row").Count() == report.Rows.Count + 1, "Every finding exported once");
                Check(Cell(detail, "D2").Value == "9223372036854775806", "64-bit element ID preserved as text");
                Check((string)Cell(detail, "D2").Attribute("t") == "inlineStr", "IDs not floating point numbers");
                Check(detail.Descendants(S + "f").Count() == 0 && Cell(detail, "B2").Value.StartsWith("=HYPERLINK"), "Formula-like model text is inert");
                Check(Cell(detail, "C2").Value.Contains("\uFFFD"), "Invalid XML characters sanitized");
                Check(Cell(detail, "C3").Value.Contains("مراجعة النموذج"), "Arabic Unicode retained");
                Check(detail.Descendants(S + "col").Select(x => (int)x.Attribute("width")).SequenceEqual(new[] { 24, 40, 80, 30, 42 }), "Review columns have deliberate widths");
                Check(Cell(summary, "B4").Value == "79.5" && Cell(summary, "B4").Attribute("t") == null, "Health score is numeric");
                Check(summary.Root.Value.Contains("Count: CadImport") && summary.Root.Value.Contains("Count: PotentialDuplicate"), "Summary counts include present checks");
                Check(summary.Root.Value.Contains("not an Autodesk rating"), "Custom metric limitation included");
                Check(summary.Root.Value.Contains(report.HealthExplanation), "Full scoring method included");
                Check(info.Root.Value.Contains(report.Release) && info.Root.Value.Contains(report.ProjectTitle), "Project and build metadata included");
                Check(info.Root.Value.Contains(report.Notes[0]) && info.Root.Value.Contains("01032638143"), "Scan coverage and creator retained");
                foreach (var sheet in new[] { detail, summary, info })
                {
                    Check((string)sheet.Descendants(S + "pane").Single().Attribute("state") == "frozen", "Frozen headers");
                    Check(sheet.Descendants(S + "autoFilter").Count() == 1, "Filters available");
                    Check(sheet.Descendants(S + "oddHeader").Single().Value.Contains("Model Review & Cleanup"), "Correct report print header");
                    Check((string)sheet.Descendants(S + "pageSetup").Single().Attribute("fitToWidth") == "1", "Print fit-to-width");
                }
            }

            // Repeated reasons are compact in Summary, while Detail and the original score retain every occurrence.
            report = Example();
            report.Rows.Clear();
            report.Rows.Add(new ModelReviewReportRow { Kind = "RevitWarning", IssueKey = "warning:first-definition",
                IssueTitle = "Common warning", Title = "Instance one", ElementIds = { 9000000000L, 9000000001L } });
            report.Rows.Add(new ModelReviewReportRow { Kind = "RevitWarning", IssueKey = "warning:first-definition",
                IssueTitle = "Common warning", Title = "Instance two", ElementIds = { 9000000001L, 9000000002L } });
            report.Rows.Add(new ModelReviewReportRow { Kind = "RevitWarning", IssueKey = "warning:other-definition",
                IssueTitle = "Common warning", Title = "Instance one", ElementIds = { 9000000000L } });
            report.Rows.Add(new ModelReviewReportRow { Kind = "CadImport", Title = "Level one.dwg", ElementIds = { 42 } });
            report.Rows.Add(new ModelReviewReportRow { Kind = "CadImport", Title = "Level two.dwg", ElementIds = { 43 } });
            ModelReviewXlsxExporter.Export(path, report);
            using (var zip = ZipFile.OpenRead(path))
            {
                var summary = Load(zip, "xl/worksheets/sheet2.xml");
                var detail = Load(zip, "xl/worksheets/sheet1.xml");
                Check(Metric(summary, "Issue types").Elements(S + "c").ElementAt(1).Value == "3", "Summary groups repeated check and warning definitions");
                Check(Metric(summary, "Finding rows (occurrences)").Elements(S + "c").ElementAt(1).Value == "5", "Summary retains true occurrence count");
                Check(detail.Descendants(S + "row").Count() == 6, "Grouped summary does not remove detail rows");
                var issueRows = summary.Descendants(S + "row").Where(row => row.Elements(S + "c").First().Value == "Issue: Common warning").ToList();
                Check(issueRows.Count == 2, "Identically worded native warning definitions remain separate");
                var repeated = issueRows.Single(row => row.Elements(S + "c").ElementAt(1).Value == "2");
                Check(repeated.Elements(S + "c").ElementAt(2).Value.Contains("3 distinct affected elements"), "Repeated elements counted once per issue with exact 64-bit IDs");
                Check(repeated.Elements(S + "c").ElementAt(1).Attribute("t") == null, "Occurrence counts remain numeric");
                Check(Metric(summary, "Issue: Imported CAD files").Elements(S + "c").ElementAt(1).Value == "2", "CAD file names do not split summary issues");
                Check(Cell(summary, "B4").Value == "79.5", "Grouping does not recalculate or improve supplied review score");
                Check(summary.Root.Value.Contains("does not authorize cleanup"), "Summary does not imply batch cleanup approval");
            }

            // Incomplete scans must never present the default or stale score as an assessment.
            report.IsComplete = false;
            report.HealthScore = double.NaN;
            report.Rows.Clear();
            ModelReviewXlsxExporter.Export(path, report);
            using (var zip = ZipFile.OpenRead(path))
            {
                var summary = Load(zip, "xl/worksheets/sheet2.xml");
                Check(Cell(summary, "B4").Value == "Unavailable", "Incomplete score unavailable");
                var detail = Load(zip, "xl/worksheets/sheet1.xml");
                Check((string)detail.Descendants(S + "autoFilter").Single().Attribute("ref") == "A1:E1", "Empty report has valid header-only range");
                Check(detail.Descendants(S + "row").Count() == 1, "Successful overwrite replaces old findings");
            }
            byte[] before = File.ReadAllBytes(path);
            report.IsComplete = true;
            ExpectFailure(() => ModelReviewXlsxExporter.Export(path, report), "Completed NaN score rejected");
            Check(before.SequenceEqual(File.ReadAllBytes(path)), "Validation failure preserves existing workbook");
            report.HealthScore = 101;
            ExpectFailure(() => ModelReviewXlsxExporter.Export(path, report), "Out-of-range score rejected");
            report.HealthScore = 100;
            report.Rows.Add(null);
            ExpectFailure(() => ModelReviewXlsxExporter.Export(path, report), "Null finding rejected");
            report.Rows.Clear();
            report.Rows.Add(new ModelReviewReportRow { ElementIds = null });
            ExpectFailure(() => ModelReviewXlsxExporter.Export(path, report), "Missing typed element identifiers rejected");
            report.Rows.Clear();
            ExpectFailure(() => ModelReviewXlsxExporter.Export(Path.Combine(folder, "bad.csv"), report), "Non-xlsx extension rejected");
            // Fail at the final rename, after the ZIP has been written.
            string directoryDestination = Path.Combine(folder, "directory.xlsx");
            Directory.CreateDirectory(directoryDestination);
            ExpectFailure(() => ModelReviewXlsxExporter.Export(directoryDestination, report), "Final move failure surfaced");
            Check(Directory.Exists(directoryDestination), "Failed final move preserves destination");
            Check(Directory.GetFiles(folder, "*.tmp", SearchOption.TopDirectoryOnly).Length == 0, "Temporary files removed after failed final move");

            foreach (string arg in args.Where(a => a.StartsWith("--example=", StringComparison.Ordinal)))
            {
                string example = Path.GetFullPath(arg.Substring("--example=".Length));
                Directory.CreateDirectory(Path.GetDirectoryName(example));
                ModelReviewXlsxExporter.Export(example, Example());
                Console.WriteLine("Example workbook: " + example);
            }
            Console.WriteLine("All " + checks.ToString(CultureInfo.InvariantCulture) + " Model Review report checks passed.");
            return 0;
        }
        catch (Exception ex) { Console.Error.WriteLine(ex); return 1; }
        finally { Directory.Delete(folder, true); }
    }

    private static ModelReviewReport Example()
    {
        return new ModelReviewReport
        {
            ProjectTitle = "ILLUSTRATIVE SAMPLE — simulated findings, not a Revit model",
            Release = "Version 2.0 / report example",
            ScannedAt = new DateTime(2026, 10, 20, 9, 0, 0, DateTimeKind.Utc),
            IsComplete = true,
            HealthScore = 79.5,
            HealthExplanation = "Example only. 100 - min(25, imported CAD × 5) - min(20, unplaced views) - min(30, duplicate groups × 5) - min(25, other warnings × 0.5).",
            Rows =
            {
                new ModelReviewReportRow { Kind = "CadImport", Title = "=HYPERLINK(\"https://example.invalid\",\"inert sample\")",
                    Detail = "A sample imported floor plan.\u0001 Review whether it is needed before cleanup.", ElementIds = { 9223372036854775806L }, CleanupAvailability = "Eligible for reviewed cleanup" },
                new ModelReviewReportRow { Kind = "UnplacedView", Title = "MEP Coordination — Level 01", Detail = "مراجعة النموذج — not placed on a sheet. This may be intentional.",
                    ElementIds = { 120045 }, CleanupAvailability = "Eligible for reviewed cleanup" },
                new ModelReviewReportRow { Kind = "PotentialDuplicate", Title = "Potential coincident duct elements", Detail = "Two elements share a conservative geometry signature. Inspect both before making changes.",
                    ElementIds = { 70001, 70002 }, CleanupAvailability = "Review only; manual decision required" },
                new ModelReviewReportRow { Kind = "CadLink", Title = "Architectural background.dwg", Detail = "Linked CAD is listed for awareness and is excluded from cleanup.",
                    ElementIds = { 140022 }, CleanupAvailability = "Review only" },
                new ModelReviewReportRow { Kind = "RevitWarning", Title = "Example warning", Detail = "Illustrative warning row, not an actual model warning.",
                    ElementIds = { 90003 }, CleanupAvailability = "Review only" }
            },
            Notes = { "ILLUSTRATIVE SAMPLE: example score is for presentation only. The report does not scan or alter a Revit document." }
        };
    }

    private static XDocument Load(ZipArchive zip, string path)
    {
        using (var stream = zip.GetEntry(path).Open()) return XDocument.Load(stream);
    }
    private static XElement Cell(XDocument doc, string address) { return doc.Descendants(S + "c").Single(x => (string)x.Attribute("r") == address); }
    private static XElement Metric(XDocument doc, string name) { return doc.Descendants(S + "row").Single(row => row.Elements(S + "c").First().Value == name); }
    private static void Check(bool condition, string label)
    {
        if (!condition) throw new Exception("FAIL: " + label);
        checks++;
        Console.WriteLine("PASS: " + label);
    }
    private static void ExpectFailure(Action action, string label)
    {
        bool failed = false;
        try { action(); } catch (Exception) { failed = true; }
        Check(failed, label);
    }
}
