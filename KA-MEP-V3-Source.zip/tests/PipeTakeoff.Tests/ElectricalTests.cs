using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Xml.Linq;
using PipeTakeoff.Core;

internal static class ElectricalTests
{
    private static readonly XNamespace S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static string folder;

    internal static void Register(Action<string, Action> test, string testFolder)
    {
        folder = testFolder;
        test("Electrical category identity separates tray, conduit, and both fitting classes", Categories);
        test("Electrical canonical sections preserve size precision and ignore display formatting", CanonicalSections);
        test("Electrical fitting connector multiplicity and reducer sections stay distinct", Connectors);
        test("Electrical service, family, and type grouping are independent options", OptionalGrouping);
        test("Electrical fitting kinds and rounded angles including null stay distinct", Fittings);
        test("Electrical straight lengths retain precision and ignore all fitting lengths", Lengths);
        test("Electrical invalid measurements, categories, and overflow are rejected", InvalidMeasurements);
        test("Electrical text and numeric filters support AND, OR, and missing parameters", Filters);
        test("Electrical workbook separates lengths and counts with fitting cells blank", Workbook);
        test("Electrical empty and single-category workbooks have honest totals", EmptyAndSingleCategory);
        test("Electrical Unicode and formula-like values remain safe literal text", SafeText);
        test("Electrical failed export preserves existing files and cleans temporary output", AtomicWorkbook);
        test("Electrical selected numeric columns and optional summary dimensions retain precision", GroupedWorkbook);
    }

    private static TakeoffOptions Options()
    { return new TakeoffOptions { Columns = ElectricalStandardFields.Create(), GroupBySystem = false }; }
    private static FieldDefinition Field(string key)
    { return ElectricalStandardFields.Create().Single(field => field.Key == key); }

    private static PipeRecord Segment(int id, string category = "Cable Tray", string section = "Rectangular:300x100", double length = 2.5, string service = "Power")
    {
        var record = new PipeRecord();
        record.Values["ElementId"] = id.ToString(CultureInfo.InvariantCulture); record.Values["Category"] = category;
        record.Values["SectionKey"] = section; record.Values["SectionLabel"] = section;
        record.Values["Size"] = "project display"; record.Values["Length"] = length;
        record.Values["Family"] = category; record.Values["Type"] = category == "Conduit" ? "EMT" : "Perforated";
        record.Values["SystemName"] = service; record.Values["Level"] = "Level 01";
        if (category == "Conduit") record.Values["Diameter"] = 25.0;
        else { record.Values["Width"] = 300.0; record.Values["Height"] = 100.0; }
        return record;
    }

    private static PipeRecord Fitting(int id, string category = "Cable Tray Fitting", string kind = "Elbow", double? angle = 90)
    {
        PipeRecord record = Segment(id, category == "Conduit Fitting" ? "Conduit" : "Cable Tray");
        record.Values["Category"] = category; record.Values.Remove("Length");
        record.Values["FittingKind"] = kind; record.Values["Angle"] = angle;
        record.Values["Family"] = category + " " + kind; record.Values["Type"] = "Standard";
        record.Values["SectionKey"] = category == "Conduit Fitting" ? "Round:25|Round:25" : "Rectangular:300x100|Rectangular:300x100";
        record.Values["SectionLabel"] = category == "Conduit Fitting" ? "Ø25 mm → Ø25 mm" : "300 × 100 mm → 300 × 100 mm";
        return record;
    }

    private static void Categories()
    {
        var records = new[] { Segment(1), Segment(2, "Conduit"), Fitting(3), Fitting(4, "Conduit Fitting") };
        foreach (PipeRecord record in records) record.Values["SectionKey"] = "Same identity";
        var rows = ElectricalTakeoffEngine.Summarize(records, Options());
        Equal(4, rows.Count, "All categories separate even with identical keys");
        Equal("Cable Tray,Cable Tray Fitting,Conduit,Conduit Fitting", string.Join(",", rows.Select(row => row.Category)), "Stable category ordering");
    }

    private static void CanonicalSections()
    {
        var records = new[] { Segment(1), Segment(2), Segment(3, section: "Rectangular:300.000001x100"), Segment(4, section: "Rectangular:100x300") };
        records[1].Values["Size"] = "11 13/16\" x 3 15/16\"";
        var rows = ElectricalTakeoffEngine.Summarize(records, Options());
        Equal(3, rows.Count, "Canonical precision and width/height orientation matter");
        Equal(2, rows.Single(row => row.Count == 2).Count, "Project-formatted Size does not change identity");
        var unresolved1 = Segment(5, section: "Unresolved:5"); var unresolved2 = Segment(6, section: "Unresolved:6");
        unresolved1.Values.Remove("Width"); unresolved1.Values.Remove("Height");
        unresolved2.Values.Remove("Width"); unresolved2.Values.Remove("Height");
        Equal(2, ElectricalTakeoffEngine.Summarize(new[] { unresolved1, unresolved2 }, Options()).Count, "Element-specific unresolved sections never merge");
    }

    private static void Connectors()
    {
        var records = new[] { Fitting(1), Fitting(2), Fitting(3), Fitting(4) };
        records[1].Values["SectionKey"] = "Rectangular:300x100|Rectangular:300x100|Rectangular:300x100";
        records[2].Values["SectionKey"] = "Rectangular:200x100|Rectangular:300x100";
        Equal(3, ElectricalTakeoffEngine.Summarize(records, Options()).Count, "Repeated connector sizes and reducer sections contribute to identity");
    }

    private static void OptionalGrouping()
    {
        var records = new[] { Segment(1), Segment(2, service: "Data"), Segment(3), Segment(4) };
        records[2].Values["Family"] = "Ladder"; records[3].Values["Type"] = "Stainless";
        var options = Options(); Equal(1, ElectricalTakeoffEngine.Summarize(records, options).Count, "Section-only grouping");
        options.GroupBySystem = true; Equal(2, ElectricalTakeoffEngine.Summarize(records, options).Count, "Service Type grouping");
        options.GroupByFamily = true; Equal(3, ElectricalTakeoffEngine.Summarize(records, options).Count, "Family grouping");
        options.GroupByType = true; Equal(4, ElectricalTakeoffEngine.Summarize(records, options).Count, "Type grouping");
    }

    private static void Fittings()
    {
        var records = new[] { Fitting(1), Fitting(2, angle: 90.0000001), Fitting(3, angle: 45), Fitting(4, angle: null),
            Fitting(5, angle: 0), Fitting(6, kind: "Tee"), Fitting(7, angle: 90.000001) };
        var rows = ElectricalTakeoffEngine.Summarize(records, Options());
        Equal(6, rows.Count, "Kind, angle, missing angle, and engineering precision distinguish groups");
        Equal(2, rows.Single(row => row.FittingKind == "Elbow" && row.AngleDegrees == 90).Count, "Conversion roundoff combines");
        Equal(1, rows.Count(row => row.AngleDegrees == null), "Null angle differs from zero");
    }

    private static void Lengths()
    {
        var fitting = Fitting(2); fitting.Values["Length"] = double.NaN;
        var conduitFitting = Fitting(4, "Conduit Fitting"); conduitFitting.Values["Length"] = 999.0;
        var rows = ElectricalTakeoffEngine.Summarize(new[] { Segment(1, length: 1.234567891234), fitting,
            Segment(3, "Conduit", "Round:25", 5.678912345678), conduitFitting }, Options());
        Near(1.234567891234, rows.Single(row => row.Category == "Cable Tray").TotalLengthMeters);
        Near(5.678912345678, rows.Single(row => row.Category == "Conduit").TotalLengthMeters);
        foreach (var row in rows.Where(row => row.Category.EndsWith(" Fitting", StringComparison.Ordinal))) Near(0, row.TotalLengthMeters);
    }

    private static void InvalidMeasurements()
    {
        foreach (object value in new object[] { null, -1.0, double.NaN, double.PositiveInfinity, "bad" })
        {
            var record = Segment(1); record.Values["Length"] = value;
            Throws<ArgumentException>(() => ElectricalTakeoffEngine.Summarize(new[] { record }, Options()));
        }
        foreach (object value in new object[] { 0.0, -1.0, double.NaN, double.NegativeInfinity, "bad" })
        {
            var record = Segment(1); record.Values["Width"] = value;
            Throws<ArgumentException>(() => ElectricalTakeoffEngine.Summarize(new[] { record }, Options()));
        }
        foreach (object value in new object[] { -1.0, 361.0, double.NaN, "bad" })
        {
            var record = Fitting(1); record.Values["Angle"] = value;
            Throws<ArgumentException>(() => ElectricalTakeoffEngine.Summarize(new[] { record }, Options()));
        }
        var missing = Segment(1); missing.Values.Remove("SectionKey");
        Throws<ArgumentException>(() => ElectricalTakeoffEngine.Summarize(new[] { missing }, Options()));
        var category = Segment(1); category.Values["Category"] = "Duct";
        Throws<ArgumentException>(() => ElectricalTakeoffEngine.Summarize(new[] { category }, Options()));
        Throws<ArgumentException>(() => ElectricalTakeoffEngine.Summarize(new PipeRecord[] { null }, Options()));
        Throws<ArgumentException>(() => ElectricalTakeoffEngine.Summarize(new[] { Segment(1, length: double.MaxValue), Segment(2, length: double.MaxValue) }, Options()));
        Throws<ArgumentException>(() => ElectricalXlsxExporter.Export(Path.Combine(folder, "electrical-overflow.xlsx"),
            new[] { Segment(1, length: double.MaxValue), Segment(2, "Conduit", "Round:25", double.MaxValue) }, Options(), null));
    }

    private static void Filters()
    {
        var records = new[] { Segment(1), Segment(2, "Conduit", "Round:25", 8, "Data"), Fitting(3) };
        var options = Options();
        options.Filters.Add(new FilterRule { Field = Field("SystemName"), Operator = FilterOperator.Contains, Value = "POWER" });
        options.Filters.Add(new FilterRule { Field = Field("Length"), Operator = FilterOperator.GreaterThan, Value = "3" });
        Equal(0, ElectricalTakeoffEngine.Filter(records, options).Count, "AND");
        options.Match = FilterMatch.Any; Equal(3, ElectricalTakeoffEngine.Filter(records, options).Count, "OR");
        options.Filters = new List<FilterRule> { new FilterRule { Field = Field("Length"), Operator = FilterOperator.IsEmpty } };
        Equal("3", ElectricalTakeoffEngine.Filter(records, options).Single().Get("ElementId"), "Fitting missing length stays filterable as empty");
        options.Filters = new List<FilterRule> { new FilterRule { Field = Field("Category"), Operator = FilterOperator.Equals, Value = "conduit" } };
        Equal("2", ElectricalTakeoffEngine.Filter(records, options).Single().Get("ElementId"), "Category filter ignores case");
    }

    private static List<PipeRecord> WorkbookRecords()
    {
        return new List<PipeRecord> { Segment(1), Segment(2, length: 3.25), Fitting(3),
            Segment(4, "Conduit", "Round:25", 8.125), Fitting(5, "Conduit Fitting") };
    }

    private static void Workbook()
    {
        string path = Path.Combine(folder, "electrical.xlsx"); var options = Options();
        options.Columns = new List<FieldDefinition> { Field("ElementId"), Field("Category"), Field("Length") };
        var records = WorkbookRecords(); records[2].Values["Length"] = double.NaN; records[4].Values["Length"] = 999.0;
        ElectricalXlsxExporter.Export(path, records, options, new ExportMetadata { Project = "حصر الكهرباء", Scope = "Project", RevitVersion = "2025" });
        using (ZipArchive zip = ZipFile.OpenRead(path))
        {
            Equal(8, zip.Entries.Count, "Native workbook parts");
            foreach (ZipArchiveEntry entry in zip.Entries) using (Stream stream = entry.Open()) XDocument.Load(stream);
            Equal("Detail,Summary,Info", string.Join(",", Read(zip, "xl/workbook.xml").Descendants(S + "sheet").Select(e => (string)e.Attribute("name"))), "Worksheet names");
            foreach (XElement relation in Read(zip, "xl/_rels/workbook.xml.rels").Root.Elements()) Check(zip.GetEntry("xl/" + (string)relation.Attribute("Target")) != null, "Relationship target missing");
            var detail = Read(zip, "xl/worksheets/sheet1.xml");
            Equal("A1:C7", (string)detail.Root.Element(S + "dimension").Attribute("ref"), "Detail range");
            Equal("A1:C6", (string)detail.Root.Element(S + "autoFilter").Attribute("ref"), "Totals excluded from filter");
            Blank(detail, "C4"); Blank(detail, "C6"); Near(13.875, Number(detail, "C7"));
            var summary = Read(zip, "xl/worksheets/sheet2.xml");
            Equal("Cable Tray Length (m)", Text(summary, "F1"), "Tray length column"); Equal("Conduit Length (m)", Text(summary, "G1"), "Conduit length column");
            Near(2, Number(summary, "E2")); Near(5.75, Number(summary, "F2")); Blank(summary, "G2");
            Blank(summary, "F3"); Blank(summary, "G3"); Near(1, Number(summary, "E3"));
            Near(8.125, Number(summary, "G4")); Blank(summary, "F4"); Blank(summary, "F5"); Blank(summary, "G5");
            Near(5, Number(summary, "E6")); Near(5.75, Number(summary, "F6")); Near(8.125, Number(summary, "G6"));
            var info = Read(zip, "xl/worksheets/sheet3.xml");
            Equal("حصر الكهرباء", InfoText(info, "Project"), "Arabic metadata");
            Near(2, InfoNumber(info, "Cable tray segment count")); Near(1, InfoNumber(info, "Cable tray fitting count"));
            Near(1, InfoNumber(info, "Conduit segment count")); Near(1, InfoNumber(info, "Conduit fitting count"));
            Near(5.75, InfoNumber(info, "Total cable tray straight length (m)")); Near(8.125, InfoNumber(info, "Total conduit straight length (m)"));
            Equal("01032638143", InfoText(info, "Tel"), "Phone leading zero retained");
        }
    }

    private static void EmptyAndSingleCategory()
    {
        string path = Path.Combine(folder, "electrical-empty.xlsx"); ElectricalXlsxExporter.Export(path, new PipeRecord[0], Options(), null);
        using (ZipArchive zip = ZipFile.OpenRead(path))
        {
            var summary = Read(zip, "xl/worksheets/sheet2.xml");
            Near(0, Number(summary, "E2")); Near(0, Number(summary, "F2")); Near(0, Number(summary, "G2"));
            Equal("A1:G1", (string)summary.Root.Element(S + "autoFilter").Attribute("ref"), "Empty filter excludes totals");
        }
        ElectricalXlsxExporter.Export(path, new[] { Fitting(1, "Conduit Fitting") }, Options(), null);
        using (ZipArchive zip = ZipFile.OpenRead(path))
        {
            var summary = Read(zip, "xl/worksheets/sheet2.xml"); Blank(summary, "F2"); Blank(summary, "G2");
            Near(1, Number(summary, "E3")); Near(0, Number(summary, "F3")); Near(0, Number(summary, "G3"));
        }
    }

    private static void SafeText()
    {
        string path = Path.Combine(folder, "electrical-text.xlsx"); var record = Segment(1);
        record.Values["Comments"] = "=HYPERLINK(\"https://example.test\")\u0001 كابل 😀 _x0041_";
        var options = Options(); options.Columns = new List<FieldDefinition> { Field("Comments") };
        ElectricalXlsxExporter.Export(path, new[] { record }, options, null);
        using (ZipArchive zip = ZipFile.OpenRead(path))
        {
            var detail = Read(zip, "xl/worksheets/sheet1.xml");
            Equal("inlineStr", (string)Cell(detail, "A2").Attribute("t"), "Formula-like text remains text");
            Equal("=HYPERLINK(\"https://example.test\")\uFFFD كابل 😀 _x005F_x0041_", Text(detail, "A2"), "XML sanitization and Excel escaping");
            Equal(0, detail.Descendants(S + "f").Count(), "No model formulas");
        }
    }

    private static void AtomicWorkbook()
    {
        string path = Path.Combine(folder, "electrical-atomic.xlsx"); File.WriteAllText(path, "Existing workbook");
        var records = WorkbookRecords(); records[0].Values["Custom"] = "not a number";
        var options = Options(); options.Columns.Add(new FieldDefinition { Key = "Custom", Header = "Custom numeric", IsNumeric = true });
        Throws<ArgumentException>(() => ElectricalXlsxExporter.Export(path, records, options, null));
        Equal("Existing workbook", File.ReadAllText(path), "Existing data survives a write failure");
        Equal(0, Directory.GetFiles(folder, "*.tmp").Length, "Failed temporary output removed");
        ElectricalXlsxExporter.Export(path, records, Options(), null);
        using (ZipArchive zip = ZipFile.OpenRead(path)) Check(zip.GetEntry("xl/workbook.xml") != null, "Successful atomic replacement");
        Throws<ArgumentException>(() => ElectricalXlsxExporter.Export(Path.Combine(folder, "wrong.csv"), records, Options(), null));
    }

    private static void GroupedWorkbook()
    {
        string path = Path.Combine(folder, "electrical-grouped.xlsx"); var options = Options();
        options.Columns = new List<FieldDefinition> { Field("Length"), Field("Diameter") };
        options.GroupBySystem = options.GroupByFamily = options.GroupByType = true;
        var record = Segment(1, "Conduit", "Round:25.123456", 1.234567891234); record.Values["Diameter"] = 25.123456;
        ElectricalXlsxExporter.Export(path, new[] { record, Fitting(2, "Conduit Fitting") }, options, null);
        using (ZipArchive zip = ZipFile.OpenRead(path))
        {
            var detail = Read(zip, "xl/worksheets/sheet1.xml"); Near(1.234567891234, Number(detail, "A2")); Near(25.123456, Number(detail, "B2")); Blank(detail, "A3");
            Near(1.234567891234, Number(detail, "A4"));
            var summary = Read(zip, "xl/worksheets/sheet2.xml");
            Equal("A1:J4", (string)summary.Root.Element(S + "dimension").Attribute("ref"), "All optional summary columns");
            Equal("Power", Text(summary, "E2"), "Service column"); Equal("Conduit", Text(summary, "F2"), "Family column"); Equal("EMT", Text(summary, "G2"), "Type column");
            Near(1, Number(summary, "H2")); Blank(summary, "I2"); Near(1.234567891234, Number(summary, "J2")); Near(2, Number(summary, "H4"));
        }
    }

    internal static void ExportExample(string path)
    {
        path = Path.GetFullPath(path); Directory.CreateDirectory(Path.GetDirectoryName(path));
        var records = WorkbookRecords();
        records[0].Values["SectionLabel"] = records[1].Values["SectionLabel"] = "300 × 100 mm";
        records[3].Values["SectionLabel"] = "Ø25 mm";
        var dataTray = Segment(101, section: "Rectangular:200x50", length: 12.875, service: "Data");
        dataTray.Values["Width"] = 200.0; dataTray.Values["Height"] = 50.0; dataTray.Values["SectionLabel"] = "200 × 50 mm"; records.Add(dataTray);
        var largeConduit = Segment(201, "Conduit", "Round:32", 16.42, "Lighting");
        largeConduit.Values["Diameter"] = 32.0; largeConduit.Values["SectionLabel"] = "Ø32 mm"; records.Add(largeConduit);
        foreach (PipeRecord record in records) record.Values["Comments"] = "ILLUSTRATIVE SAMPLE / بيانات تجريبية — not a Revit model";
        var options = Options(); options.GroupBySystem = options.GroupByFamily = options.GroupByType = true;
        options.Columns = options.Columns.Where(field => field.Key != "SectionKey" && field.Key != "Size").ToList();
        ElectricalXlsxExporter.Export(path, records, options, new ExportMetadata
        {
            Project = "KA MEP V2.0 — ILLUSTRATIVE SAMPLE — simulated electrical data, not a Revit model",
            Scope = "Demonstration records only", RevitVersion = "2024 / 2025 (sample)", ExportedAt = new DateTime(2026, 10, 17, 12, 0, 0)
        });
        Console.WriteLine("Electrical example workbook: " + path);
    }

    private static XDocument Read(ZipArchive zip, string name)
    { using (Stream stream = zip.GetEntry(name).Open()) return XDocument.Load(stream); }
    private static XElement Cell(XDocument sheet, string address)
    { return sheet.Descendants(S + "c").Single(cell => (string)cell.Attribute("r") == address); }
    private static string Text(XDocument sheet, string address)
    { return string.Concat(Cell(sheet, address).Descendants(S + "t").Select(text => text.Value)); }
    private static double Number(XDocument sheet, string address)
    {
        var cell = Cell(sheet, address); Check(cell.Attribute("t") == null || (string)cell.Attribute("t") == "n", "Expected numeric cell " + address);
        return double.Parse(cell.Element(S + "v").Value, CultureInfo.InvariantCulture);
    }
    private static void Blank(XDocument sheet, string address)
    { Check(Cell(sheet, address).Element(S + "v") == null && !Cell(sheet, address).Descendants(S + "t").Any(), "Expected blank cell " + address); }
    private static XElement InfoValue(XDocument sheet, string key)
    { return sheet.Descendants(S + "row").Single(row => string.Concat(row.Elements(S + "c").First().Descendants(S + "t").Select(t => t.Value)) == key).Elements(S + "c").Last(); }
    private static string InfoText(XDocument sheet, string key)
    { return string.Concat(InfoValue(sheet, key).Descendants(S + "t").Select(t => t.Value)); }
    private static double InfoNumber(XDocument sheet, string key)
    { return double.Parse(InfoValue(sheet, key).Element(S + "v").Value, CultureInfo.InvariantCulture); }
    private static void Check(bool condition, string message)
    { if (!condition) throw new InvalidOperationException(message); }
    private static void Equal<T>(T expected, T actual, string message)
    { Check(EqualityComparer<T>.Default.Equals(expected, actual), message + "; expected " + expected + ", got " + actual); }
    private static void Near(double expected, double actual)
    { Check(Math.Abs(expected - actual) < 1e-9, "Expected " + expected + ", got " + actual); }
    private static void Throws<T>(Action action) where T : Exception
    {
        try { action(); } catch (T) { return; }
        throw new InvalidOperationException("Expected " + typeof(T).Name + ".");
    }
}
