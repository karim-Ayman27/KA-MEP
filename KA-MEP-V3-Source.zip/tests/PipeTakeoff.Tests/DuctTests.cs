using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Xml.Linq;
using PipeTakeoff.Core;

internal static class DuctTests
{
    private static readonly XNamespace S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static string folder;

    internal static void Register(Action<string, Action> test, string testFolder)
    {
        folder = testFolder;
        test("Duct canonical dimensions and shape prevent formatted-size merging", CanonicalSections);
        test("Duct system, family, and type grouping are optional independent dimensions", OptionalGrouping);
        test("Duct fitting kinds and rounded angles including null remain distinct", FittingGrouping);
        test("Duct fitting connector multiplicity and reducer sections remain distinct", ConnectorSections);
        test("Duct straight lengths exclude fittings and preserve precision", StraightLengths);
        test("Duct area coverage distinguishes missing measurements from actual zero", AreaCoverage);
        test("Duct invalid measurements and quantity overflow are rejected", InvalidMeasurements);
        test("Duct text and numeric filters honor AND/OR and missing areas", Filters);
        test("Duct workbook parts, numeric totals, fitting blanks, and coverage round-trip", Workbook);
        test("Duct all-missing area cells remain blank and coverage is explicit", AllMissingWorkbook);
        test("Duct empty workbook contains zero totals", EmptyWorkbook);
        test("Duct workbook text is XML-safe literal text and preserves Arabic", SafeText);
        test("Duct workbook replacement is atomic on success and numeric failure", AtomicWorkbook);
        test("Duct selected numeric columns retain quantity precision and all optional groups", GroupedWorkbook);
    }

    private static TakeoffOptions Options()
    { return new TakeoffOptions { Columns = DuctStandardFields.Create(), GroupBySystem = false }; }
    private static FieldDefinition Field(string key)
    { return DuctStandardFields.Create().Single(field => field.Key == key); }
    private static PipeRecord Duct(int id, string shape = "Rectangular", string section = "Rectangular:500x300", double length = 2.5, double? area = 4, string system = "Supply Air")
    {
        var record = new PipeRecord();
        record.Values["ElementId"] = id.ToString(CultureInfo.InvariantCulture);
        record.Values["Category"] = "Duct"; record.Values["Shape"] = shape;
        record.Values["SectionKey"] = section; record.Values["SectionLabel"] = section;
        record.Values["Size"] = "project display"; record.Values["Length"] = length;
        record.Values["Area"] = area; record.Values["AreaSource"] = area.HasValue ? "Revit surface area (RBS_CURVE_SURFACE_AREA)" : "Not available";
        record.Values["Family"] = "Ducts"; record.Values["Type"] = "Galvanized";
        record.Values["SystemName"] = system; record.Values["SystemType"] = "Supply Air";
        record.Values["Level"] = "Level 01"; record.Values["Width"] = 500.0; record.Values["Height"] = 300.0;
        return record;
    }
    private static PipeRecord Fitting(int id, string kind = "Elbow", double? angle = 90, double? area = null)
    {
        PipeRecord record = Duct(id, length: 0, area: area);
        record.Values["Category"] = "Duct Fitting"; record.Values.Remove("Length");
        record.Values["FittingKind"] = kind; record.Values["Angle"] = angle;
        record.Values["Family"] = "Rectangular " + kind; record.Values["Type"] = "Standard";
        record.Values["AreaSource"] = area.HasValue ? "Revit surface-area parameter" : "Unavailable — no reliable surface area";
        return record;
    }

    private static void CanonicalSections()
    {
        var records = new[] { Duct(1), Duct(2), Duct(3, "Oval"), Duct(4, section: "Rectangular:500.001x300") };
        records[1].Values["Size"] = "1′-7 11/16″ × 11 13/16″";
        var rows = DuctTakeoffEngine.Summarize(records, Options());
        Equal(3, rows.Count, "Canonical keys, not display text, identify sections");
        Equal(2, rows.Single(row => row.Shape == "Rectangular" && row.Count == 2).Count, "Identical sections combine across display formatting");
        Equal(1, rows.Count(row => row.Shape == "Oval"), "Oval and rectangular remain distinct");
    }
    private static void OptionalGrouping()
    {
        var records = new[] { Duct(1), Duct(2, system: "Return Air"), Duct(3), Duct(4) };
        records[2].Values["Family"] = "Alternative Ducts";
        records[3].Values["Type"] = "Stainless";
        var options = Options(); Equal(1, DuctTakeoffEngine.Summarize(records, options).Count, "Section only");
        options.GroupBySystem = true; Equal(2, DuctTakeoffEngine.Summarize(records, options).Count, "Different systems separate");
        options.GroupByFamily = true; Equal(3, DuctTakeoffEngine.Summarize(records, options).Count, "Different families separate");
        options.GroupByType = true; Equal(4, DuctTakeoffEngine.Summarize(records, options).Count, "Different types separate");
    }
    private static void FittingGrouping()
    {
        var records = new[] { Fitting(1, angle: 90), Fitting(2, angle: 90.0000001), Fitting(3, angle: 45),
            Fitting(4, angle: null), Fitting(5, angle: 0), Fitting(6, kind: "Tee", angle: 90), Fitting(7, angle: 90.000001) };
        var rows = DuctTakeoffEngine.Summarize(records, Options());
        Equal(6, rows.Count, "Different fitting kind, missing angle, zero angle, and engineering precision");
        Equal(2, rows.Single(row => row.FittingKind == "Elbow" && row.AngleDegrees == 90).Count, "Conversion roundoff is grouped");
        Equal(1, rows.Count(row => row.AngleDegrees == null), "Missing angle group");
        Near(7, rows.Sum(row => row.Count));
    }
    private static void StraightLengths()
    {
        var fitting = Fitting(2); fitting.Values["Length"] = 999.0;
        var rows = DuctTakeoffEngine.Summarize(new[] { Duct(1, length: 1.23456789), fitting }, Options());
        Near(1.23456789, rows.Sum(row => row.TotalLengthMeters));
        Near(0, rows.Single(row => row.Category == "Duct Fitting").TotalLengthMeters);
    }
    private static void ConnectorSections()
    {
        var elbow = Fitting(1);
        elbow.Values["SectionKey"] = "Rectangular:500x300|Rectangular:500x300";
        var threePort = Fitting(2);
        threePort.Values["SectionKey"] = "Rectangular:500x300|Rectangular:500x300|Rectangular:500x300";
        var reducer = Fitting(3);
        reducer.Values["SectionKey"] = "Rectangular:400x300|Rectangular:500x300";
        var repeated = Fitting(4);
        repeated.Values["SectionKey"] = elbow.Get("SectionKey");
        repeated.Values["Size"] = "Localized display should not affect grouping";
        var rows = DuctTakeoffEngine.Summarize(new[] { elbow, threePort, reducer, repeated }, Options());
        Equal(3, rows.Count, "Connector count and every port size are part of the section identity");
        Equal(2, rows.Single(row => row.Count == 2).Count, "Identical canonical port sets combine");
    }
    private static void AreaCoverage()
    {
        var records = new[] { Duct(1, area: null), Duct(2, area: 0), Duct(3, area: 2.3456789), Fitting(4) };
        var rows = DuctTakeoffEngine.Summarize(records, Options());
        var duct = rows.Single(row => row.Category == "Duct");
        Equal(3, duct.Count, "Count includes elements with missing areas");
        Equal(1, duct.MissingAreaCount, "Provided zero is known");
        Near(2.3456789, duct.TotalAreaSquareMeters);
        Equal(2, rows.Sum(row => row.MissingAreaCount), "Fitting coverage tracked");
    }
    private static void InvalidMeasurements()
    {
        foreach (object value in new object[] { null, -1.0, double.NaN, double.PositiveInfinity, "bad" })
        {
            var record = Duct(1); record.Values["Length"] = value;
            Throws<ArgumentException>(() => DuctTakeoffEngine.Summarize(new[] { record }, Options()));
        }
        foreach (object value in new object[] { -1.0, double.NaN, double.NegativeInfinity, "bad" })
        {
            var record = Duct(1); record.Values["Area"] = value;
            Throws<ArgumentException>(() => DuctTakeoffEngine.Summarize(new[] { record }, Options()));
        }
        var missing = Duct(1); missing.Values.Remove("SectionKey");
        Throws<ArgumentException>(() => DuctTakeoffEngine.Summarize(new[] { missing }, Options()));
        var badCategory = Duct(1); badCategory.Values["Category"] = "Pipe";
        Throws<ArgumentException>(() => DuctTakeoffEngine.Summarize(new[] { badCategory }, Options()));
        Throws<ArgumentException>(() => DuctTakeoffEngine.Summarize(new[] { Duct(1, length: double.MaxValue), Duct(2, length: double.MaxValue) }, Options()));
        Throws<ArgumentException>(() => DuctTakeoffEngine.Summarize(new[] { Duct(1, area: double.MaxValue), Duct(2, area: double.MaxValue) }, Options()));
        // Even individually finite group totals must not overflow the complete workbook totals.
        Throws<ArgumentException>(() => DuctXlsxExporter.Export(Path.Combine(folder, "duct-overflow.xlsx"),
            new[] { Duct(1, area: double.MaxValue), Duct(2, section: "Other", area: double.MaxValue) }, Options(), null));
    }
    private static void Filters()
    {
        var records = new[] { Duct(1, area: null), Duct(2, area: 0), Duct(3, area: 8, system: "Return Air") };
        var options = Options();
        options.Filters.Add(new FilterRule { Field = Field("SystemName"), Operator = FilterOperator.Contains, Value = "supply" });
        options.Filters.Add(new FilterRule { Field = Field("Area"), Operator = FilterOperator.GreaterThan, Value = "1" });
        Equal(0, DuctTakeoffEngine.Filter(records, options).Count, "AND");
        options.Match = FilterMatch.Any;
        Equal(3, DuctTakeoffEngine.Filter(records, options).Count, "OR");
        options.Filters = new List<FilterRule> { new FilterRule { Field = Field("Area"), Operator = FilterOperator.IsEmpty } };
        Equal("1", DuctTakeoffEngine.Filter(records, options).Single().Get("ElementId"), "Unknown area selectable for audit");
    }
    private static List<PipeRecord> WorkbookRecords()
    {
        return new List<PipeRecord> { Duct(1), Duct(2, length: 3.25, area: 5.2), Fitting(3, area: 0.3), Fitting(4, kind: "Tee", angle: null) };
    }
    private static void Workbook()
    {
        string path = Path.Combine(folder, "duct.xlsx"); var options = Options();
        options.Columns = new List<FieldDefinition> { Field("ElementId"), Field("Category"), Field("Length"), Field("Area"), Field("AreaSource") };
        var records = WorkbookRecords(); records[2].Values["Length"] = 999;
        DuctXlsxExporter.Export(path, records, options, new ExportMetadata { Project = "حصر الداكت", Scope = "Project", RevitVersion = "2025" });
        using (ZipArchive zip = ZipFile.OpenRead(path))
        {
            Equal(8, zip.Entries.Count, "Native workbook parts");
            foreach (ZipArchiveEntry entry in zip.Entries) using (Stream stream = entry.Open()) XDocument.Load(stream);
            Equal("Detail,Summary,Info", string.Join(",", Read(zip, "xl/workbook.xml").Descendants(S + "sheet").Select(e => (string)e.Attribute("name"))), "Sheet names");
            foreach (XElement relation in Read(zip, "xl/_rels/workbook.xml.rels").Root.Elements()) Check(zip.GetEntry("xl/" + (string)relation.Attribute("Target")) != null, "Relationship target missing");
            var detail = Read(zip, "xl/worksheets/sheet1.xml");
            Equal("A1:E6", (string)detail.Root.Element(S + "dimension").Attribute("ref"), "Detail range");
            Equal("A1:E5", (string)detail.Root.Element(S + "autoFilter").Attribute("ref"), "Totals excluded from filter");
            Near(5.75, Number(detail, "C6")); Near(9.5, Number(detail, "D6"));
            Blank(detail, "C4"); Blank(detail, "C5"); Blank(detail, "D5");
            Check(Text(detail, "E6").Contains("INCOMPLETE"), "Detail coverage status");
            var summary = Read(zip, "xl/worksheets/sheet2.xml");
            Near(2, Number(summary, "F2")); Near(5.75, Number(summary, "G2")); Near(9.2, Number(summary, "H2"));
            Blank(summary, "G3"); Blank(summary, "H4"); Near(1, Number(summary, "I4"));
            Near(4, Number(summary, "F5")); Near(5.75, Number(summary, "G5")); Near(9.5, Number(summary, "H5")); Near(1, Number(summary, "I5"));
            Check(Text(summary, "A5").Contains("INCOMPLETE"), "Summary incomplete total label");
            var info = Read(zip, "xl/worksheets/sheet3.xml");
            Equal("حصر الداكت", InfoText(info, "Project"), "Arabic metadata");
            Near(1, InfoNumber(info, "Elements with missing area"));
            Equal("01032638143", InfoText(info, "Tel"), "Creator telephone remains text with leading zero");
        }
    }
    private static void AllMissingWorkbook()
    {
        string path = Path.Combine(folder, "duct-missing.xlsx");
        DuctXlsxExporter.Export(path, new[] { Duct(1, area: null), Fitting(2) }, Options(), null);
        using (ZipArchive zip = ZipFile.OpenRead(path))
        {
            var summary = Read(zip, "xl/worksheets/sheet2.xml");
            Blank(summary, "H2"); Blank(summary, "H3"); Blank(summary, "H4"); Near(2, Number(summary, "I4"));
            var info = Read(zip, "xl/worksheets/sheet3.xml");
            Check(InfoText(info, "Area coverage").Contains("INCOMPLETE"), "Missing coverage explicit");
            XElement totalArea = InfoValue(info, "Sum of known areas (m²)");
            Check(totalArea.Element(S + "v") == null && !totalArea.Descendants(S + "t").Any(), "Unknown Info total stays blank rather than zero");
            Check(InfoText(info, "Area").Contains("No geometric estimates"), "Authoritative Revit area policy is explicit");
        }
        // Actual zero areas stay numeric, including a total of zero.
        DuctXlsxExporter.Export(path, new[] { Duct(1, area: 0) }, Options(), null);
        using (ZipArchive zip = ZipFile.OpenRead(path))
        { var summary = Read(zip, "xl/worksheets/sheet2.xml"); Near(0, Number(summary, "H2")); Near(0, Number(summary, "H3")); Near(0, Number(summary, "I3")); }
    }
    private static void EmptyWorkbook()
    {
        string path = Path.Combine(folder, "duct-empty.xlsx"); DuctXlsxExporter.Export(path, new PipeRecord[0], Options(), null);
        using (ZipArchive zip = ZipFile.OpenRead(path))
        {
            var summary = Read(zip, "xl/worksheets/sheet2.xml");
            foreach (string column in new[] { "F", "G", "H", "I" }) Near(0, Number(summary, column + "2"));
            Equal("A1:I1", (string)summary.Root.Element(S + "autoFilter").Attribute("ref"), "Empty filter range");
        }
    }
    private static void SafeText()
    {
        string path = Path.Combine(folder, "duct-text.xlsx"); var record = Duct(1);
        record.Values["Comments"] = "=HYPERLINK(\"https://example.test\")\u0001 مرحبا 😀 _x0041_";
        var options = Options(); options.Columns = new List<FieldDefinition> { Field("Comments") };
        DuctXlsxExporter.Export(path, new[] { record }, options, null);
        using (ZipArchive zip = ZipFile.OpenRead(path))
        {
            var detail = Read(zip, "xl/worksheets/sheet1.xml");
            Equal("inlineStr", (string)Cell(detail, "A2").Attribute("t"), "Formula-like text");
            Equal("=HYPERLINK(\"https://example.test\")\uFFFD مرحبا 😀 _x005F_x0041_", Text(detail, "A2"), "Sanitized and escaped text");
            Equal(0, detail.Descendants(S + "f").Count(), "No formulas from model content");
        }
    }
    private static void AtomicWorkbook()
    {
        string path = Path.Combine(folder, "duct-atomic.xlsx"); File.WriteAllText(path, "Original workbook content");
        var records = WorkbookRecords(); records[0].Values["Custom"] = "Bad numeric value";
        var options = Options(); options.Columns.Add(new FieldDefinition { Key = "Custom", Header = "Custom numeric", IsNumeric = true });
        Throws<ArgumentException>(() => DuctXlsxExporter.Export(path, records, options, null));
        Equal("Original workbook content", File.ReadAllText(path), "Existing workbook survives partially written temporary output");
        Equal(0, Directory.GetFiles(folder, "*.tmp").Length, "Failed temporary workbook removed");
        DuctXlsxExporter.Export(path, records, Options(), null);
        using (ZipArchive zip = ZipFile.OpenRead(path)) Check(zip.GetEntry("xl/workbook.xml") != null, "Successful overwrite");
    }

    private static void GroupedWorkbook()
    {
        string path = Path.Combine(folder, "duct-grouped-precision.xlsx");
        var options = Options();
        options.Columns = new List<FieldDefinition> { Field("Length"), Field("Area"), Field("Diameter") };
        options.GroupBySystem = options.GroupByFamily = options.GroupByType = true;
        var record = Duct(1, "Round", "Round:250.123456", 1.234567891234, 2.345678912345);
        record.Values["Diameter"] = 250.123456;
        var fitting = Fitting(2, area: null);
        DuctXlsxExporter.Export(path, new[] { record, fitting }, options, null);
        using (ZipArchive zip = ZipFile.OpenRead(path))
        {
            var detail = Read(zip, "xl/worksheets/sheet1.xml");
            Near(1.234567891234, Number(detail, "A2")); Near(2.345678912345, Number(detail, "B2"));
            Near(250.123456, Number(detail, "C2")); Blank(detail, "A3"); Blank(detail, "B3");
            Near(1.234567891234, Number(detail, "A4")); Near(2.345678912345, Number(detail, "B4"));
            var summary = Read(zip, "xl/worksheets/sheet2.xml");
            Equal("A1:L4", (string)summary.Root.Element(S + "dimension").Attribute("ref"), "All optional group columns");
            Equal("Supply Air", Text(summary, "F2"), "System column"); Equal("Ducts", Text(summary, "G2"), "Family column"); Equal("Galvanized", Text(summary, "H2"), "Type column");
            Near(1, Number(summary, "I2")); Near(1.234567891234, Number(summary, "J2")); Near(2.345678912345, Number(summary, "K2"));
            Near(2, Number(summary, "I4")); Near(1, Number(summary, "L4"));
        }
    }

    internal static void ExportExample(string path)
    {
        path = Path.GetFullPath(path); Directory.CreateDirectory(Path.GetDirectoryName(path));
        var records = WorkbookRecords();
        var round = Duct(201, "Round", "Round:250", 8, 6.283185307179586, "Exhaust Air");
        round.Values["SectionLabel"] = "Ø250 mm"; round.Values["Size"] = "Ø250"; round.Values["Diameter"] = 250.0;
        round.Values.Remove("Width"); round.Values.Remove("Height");
        var oval = Duct(301, "Oval", "Oval:600x300", 4, 6.169911184307752, "Supply Air");
        oval.Values["SectionLabel"] = "600 × 300 mm (flat oval)"; oval.Values["Size"] = "600 × 300"; oval.Values["Width"] = 600.0;
        records.Add(round); records.Add(oval);
        foreach (PipeRecord record in records)
        {
            record.Values["Comments"] = "ILLUSTRATIVE SAMPLE / بيانات تجريبية — not a Revit model";
            if (record.Get("Area") != null) record.Values["AreaSource"] = "SIMULATED Revit surface-area value — illustrative only";
        }
        var options = Options(); options.GroupBySystem = true; options.GroupByFamily = true; options.GroupByType = true;
        DuctXlsxExporter.Export(path, records, options, new ExportMetadata
        {
            Project = "KA MEP — ILLUSTRATIVE SAMPLE — simulated duct data, not a Revit model",
            RevitVersion = "2024 / 2025 (sample)", Scope = "Demonstration records only",
            ExportedAt = new DateTime(2026, 10, 12, 12, 0, 0)
        });
        Console.WriteLine("Duct example workbook: " + path);
    }

    private static XDocument Read(ZipArchive zip, string name)
    { using (Stream stream = zip.GetEntry(name).Open()) return XDocument.Load(stream); }
    private static XElement Cell(XDocument sheet, string address)
    { return sheet.Descendants(S + "c").Single(cell => (string)cell.Attribute("r") == address); }
    private static string Text(XDocument sheet, string address)
    { return string.Concat(Cell(sheet, address).Descendants(S + "t").Select(text => text.Value)); }
    private static double Number(XDocument sheet, string address)
    {
        var cell = Cell(sheet, address); Check(cell.Attribute("t") == null || (string)cell.Attribute("t") == "n", "Expected numeric cell " + address);
        return double.Parse(cell.Element(S + "v").Value, CultureInfo.InvariantCulture);
    }
    private static void Blank(XDocument sheet, string address)
    { Check(Cell(sheet, address).Element(S + "v") == null && !Cell(sheet, address).Descendants(S + "t").Any(), "Expected blank cell " + address); }
    private static XElement InfoValue(XDocument sheet, string key)
    {
        return sheet.Descendants(S + "row").Single(row => string.Concat(row.Elements(S + "c").First().Descendants(S + "t").Select(t => t.Value)) == key).Elements(S + "c").Last();
    }
    private static string InfoText(XDocument sheet, string key)
    { return string.Concat(InfoValue(sheet, key).Descendants(S + "t").Select(t => t.Value)); }
    private static double InfoNumber(XDocument sheet, string key)
    { return double.Parse(InfoValue(sheet, key).Element(S + "v").Value, CultureInfo.InvariantCulture); }
    private static void Check(bool condition, string message)
    { if (!condition) throw new InvalidOperationException(message); }
    private static void Equal<T>(T expected, T actual, string message)
    { Check(EqualityComparer<T>.Default.Equals(expected, actual), message + "; expected " + expected + ", got " + actual); }
    private static void Near(double expected, double actual)
    { Check(Math.Abs(expected - actual) < 1e-9, "Expected " + expected + ", got " + actual); }
    private static void Throws<T>(Action action) where T : Exception
    {
        try { action(); }
        catch (T) { return; }
        throw new InvalidOperationException("Expected " + typeof(T).Name + ".");
    }
}
