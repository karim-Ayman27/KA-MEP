using System;
using System.Collections.Generic;
using System.Linq;
using PipeTakeoff.Core;

internal static class SheetNamingTests
{
    internal static void Register(Action<string, Action> test)
    {
        test("Sheet filename rule preserves parameter order, affixes, custom separator and Arabic", OrderedParts);
        test("Sheet filenames use NA for empty or unavailable parameters", MissingValues);
        test("Sheet filename collisions resolve case, sanitization, truncation and pre-existing suffixes", CollisionNames);
        test("Sheet filenames reject Windows reserved devices, separators, controls and trailing dots", WindowsNames);
        test("Sheet filename truncation and collisions preserve Unicode surrogate pairs", UnicodeBounds);
        test("Sheet filename generation is deterministic and does not change detached values", Deterministic);
    }

    private static SheetNameRecord Row(params string[] values)
    {
        var row = new SheetNameRecord { Fallback = "A101_42" };
        for (int i = 0; i < values.Length; i++) row.Values["p" + i] = values[i];
        return row;
    }
    private static List<string> Names(SheetNameOptions options, params SheetNameRecord[] rows)
    { return SheetFileNaming.BuildNames(rows, options); }
    private static SheetNameOptions Options(params string[] keys) { return new SheetNameOptions { ParameterKeys = keys }; }
    private static void Equal(string expected, string actual)
    { if (expected != actual) throw new InvalidOperationException("Expected [" + expected + "] but received [" + actual + "]"); }
    private static void Check(bool value, string message) { if (!value) throw new InvalidOperationException(message); }

    private static void OrderedParts()
    {
        var options = Options("p1", "p0"); options.Prefix = "KA"; options.Suffix = "Rev 02"; options.Separator = " - ";
        Equal("KA - مخطط التكييف - M-101 - Rev 02", Names(options, Row("M-101", "مخطط التكييف"))[0]);
        options.Separator = "";
        Equal("KAمخطط التكييفM-101Rev 02", Names(options, Row("M-101", "مخطط التكييف"))[0]);
    }
    private static void MissingValues()
    {
        Equal("A101_NA_NA", Names(Options("p0", "p1", "absent"), Row("A101", "  "))[0]);
        Equal("A101_42", Names(Options(), Row())[0]);
        Equal("NA", Names(Options("p0"), Row((string)null))[0]);
    }
    private static void CollisionNames()
    {
        var names = Names(Options("p0"), Row("A/B"), Row("A:B"), Row("a_b"), Row("A_B_2"), Row("A_B"));
        Equal("A_B", names[0]); Equal("A_B_2", names[1]); Equal("a_b_3", names[2]); Equal("A_B_2_2", names[3]); Equal("A_B_4", names[4]);
        var longNames = Names(Options("p0"), Row(new string('x', 101)), Row(new string('x', 102)));
        Check(longNames.All(x => x.Length <= 100), "Collision suffix must fit the filename limit");
        Check(longNames.Distinct(StringComparer.OrdinalIgnoreCase).Count() == 2, "Truncation collisions must remain unique");
    }
    private static void WindowsNames()
    {
        foreach (string name in new[] { "CON", "nul.txt", "COM1", "lpt9.xlsx", "COM¹", "conout$" })
            Check(SheetFileNaming.SafeStem(name).StartsWith("_", StringComparison.Ordinal), "Reserved device must be escaped: " + name);
        Equal("M__A__1", SheetFileNaming.SafeStem(" M:<A>?1... "));
        Equal("A_B", SheetFileNaming.SafeStem("A\nB"));
        Equal("Sheet", SheetFileNaming.SafeStem("...", "..."));
        Equal("_", SheetFileNaming.SafeStem("\ud800"));
    }
    private static void UnicodeBounds()
    {
        string input = new string('x', 99) + "😀";
        var names = Names(Options("p0"), Row(input), Row(input));
        foreach (var name in names)
        {
            Check(name.Length <= 100, "Filename exceeds bound");
            for (int i = 0; i < name.Length; i++)
                if (char.IsSurrogate(name[i])) { Check(char.IsHighSurrogate(name[i]) && i + 1 < name.Length && char.IsLowSurrogate(name[i + 1]), "Dangling surrogate"); i++; }
        }
        Equal("مخطط😀", SheetFileNaming.SafeStem("مخطط😀"));
    }
    private static void Deterministic()
    {
        var rows = new[] { Row("M101"), Row("M101") }; var options = Options("p0");
        Check(Names(options, rows).SequenceEqual(Names(options, rows)), "Same order and values must generate identical names");
        Equal("M101", rows[1].Values["p0"]);
    }
}
