using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Xml.Linq;
using PipeTakeoff.Core;

internal static class Program
{
    private static readonly XNamespace S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static readonly string TestFolder = Path.Combine(Path.GetTempPath(), "PipeTakeoff-Tests-" + Guid.NewGuid().ToString("N"));
    private static int failures;
    private static int testCount;

    private static int Main(string[] args)
    {
        Directory.CreateDirectory(TestFolder);
        try
        {
            Test("No rules exports every record for All and Any", NoFilters);
            Test("Text filters ignore case and combine using All or Any", TextFilters);
            Test("All numeric operators compare numbers rather than text", NumericFilters);
            Test("Current and invariant decimal input both work", CultureFilters);
            Test("Missing and blank parameters have explicit consistent semantics", MissingParameters);
            Test("Invalid numeric input and invalid operator combinations are rejected", InvalidFilters);
            Test("Diameter summary combines lengths and counts", DiameterSummary);
            Test("Optional grouping dimensions prevent cross-system/family/type merging", DimensionSummary);
            Test("Nominal diameters are grouped to six decimal millimeters", DiameterPrecision);
            Test("Invalid pipe measurements and aggregate overflow are rejected", InvalidMeasurements);
            Test("Workbook structure, relations, numeric values, totals and selected fields round-trip", WorkbookRoundTrip);
            Test("Empty exports remain well-formed with zero totals", EmptyWorkbook);
            Test("Model text cannot become formulas and invalid XML is sanitized", TextSafety);
            Test("Text truncation preserves Unicode surrogate pairs", TextBounds);
            Test("Successful export atomically replaces an existing workbook", AtomicOverwrite);
            Test("Failed export leaves existing workbook unchanged and removes temporary files", AtomicFailure);
            Test("Excel row and column limits fail before writing", WorkbookBounds);
            Test("Columns are validated and Excel addresses span beyond Z", ColumnValidation);
            DuctTests.Register(Test, TestFolder);
            SheetNamingTests.Register(Test);
            ElectricalTests.Register(Test, TestFolder);
            WorkbookPresentationTests.Register(Test, TestFolder);
            foreach (string arg in args)
            {
                if (arg.StartsWith("--electrical-example=", StringComparison.Ordinal))
                {
                    ElectricalTests.ExportExample(Path.GetFullPath(arg.Substring("--electrical-example=".Length)));
                    continue;
                }
                if (arg.StartsWith("--duct-example=", StringComparison.Ordinal))
                {
                    DuctTests.ExportExample(Path.GetFullPath(arg.Substring("--duct-example=".Length)));
                    continue;
                }
                if (!arg.StartsWith("--example=", StringComparison.Ordinal)) continue;
                string path = Path.GetFullPath(arg.Substring("--example=".Length));
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                var options = Options();
                options.GroupBySystem = true;
                options.Columns.Add(new FieldDefinition { Key = "SampleCode", Header = "Example custom parameter", IsNumeric = false });
                List<PipeRecord> records = ExampleRecords();
                XlsxExporter.Export(path, records, options, new ExportMetadata
                {
                    Project = "ILLUSTRATIVE SAMPLE — simulated pipe data, not a Revit model",
                    RevitVersion = "2024 / 2025 (sample)",
                    Scope = "Demonstration records only",
                    ExportedAt = new DateTime(2026, 10, 10, 12, 0, 0)
                });
                Console.WriteLine("Example workbook: " + path);
            }
        }
        finally { Directory.Delete(TestFolder, true); }
        Console.WriteLine(failures == 0 ? "All " + testCount + " tests passed." : failures + " test(s) failed.");
        return failures == 0 ? 0 : 1;
    }

    private static void Test(string name, Action action)
    {
        testCount++;
        try { action(); Console.WriteLine("PASS " + name); }
        catch (Exception ex) { failures++; Console.WriteLine("FAIL " + name + ": " + ex); }
    }
    private static void Check(bool condition, string message)
    { if (!condition) throw new InvalidOperationException(message); }
    private static void Equal<T>(T expected, T actual, string message)
    { Check(EqualityComparer<T>.Default.Equals(expected, actual), message + "; expected " + expected + ", got " + actual); }
    private static void Near(double expected, double actual)
    { Check(Math.Abs(expected - actual) < 0.000000001, "Expected " + expected + ", got " + actual); }
    private static void Throws<T>(Action action) where T : Exception
    {
        try { action(); }
        catch (T) { return; }
        throw new InvalidOperationException("Expected " + typeof(T).Name + ".");
    }
    private static TakeoffOptions Options()
    { return new TakeoffOptions { Columns = StandardFields.Create(), GroupBySystem = false }; }
    private static FieldDefinition Field(string key)
    { return StandardFields.Create().Single(f => f.Key == key); }
    private static FilterRule Rule(string key, FilterOperator op, string value)
    { return new FilterRule { Field = Field(key), Operator = op, Value = value }; }
    private static PipeRecord Pipe(int id, double diameter, double length, string system = "CHWS", string family = "Pipes", string type = "Steel")
    {
        var record = new PipeRecord();
        record.Values["ElementId"] = id.ToString(CultureInfo.InvariantCulture);
        record.Values["Diameter"] = diameter; record.Values["Length"] = length;
        record.Values["Family"] = family; record.Values["Type"] = type;
        record.Values["SystemName"] = system; record.Values["SystemType"] = "Hydronic Supply";
        record.Values["Size"] = diameter.ToString(CultureInfo.InvariantCulture) + " mm";
        record.Values["Level"] = "Level 01"; record.Values["Mark"] = "P-" + id;
        return record;
    }
    private static List<PipeRecord> Records()
    { return new List<PipeRecord> { Pipe(1, 25, 2.5), Pipe(2, 25, 3.75), Pipe(3, 50, 1.25, "CHWR", "Pipes", "Copper") }; }

    private static void NoFilters()
    {
        var options = Options();
        Equal(3, TakeoffEngine.Filter(Records(), options).Count, "All with no rules");
        options.Match = FilterMatch.Any;
        Equal(3, TakeoffEngine.Filter(Records(), options).Count, "Any with no rules");
        Equal(0, TakeoffEngine.Filter(new PipeRecord[0], options).Count, "Empty records");
    }
    private static void TextFilters()
    {
        var options = Options();
        options.Filters.Add(Rule("SystemName", FilterOperator.Equals, "chws"));
        options.Filters.Add(Rule("Type", FilterOperator.Contains, "COP"));
        Equal(0, TakeoffEngine.Filter(Records(), options).Count, "All rules");
        options.Match = FilterMatch.Any;
        Equal(3, TakeoffEngine.Filter(Records(), options).Count, "Any rule");
        options.Filters = new List<FilterRule> { Rule("Type", FilterOperator.DoesNotContain, "cop") };
        Equal(2, TakeoffEngine.Filter(Records(), options).Count, "Does not contain");
        options.Filters[0] = Rule("SystemName", FilterOperator.NotEquals, "CHWS");
        Equal("3", TakeoffEngine.Filter(Records(), options).Single().Get("ElementId"), "Not equal");
    }
    private static void NumericFilters()
    {
        var options = Options();
        FilterOperator[] operators = { FilterOperator.Equals, FilterOperator.NotEquals, FilterOperator.GreaterThan, FilterOperator.GreaterOrEqual, FilterOperator.LessThan, FilterOperator.LessOrEqual };
        int[] counts = { 1, 2, 1, 2, 1, 2 };
        for (int i = 0; i < operators.Length; i++)
        {
            options.Filters = new List<FilterRule> { Rule("Length", operators[i], "2.5") };
            Equal(counts[i], TakeoffEngine.Filter(Records(), options).Count, operators[i].ToString());
        }
        options.Filters = new List<FilterRule> { Rule("Diameter", FilterOperator.GreaterThan, "30") };
        Equal("3", TakeoffEngine.Filter(Records(), options).Single().Get("ElementId"), "Numeric diameter");
        var roundoff = new[] { Pipe(9, 49.99999999999999, 1) };
        foreach (FilterOperator op in new[] { FilterOperator.Equals, FilterOperator.GreaterOrEqual, FilterOperator.LessOrEqual })
        {
            options.Filters = new List<FilterRule> { Rule("Diameter", op, "50") };
            Equal(1, TakeoffEngine.Filter(roundoff, options).Count, "Unit conversion roundoff: " + op);
        }
        foreach (FilterOperator op in new[] { FilterOperator.NotEquals, FilterOperator.GreaterThan, FilterOperator.LessThan })
        {
            options.Filters = new List<FilterRule> { Rule("Diameter", op, "50") };
            Equal(0, TakeoffEngine.Filter(roundoff, options).Count, "Strict comparisons respect tolerance: " + op);
        }
    }
    private static void CultureFilters()
    {
        CultureInfo original = CultureInfo.CurrentCulture;
        try
        {
            CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("de-DE");
            var options = Options();
            options.Filters.Add(Rule("Length", FilterOperator.Equals, "1,25"));
            Equal(1, TakeoffEngine.Filter(Records(), options).Count, "Current decimal separator");
            options.Filters[0].Value = "1.25";
            Equal(1, TakeoffEngine.Filter(Records(), options).Count, "Invariant decimal separator");
            options.Filters[0].Value = "1,234.5";
            Throws<ArgumentException>(() => TakeoffEngine.ValidateFilters(options));
        }
        finally { CultureInfo.CurrentCulture = original; }
    }
    private static void MissingParameters()
    {
        var records = Records(); records[1].Values["Comments"] = "   "; records[2].Values["Comments"] = "Ready";
        var options = Options();
        options.Filters.Add(Rule("Comments", FilterOperator.IsEmpty, "ignored"));
        Equal(2, TakeoffEngine.Filter(records, options).Count, "Missing or whitespace is empty");
        options.Filters[0].Operator = FilterOperator.IsNotEmpty;
        Equal(1, TakeoffEngine.Filter(records, options).Count, "Nonempty");
        options.Filters[0].Operator = FilterOperator.NotEquals; options.Filters[0].Value = "other";
        Equal(1, TakeoffEngine.Filter(records, options).Count, "Missing does not match negative comparison");
        records[0].Values.Remove("Length");
        options.Filters[0] = Rule("Length", FilterOperator.NotEquals, "0");
        Equal(2, TakeoffEngine.Filter(records, options).Count, "Missing numeric does not match NotEquals");
    }
    private static void InvalidFilters()
    {
        var options = Options();
        foreach (string value in new[] { "abc", "", "NaN", "Infinity", "1e9999" })
        {
            options.Filters = new List<FilterRule> { Rule("Length", FilterOperator.Equals, value) };
            Throws<ArgumentException>(() => TakeoffEngine.ValidateFilters(options));
        }
        options.Filters[0] = Rule("Family", FilterOperator.LessThan, "Pipes");
        Throws<ArgumentException>(() => TakeoffEngine.ValidateFilters(options));
        options.Filters[0] = new FilterRule();
        Throws<ArgumentException>(() => TakeoffEngine.ValidateFilters(options));
        options.Filters[0] = Rule("Length", (FilterOperator)999, "1");
        Throws<ArgumentException>(() => TakeoffEngine.ValidateFilters(options));
    }
    private static void DiameterSummary()
    {
        var options = Options();
        List<SummaryRow> result = TakeoffEngine.Summarize(Records(), options);
        Equal(2, result.Count, "Diameter groups"); Equal(2, result[0].Count, "Pipe count"); Near(6.25, result[0].TotalLengthMeters);
        Near(7.5, result.Sum(r => r.TotalLengthMeters));
        options.Filters.Add(Rule("Length", FilterOperator.GreaterThan, "2"));
        result = TakeoffEngine.Summarize(TakeoffEngine.Filter(Records(), options), options);
        Equal(1, result.Count, "Filters apply before grouping"); Near(6.25, result[0].TotalLengthMeters);
    }
    private static void DimensionSummary()
    {
        var records = new[] { Pipe(1, 25, 1, "A", "Pipes", "Steel"), Pipe(2, 25, 2, "B", "Pipes", "Steel"), Pipe(3, 25, 3, "A", "Flex Pipes", "Steel"), Pipe(4, 25, 4, "A", "Pipes", "Copper") };
        var options = Options(); Equal(1, TakeoffEngine.Summarize(records, options).Count, "Diameter only");
        options.GroupBySystem = true; Equal(2, TakeoffEngine.Summarize(records, options).Count, "System grouping");
        options.GroupByFamily = true; Equal(3, TakeoffEngine.Summarize(records, options).Count, "Family grouping");
        options.GroupByType = true; Equal(4, TakeoffEngine.Summarize(records, options).Count, "Type grouping");
    }
    private static void DiameterPrecision()
    {
        var result = TakeoffEngine.Summarize(new[] { Pipe(1, 25, 1), Pipe(2, 25.0000001, 2), Pipe(3, 25.000001, 3) }, Options());
        Equal(2, result.Count, "Precision groups"); Equal(2, result[0].Count, "Near-identical diameters combine");
        Near(25.000001, result[1].DiameterMillimeters);
    }
    private static void InvalidMeasurements()
    {
        var invalid = Pipe(1, double.NaN, 1);
        Throws<ArgumentException>(() => TakeoffEngine.Summarize(new[] { invalid }, Options()));
        invalid = Pipe(1, 25, -1);
        Throws<ArgumentException>(() => TakeoffEngine.Summarize(new[] { invalid }, Options()));
        Throws<ArgumentException>(() => TakeoffEngine.Summarize(new[] { Pipe(1, 25, double.MaxValue), Pipe(2, 25, double.MaxValue) }, Options()));
    }

    private static void WorkbookRoundTrip()
    {
        string path = Path.Combine(TestFolder, "roundtrip.xlsx"); var options = Options();
        options.Columns = new List<FieldDefinition> { Field("ElementId"), Field("Family"), Field("Length"), Field("Diameter"), new FieldDefinition { Key = "Custom", Header = "Insulation code" } };
        var records = Records(); records[0].Values["Custom"] = "INS-19";
        XlsxExporter.Export(path, records, options, new ExportMetadata { Project = "حصر المواسير", RevitVersion = "2025", Scope = "Project" });
        using (ZipArchive zip = ZipFile.OpenRead(path))
        {
            Equal(8, zip.Entries.Count, "Minimal XLSX parts");
            foreach (ZipArchiveEntry entry in zip.Entries) using (Stream stream = entry.Open()) XDocument.Load(stream);
            XDocument workbook = Read(zip, "xl/workbook.xml");
            Equal("Detail,Summary,Info", string.Join(",", workbook.Descendants(S + "sheet").Select(e => (string)e.Attribute("name"))), "Sheet names");
            XDocument relations = Read(zip, "xl/_rels/workbook.xml.rels");
            foreach (XElement relation in relations.Root.Elements()) Check(zip.GetEntry("xl/" + (string)relation.Attribute("Target")) != null, "Missing relationship target");
            var detail = Read(zip, "xl/worksheets/sheet1.xml");
            Equal("A1:E5", (string)detail.Root.Element(S + "dimension").Attribute("ref"), "Detail dimensions");
            Equal("A1:E4", (string)detail.Root.Element(S + "autoFilter").Attribute("ref"), "Totals excluded from filter");
            Equal("frozen", (string)detail.Descendants(S + "pane").Single().Attribute("state"), "Frozen header");
            Near(2.5, Number(detail, "C2")); Near(25, Number(detail, "D2")); Near(7.5, Number(detail, "C5"));
            Equal("INS-19", CellText(detail, "E2"), "Custom parameter exported");
            Check(Cell(detail, "E3").Element(S + "v") == null, "Missing custom parameter stays blank");
            var summary = Read(zip, "xl/worksheets/sheet2.xml");
            Near(2, Number(summary, "B2")); Near(6.25, Number(summary, "C2")); Near(3, Number(summary, "B4")); Near(7.5, Number(summary, "C4"));
            var info = Read(zip, "xl/worksheets/sheet3.xml"); Equal("حصر المواسير", CellText(info, "B2"), "Arabic metadata roundtrip");
            Equal(0, detail.Descendants(S + "f").Count(), "No user data formulas");
            int styles = Read(zip, "xl/styles.xml").Root.Element(S + "cellXfs").Elements().Count();
            foreach (XElement cell in detail.Descendants(S + "c")) Check((int)cell.Attribute("s") < styles, "Undefined style");
        }
    }
    private static void EmptyWorkbook()
    {
        string path = Path.Combine(TestFolder, "empty.xlsx");
        XlsxExporter.Export(path, new List<PipeRecord>(), Options(), null);
        using (ZipArchive zip = ZipFile.OpenRead(path))
        {
            var detail = Read(zip, "xl/worksheets/sheet1.xml"); Near(0, Number(detail, "D2"));
            Equal("A1:K1", (string)detail.Root.Element(S + "autoFilter").Attribute("ref"), "Empty detail filter");
            var summary = Read(zip, "xl/worksheets/sheet2.xml"); Near(0, Number(summary, "B2")); Near(0, Number(summary, "C2"));
        }
    }
    private static void TextSafety()
    {
        var records = Records(); var options = Options(); options.Columns = new List<FieldDefinition> { Field("Comments") };
        records[0].Values["Comments"] = "=HYPERLINK(\"https://example.test\",\"Click\")";
        records[1].Values["Comments"] = "+1\t<&>\u0001مرحبا 😀\uD800";
        records[2].Values["Comments"] = "literal _x0041_ and _x005F_";
        string path = Path.Combine(TestFolder, "text.xlsx"); XlsxExporter.Export(path, records, options, null);
        using (ZipArchive zip = ZipFile.OpenRead(path))
        {
            var sheet = Read(zip, "xl/worksheets/sheet1.xml");
            Equal("inlineStr", (string)Cell(sheet, "A2").Attribute("t"), "Formula-like text type");
            Equal((string)records[0].Get("Comments"), CellText(sheet, "A2"), "Formula-like text preserved");
            Equal("+1\t<&>\uFFFDمرحبا 😀\uFFFD", CellText(sheet, "A3"), "Invalid XML sanitized and Unicode preserved");
            Equal("literal _x005F_x0041_ and _x005F_x005F_", CellText(sheet, "A4"), "SpreadsheetML literal escape convention");
            Equal(0, sheet.Descendants(S + "f").Count(), "No formulas"); Equal(0, sheet.Descendants(S + "hyperlink").Count(), "No activated hyperlinks");
        }
    }
    private static void TextBounds()
    {
        var record = Pipe(1, 25, 1); record.Values["Comments"] = new string('a', 32766) + "😀tail";
        var options = Options(); options.Columns = new List<FieldDefinition> { Field("Comments") };
        string path = Path.Combine(TestFolder, "long.xlsx"); XlsxExporter.Export(path, new[] { record }, options, null);
        using (ZipArchive zip = ZipFile.OpenRead(path)) Equal(32766, CellText(Read(zip, "xl/worksheets/sheet1.xml"), "A2").Length, "No split surrogate at Excel text bound");
    }
    private static void AtomicOverwrite()
    {
        string path = Path.Combine(TestFolder, "overwrite.xlsx"); File.WriteAllText(path, "previous file");
        XlsxExporter.Export(path, Records(), Options(), null);
        using (ZipArchive zip = ZipFile.OpenRead(path)) Check(zip.GetEntry("xl/workbook.xml") != null, "Existing workbook replaced");
        Equal(0, Directory.GetFiles(TestFolder, "*.tmp").Length, "No temporary files");
    }
    private static void AtomicFailure()
    {
        string path = Path.Combine(TestFolder, "protected.xlsx"); File.WriteAllText(path, "original content must survive");
        var records = Records(); records[0].Values["Bad"] = "not a number";
        var options = Options(); options.Columns.Add(new FieldDefinition { Key = "Bad", Header = "Bad numeric parameter", IsNumeric = true });
        Throws<ArgumentException>(() => XlsxExporter.Export(path, records, options, null));
        Equal("original content must survive", File.ReadAllText(path), "Original untouched after partial temporary export");
        Equal(0, Directory.GetFiles(TestFolder, "*.tmp").Length, "Partial temporary workbook removed");
    }
    private static void WorkbookBounds()
    {
        string path = Path.Combine(TestFolder, "bound.xlsx");
        Throws<ArgumentException>(() => XlsxExporter.Export(path, new CountOnlyList(1048575), Options(), null));
        var options = Options(); options.Columns = Enumerable.Range(0, 16385).Select(i => new FieldDefinition { Key = "c" + i, Header = "Column" }).ToList();
        Throws<ArgumentException>(() => XlsxExporter.Export(path, new PipeRecord[0], options, null));
        Check(!File.Exists(path), "Bounds checked before file creation");
    }
    private static void ColumnValidation()
    {
        string path = Path.Combine(TestFolder, "columns.xlsx"); var options = Options();
        options.Columns.Clear(); Throws<ArgumentException>(() => XlsxExporter.Export(path, Records(), options, null));
        options.Columns = new List<FieldDefinition> { Field("Family"), Field("Family") };
        Throws<ArgumentException>(() => XlsxExporter.Export(path, Records(), options, null));
        options.Columns = Enumerable.Range(1, 28).Select(i => new FieldDefinition { Key = "c" + i, Header = "Column " + i }).ToList();
        XlsxExporter.Export(path, Records(), options, null);
        using (ZipArchive zip = ZipFile.OpenRead(path)) Equal("Column 28", CellText(Read(zip, "xl/worksheets/sheet1.xml"), "AB1"), "Column letters beyond Z");
    }

    private static XDocument Read(ZipArchive zip, string name)
    { using (Stream stream = zip.GetEntry(name).Open()) return XDocument.Load(stream); }
    private static XElement Cell(XDocument sheet, string address)
    { return sheet.Descendants(S + "c").Single(c => (string)c.Attribute("r") == address); }
    private static string CellText(XDocument sheet, string address)
    { return string.Concat(Cell(sheet, address).Descendants(S + "t").Select(t => t.Value)); }
    private static double Number(XDocument sheet, string address)
    {
        XElement cell = Cell(sheet, address); Check(cell.Attribute("t") == null || (string)cell.Attribute("t") == "n", "Expected numeric cell " + address);
        return double.Parse(cell.Element(S + "v").Value, CultureInfo.InvariantCulture);
    }
    private static List<PipeRecord> ExampleRecords()
    {
        var records = new List<PipeRecord>
        {
            Pipe(10101, 25, 4.250, "Domestic Cold Water", "Pipes", "Copper - Type L"),
            Pipe(10102, 25, 6.125, "Domestic Cold Water", "Pipes", "Copper - Type L"),
            Pipe(10103, 32, 3.600, "Domestic Cold Water", "Pipes", "Copper - Type L"),
            Pipe(10104, 25, 5.100, "Domestic Hot Water", "Pipes", "Copper - Type L"),
            Pipe(10105, 50, 8.750, "CHWS", "Pipes", "Steel - Schedule 40"),
            Pipe(10106, 50, 2.500, "CHWS", "Pipes", "Steel - Schedule 40"),
            Pipe(10107, 50, 10.250, "CHWR", "Pipes", "Steel - Schedule 40"),
            Pipe(10108, 100, 7.800, "Sanitary", "Pipes", "PVC - Schedule 40")
        };
        foreach (PipeRecord record in records)
        {
            record.Values["SystemType"] = record.Get("SystemName");
            record.Values["Comments"] = "Illustrative sample / بيانات توضيحية";
            record.Values["SampleCode"] = "DEMO-" + record.Get("ElementId");
        }
        return records;
    }
    private sealed class CountOnlyList : IList<PipeRecord>
    {
        internal CountOnlyList(int count) { Count = count; }
        public int Count { get; private set; }
        public bool IsReadOnly { get { return true; } }
        public PipeRecord this[int index] { get { throw new InvalidOperationException("Must reject size before enumeration."); } set { throw new NotSupportedException(); } }
        public IEnumerator<PipeRecord> GetEnumerator() { throw new InvalidOperationException("Must reject size before enumeration."); }
        IEnumerator IEnumerable.GetEnumerator() { return GetEnumerator(); }
        public void Add(PipeRecord item) { throw new NotSupportedException(); }
        public void Clear() { throw new NotSupportedException(); }
        public bool Contains(PipeRecord item) { throw new NotSupportedException(); }
        public void CopyTo(PipeRecord[] array, int arrayIndex) { throw new NotSupportedException(); }
        public int IndexOf(PipeRecord item) { throw new NotSupportedException(); }
        public void Insert(int index, PipeRecord item) { throw new NotSupportedException(); }
        public bool Remove(PipeRecord item) { throw new NotSupportedException(); }
        public void RemoveAt(int index) { throw new NotSupportedException(); }
    }
}
