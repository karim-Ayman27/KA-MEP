using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Xml.Linq;
using PipeTakeoff.Core;

internal static class WorkbookPresentationTests
{
    private static readonly XNamespace S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static string folder;

    internal static void Register(Action<string, Action> test, string testFolder)
    {
        folder = testFolder;
        test("All quantity workbooks have readable bands, wrapped headers and distinct numeric totals", Styles);
        test("All quantity workbooks freeze headers, open Summary and define complete printable ranges", PrintAndNavigation);
        test("All report Info sheets wrap notes and preserve creator contacts as literal text", InfoPresentation);
    }

    private static List<string> Reports()
    {
        var paths = new List<string>();
        for (int kind = 0; kind < 3; kind++)
        {
            string path = Path.Combine(folder, "presentation-" + kind + ".xlsx");
            var records = new List<PipeRecord>();
            for (int i = 0; i < 2; i++)
            {
                var row = new PipeRecord();
                row.Values["ElementId"] = (i + 1).ToString(CultureInfo.InvariantCulture);
                row.Values["Family"] = "Family " + i;
                row.Values["Length"] = 2.123456789 + i;
                row.Values["Diameter"] = 25.0 + i;
                row.Values["Category"] = kind == 1 ? "Duct" : "Conduit";
                row.Values["SectionKey"] = "Round:" + (25 + i);
                row.Values["SectionLabel"] = "Diameter " + (25 + i);
                row.Values["Shape"] = "Round";
                row.Values["Area"] = 1.5 + i;
                records.Add(row);
            }
            var options = new TakeoffOptions
            {
                Columns = StandardFields.Create().Where(field => new[] { "Family", "Length", "Diameter" }.Contains(field.Key)).ToList(),
                GroupBySystem = true, GroupByFamily = true, GroupByType = true
            };
            var metadata = new ExportMetadata { Project = "مشروع تجريبي — Sample Project", Scope = "Entire project" };
            if (kind == 0) XlsxExporter.Export(path, records, options, metadata);
            else if (kind == 1) DuctXlsxExporter.Export(path, records, options, metadata);
            else ElectricalXlsxExporter.Export(path, records, options, metadata);
            paths.Add(path);
        }
        return paths;
    }

    private static void Styles()
    {
        foreach (string path in Reports()) using (ZipArchive zip = ZipFile.OpenRead(path))
        {
            XDocument sheet = Read(zip, "xl/worksheets/sheet1.xml");
            XDocument styles = Read(zip, "xl/styles.xml");
            var formats = styles.Root.Element(S + "cellXfs").Elements().ToArray();
            var fonts = styles.Root.Element(S + "fonts").Elements().ToArray();
            Func<string, XElement> format = address => formats[(int)Cell(sheet, address).Attribute("s")];
            Check((int)format("A2").Attribute("fillId") != (int)format("A3").Attribute("fillId"), "Adjacent body rows must be visually separated");
            Check((int)format("A2").Attribute("fillId") == (int)format("B2").Attribute("fillId"), "Text and number bands must stay aligned");
            XElement header = format("A1");
            Check(fonts[(int)header.Attribute("fontId")].Element(S + "b") != null, "Header must be bold");
            Check((string)header.Element(S + "alignment").Attribute("wrapText") == "1", "Long column titles must wrap");
            Check((double)sheet.Descendants(S + "row").First().Attribute("ht") >= 30, "Header must have room for wrapped titles");
            Check((int)format("B2").Attribute("numFmtId") == (int)format("B3").Attribute("numFmtId"), "Banding cannot change numeric formats");
            Check((int)format("B2").Attribute("numFmtId") != (int)format("C2").Attribute("numFmtId"), "Lengths and dimensions use appropriate distinct precision formats");
            Check((int)format("B4").Attribute("fillId") != (int)format("B2").Attribute("fillId") &&
                (int)format("B4").Attribute("fillId") != (int)format("B3").Attribute("fillId"), "Totals require a distinct visual treatment");
            Check(Math.Abs(double.Parse(Cell(sheet, "B2").Element(S + "v").Value, CultureInfo.InvariantCulture) - 2.123456789) < 1e-12,
                "Display formatting must retain underlying measurement precision");
        }
    }

    private static void PrintAndNavigation()
    {
        foreach (string path in Reports()) using (ZipArchive zip = ZipFile.OpenRead(path))
        {
            XDocument book = Read(zip, "xl/workbook.xml");
            Check((string)book.Descendants(S + "workbookView").Single().Attribute("activeTab") == "1", "Summary should be the landing sheet");
            string[] names = { "Detail", "Summary", "Info" };
            for (int i = 0; i < names.Length; i++)
            {
                XDocument sheet = Read(zip, "xl/worksheets/sheet" + (i + 1) + ".xml");
                string lastCell = ((string)sheet.Root.Element(S + "dimension").Attribute("ref")).Split(':')[1];
                string lastColumn = new string(lastCell.TakeWhile(char.IsLetter).ToArray());
                int lastRow = int.Parse(new string(lastCell.SkipWhile(char.IsLetter).ToArray()), CultureInfo.InvariantCulture);
                var definitions = book.Descendants(S + "definedName").Where(item => (int)item.Attribute("localSheetId") == i).ToList();
                Check(definitions.Single(item => (string)item.Attribute("name") == "_xlnm.Print_Titles").Value == "'" + names[i] + "'!$1:$1", "Print headings must repeat on each page");
                Check(definitions.Single(item => (string)item.Attribute("name") == "_xlnm.Print_Area").Value == "'" + names[i] + "'!$A$1:$" + lastColumn + "$" + lastRow, "Print area must include the entire report and total");
                Check((string)sheet.Root.Element(S + "autoFilter").Attribute("ref") == "A1:" + lastColumn + (i == 2 ? lastRow : lastRow - 1), "Data filters must exclude static totals");
                XElement view = sheet.Descendants(S + "sheetView").Single();
                Check((string)view.Attribute("showGridLines") == "0", "Raw gridlines should be hidden");
                Check((string)view.Element(S + "pane").Attribute("xSplit") == "1" && (string)view.Element(S + "pane").Attribute("ySplit") == "1", "First row and column must stay visible while scrolling");
                XElement setup = sheet.Root.Element(S + "pageSetup");
                Check((string)setup.Attribute("orientation") == "landscape" && (string)setup.Attribute("fitToWidth") == "1" && (string)setup.Attribute("fitToHeight") == "0", "Print layout must fit width without forcing all rows onto one page");
                Check(sheet.Descendants(S + "oddHeader").Single().Value.Contains(ReportBranding.VersionLabel), "Printed pages must carry the correct brand and version");
                Check(sheet.Descendants(S + "oddFooter").Single().Value.Contains("&P of &N"), "Printed pages must have page numbering");
            }
        }
    }

    private static void InfoPresentation()
    {
        foreach (string path in Reports()) using (ZipArchive zip = ZipFile.OpenRead(path))
        {
            XDocument sheet = Read(zip, "xl/worksheets/sheet3.xml");
            var rows = sheet.Descendants(S + "row").Skip(1).ToList();
            XElement telephone = rows.Single(row => Text(row.Elements(S + "c").First()) == "Tel").Elements(S + "c").Last();
            Check(Text(telephone) == "01032638143" && telephone.Element(S + "v") == null, "Telephone must retain its leading zero as text");
            Check(rows.All(row => (double)row.Attribute("ht") >= 30), "Info values must have sufficient wrapped reading space");
            Check((double)sheet.Descendants(S + "col").Last().Attribute("width") > 90, "Notes column must fit longer project and quantity explanations");
            Check(rows.Any(row => Text(row.Elements(S + "c").Last()).Contains("مشروع تجريبي")), "Arabic project metadata must remain intact");
        }
    }

    private static XElement Cell(XDocument sheet, string address)
    { return sheet.Descendants(S + "c").Single(cell => (string)cell.Attribute("r") == address); }
    private static string Text(XElement cell) { return string.Concat(cell.Descendants(S + "t").Select(text => text.Value)); }
    private static XDocument Read(ZipArchive zip, string entry)
    { using (Stream stream = zip.GetEntry(entry).Open()) return XDocument.Load(stream); }
    private static void Check(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
}
