# Branding and installer layout regression

The standalone .NET Framework 4.8 harness links the actual HubForm, KaTheme,
SetupForm, InstallerEngine and shared logo resources. It never clicks an install
button or invokes installer operations and does not load Revit.

Six form layouts cover a client viewport of 1366×728 at 100% and 1280×680 at
explicitly scaled controls/fonts of 150% and 200%. Each of the three paired cases opens the hub and installer,
checks the embedded logos and window icons, checks logo aspect preservation and
visibility within ancestor bounds, and verifies the installer offers all six versions from Revit 2022.1+ through 2027 with visible, non-overlapping controls and Install/Close buttons.

Build with `dotnet build tests/BrandingLayout.Tests/BrandingLayout.Tests.csproj -c Release`.
Run from a Windows desktop session, or under Mono with Xvfb. For Mono, isolate
each paired case in a fresh process with `--case=1366x728_100`,
`--case=1280x680_150` or `--case=1280x680_200`.
`--screenshots=PATH` captures three reference images plus failures.

These are simulated control/font scaling checks. Linux Mono WinForms results do
not certify rendering in Windows, actual operating-system DPI changes, Revit
hosting or actual installer execution.

Validation on 2026-10-18: all three paired cases (six form layouts) passed after
the hub root row was constrained to available height and installer rows sized
to their content. Logs and three reviewed screenshots are under
`/workspace/.ka-mep-layout-runtime/branding-v1-fixed-cases/`.
Screenshot capture uses the visible Xvfb screen because Mono's recursive
`DrawToBitmap` failed on zero-size nested controls in the initial harness run.

Validation on 2026-10-22 (Build20261022-01): all three paired cases passed with the white transparent logo. The normal hub/installer and scaled installer screenshots were visually checked for a white monogram on the existing navy header without a white logo tile. Evidence is in `docs/validation-white-logo/ui/`. The ICO uses 32-bit DIB frames plus legacy AND masks for .NET Framework/Mono compatibility. No installer operations were invoked.
