using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using PipeTakeoff.Revit;
using KAMEP.Setup;

internal static class Program
{
    [STAThread]
    private static int Main(string[] args)
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        string only = Value(args, "--case=");
        string screenshots = Value(args, "--screenshots=");
        if (screenshots != null) Directory.CreateDirectory(screenshots);
        int count = 0, failed = 0;
        Console.WriteLine("Actual linked KA MEP HubForm / SetupForm branding layout regression.");
        Console.WriteLine("Explicit control/font scales, not operating-system DPI. No installer operation is invoked.");
        foreach (float scale in new[] { 1F, 1.5F, 2F })
            {
                Size viewport = scale == 1F ? new Size(1366, 728) : new Size(1280, 680);
                string name = viewport.Width + "x" + viewport.Height + "_" + (scale * 100).ToString("0", CultureInfo.InvariantCulture);
                if (only != null && only != name) continue;
                count++;
                var errors = new List<string>();
                using (var hub = new HubForm()) CheckForm(hub, false, viewport, scale, name, screenshots, errors);
                using (var setup = new SetupForm()) CheckForm(setup, true, viewport, scale, name, screenshots, errors);
                Console.WriteLine((errors.Count == 0 ? "PASS " : "FAIL ") + name);
                foreach (string error in errors.Distinct()) Console.WriteLine("  " + error);
                if (errors.Count > 0) failed++;
            }
        Console.WriteLine("RESULT: " + (count - failed) + "/" + count + " paired branding cases passed; " + failed + " failed (two forms per case).");
        return count > 0 && failed == 0 ? 0 : 1;
    }

    private static void CheckForm(Form form, bool setup, Size viewport, float scale, string name, string screenshots, List<string> errors)
    {
        string mode = setup ? "setup" : "hub";
        int before = errors.Count;
        form.StartPosition = FormStartPosition.Manual;
        form.Location = new Point(20, 20);
        form.Show();
        Pump(form);
        form.AutoScaleMode = AutoScaleMode.None;
        var fontSpecs = Descendants(form).Select(control => new FontSpec(control)).ToArray();
        form.Scale(new SizeF(scale, scale));
        foreach (FontSpec spec in fontSpecs) spec.Control.Font = new Font(spec.Family, spec.Size * scale, spec.Style, spec.Unit);
        form.MinimumSize = Size.Empty;
        form.ClientSize = viewport;
        form.Location = new Point(20, 20);
        Pump(form);

        PictureBox logo = Descendants(form).OfType<PictureBox>().Single();
        if (logo.Image == null || logo.Image.Width < 16 || logo.Image.Height < 16) errors.Add(mode + ": logo resource is empty");
        if (logo.SizeMode != PictureBoxSizeMode.Zoom) errors.Add(mode + ": logo must preserve aspect ratio using Zoom");
        if (form.Icon == null || form.Icon.Width <= 0) errors.Add(mode + ": branded window icon is missing");
        ValidateControl(mode, logo, errors);
        Button close = Descendants(form).OfType<Button>().Single(button => button.Text == "Close");
        ValidateControl(mode, close, errors);
        if (!ReferenceEquals(form.CancelButton, close)) errors.Add(mode + ": Escape does not target Close");
        if (!setup)
        {
            Button[] tools = Descendants(form).OfType<Button>().Where(button => button.Text.StartsWith("OPEN ", StringComparison.Ordinal)).ToArray();
            if (tools.Length != 11) errors.Add("hub: all eleven tool launchers must remain present");
            if (!tools.Any(button => button.Text == "OPEN CLAUDE MCP")) errors.Add("hub: Claude MCP launcher missing");
            Button spaces = tools.SingleOrDefault(button => button.Text == "OPEN HVAC SPACES");
            if (spaces == null) errors.Add("hub: HVAC Spaces launcher missing");
            if (!tools.Any(button => button.Text == "OPEN CLASH MANAGER")) errors.Add("hub: Clash Manager launcher missing");
            var viewportPanel = Descendants(form).OfType<Panel>().Single(panel => panel.AutoScroll);
            foreach (Button tool in tools)
            {
                Reachable(viewportPanel, tool, form);
                ValidateControl(mode, tool, errors);
                foreach (Control child in tool.Parent.Controls)
                    if (!tool.Parent.ClientRectangle.Contains(child.Bounds))
                        errors.Add("hub: " + child.Text + " clipped inside its tool card");
            }
            viewportPanel.AutoScrollPosition = Point.Empty; Pump(form);
        }
        if (setup)
        {
            CheckBox[] versions = Descendants(form).OfType<CheckBox>().ToArray();
            if (!versions.Select(check => check.Text).OrderBy(text => text).SequenceEqual(new[] { "Revit 2022.1+", "Revit 2023", "Revit 2024", "Revit 2025", "Revit 2026", "Revit 2027" }))
                errors.Add("setup: exact six supported Revit versions are required");
            foreach (CheckBox version in versions)
            {
                ValidateControl(mode, version, errors);
                string year = version.Text.Substring(6, 4);
                if (!version.Checked || !string.Equals(version.Tag as string, year, StringComparison.Ordinal))
                    errors.Add("setup: version checkbox does not map to its matching installer year: " + version.Text);
            }
            Button install = Descendants(form).OfType<Button>().Single(button => button.Text == "Install KA MEP");
            ValidateControl(mode, install, errors);
            if (!ReferenceEquals(form.AcceptButton, install)) errors.Add("setup: Enter does not target Install KA MEP");
            ValidateNoOverlap(mode, versions.Cast<Control>().ToArray(), errors);
            ValidateNoOverlap(mode, new Control[] { install, close }, errors);
        }
        bool referenceShot = name == "1366x728_100" || name == "1280x680_200";
        if (screenshots != null && (referenceShot || errors.Count > before))
            using (var image = new Bitmap(form.Width, form.Height))
            {
                using (Graphics graphics = Graphics.FromImage(image))
                    graphics.CopyFromScreen(form.Location, Point.Empty, form.Size);
                image.Save(Path.Combine(screenshots, mode + "_" + name + ".png"));
            }
        form.Close();
    }

    private static void ValidateControl(string mode, Control control, List<string> errors)
    {
        Rectangle bounds = control.RectangleToScreen(control.ClientRectangle);
        string label = string.IsNullOrEmpty(control.Name) ? control.Text : control.Name;
        if (!control.Visible || !control.Enabled || bounds.Width <= 0 || bounds.Height <= 0)
            errors.Add(mode + ": " + label + " is hidden, disabled or empty");
        for (Control ancestor = control.Parent; ancestor != null; ancestor = ancestor.Parent)
        {
            Rectangle available = ancestor.RectangleToScreen(ancestor.ClientRectangle);
            if (!available.Contains(bounds)) errors.Add(mode + ": " + label + " clipped by " + ancestor.GetType().Name + " available=" + available + " control=" + bounds);
        }
    }

    private static void Reachable(Panel viewport, Control control, Form form)
    {
        viewport.ScrollControlIntoView(control); Pump(form);
        for (int attempt = 0; attempt < 3; attempt++)
        {
            Rectangle bounds = viewport.RectangleToClient(control.RectangleToScreen(control.ClientRectangle));
            int dx = bounds.Left < 0 ? bounds.Left : Math.Max(0, bounds.Right - viewport.ClientSize.Width);
            int dy = bounds.Top < 0 ? bounds.Top : Math.Max(0, bounds.Bottom - viewport.ClientSize.Height);
            if (dx == 0 && dy == 0) return;
            viewport.AutoScrollPosition = new Point(Math.Max(0, -viewport.AutoScrollPosition.X + dx),
                Math.Max(0, -viewport.AutoScrollPosition.Y + dy));
            Pump(form);
        }
    }

    private static void ValidateNoOverlap(string mode, Control[] controls, List<string> errors)
    {
        for (int i = 0; i < controls.Length; i++)
            for (int j = i + 1; j < controls.Length; j++)
                if (controls[i].RectangleToScreen(controls[i].ClientRectangle).IntersectsWith(controls[j].RectangleToScreen(controls[j].ClientRectangle)))
                    errors.Add(mode + ": " + controls[i].Text + " overlaps " + controls[j].Text);
    }

    private static string Value(string[] args, string prefix)
    {
        string value = args.FirstOrDefault(arg => arg.StartsWith(prefix, StringComparison.Ordinal));
        return value == null ? null : value.Substring(prefix.Length);
    }

    private static void Pump(Control root)
    {
        for (int i = 0; i < 3; i++)
        {
            foreach (Control control in Descendants(root).Reverse()) control.PerformLayout();
            Application.DoEvents();
        }
    }

    private static IEnumerable<Control> Descendants(Control root)
    {
        yield return root;
        foreach (Control child in root.Controls)
            foreach (Control control in Descendants(child)) yield return control;
    }

    private sealed class FontSpec
    {
        public Control Control;
        public string Family;
        public float Size;
        public FontStyle Style;
        public GraphicsUnit Unit;
        public FontSpec(Control control)
        {
            Control = control;
            Family = control.Font.FontFamily.Name;
            Size = control.Font.Size;
            Style = control.Font.Style;
            Unit = control.Font.Unit;
        }
    }
}
