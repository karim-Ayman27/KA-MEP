using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using PipeTakeoff.Core;
using PipeTakeoff.Revit;

internal static class Program
{
    private static int cases;
    private static int failures;

    [STAThread]
    private static int Main(string[] args)
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        string screenshots = args.FirstOrDefault(a => a.StartsWith("--screenshots=", StringComparison.Ordinal));
        screenshots = screenshots == null ? null : screenshots.Substring("--screenshots=".Length);
        if (screenshots != null) Directory.CreateDirectory(screenshots);
        string onlyCase = args.FirstOrDefault(a => a.StartsWith("--case=", StringComparison.Ordinal));
        onlyCase = onlyCase == null ? null : onlyCase.Substring("--case=".Length);

        Console.WriteLine("Actual linked pipe, duct, cable tray and conduit action visibility regression.");
        Console.WriteLine("Runtime: " + (Type.GetType("Mono.Runtime") == null ? "Windows .NET Framework" : "Mono WinForms (not a Windows DPI certification)"));
        Console.WriteLine("Scale factors below explicitly scale controls and fonts; they are not operating-system DPI changes.");

        var sizes = new[] { new Size(876, 571), new Size(1160, 670), new Size(1280, 680), new Size(1366, 728), new Size(1000, 650) };
        foreach (string mode in new[] { "pipe", "duct", "tray", "conduit" })
            foreach (float scale in new[] { 1F, 1.5F, 2F })
                foreach (Size size in sizes)
                    if (onlyCase == null || string.Equals(onlyCase, CaseName(mode, size, scale), StringComparison.Ordinal))
                        RunCase(mode, size, scale, screenshots);

        Console.WriteLine("RESULT: " + (cases - failures) + "/" + cases + " layouts passed; " + failures + " failed.");
        return failures == 0 && cases > 0 ? 0 : 1;
    }

    private static string CaseName(string mode, Size clientSize, float scale)
    {
        return mode + "_" + clientSize.Width + "x" + clientSize.Height + "_" + (scale * 100).ToString("0", CultureInfo.InvariantCulture);
    }

    private static void RunCase(string mode, Size clientSize, float scale, string screenshots)
    {
        string name = CaseName(mode, clientSize, scale);
        cases++;
        var records = new List<PipeRecord> { Sample(mode) };
        if (mode == "tray" || mode == "conduit") records.Add(SampleFitting(mode));
        using (TakeoffForm form = CreateForm(mode, records))
        {
            form.StartPosition = FormStartPosition.Manual;
            form.Location = new Point(20, 20);
            form.Show();
            PumpLayout(form);

            // Simulate larger controls/text at a fixed physical viewport. Snapshot fonts before
            // assigning any font so inherited font properties do not accidentally multiply twice.
            form.AutoScaleMode = AutoScaleMode.None;
            var fontSizes = DescendantsAndSelf(form).Select(control => new FontSpec(control)).ToArray();
            form.Scale(new SizeF(scale, scale));
            foreach (FontSpec spec in fontSizes)
                spec.Control.Font = new Font(spec.Family, spec.Size * scale, spec.Style, spec.Unit);
            form.MinimumSize = Size.Empty;
            form.ClientSize = clientSize;
            form.Location = new Point(20, 20);
            PumpLayout(form);

            Button export = DescendantsAndSelf(form).OfType<Button>().Single(b => b.Text.StartsWith("Export Excel", StringComparison.Ordinal));
            Button refresh = DescendantsAndSelf(form).OfType<Button>().Single(b => b.Text == "Refresh preview");
            Button close = DescendantsAndSelf(form).OfType<Button>().Single(b => b.Text == "Close");
            var errors = new List<string>();
            var buttons = new[] { export, refresh, close };
            ValidateButtons(form, buttons, errors);
            if (mode == "tray" || mode == "conduit") ValidateElectricalPreview(form, refresh, errors);

            // Status text must never consume the action row's available width.
            var status = (Label)typeof(TakeoffForm).GetField("selectionStatus", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(form);
            status.Text = string.Concat(Enumerable.Repeat("Long status: selected detail columns and grouped summary. ", 8));
            PumpLayout(form);
            ValidateButtons(form, buttons, errors);

            // Exercise both resize directions, ending at the test viewport.
            form.ClientSize = new Size(1600, 900);
            PumpLayout(form);
            ValidateButtons(form, buttons, errors);
            form.ClientSize = clientSize;
            PumpLayout(form);
            ValidateButtons(form, buttons, errors);

            if (!ReferenceEquals(form.AcceptButton, export)) errors.Add("Enter does not target Export Excel");
            if (!ReferenceEquals(form.CancelButton, close)) errors.Add("Escape does not target Close");

            if (screenshots != null && (errors.Count > 0 || clientSize == new Size(876, 571)))
            {
                using (var image = new Bitmap(form.Width, form.Height))
                {
                    form.DrawToBitmap(image, new Rectangle(Point.Empty, form.Size));
                    image.Save(Path.Combine(screenshots, name + ".png"));
                }
            }

            Console.WriteLine((errors.Count == 0 ? "PASS " : "FAIL ") + name + " export=" + form.RectangleToClient(export.RectangleToScreen(export.ClientRectangle)));
            foreach (string error in errors.Distinct()) Console.WriteLine("  " + error);
            if (errors.Count > 0) failures++;
            form.Close();
        }
    }

    private static void ValidateElectricalPreview(TakeoffForm form, Button refresh, List<string> errors)
    {
        var grid = PrivateField<DataGridView>(form, "summaryGrid");
        var includeFittings = PrivateField<CheckBox>(form, "includeFittings");
        if (!form.IncludesElectricalFittings || form.FilteredRecords.Count() != 2)
            errors.Add("Electrical preview must initially include both the straight segment and fitting");
        if (grid.Columns.Contains("Area") || grid.Columns.Contains("Shape"))
            errors.Add("Electrical preview contains duct-only columns");
        if (grid.Columns["System"].HeaderText != "Service type")
            errors.Add("Electrical preview service header is incorrect");
        if (!form.Options.GroupBySystem || !form.Options.GroupByFamily || !form.Options.GroupByType)
            errors.Add("Electrical grouping defaults are incomplete");
        var fittingRow = grid.Rows.Cast<DataGridViewRow>().SingleOrDefault(row =>
            row.DataBoundItem is ElectricalSummaryRow && ((ElectricalSummaryRow)row.DataBoundItem).Category.EndsWith(" Fitting", StringComparison.Ordinal));
        if (fittingRow == null || Convert.ToString(fittingRow.Cells["Length"].FormattedValue, CultureInfo.InvariantCulture) != "—")
            errors.Add("Electrical fitting length must be displayed as an em dash");
        if (PrivateField<Label>(form, "countMetric").Text != "1" ||
            PrivateField<Label>(form, "thirdMetric").Text != "1" ||
            PrivateField<Label>(form, "lengthMetric").Text != 12.75D.ToString("N3"))
            errors.Add("Electrical initial metrics do not separate straight length and fitting count");

        includeFittings.Checked = false;
        refresh.PerformClick();
        PumpLayout(form);
        if (form.IncludesElectricalFittings || form.FilteredRecords.Count() != 1 ||
            PrivateField<Label>(form, "thirdMetric").Text != "0" ||
            PrivateField<Label>(form, "lengthMetric").Text != 12.75D.ToString("N3"))
            errors.Add("Excluding electrical fittings must preserve straight length and remove fitting count");
        includeFittings.Checked = true;
        refresh.PerformClick();
        PumpLayout(form);
        if (!form.IncludesElectricalFittings || form.FilteredRecords.Count() != 2)
            errors.Add("Re-enabling electrical fittings must restore both records");
    }

    private static T PrivateField<T>(TakeoffForm form, string name)
    {
        return (T)typeof(TakeoffForm).GetField(name, BindingFlags.Instance | BindingFlags.NonPublic).GetValue(form);
    }

    private static TakeoffForm CreateForm(string mode, List<PipeRecord> records)
    {
        if (mode == "duct") return new DuctTakeoffForm(records, DuctStandardFields.Create(), "Entire project");
        if (mode == "tray" || mode == "conduit")
            return new ElectricalTakeoffForm(records, ElectricalStandardFields.Create(), "Entire project", mode == "tray");
        return new TakeoffForm(records, StandardFields.Create(), "Entire project");
    }

    private static void ValidateButtons(Form form, Button[] buttons, List<string> errors)
    {
        foreach (Button button in buttons)
        {
            Rectangle bounds = button.RectangleToScreen(button.ClientRectangle);
            if (!button.Visible || !button.Enabled || bounds.Width <= 0 || bounds.Height <= 0)
                errors.Add(button.Text + " is hidden, disabled or empty");
            for (Control ancestor = button.Parent; ancestor != null; ancestor = ancestor.Parent)
            {
                Rectangle visible = ancestor.RectangleToScreen(ancestor.ClientRectangle);
                if (!visible.Contains(bounds))
                    errors.Add(button.Text + " clipped by " + ancestor.GetType().Name + " " + visible + " button=" + bounds);
            }
        }
        for (int i = 0; i < buttons.Length; i++)
            for (int j = i + 1; j < buttons.Length; j++)
                if (buttons[i].RectangleToScreen(buttons[i].ClientRectangle).IntersectsWith(buttons[j].RectangleToScreen(buttons[j].ClientRectangle)))
                    errors.Add(buttons[i].Text + " overlaps " + buttons[j].Text);
    }

    private static void PumpLayout(Control root)
    {
        for (int i = 0; i < 3; i++)
        {
            foreach (Control control in DescendantsAndSelf(root).Reverse()) control.PerformLayout();
            Application.DoEvents();
        }
    }

    private static IEnumerable<Control> DescendantsAndSelf(Control root)
    {
        yield return root;
        foreach (Control child in root.Controls)
            foreach (Control descendant in DescendantsAndSelf(child)) yield return descendant;
    }

    private static PipeRecord Sample(string mode)
    {
        bool duct = mode == "duct";
        var row = new PipeRecord();
        row.Values["ElementId"] = "1001";
        row.Values["Family"] = duct ? "Rectangular Duct" : "Pipes";
        row.Values["Type"] = "Standard";
        row.Values["SystemName"] = duct ? "Supply Air" : "Domestic Cold Water";
        row.Values["SystemType"] = row.Values["SystemName"];
        row.Values["Size"] = duct ? "400 x 250" : "100 mm";
        row.Values["Length"] = 12.75D;
        row.Values["Diameter"] = 100D;
        if (duct)
        {
            row.Values["Category"] = "Duct";
            row.Values["Shape"] = "Rectangular";
            row.Values["SectionKey"] = "rectangular:400x250";
            row.Values["Area"] = 16.575D;
            row.Values["AreaSource"] = "Revit surface area";
        }
        else if (mode == "tray" || mode == "conduit")
        {
            bool tray = mode == "tray";
            row.Values["Category"] = tray ? "Cable Tray" : "Conduit";
            row.Values["Family"] = tray ? "Cable Tray with Fittings" : "Conduit with Fittings";
            row.Values["SystemName"] = "Electrical Power";
            row.Values["SystemType"] = "Electrical Power";
            row.Values["Size"] = tray ? "300 x 100 mm" : "25 mm";
            row.Values["SectionLabel"] = row.Values["Size"];
            row.Values["SectionKey"] = tray ? "rectangular:300x100" : "round:25";
            row.Values["Diameter"] = tray ? null : (object)25D;
            row.Values["Width"] = tray ? (object)300D : null;
            row.Values["Height"] = tray ? (object)100D : null;
        }
        return row;
    }

    private static PipeRecord SampleFitting(string mode)
    {
        PipeRecord row = Sample(mode);
        row.Values["ElementId"] = "1002";
        row.Values["Category"] = mode == "tray" ? "Cable Tray Fitting" : "Conduit Fitting";
        row.Values["Family"] = "Elbow";
        row.Values["SectionKey"] = "fitting:" + row.Values["SectionKey"];
        row.Values["FittingKind"] = "Elbow";
        row.Values["Angle"] = 90D;
        row.Values["Length"] = 999D; // Fitting lengths must never affect straight-length metrics.
        return row;
    }

    private sealed class FontSpec
    {
        public Control Control;
        public string Family;
        public float Size;
        public FontStyle Style;
        public GraphicsUnit Unit;
        public FontSpec(Control control)
        {
            Control = control;
            Family = control.Font.FontFamily.Name;
            Size = control.Font.Size;
            Style = control.Font.Style;
            Unit = control.Font.Unit;
        }
    }
}
