# Takeoff action visibility regression

This standalone .NET Framework 4.8 executable links the production `TakeoffForm`,
`DuctTakeoffForm`, `ElectricalTakeoffForm`, `KaTheme`, and detached data models. It does not load Revit.

It opens the actual pipe, duct, cable tray and conduit dialogs, then checks that Export Excel, Refresh
preview and Close are visible, enabled, non-overlapping, and fully inside every
ancestor's client bounds. Enter and Escape button assignments are checked too.
The 60 layouts cover four takeoff modes, five client sizes and explicit control/font scale factors of
1, 1.5 and 2. Each checks the initial state, very long status text, expansion to a
larger viewport and shrinking back to the test size. These are simulated scaling
checks, not operating-system DPI changes.

Electrical cases also check the fitting inclusion toggle in both directions,
default grouping, service label, separate straight/fitting counts, straight-only
length totals, the fitting length placeholder, and absence of duct-only columns.

Build on Windows with the .NET SDK and run from a desktop session:

```powershell
dotnet build tests/TakeoffLayout.Tests/TakeoffLayout.Tests.csproj -c Release
& tests/TakeoffLayout.Tests/bin/Release/net48/KAMEP.TakeoffLayout.Tests.exe
```

Optional `--screenshots=PATH` saves screenshots of smallest layouts and failures.
`--case=pipe_876x571_100` selects one case so Mono native resources can be isolated
in a fresh process for each run.
The mode names are `pipe`, `duct`, `tray` and `conduit`; viewport sizes are
`876x571`, `1160x670`, `1280x680`, `1366x728` and `1000x650`; scale suffixes are
`100`, `150` and `200`.
To compare an earlier source copy, pass MSBuild
`-p:TakeoffSourceDirectory=ABSOLUTE_DIRECTORY` containing `TakeoffForm.cs` and
`KaTheme.cs`. The current production sources are used by default.

The executable can also run under Mono WinForms with an X server. Such a run
checks general layout behavior; it does not certify Windows/Revit rendering or
per-monitor DPI behavior. A real Revit smoke test at Windows 100%, 150% and 200%
display scaling remains appropriate.

Validation on 2026-10-15: the original layout failed 24 of the initial 30 viewport
checks. The corrected layout passed all 30 cases, including long status and
grow/shrink checks, with each case in a separate Mono process. An earlier run of
all corrected cases in one Mono process encountered a native libgdiplus
`GdipDeleteStringFormat` disposal fault after 14 passing cases; that run was not
counted as passing. Fresh per-case processes all exited successfully. This is
why the Mono verification used `--case` isolation.

Validation on 2026-10-17: all 60 pipe/duct/cable tray/conduit cases passed in
separate Mono processes. Electrical preview checks passed in all 30 electrical
cases. Logs and screenshots from this run are at
`/workspace/.ka-mep-layout-runtime/electrical-v1-cases/`; this remains a simulated
scale/layout check outside Windows and Revit.
