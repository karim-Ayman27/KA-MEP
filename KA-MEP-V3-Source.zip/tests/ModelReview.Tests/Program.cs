using System;
using System.Collections.Generic;
using System.Linq;
using PipeTakeoff.Revit;

internal static class Program
{
    private static int count;
    private static int Main()
    {
        try
        {
            Equal(100.0, ReviewHealth.Score(0, 0, 0, 0), "Empty checks score 100");
            Equal(88.5, ReviewHealth.Score(1, 1, 1, 1), "Weights include half-point warnings");
            Equal(0.0, ReviewHealth.Score(500, 500, 500, 500), "Category caps give a zero floor");
            Equal(75.0, ReviewHealth.Score(int.MaxValue, 0, 0, 0), "CAD count avoids integer overflow");
            Equal(80.0, ReviewHealth.Score(0, int.MaxValue, 0, 0), "View cap");
            Equal(70.0, ReviewHealth.Score(0, 0, int.MaxValue, 0), "Duplicate cap");
            Equal(75.0, ReviewHealth.Score(0, 0, 0, int.MaxValue), "Warning cap");
            Throws(() => ReviewHealth.Score(-1, 0, 0, 0), "Negative count rejected");
            var snapshot = new ReviewSnapshot();
            snapshot.Findings.Add(F("link", ReviewKind.CadLink, false));
            Equal(100.0, snapshot.HealthScore, "CAD links do not lower score");
            snapshot.Findings.Add(F("cad", ReviewKind.CadImport, true));
            snapshot.Findings.Add(F("view", ReviewKind.UnplacedView, true));
            snapshot.Findings.Add(F("duplicate", ReviewKind.PotentialDuplicate, false));
            snapshot.Findings.Add(F("warning", ReviewKind.RevitWarning, false));
            Equal(88.5, snapshot.HealthScore, "Snapshot counts score all review categories");
            snapshot.IsComplete = false;
            Check(double.IsNaN(snapshot.HealthScore), "Incomplete scan score unavailable");
            Throws(() => ReviewHealth.CleanableSelection(snapshot, new[] { "cad" }), "Incomplete scan blocks cleanup at service selection boundary");
            snapshot.IsComplete = true;
            snapshot.Findings.RemoveAll(f => f.Kind == ReviewKind.CadImport);
            Equal(93.5, snapshot.HealthScore, "Fix and refresh improves score with same formula");
            snapshot.Findings.Add(F("cad", ReviewKind.CadImport, true));
            Equal(2, ReviewHealth.CleanableSelection(snapshot, new[] { "cad", "view", "cad" }).Count, "Explicit cleanup selection deduplicated");
            Throws(() => ReviewHealth.CleanableSelection(snapshot, new string[0]), "Empty cleanup rejected");
            Throws(() => ReviewHealth.CleanableSelection(snapshot, new[] { "missing" }), "Stale selection rejected");
            Throws(() => ReviewHealth.CleanableSelection(snapshot, new[] { "cad", "duplicate" }), "Mixed cleanup and duplicate selection rejected atomically");
            Throws(() => ReviewHealth.CleanableSelection(snapshot, new[] { "link" }), "Linked CAD protected");
            Throws(() => ReviewHealth.CleanableSelection(snapshot, new[] { "warning" }), "Warning cleanup protected");
            snapshot.Findings.First(f => f.Key == "view").CanClean = false;
            Throws(() => ReviewHealth.CleanableSelection(snapshot, new[] { "view" }), "Protected view rejected");
            snapshot.Findings.First(f => f.Key == "duplicate").CanClean = true;
            Throws(() => ReviewHealth.CleanableSelection(snapshot, new[] { "duplicate" }), "Kind protection survives incorrect CanClean flag");
            Equal("duplicate:1,2,9000000000", ReviewHealth.DuplicateKey(new long[] { 9000000000L, 2, 1, 2 }), "Stable duplicate identity supports 64-bit IDs");
            var groups = ReviewDuplicateGroups.Merge(new[] {
                new long[] { 1, 2 }, new long[] { 2, 3 }, new long[] { 9, 10 }, new long[] { 3, 4 },
                new long[] { 1, 4 }, new long[] { 50 }, new long[] { 9, 10 }, new long[0] });
            Equal(2, groups.Count, "Native and geometric findings merge instead of double counting");
            Equal("1,2,3,4", string.Join(",", groups[0]), "Transitive overlapping group union");
            Equal("9,10", string.Join(",", groups[1]), "Separate groups remain separate");
            Equal(0, ReviewDuplicateGroups.Merge(new IEnumerable<long>[0]).Count, "Empty duplicate groups");
            Check(ReviewHealth.Explanation.Contains("not an Autodesk"), "Metric states custom scope");
            Check(ReviewHealth.Explanation.Contains("partial scan has no score"), "Partial check policy explained");
            CheckIssueGrouping();
            for (int n = 0; n < 100; n++)
            {
                double before = ReviewHealth.Score(n, n, n, n);
                double after = ReviewHealth.Score(Math.Max(0, n - 1), n, n, n);
                if (after < before || before < 0 || before > 100) throw new Exception("Score monotonicity/bounds");
            }
            count++;
            Console.WriteLine("PASS " + count + " Model Review model checks (includes 100 score monotonicity cases).");
            return 0;
        }
        catch (Exception ex) { Console.Error.WriteLine(ex); return 1; }
    }
    private static void CheckIssueGrouping()
    {
        var snapshot = new ReviewSnapshot();
        for (int i = 0; i < 100; i++)
            snapshot.Findings.Add(new ReviewFinding { Key = "view:" + i, Title = "View " + i, Kind = ReviewKind.UnplacedView,
                IssueCode = "unplaced-views", ElementIds = new List<long> { 9000000000L + i }, CanClean = true });
        snapshot.Findings.Add(new ReviewFinding { Key = "warning:a", Title = "Warning instance A", Kind = ReviewKind.RevitWarning,
            IssueCode = "revit-warning:11111111111111111111111111111111", IssueTitle = "Common warning",
            ElementIds = new List<long> { 1, 2, 2 } });
        snapshot.Findings.Add(new ReviewFinding { Key = "warning:b", Title = "Warning instance B", Kind = ReviewKind.RevitWarning,
            IssueCode = "revit-warning:11111111111111111111111111111111", IssueTitle = "Common warning",
            ElementIds = new List<long> { 2, 3 } });
        snapshot.Findings.Add(new ReviewFinding { Key = "warning:c", Title = "Warning instance A", Kind = ReviewKind.RevitWarning,
            IssueCode = "revit-warning:22222222222222222222222222222222", IssueTitle = "Common warning",
            ElementIds = new List<long> { 4 } });
        snapshot.Findings.Add(new ReviewFinding { Key = "duplicate:a", Title = "Coincident pipes", Kind = ReviewKind.PotentialDuplicate,
            ElementIds = new List<long> { 10, 11 } });
        snapshot.Findings.Add(new ReviewFinding { Key = "duplicate:b", Title = "Coincident ducts", Kind = ReviewKind.PotentialDuplicate,
            ElementIds = new List<long> { 20, 21 } });
        double before = snapshot.HealthScore;
        var groups = snapshot.IssueGroups;
        Equal(4, groups.Count, "One summary per check or native warning definition");
        Equal(105, groups.Sum(group => group.OccurrenceCount), "Grouping retains every underlying occurrence");
        Equal(105, snapshot.Findings.Count, "Grouping does not replace canonical findings");
        Equal(before, snapshot.HealthScore, "Display grouping does not inflate health score");
        Equal(68.5, snapshot.HealthScore, "Two duplicate groups and three warnings still contribute separately");
        var views = groups.Single(group => group.Kind == ReviewKind.UnplacedView);
        Equal(100, views.OccurrenceCount, "Hundreds of repeated views collapse into one summary row");
        Equal(100, views.AffectedElementCount, "Affected element count is explicit");
        Equal(9000000099L, views.ElementIds.Last(), "Grouping retains exact 64-bit element identifiers");
        var warning = groups.Single(group => group.Kind == ReviewKind.RevitWarning && group.OccurrenceCount == 2);
        Equal("Common warning", warning.Title, "Group title does not expose per-instance detail");
        Equal("1,2,3", string.Join(",", warning.ElementIds), "Repeated IDs count once within each issue");
        Equal(2, groups.Count(group => group.Kind == ReviewKind.RevitWarning), "Distinct native definitions stay separate even with matching descriptions");
        Equal(4, groups.Single(group => group.Kind == ReviewKind.PotentialDuplicate).AffectedElementCount, "Duplicate summary counts elements across distinct duplicate groups");
        Throws(() => ReviewHealth.CleanableSelection(snapshot, new[] { views.Key }), "Summary issue key cannot authorize cleanup of group members");
        Equal(1, ReviewHealth.CleanableSelection(snapshot, new[] { views.Findings[0].Key }).Count, "Only individually selected detail findings authorize cleanup");
        string identities = string.Join("|", groups.Select(group => group.Key));
        snapshot.Findings.Reverse();
        Equal(identities, string.Join("|", snapshot.IssueGroups.Select(group => group.Key)), "Issue identity is independent of scan ordering");
        views.Findings.Clear();
        Equal(100, snapshot.Count(ReviewKind.UnplacedView), "Presentation membership is detached from canonical list");

        var fallback = ReviewIssueGrouping.Group(new[] {
            new ReviewFinding { Key = "a", Kind = ReviewKind.RevitWarning, Title = "Repeated   warning" },
            new ReviewFinding { Key = "b", Kind = ReviewKind.RevitWarning, Title = " repeated\nWARNING " },
            new ReviewFinding { Key = "c", Kind = ReviewKind.RevitWarning, Title = "Different warning" },
            new ReviewFinding { Key = "d", Kind = ReviewKind.CadImport, Title = "plan A.dwg" },
            new ReviewFinding { Key = "e", Kind = ReviewKind.CadImport, Title = "plan B.dwg" },
            new ReviewFinding { Key = "f", Kind = ReviewKind.CadLink, Title = "plan A.dwg" }
        });
        Equal(4, fallback.Count, "Fallback groups exact normalized warning descriptions and each CAD check");
        Equal(2, fallback.Single(group => group.Kind == ReviewKind.CadImport).OccurrenceCount, "CAD import names do not create separate issue types");
        Check(fallback.Single(group => group.Kind == ReviewKind.CadLink).Title.Contains("informational"), "Links remain separate and informational");
        Equal(0, ReviewIssueGrouping.Group(new ReviewFinding[0]).Count, "No findings produce no issue rows");
        Throws(() => ReviewIssueGrouping.Group(null), "Missing findings rejected");
        Throws(() => ReviewIssueGrouping.Group(new ReviewFinding[] { null }), "Missing individual finding rejected");
    }
    private static ReviewFinding F(string key, ReviewKind kind, bool clean) { return new ReviewFinding { Key = key, Title = key, Kind = kind, CanClean = clean }; }
    private static void Equal<T>(T expected, T actual, string name) { Check(Equals(expected, actual), name + ": expected " + expected + ", actual " + actual); }
    private static void Check(bool condition, string name) { if (!condition) throw new Exception(name); count++; }
    private static void Throws(Action action, string name) { try { action(); } catch (ArgumentException) { count++; return; } catch (InvalidOperationException) { count++; return; } throw new Exception(name); }
}
