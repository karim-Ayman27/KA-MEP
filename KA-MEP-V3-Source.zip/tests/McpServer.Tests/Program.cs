using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using KAMEP.Mcp.Server;
using PipeTakeoff.Core.Mcp;

internal static class Program
{
    private static readonly JavaScriptSerializer Json = new JavaScriptSerializer();
    private static int passed;
    private static int failed;

    private static int Main()
    {
        Run("All four supported protocol revisions negotiate without accessing Revit", ProtocolVersions);
        Run("Unknown protocol revisions negotiate a supported revision", UnknownVersion);
        Run("Tools are unavailable before the initialized notification", InitializationRequired);
        Run("Repeated initialize is rejected", RepeatedInitialize);
        Run("Early readiness and invalid initialization cannot bypass lifecycle", InitializationOrdering);
        Run("Ping succeeds independently of Revit", Ping);
        Run("Notifications never produce responses or execute tools", Notifications);
        Run("Malformed JSON is a parse error and the next request still succeeds", MalformedJson);
        Run("JavaScript extensions and duplicate JSON properties are rejected", StrictJson);
        Run("JSON batches and invalid request envelopes are rejected", InvalidEnvelopes);
        Run("Unknown methods return method not found", UnknownMethod);
        Run("String and large integer request IDs round trip without loss", RequestIdentity);
        Run("Discovery contains exactly the six bounded read-only tools", ToolDiscovery);
        Run("Project info requires no project key and exposes text content", ProjectInfo);
        Run("Project info exposes bounded link paging without a required project key", ProjectInfoPaging);
        Run("Every project-scoped tool requires a project key", RequiredProjectKey);
        Run("Project identity and Unicode query cross the protocol unchanged", IdentityAndUnicode);
        Run("Element parameters preserve 64-bit IDs as strings", ElementIdentity);
        Run("Element parameters accept unique ID and reject a missing identity", UniqueIdentity);
        Run("Page defaults and inclusive upper boundaries reach the backend", PagingBounds);
        Run("Negative, excessive, fractional and incorrectly typed pages are rejected", InvalidPages);
        Run("Find requires an allowed category and bounds query length", FindValidation);
        Run("Unexpected arguments and incompatible argument types cannot reach Revit", StrictArguments);
        Run("Unknown tools are rejected without calling the backend", UnknownTool);
        Run("Backend failures are MCP tool errors with readable content", BackendFailure);
        Run("Backend exceptions are contained as tool errors", BackendException);
        Run("Caller cancellation reaches the active backend and produces a tool error", CancellationPropagation);
        Run("Pre-cancelled requests never invoke the backend", PreCancelledRequest);
        Run("MCP cancellation notifications cancel an active request without a response", NotificationCancellation);
        Run("Duplicate active request IDs are rejected without a second backend call", DuplicateRequest);
        Run("Active request IDs cannot be reused by other RPC methods", DuplicateAcrossMethods);
        Run("Equivalent numeric IDs share cancellation and duplicate detection", NumericRequestIdentity);
        Run("Cancellation callback failures cannot escape notifications", CancellationCallbackFailure);
        Run("Outstanding bridge work is bounded to eight requests", ConcurrencyLimit);
        Run("Missing, malformed and excessive bridge results become tool errors", InvalidBackendResults);
        Run("Oversized protocol messages are rejected before backend dispatch", OversizedInput);
        Run("Malformed connection records return safe tool errors", InvalidConnections);
        Console.WriteLine("RESULT: " + passed + "/" + (passed + failed) + " MCP protocol cases passed; " + failed + " failed.");
        return failed == 0 ? 0 : 1;
    }

    private static void ProtocolVersions()
    {
        foreach (string version in new[] { "2024-11-05", "2025-03-26", "2025-06-18", "2025-11-25" })
        {
            var f = new Fixture(false);
            var result = Result(f.Send(Request("initialize", Initialization(version))));
            Equal(version, result["protocolVersion"]);
            Assert(Object(result["capabilities"]).ContainsKey("tools"), "Tools capability omitted");
            Assert(Object(result["serverInfo"]).ContainsKey("name"), "Server identity omitted");
            Equal(0, f.Calls);
        }
    }

    private static void UnknownVersion()
    {
        var f = new Fixture(false);
        var result = Result(f.Send(Request("initialize", Initialization("1900-01-01"))));
        Assert(new[] { "2024-11-05", "2025-03-26", "2025-06-18", "2025-11-25" }.Contains((string)result["protocolVersion"]), "Unsupported negotiated protocol");
    }

    private static void InitializationRequired()
    {
        var f = new Fixture(false);
        Error(-32002, f.Send(Request("tools/list")));
        f.Send(Request("initialize", Initialization("2025-11-25")));
        Error(-32002, f.Send(Request("tools/call", Tool("ka_revit_project_info", Args()))));
        Equal(0, f.Calls);
        Equal(null, f.Send(Notify("notifications/initialized")));
        Result(f.Send(Request("tools/list")));
    }

    private static void RepeatedInitialize()
    {
        Error(-32600, new Fixture().Send(Request("initialize", Initialization("2025-11-25"))));
    }

    private static void InitializationOrdering()
    {
        var f = new Fixture(false);
        Equal(null, f.Send(Notify("notifications/initialized")));
        Error(-32602, f.Send(Request("initialize", Args("protocolVersion", "2025-11-25"))));
        Error(-32002, f.Send(Request("tools/list")));
        Result(f.Send(Request("initialize", Initialization("2025-11-25"))));
        Error(-32002, f.Send(Request("tools/list")));
        Equal(null, f.Send(Notify("notifications/initialized")));
        Result(f.Send(Request("tools/list")));
        Equal(0, f.Calls);
    }

    private static void Ping()
    {
        var f = new Fixture(false);
        Equal(0, Result(f.Send(Request("ping"))).Count);
        Equal(0, f.Calls);
    }

    private static void Notifications()
    {
        var f = new Fixture();
        Equal(null, f.Send(Notify("ping")));
        Equal(null, f.Send(Notify("notifications/cancelled", Args("requestId", 99, "reason", "User cancelled"))));
        Equal(null, f.Send(Notify("unknown/notification")));
        Equal(null, f.Send(Notify("tools/call", Tool("ka_revit_project_info", Args()))));
        Equal(0, f.Calls);
    }

    private static void MalformedJson()
    {
        var f = new Fixture();
        var response = f.Send("{\"jsonrpc\":");
        Error(-32700, response);
        Equal(null, Object(Json.DeserializeObject(response))["id"]);
        Result(f.Send(Request("ping")));
    }

    private static void StrictJson()
    {
        var f = new Fixture();
        foreach (string input in new[] {
            "{'jsonrpc':'2.0','id':1,'method':'ping'}",
            "{jsonrpc:\"2.0\",id:1,method:\"ping\"}",
            "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"ping\",}",
            "{\"jsonrpc\":\"2.0\",\"id\":01,\"method\":\"ping\"}",
            "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"ping\",\"method\":\"tools/list\"}",
            "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"ping\",\"\\u006dethod\":\"tools/list\"}",
            "{\"jsonrpc\":\"2.0\",\"id\":1,/*comment*/\"method\":\"ping\"}" })
            Error(-32700, f.Send(input));
        Result(f.Send(Request("ping")));
        Equal(0, f.Calls);
    }

    private static void InvalidEnvelopes()
    {
        var f = new Fixture();
        foreach (string input in new[] {
            "[]", "[ {\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"ping\"} ]", "null", "42", "{}",
            "{\"jsonrpc\":\"1.0\",\"id\":1,\"method\":\"ping\"}",
            "{\"jsonrpc\":\"2.0\",\"id\":true,\"method\":\"ping\"}",
            "{\"jsonrpc\":\"2.0\",\"id\":1.5,\"method\":\"ping\"}" })
            Error(-32600, f.Send(input));
        Equal(0, f.Calls);
    }

    private static void UnknownMethod()
    {
        Error(-32601, new Fixture().Send(Request("resources/list")));
    }

    private static void RequestIdentity()
    {
        var f = new Fixture();
        foreach (object id in new object[] { "request-\u0627\u0644\u0639\u0631\u0628\u064a\u0629", 9223372036854775807L })
        {
            var request = Args("jsonrpc", "2.0", "id", id, "method", "ping");
            var response = Object(Json.DeserializeObject(f.Send(Json.Serialize(request))));
            Equal(id.ToString(), response["id"].ToString());
        }
    }

    private static void ToolDiscovery()
    {
        var f = new Fixture();
        var tools = Array(Result(f.Send(Request("tools/list")))["tools"]).Select(Object).ToList();
        var expected = new[] { "ka_revit_project_info", "ka_revit_selection", "ka_revit_find_elements", "ka_revit_element_parameters", "ka_revit_sheets", "ka_revit_warnings" };
        Equal(6, tools.Count);
        Assert(new HashSet<string>(tools.Select(t => (string)t["name"])).SetEquals(expected), "Unexpected tool surface");
        foreach (var tool in tools)
        {
            var hints = Object(tool["annotations"]);
            Equal(true, hints["readOnlyHint"]); Equal(false, hints["destructiveHint"]); Equal(false, hints["openWorldHint"]);
            var schema = Object(tool["inputSchema"]);
            Equal("object", schema["type"]); Equal(false, schema["additionalProperties"]);
            if ((string)tool["name"] != "ka_revit_project_info")
            {
                Assert(Array(schema["required"]).Contains("projectKey"), "Project identity missing from schema");
                Equal(64, Object(Object(schema["properties"])["projectKey"])["maxLength"]);
            }
        }
        var find = Object(tools.Single(t => (string)t["name"] == "ka_revit_find_elements")["inputSchema"]);
        var props = Object(find["properties"]);
        Assert(Array(Object(props["category"])["enum"]).Contains("Pipes"), "Category enum missing Pipes");
        Equal(200, Object(props["limit"])["maximum"]);
        Equal(100000, Object(props["offset"])["maximum"]);
        Equal(160, Object(props["query"])["maxLength"]);
        var parameters = Object(tools.Single(t => (string)t["name"] == "ka_revit_element_parameters")["inputSchema"]);
        Equal("string", Object(Object(parameters["properties"])["elementId"])["type"]);
        Equal(128, Object(Object(parameters["properties"])["uniqueId"])["maxLength"]);
        Equal(0, f.Calls);
    }

    private static void ProjectInfo()
    {
        var f = new Fixture();
        var result = Result(f.Call("ka_revit_project_info", Args()));
        Equal(false, result["isError"]);
        Equal("ka_revit_project_info", f.Last.Tool);
        Equal(1, f.Calls);
        Equal("text", Object(Array(result["content"])[0])["type"]);
        Equal("demo-project", Object(Json.DeserializeObject(Text(result)))["projectKey"]);
    }

    private static void ProjectInfoPaging()
    {
        var f = new Fixture();
        var tools = Array(Result(f.Send(Request("tools/list")))["tools"]).Select(Object);
        var schema = Object(tools.Single(t => (string)t["name"] == "ka_revit_project_info")["inputSchema"]);
        var properties = Object(schema["properties"]);
        Assert(!schema.ContainsKey("required") && !properties.ContainsKey("projectKey"), "Project info unexpectedly requires a key");
        Equal(200, Object(properties["limit"])["maximum"]);
        Result(f.Call("ka_revit_project_info", Args("offset", 100000, "limit", 200)));
        Equal(100000, f.Last.Arguments.Offset); Equal(200, f.Last.Arguments.Limit);
        Equal(null, f.Last.Arguments.ProjectKey);
        Invalid(new Fixture(), "ka_revit_project_info", Args("limit", 201));
        Invalid(new Fixture(), "ka_revit_project_info", Args("offset", -1));
    }

    private static void RequiredProjectKey()
    {
        foreach (string tool in new[] { "ka_revit_selection", "ka_revit_find_elements", "ka_revit_element_parameters", "ka_revit_sheets", "ka_revit_warnings" })
        {
            var f = new Fixture();
            var args = Args();
            if (tool == "ka_revit_find_elements") args["category"] = "Pipes";
            if (tool == "ka_revit_element_parameters") args["elementId"] = "1";
            Invalid(f, tool, args);
            args["projectKey"] = " "; Invalid(f, tool, args);
        }
    }

    private static void IdentityAndUnicode()
    {
        var f = new Fixture();
        const string query = "\u0645\u0636\u062e\u0629 — 楼层 & < > $()";
        Result(f.Call("ka_revit_find_elements", Args("projectKey", "project-guid", "category", "MechanicalEquipment", "query", query)));
        Equal("project-guid", f.Last.Arguments.ProjectKey);
        Equal("MechanicalEquipment", f.Last.Arguments.Category);
        Equal(query, f.Last.Arguments.Query);
    }

    private static void ElementIdentity()
    {
        var f = new Fixture();
        Result(f.Call("ka_revit_element_parameters", Args("projectKey", "p", "elementId", "9223372036854775807", "includeType", true)));
        Equal("9223372036854775807", f.Last.Arguments.ElementId); Equal(true, f.Last.Arguments.IncludeType);
        Invalid(new Fixture(), "ka_revit_element_parameters", Args("projectKey", "p", "elementId", 9223372036854775807L));
    }

    private static void UniqueIdentity()
    {
        var f = new Fixture();
        Result(f.Call("ka_revit_element_parameters", Args("projectKey", "p", "uniqueId", "e7e54158-a793-41b5-bd88-17177815f261-00000001")));
        Equal("e7e54158-a793-41b5-bd88-17177815f261-00000001", f.Last.Arguments.UniqueId);
        Invalid(new Fixture(), "ka_revit_element_parameters", Args("projectKey", "p"));
        Invalid(new Fixture(), "ka_revit_element_parameters", Args("projectKey", "p", "elementId", "", "uniqueId", ""));
    }

    private static void PagingBounds()
    {
        var f = new Fixture();
        Result(f.Call("ka_revit_selection", Args("projectKey", "p")));
        Equal(0, f.Last.Arguments.Offset); Equal(50, f.Last.Arguments.Limit);
        Result(f.Call("ka_revit_sheets", Args("projectKey", "p", "offset", 100000, "limit", 200)));
        Equal(100000, f.Last.Arguments.Offset); Equal(200, f.Last.Arguments.Limit);
        Result(f.Call("ka_revit_warnings", Args("projectKey", "p", "offset", 0, "limit", 1)));
        Equal(0, f.Last.Arguments.Offset); Equal(1, f.Last.Arguments.Limit);
    }

    private static void InvalidPages()
    {
        foreach (object limit in new object[] { 0, -1, 201, 1.25m, "10", true, 2147483648L })
            Invalid(new Fixture(), "ka_revit_sheets", Args("projectKey", "p", "limit", limit));
        foreach (object offset in new object[] { -1, 100001, 0.1m, "0", false, 2147483648L })
            Invalid(new Fixture(), "ka_revit_warnings", Args("projectKey", "p", "offset", offset));
    }

    private static void FindValidation()
    {
        Invalid(new Fixture(), "ka_revit_find_elements", Args("projectKey", "p"));
        foreach (string category in new[] { "All", "Walls", "pipes", "", "Pipes;delete" })
            Invalid(new Fixture(), "ka_revit_find_elements", Args("projectKey", "p", "category", category));
        var f = new Fixture();
        Result(f.Call("ka_revit_find_elements", Args("projectKey", "p", "category", "Pipes", "query", new string('x', 160))));
        Equal(160, f.Last.Arguments.Query.Length);
        Invalid(new Fixture(), "ka_revit_find_elements", Args("projectKey", "p", "category", "Pipes", "query", new string('x', 161)));
    }

    private static void StrictArguments()
    {
        Invalid(new Fixture(), "ka_revit_project_info", Args("projectKey", "p"));
        Invalid(new Fixture(), "ka_revit_selection", Args("projectKey", "p", "command", "delete"));
        Invalid(new Fixture(), "ka_revit_selection", Args("ProjectKey", "p"));
        Invalid(new Fixture(), "ka_revit_selection", Args("projectKey", 1));
        Invalid(new Fixture(), "ka_revit_element_parameters", Args("projectKey", "p", "elementId", "1", "includeType", "true"));
        Invalid(new Fixture(), "ka_revit_find_elements", Args("projectKey", "p", "category", "Pipes", "query", new object[0]));
        var f = new Fixture();
        Error(-32602, f.Send(Request("tools/call", Args("name", "ka_revit_project_info", "arguments", "invalid"))));
        Equal(0, f.Calls);
    }

    private static void UnknownTool()
    {
        Invalid(new Fixture(), "ka_revit_delete_elements", Args("projectKey", "p"));
    }

    private static void BackendFailure()
    {
        var f = new Fixture();
        f.Response = new McpWireResponse { Success = false, ErrorCode = "PROJECT_CHANGED", Error = "The active project changed. Run project info again." };
        var result = Result(f.Call("ka_revit_selection", Args("projectKey", "old-project")));
        Equal(true, result["isError"]);
        Assert(Text(result).Contains("active project changed"), "Tool failure explanation was lost");
        Equal(1, f.Calls);
    }

    private static void BackendException()
    {
        var f = new Fixture(); f.Failure = new InvalidOperationException("Sensitive token should-not-escape-123");
        var result = Result(f.Call("ka_revit_project_info", Args()));
        Equal(true, result["isError"]); Assert(Text(result).Length > 0, "Tool failure content omitted");
        Assert(!Text(result).Contains("should-not-escape-123"), "Exception details leaked through tool result");
    }

    private static void CancellationPropagation()
    {
        var f = new Fixture(); f.Hold = true;
        using (var source = new CancellationTokenSource())
        {
            var response = f.Engine.ProcessLineAsync(Request("tools/call", Tool("ka_revit_project_info", Args())), source.Token);
            Assert(!response.IsCompleted, "Backend did not remain active");
            Assert(f.LastToken.CanBeCanceled, "Backend token does not support cancellation");
            source.Cancel();
            Equal(true, Result(response.GetAwaiter().GetResult())["isError"]);
            Assert(f.LastToken.IsCancellationRequested, "Caller cancellation did not reach backend");
        }
    }

    private static void NotificationCancellation()
    {
        var f = new Fixture(); f.Hold = true;
        var response = f.Engine.ProcessLineAsync(Request("tools/call", Tool("ka_revit_project_info", Args())), CancellationToken.None);
        Equal(null, f.Send(Notify("notifications/cancelled", Args("requestId", 1, "reason", "User cancelled"))));
        var result = Result(response.GetAwaiter().GetResult());
        Equal(true, result["isError"]);
        Assert(f.LastToken.IsCancellationRequested, "Cancellation notification did not reach backend");
    }

    private static void PreCancelledRequest()
    {
        var f = new Fixture();
        using (var cancellation = new CancellationTokenSource())
        {
            cancellation.Cancel();
            Equal(true, Result(f.Send(Request("tools/call", Tool("ka_revit_project_info", Args())), cancellation.Token))["isError"]);
            Equal(0, f.Calls);
        }
    }

    private static void DuplicateRequest()
    {
        var f = new Fixture(); f.Hold = true;
        var line = Request("tools/call", Tool("ka_revit_project_info", Args()));
        var response = f.Engine.ProcessLineAsync(line, CancellationToken.None);
        Error(-32600, f.Send(line)); Equal(1, f.Calls);
        f.Send(Notify("notifications/cancelled", Args("requestId", 1)));
        Equal(true, Result(response.GetAwaiter().GetResult())["isError"]);
    }

    private static void DuplicateAcrossMethods()
    {
        var f = new Fixture(); f.Hold = true;
        var response = f.Engine.ProcessLineAsync(Request("tools/call", Tool("ka_revit_project_info", Args())), CancellationToken.None);
        foreach (string method in new[] { "ping", "tools/list", "resources/list" }) Error(-32600, f.Send(Request(method)));
        f.Send(Notify("notifications/cancelled", Args("requestId", 1)));
        Equal(true, Result(response.GetAwaiter().GetResult())["isError"]);
        Result(f.Send(Request("ping")));
    }

    private static void NumericRequestIdentity()
    {
        var f = new Fixture(); f.Hold = true;
        string line = Request("tools/call", Tool("ka_revit_project_info", Args())).Replace("\"id\":1", "\"id\":1.0");
        var response = f.Engine.ProcessLineAsync(line, CancellationToken.None);
        Error(-32600, f.Send(Request("ping")));
        var different = Json.Serialize(Args("jsonrpc", "2.0", "id", "1", "method", "ping"));
        Result(f.Send(different));
        f.Send(Notify("notifications/cancelled", Args("requestId", 1)));
        Assert(response.Wait(2000), "Equivalent numeric cancellation ID did not match");
        Equal(true, Result(response.GetAwaiter().GetResult())["isError"]);
        Equal(1, f.Calls);
    }

    private static void CancellationCallbackFailure()
    {
        var f = new Fixture(); f.Hold = true; f.ThrowOnCancellation = true;
        var response = f.Engine.ProcessLineAsync(Request("tools/call", Tool("ka_revit_project_info", Args())), CancellationToken.None);
        Equal(null, f.Send(Notify("notifications/cancelled", Args("requestId", 1))));
        Equal(true, Result(response.GetAwaiter().GetResult())["isError"]);
        Result(f.Send(Request("ping")));
    }

    private static void ConcurrencyLimit()
    {
        var f = new Fixture(); f.Hold = true;
        using (var source = new CancellationTokenSource())
        {
            var responses = new List<Task<string>>();
            for (int id = 10; id < 18; id++)
            {
                string line = Json.Serialize(Args("jsonrpc", "2.0", "id", id, "method", "tools/call", "params", Tool("ka_revit_project_info", Args())));
                responses.Add(f.Engine.ProcessLineAsync(line, source.Token));
            }
            Equal(8, f.Calls);
            Equal(true, Result(f.Call("ka_revit_project_info", Args()))["isError"]);
            Equal(8, f.Calls);
            source.Cancel();
            foreach (var response in responses) Equal(true, Result(response.GetAwaiter().GetResult())["isError"]);
        }
    }

    private static void InvalidBackendResults()
    {
        foreach (string payload in new[] { null, "", "{invalid", new string('x', 1048577) })
        {
            var f = new Fixture(); f.Response.PayloadJson = payload;
            Equal(true, Result(f.Call("ka_revit_project_info", Args()))["isError"]);
        }
        var empty = new Fixture(); empty.Response = null;
        Equal(true, Result(empty.Call("ka_revit_project_info", Args()))["isError"]);
    }

    private static void OversizedInput()
    {
        var f = new Fixture();
        var input = Request("tools/call", Tool("ka_revit_project_info", Args("padding", new string('x', 65536))));
        var reply = Object(Json.DeserializeObject(f.Send(input)));
        Assert(reply.ContainsKey("error"), "Oversized input was not rejected"); Equal(0, f.Calls);
    }

    private static void InvalidConnections()
    {
        string directory = Path.Combine(Path.GetTempPath(), "ka-mep-connection-tests-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(directory);
        string path = Path.Combine(directory, "connection.json");
        try
        {
            var bridge = new ConnectionFileBridge(path);
            var request = new McpWireRequest { Protocol = 1, RequestId = "safe-id", Tool = "ka_revit_project_info", Arguments = new McpArguments { Limit = 50 } };
            var records = new List<string> { null, "{", new string('x', 16385), "{\"protocol\":1,\"protocol\":1}" };
            foreach (string token in new[] { "x", new string('a', 63), new string('a', 65), new string('z', 64) })
                records.Add(Json.Serialize(Args("protocol", 1, "port", 12345, "processId", 123, "token", token)));
            records.Add(Json.Serialize(Args("protocol", 1, "port", 0, "processId", 123, "token", new string('a', 64))));
            foreach (string record in records)
            {
                if (record != null) File.WriteAllText(path, record);
                var response = bridge.CallAsync(request, CancellationToken.None).GetAwaiter().GetResult();
                Equal(false, response.Success); Equal("connection_unavailable", response.ErrorCode);
                Assert(!response.Error.Contains(directory), "Connection path leaked through an error");
            }
            bool rejected = false;
            try { ConnectionFileBridge.ValidatePath("relative.json"); } catch (ArgumentException) { rejected = true; }
            Assert(rejected, "Relative connection path was accepted");
        }
        finally { Directory.Delete(directory, true); }
    }

    private static Dictionary<string, object> Initialization(string version)
    { return Args("protocolVersion", version, "capabilities", Args(), "clientInfo", Args("name", "KA MEP tests", "version", "1.0")); }
    private static string Request(string method, object parameters = null)
    { var value = Args("jsonrpc", "2.0", "id", 1, "method", method); if (parameters != null) value["params"] = parameters; return Json.Serialize(value); }
    private static string Notify(string method, object parameters = null)
    { var value = Args("jsonrpc", "2.0", "method", method); if (parameters != null) value["params"] = parameters; return Json.Serialize(value); }
    private static Dictionary<string, object> Tool(string name, object arguments)
    { return Args("name", name, "arguments", arguments); }
    private static Dictionary<string, object> Args(params object[] pairs)
    { var value = new Dictionary<string, object>(); for (int i = 0; i < pairs.Length; i += 2) value.Add((string)pairs[i], pairs[i + 1]); return value; }
    private static Dictionary<string, object> Object(object value)
    { var result = value as Dictionary<string, object>; Assert(result != null, "Expected JSON object"); return result; }
    private static object[] Array(object value)
    { var result = value as object[]; if (result != null) return result; var list = value as ArrayList; Assert(list != null, "Expected JSON array"); return list.ToArray(); }
    private static Dictionary<string, object> Result(string response)
    { Assert(response != null, "Response missing"); var envelope = Object(Json.DeserializeObject(response)); Equal("2.0", envelope["jsonrpc"]); Assert(!envelope.ContainsKey("error"), "Unexpected JSON-RPC error: " + response); return Object(envelope["result"]); }
    private static string Text(Dictionary<string, object> result)
    { return (string)Object(Array(result["content"])[0])["text"]; }
    private static void Error(int code, string response)
    { Assert(response != null, "Expected error response"); var envelope = Object(Json.DeserializeObject(response)); Equal("2.0", envelope["jsonrpc"]); Assert(envelope.ContainsKey("error"), "Expected JSON-RPC error: " + response); Equal(code, Object(envelope["error"])["code"]); }
    private static void Invalid(Fixture fixture, string tool, Dictionary<string, object> arguments)
    { Error(-32602, fixture.Call(tool, arguments)); Equal(0, fixture.Calls); }
    private static void Equal<T>(T expected, T actual)
    { Assert(EqualityComparer<T>.Default.Equals(expected, actual), "Expected " + expected + "; got " + actual); }
    private static void Assert(bool value, string message)
    { if (!value) throw new InvalidOperationException(message); }
    private static void Run(string name, Action action)
    { try { action(); passed++; Console.WriteLine("PASS " + name); } catch (Exception ex) { failed++; Console.WriteLine("FAIL " + name + ": " + ex.Message); } }

    private sealed class Fixture
    {
        internal readonly McpProtocolEngine Engine;
        internal int Calls;
        internal McpWireRequest Last;
        internal CancellationToken LastToken;
        internal Exception Failure;
        internal bool Hold;
        internal bool ThrowOnCancellation;
        internal McpWireResponse Response = new McpWireResponse { Success = true, PayloadJson = "{\"projectKey\":\"demo-project\",\"title\":\"Demo model\"}" };
        internal Fixture(bool initialize = true)
        {
            Engine = new McpProtocolEngine(Backend);
            if (initialize) { Send(Request("initialize", Initialization("2025-11-25"))); Send(Notify("notifications/initialized")); }
        }
        internal string Call(string name, Dictionary<string, object> arguments)
        { return Send(Request("tools/call", Tool(name, arguments))); }
        internal string Send(string line, CancellationToken token = default(CancellationToken))
        { return Engine.ProcessLineAsync(line, token).GetAwaiter().GetResult(); }
        private Task<McpWireResponse> Backend(McpWireRequest request, CancellationToken token)
        {
            Calls++; Last = request; LastToken = token;
            if (Failure != null) throw Failure;
            if (!Hold) return Task.FromResult(Response);
            var pending = new TaskCompletionSource<McpWireResponse>();
            token.Register(() => pending.TrySetCanceled());
            if (ThrowOnCancellation) token.Register(() => { throw new InvalidOperationException("Backend cancellation callback failed"); });
            return pending.Task;
        }
    }
}
