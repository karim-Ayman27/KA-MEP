# MCP companion tests

Build the .NET Framework 4.8 executable harness with the repository SDK:

```sh
dotnet build tests/McpServer.Tests/McpServer.Tests.csproj -c Release
```

On Windows, run `tests/McpServer.Tests/bin/Release/net48/KAMEP.McpServer.Tests.exe`. On Linux, run that executable with Mono and the runtime environment used by the repository's .NET Framework layout harnesses.

The harness injects the companion's bridge delegate. It covers MCP lifecycle/version negotiation, request identity, strict JSON-RPC validation, notifications, the exact six read-only tool schemas, argument boundaries, project scoping, string-encoded 64-bit IDs, tool errors, cancellation propagation and message size limits. It does not create Revit API stubs or claim to validate Autodesk behavior.

Run the actual executable's stdio checks separately:

```sh
python3 tests/McpServer.Tests/stdio_integration.py src/KAMEP.Mcp.Server/bin/Release/net48/KAMEP.Mcp.Server.exe --runtime /path/to/mono
```

On Windows omit `--runtime`. The Python harness starts the real companion with a temporary, absent connection-file path and verifies UTF-8 newline JSON, protocol-only stdout, normal unavailable-bridge tool errors, error recovery, bounded input, clean EOF and invalid command-line rejection. It does not require a Revit installation, API credentials, internet access, or an external service. Live Revit and Claude Desktop checks remain separate release gates.
