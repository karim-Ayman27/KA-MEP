#!/usr/bin/env python3
"""Exercise the real companion process without Revit, API credentials or external services."""

import argparse
import json
import os
from pathlib import Path
import queue
import subprocess
import tempfile
import threading


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def rpc(method, request_id=None, params=None):
    value = {"jsonrpc": "2.0", "method": method}
    if request_id is not None:
        value["id"] = request_id
    if params is not None:
        value["params"] = params
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


class Companion:
    def __init__(self, command, connection):
        self.process = subprocess.Popen(
            command + ["--connection-file", str(connection)],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding="utf-8", bufsize=1)
        self.lines = queue.Queue()
        self.errors = []
        self.stdout_thread = threading.Thread(target=self._read_stdout, daemon=True)
        self.stderr_thread = threading.Thread(target=self._read_stderr, daemon=True)
        self.stdout_thread.start()
        self.stderr_thread.start()

    def _read_stdout(self):
        for line in self.process.stdout:
            self.lines.put(line)
        self.lines.put(None)

    def _read_stderr(self):
        for line in self.process.stderr:
            self.errors.append(line)

    def send(self, line):
        self.process.stdin.write(line + "\n")
        self.process.stdin.flush()

    def response(self, request_id):
        try:
            line = self.lines.get(timeout=10)
        except queue.Empty:
            raise AssertionError("Companion did not respond within 10 seconds")
        check(line is not None, "Companion closed stdout unexpectedly: " + "".join(self.errors))
        check(not line.startswith("\ufeff"), "Stdout must not contain a UTF-8 BOM")
        value = json.loads(line)
        check(value["jsonrpc"] == "2.0", "Stdout contains non-protocol output")
        check(value.get("id") == request_id, "Unexpected response ID or notification response")
        return value

    def close(self):
        if self.process.stdin and not self.process.stdin.closed:
            self.process.stdin.close()
        try:
            code = self.process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait()
            raise AssertionError("Companion did not exit within 5 seconds after EOF")
        self.stdout_thread.join(timeout=2)
        self.stderr_thread.join(timeout=2)
        check(code == 0, "Companion exit code: " + str(code) + " stderr: " + "".join(self.errors))
        remaining = []
        while not self.lines.empty():
            value = self.lines.get_nowait()
            if value is not None:
                remaining.append(value)
        check(not remaining, "Unsolicited protocol output: " + repr(remaining))

    def kill(self):
        if self.process.poll() is None:
            self.process.kill()
            self.process.wait()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("server", type=Path, help="Built KAMEP.Mcp.Server.exe")
    parser.add_argument("--runtime", help="Mono executable when not running on Windows")
    args = parser.parse_args()
    command = ([args.runtime] if args.runtime else ([] if os.name == "nt" else ["mono"])) + [str(args.server.resolve())]
    cases = 0
    with tempfile.TemporaryDirectory(prefix="kamep-mcp-stdio-") as directory:
        # No listener is created: unavailable Revit must be a normal MCP tool failure.
        connection = Path(directory) / "unavailable-connection.json"
        child = Companion(command, connection)
        try:
            child.send(rpc("initialize", 1, {
                "protocolVersion": "2025-11-25", "capabilities": {},
                "clientInfo": {"name": "stdio-integration", "version": "1.0"}}))
            value = child.response(1)
            check(value["result"]["protocolVersion"] == "2025-11-25", "Initialization failed")
            cases += 1
            print("PASS real process initialization and UTF-8 protocol-only stdout")

            child.send(rpc("notifications/initialized"))
            child.send(rpc("notifications/cancelled", params={"requestId": "absent"}))
            child.send(rpc("ping", "ping-اختبار"))
            check(child.response("ping-اختبار")["result"] == {}, "Ping failed")
            cases += 1
            print("PASS notifications produce no output and Unicode request IDs survive stdio")

            child.send(rpc("tools/list", 3))
            tools = child.response(3)["result"]["tools"]
            check(len(tools) == 6, "Unexpected tool count")
            check(all(t["annotations"]["readOnlyHint"] is True for t in tools), "Mutable tool advertised")
            cases += 1
            print("PASS real process advertises exactly six read-only tools")

            child.send(rpc("tools/call", 4, {"name": "ka_revit_project_info", "arguments": {}}))
            error = child.response(4)["result"]
            check(error["isError"] is True and error["content"][0]["type"] == "text", "Unavailable bridge was not a tool error")
            cases += 1
            print("PASS unavailable Revit produces structured tool error without ending the process")

            child.send(rpc("resources/list", 5))
            check(child.response(5)["error"]["code"] == -32601, "Unknown method not rejected")
            child.send('{"jsonrpc":')
            check(child.response(None)["error"]["code"] == -32700, "Malformed JSON not rejected")
            child.send(rpc("ping", 6))
            check(child.response(6)["result"] == {}, "Protocol did not recover after invalid JSON")
            cases += 1
            print("PASS protocol errors are isolated and subsequent requests still succeed")

            child.process.stdin.buffer.write(b'\xff\xfe\n')
            child.process.stdin.buffer.flush()
            check(child.response(None)["error"]["code"] == -32700, "Invalid UTF-8 was not rejected")
            child.send(rpc("ping", "after-invalid-utf8"))
            check(child.response("after-invalid-utf8")["result"] == {}, "Protocol did not recover after invalid UTF-8")
            cases += 1
            print("PASS invalid UTF-8 input is rejected and the next request still succeeds")

            child.send(rpc("ping", 7, {"padding": "x" * 70000}))
            check("error" in child.response(None), "Oversized input was not rejected")
            child.send(rpc("ping", 8))
            check(child.response(8)["result"] == {}, "Protocol did not recover after oversized line")
            cases += 1
            print("PASS oversized stdio input is bounded and the following line remains usable")

            child.close()
            cases += 1
            print("PASS clean EOF exits promptly with no unsolicited stdout")
        finally:
            child.kill()

        invalid = subprocess.run(command + ["--connection-file", "relative.json"],
                                 capture_output=True, text=True, encoding="utf-8", timeout=10)
        check(invalid.returncode != 0, "Relative connection file path was accepted")
        check(invalid.stdout == "", "Command-line diagnostics contaminated stdout")
        check(bool(invalid.stderr.strip()), "Invalid command line has no diagnostic")
        cases += 1
        print("PASS invalid relative connection path fails with stderr diagnostics only")

    print("RESULT: " + str(cases) + "/" + str(cases) + " MCP stdio subprocess cases passed.")


if __name__ == "__main__":
    main()
