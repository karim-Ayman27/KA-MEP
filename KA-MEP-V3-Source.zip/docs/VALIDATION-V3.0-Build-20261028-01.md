# KA MEP V3.0 — Clash Manager and opening Size validation

Development build **3.0.0+20261028-01**, checked **2026-10-29**. This records source/DLL checks, not a released installer. **No V3 installer was created or published.** Native Windows, Revit and desktop Excel acceptance testing remains pending.

## Implemented behavior

- HVAC opening details and the Excel `Openings` sheet now include **Size (W × H)** beside numeric width, height and nominal area. The form follows its m/mm choice; the workbook labels opening dimensions in metres. Missing or invalid dimensions remain unknown and do not manufacture zero area.
- **Clash Manager** is available in the Model ribbon and Hub. It reads local HTML text through Browse or drag/drop, recognizes supported Revit/Navisworks report layouts and offers manual table/column mapping when automatic detection cannot import the report. It never hosts the HTML in a browser. Imported fields and status remain separate from current Revit results.
- The modeless form supports search, test/status filters, source choices for each element, Refresh visible/selected, cancellation between batches, pair details, 3D focus and fixed-footer Excel export. Revit operations run in a document-bound ExternalEvent; queued checks and stale model results become Unchecked immediately.
- Element resolution checks exact Element ID/UniqueId and host/direct-link identity. Repeated links, ambiguous/missing/unloaded sources, contradictory categories and changed identity pins need review. Source paths are not reduced to basenames when a path was supplied. Link placements use UniqueId-based keys.
- Current **Hard** checks use valid, complete model solids in host coordinates, including contextual/nonvisible geometry, with a 1 mm³ intersection-volume tolerance from the UI. Unsupported/incomplete geometry and failed Boolean operations need review. Missing elements are never assumed solved. Unknown criteria need explicit opt-in; Clearance and Duplicate remain unsupported.
- Focus creates/reuses only the tool's own 3D inspection view, applies a section box and optional temporary isolation, and attempts zoom-to-fit. For linked elements, isolation targets their whole containing link instances. Focus changes view state, not MEP geometry; import/check/export do not edit model elements.
- The formatted clash workbook contains **Summary, Clashes, Info**, status colors/text, exact text identifiers, check basis/time, reported and resolved provenance, filters, frozen headings and print settings. Totals follow exported visible rows; selection alone does not restrict export. Exports preserve the previous destination if validation or final replacement fails.

## Completed checks

| Check | Result |
| --- | --- |
| Opening dimensions/association/quantity policy | 124 assertions |
| HVAC five-sheet Excel including Size | 148 assertions |
| Clash three-sheet Excel | 129 assertions |
| Clash source/identity/criterion/volume policy | 91 assertions; native API geometry is outside this test |
| HTML import | 270 assertions across 14 groups; zero failures |
| Production HVAC form, detached Mono/Xvfb | 9/9 viewport/font-scale cases |
| Production Clash Manager and mapping form, detached Mono/Xvfb | 9/9 viewport/font-scale cases, including filters, source remapping, statuses, refresh/export events, cancellation and all 18 mapping fields |
| Production Hub/Setup presentation | 3/3 paired cases at 100/150/200%; all ten Hub launchers reachable; no installer operation invoked |
| Revit reference builds | 6/6 final targets; zero warnings/errors |
| Assembly identity/API/runtime inspection | Matching RevitAPI/RevitAPIUI major versions, runtime, build identity and new/retained feature classes in all six DLL pairs |
| Independent workbook read | Both sample ZIPs/openpyxl loads valid; expected five/three sheets, filters, freezes and landscape settings; no formula cells |

The UI matrix uses 1366×728 at 100%, 1280×680 at 150/200%, and 1024×600 and 876×571 at 100/150/200%. It uses the actual detached production forms with explicit font/control scaling; it is not native Windows DPI testing. Initial failed layout logs are retained. Final Clash results, source details and mapping screenshots were visually reviewed. A separate exploratory Spaces horizontal-scroll screenshot check was not completed after scope was narrowed to Clash Manager; it is not counted as passed and does not replace the nine-case production-form result. An initial Hub runner hit its 50-second timeout while concurrent UI cases were running; rerunning with a 180-second per-case bound completed all three paired cases without a product change.

The controller also received an independent source audit of document binding, immediate invalidation, cancellation, queued event closure and focus suppression. No confirmed controller defect remained; source review is not native callback-order validation.

| Revit target | Runtime |
| --- | --- |
| 2022.1+ / 2023 / 2024 | .NET Framework 4.8 |
| 2025 / 2026 | .NET 8 Windows |
| 2027 | .NET 10 Windows |

Evidence lives in [validation-v3-clashes-20261028-01](validation-v3-clashes-20261028-01/). The prior HVAC-only DLLs were preserved before current builds in `artifacts/development/KA-MEP-V3-HVAC-Build-20261026-01-DLLs.zip`. The [prior HVAC validation](VALIDATION-V3.0-Build-20261026-01.md) remains unchanged.

## Limits requiring native acceptance

No user RVT or genuine user-generated HTML report was available. HTML tests use synthetic, documented fixtures for representative layouts, not a claim that every producer version is supported. Real reports may need manual mapping or a parser extension. Revit geometry extraction, reflections, Boolean results, view transactions, modeless event ordering and every exact Revit release still require the [pending native checklist](CLASH-MANAGER-SMOKE-TEST.md).

The check is a supported volumetric hard-intersection test, not Navisworks criterion equivalence or a distance-clearance check. It excludes nested links. A numeric-only report cannot prove that an ID was reused before the first resolved UniqueId pin; review sources and prefer UniqueIds when available. Category-language differences conservatively require review. Current statuses are session-based and must be refreshed after model changes; exported Excel is a static snapshot.

Existing HVAC limits remain: heights are sampled physical clearances, not certified whole-room extrema; areas of openings are nominal width × height, not net glazing. Missing/incomplete sources remain distinguishable from verified zero. Linux fallback fonts do not establish native Windows Arabic rendering. The [Spaces checklist](HVAC-SPACES-SMOKE-TEST.md) and Excel visual/print checks remain pending.

## Publisher and preserved release boundary

Assembly Company/Authors and add-in VendorDescription already name **Karim Ayman**. The user confirmed no code-signing certificate is available. Therefore the DLLs remain unsigned and **Unknown Publisher has not been resolved**. Trusted publisher identity requires Authenticode signing using a trusted certificate issued with the intended publisher name; metadata cannot replace that step. Signing preparation is documented in [SIGNING.ar.md](SIGNING.ar.md). No certificate was generated, private key requested, root trust installed or file signed here.

The existing V2 installer is unchanged: **2,183,680 bytes**, SHA256 `5425faa33b8f11ad9a79e7e348ade185189f7928a79dafb0ffa5d296a22338ac`. Its [release validation](VALIDATION-V2.0-Build-20261024-01.md) and source checkpoint remain preserved. **Do not build a V3 installer until the user explicitly requests it.**
