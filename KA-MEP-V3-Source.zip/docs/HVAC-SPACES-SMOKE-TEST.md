# V3 HVAC Spaces — manual Revit and Excel smoke-test checklist

**Status: procedure only; not executed by this document.** Empty boxes are pending checks, not passes. Build/unit-test evidence must be recorded separately; it does not establish Revit runtime or Excel compatibility. The V3.0 / Build 20261030-01 package includes this feature; packaging does not imply native acceptance.

Use a disposable copy of the fixture with the intended V3 DLL loaded for the exact Revit version. The published V2 installer does not contain HVAC Spaces. Repeat runtime checks for each Revit version intended for release; the source has separate 2022–2027 targets (2022 API baseline is 2022.1).

## Run record

| Field | Record before running |
| --- | --- |
| Tester / date | Pending |
| Revit version / full build | Pending |
| Add-in version / build / DLL hash | Pending |
| Host / architecture fixture paths or hashes | Pending |
| Host Phase → mapped linked Phase | Pending |
| Link placement / transform / IDs | Pending |
| Display resolution / scaling | Pending |
| Excel version / build (or other viewer) | Pending |
| Export paths / screenshots / notes | Pending |
| Overall outcome / failures | Not run |

Record actual values, source element IDs and failures beside each expected result. Do not mark a test passed solely because a workbook or dialog opens.

## Fixture setup

Prepare a host MEP file with three enclosed Spaces, named and numbered differently from their matching architectural Rooms. Include leading-zero Room numbers such as `001` and an Arabic Room name. Use a directly loaded architecture link with a known nonidentity translation/rotation and explicit Phase Mapping. Keep all baseline elements in the main model or primary design option. Verify all baseline Doors/Windows have valid phase-specific Room associations; one unassociated source opening can make that source's counts unknown.

| Baseline Room | Host Space | Geometry and openings | Expected baseline quantities |
| --- | --- | --- | --- |
| A / `001` | `S-101`, different name | Floor top +0.10 m; ceiling underside +3.10 m; overhead slab underside +3.60 m. One shared door to B, 0.90 × 2.10 m; one window 1.20 × 1.50 m. | 3.00 m sampled ceiling clearance; 1 door / 1.89 m²; 1 window / 1.80 m². |
| B / `002` | `S-102`, different name | Floor top +0.10 m; no ceiling; nearest overhead slab underside +3.60 m. Shared A–B door only. | 3.50 m sampled slab clearance; 1 door / 1.89 m²; 0 windows / 0 m². |
| C / `003` | `S-103`, different name | Same flat floor/ceiling as A, no associated doors or windows. | 3.00 m sampled clearance; verified 0 counts and 0 nominal areas. |

Use equivalent elevations after applying the link transform; check physical elevations in a section. Make Room A and its host Space areas deliberately different by changing a host Space boundary, while keeping all interior sample points within Room A. Record the expected **Space** area from a Revit Space schedule. Keep the shared door and window dimension parameters available as built-in length parameters.

Create fixture variants or reset between edits. Keep the baseline intact so one failure condition does not mask another.

## Open, select sources, and scan

- [ ] With no project or with a family document, the command offers an appropriate project requirement and does not fail unexpectedly.
- [ ] `KA MEP → HVAC → HVAC Spaces` opens the V3 dialog. The default includes linked sources and excludes host sources; one loaded link is selected automatically.
- [ ] Choose the baseline phase/link and run `Scan / Refresh`. The three host Spaces appear once each; architectural Rooms do not create additional Space rows.
- [ ] Room and Space names/numbers stay separate. Areas equal the host Space schedule, including the deliberately different Room A area.
- [ ] Sources report the correct document, link instance, element ID and mapped phase. Translated/rotated placement gives the same physical distances as the reference section.
- [ ] Model, active-view and selection scopes include only the intended host Spaces. Other selected categories and linked Space elements are not treated as host Spaces.
- [ ] Hiding a relevant floor/ceiling in the active view does not silently change the geometry source scope. The view option filters Spaces.
- [ ] Change a scan option after a successful scan. Export becomes unavailable until a fresh scan. Changes to result filters or display units do not require another scan.
- [ ] Closing or cancelling a save dialog leaves the model untouched. Confirm no new model transaction/Undo operation resulted from scanning or exporting.

## Physical heights and coverage

- [ ] Baseline A reports 3.00 m with `Ceiling underside`; B reports 3.50 m with `Slab underside`. Verify sample source element IDs and physical floor/overhead elevations.
- [ ] Add a ceiling above B's intervening slab. B still uses the nearer slab underside, not the ceiling of the next storey.
- [ ] Give a Space an analytical upper limit/height different from its physical surfaces. The tool still uses physical faces; it does not substitute the Space height or volume/area.
- [ ] Add a valid positive Space base offset while keeping the physical floor inside the configured search band. Check the result remains a physical floor measurement when containment is valid.
- [ ] Split a floor into a structural slab plus a touching/overlapping finish Floor. Use the highest verified connected top. Add a detached floor/mezzanine within the search band and confirm ambiguity is flagged rather than silently accepted.
- [ ] Use a sloping ceiling/floor with sampled variation greater than 20 mm. The single clear height is blank; sampled min/max and `Variable height` remain visible.
- [ ] Use a small sampled variation within the tolerance. A complete consistent result uses the minimum sampled height, not its average.
- [ ] Cover only part of a Room with a ceiling, leaving the rest under a slab. With samples on both extents, expect mixed basis, review status and blank single height.
- [ ] Remove a floor or overhead surface at some samples. Expect partial measurement and retained successful sample range, with a blank single height.
- [ ] Remove all floor or overhead coverage, or make it fall outside the configured search band. Expect the matching missing-surface status and unknown values, never a fabricated zero or analytical fallback.
- [ ] Where a geometry read failure can be reproduced, verify source notes identify incomplete coverage and retained samples cannot produce a complete single-height claim.
- [ ] Test an unplaced Space, unenclosed Space, narrow/concave Space and a Space with a hole. Check explicit statuses and that sampled points are interior. Dense/complex boundaries that hit a sampling limit must remain partial/reviewable.
- [ ] Test a curved face if available. Verify mesh approximation is disclosed; do not treat sampled min/max as certified extrema.
- [ ] Verify beams, Roof elements, ducts and imported/DirectShape geometry do not become unsupported clearance surfaces.

## Room matching, phases and links

- [ ] Room A's verified identity is preserved even when its ceiling is unavailable; opening quantities can still be complete independently of height.
- [ ] Set linked Room Base Offset to +0.20 m and host Space Base Offset to 0, with both enclosing the higher interior probes. Verify the Room is found at a valid interior elevation even though the lowest probe lies below its base. Physical height still has one measurement per XY column.
- [ ] Make a tall host Space span two vertically stacked linked Rooms at the same XY. Ensure lower and upper interior probes fall inside their respective Rooms. Expect an ambiguous Room association and blank complete opening counts, not a verified lower Room alone. Record all Room IDs and probe elevations.
- [ ] Overlap two architectural Rooms/link placements at a Space's samples. Expect ambiguous Room fields/notes and unavailable complete opening counts.
- [ ] Remove a unique matching Room but retain stored associated-Room text on the Space. Any displayed fallback text is labelled unverified; complete opening counts stay blank.
- [ ] Introduce another phase with reused Room numbers and created/demolished openings. Confirm only the selected host phase and actual mapped linked phase participate; no last-phase or name-only substitution.
- [ ] Break the link phase map or make the selected source unavailable. Confirm the failure/incomplete-source state is explicit and quantities are not presented as verified zeros.
- [ ] Use two direct placements of the same link at different locations. Each placement retains its own physical source identity and independent opening totals.
- [ ] Include an unloaded link in `All loaded direct Revit Links`. Verify its exclusion is documented; completion applies only to the loaded direct-link scope.
- [ ] Include a nested architectural/structural link. Verify nested links are excluded and noted. Then load it directly in the host and verify the intended source can participate.
- [ ] Add relevant elements in a nonprimary design option. Verify exclusion and compare the main/primary result explicitly.

## Door/window counts, dimensions and unknowns

- [ ] Baseline rows match the quantity table. A shared door appears once per associated Room/Space and is flagged shared.
- [ ] Baseline `Summary` has 2 observed door Room associations, 3.78 m² associated known door area, **1 unique door / 1.89 m²**, and **1 unique window / 1.80 m²**.
- [ ] Link a second Space to the same Room. Room quantities repeat for the associated Space rows; overall unique opening totals still count the physical opening once.
- [ ] Add an exterior opening with one valid Room side and a null exterior side. Confirm it is associated once, without an invented outside Room.
- [ ] Test valid type dimensions and valid instance overrides separately. Instance length values take precedence; type length values are used where instance values are unavailable/invalid. Verify metres and square metres against Revit dimensions.
- [ ] Inspect `Size (W × H)` for each opening alongside its numeric width, height and nominal area. The baseline door reads `0.9 × 2.1 m` and changes to `900 × 2100 mm` in the UI when millimetres are selected. Add a differently sized opening in the same Room and confirm both individual sizes remain visible.
- [ ] Give an otherwise associated opening a missing/nonpositive dimension or only an unsupported custom dimension parameter. Its count remains known when association coverage is complete; its area and its category's complete area are blank. The known-area subtotal excludes it and missing-dimension count increases.
- [ ] Check one and then both missing dimensions in the UI and Excel `Size (W × H)` column. Each unavailable dimension reads `Unknown` (for example `Unknown × 2.1 m`), never zero; numeric missing dimensions and nominal area remain blank.
- [ ] Do not accept Bounding Box extents, unitless parameters or glazing/frame parameters as nominal width/height substitutes.
- [ ] Create an opening with no phase-specific FromRoom/ToRoom/Room association. Source notes expose it; complete counts/areas for affected source Rooms become blank, while known details/subtotals remain. Zero is reserved for a verified empty category.
- [ ] Where reproducible, force a Room lookup/collection failure. Verify the scan remains explicitly incomplete; partial observed records do not become a complete inventory.
- [ ] Include nested door/window components. Verify exclusion notes and no parent/child double counting. Include a Generic Model/Curtain Panel shaped like a window and verify it is not silently counted as an OST_Windows family.
- [ ] Compare an opening's nominal rectangular width × height area to its actual glass/clear opening, including a nonrectangular family if available. `Size (W × H)` and the area do not claim a measured outline, net glass area or wall deduction.

## Filters, Excel contents and presentation

- [ ] `Needs review`, height, overhead and opening-completeness filters match the rows' actual states. Search and Level filters combine as expected.
- [ ] Export only Room A through the result filters. The workbook has one Space row; summary unique totals derive from that row. The shared door remains flagged shared even with Room B excluded.
- [ ] Restore all baseline results and select one grid row. Export still includes all visible rows, not just the selected detail row.
- [ ] Export in metres and millimetres. Clear/sample heights scale by 1000, while floor/overhead elevations, XY coordinates and opening width/height stay in metres; areas stay in m². The Excel `Openings` sheet keeps `Size (W × H)` in metres (baseline door `0.9 × 2.1 m`) with separate numeric `Width (m)` and `Height (m)` columns, even when the UI shows millimetres.
- [ ] Open the `.xlsx` in the recorded Excel version without a repair warning. Confirm the five sheets: `Spaces`, `Summary`, `Measurements`, `Openings`, `Info`.
- [ ] Compare every baseline quantity to the fixture schedule and physical dimensions. Check both complete totals and known-area subtotals in failure variants.
- [ ] Check names, Arabic text, leading-zero Room numbers and exact element/link IDs. Formula-like model names are displayed as text, not executed as formulas.
- [ ] `Measurements` contains per-sample results and sources only for exported Spaces. `Openings` contains one row per exported Space–opening association, with source identity and dimension notes.
- [ ] `Info` records source scan timestamp, V3 build, scope, filters, method and coverage notes. Source-scan counts may include excluded Rooms/unassociated openings and must not be added to Summary.
- [ ] Verify heading/first-column freezing, filters, number formats, text wrapping, widths and print preview. Long names/source notes should remain inspectable. Check a narrow window and Windows scaling at 100%, 150% and 200% for accessible buttons, tabs and scrollbars.
- [ ] Apply an Excel filter after export: stored Summary remains a static total of the originally exported rows. Record that behaviour rather than expecting live recalculation.
- [ ] Save cancellation, a locked existing workbook and an unwritable destination produce clear outcomes without reporting a successful export or damaging an existing report.

## Evidence and release boundary

Attach screenshots of baseline results, partial/unknown cases, source details and workbook sheets; include the exported files and their hashes. Record every deviation, environment limitation and unexecuted case. A passed source build or headless layout check does not replace these in-Revit/Excel checks.

This procedure ends with reviewable DLL/runtime evidence. The current source/installer packaging was explicitly requested by the user. Preserve the existing V2 release artifacts and their recorded history.
