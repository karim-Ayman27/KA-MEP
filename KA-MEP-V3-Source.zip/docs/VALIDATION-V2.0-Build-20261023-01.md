# KA MEP V2.0 — black installer file icon

Completed 2026-10-23. Public version **V2.0**, build **20261023-01**.

Installer: `artifacts/KA-MEP-Setup-V2.0-Full-2022-2023-2024-2025-2026-2027-Build-20261023-01.exe`  
Size: **2,055,168 bytes**  
SHA256: `ede58924f1420153430cd92c5ba775c64ad6e1db405b26932603c8f63e22119f`

The only visual change is the installer EXE file icon: it is now black with transparent background. `installer/Setup.ico` preserves every frame's alpha, dimensions and masks from the white icon. The embedded white logo, shared window icon, installer header and Revit UI assets are unchanged. Their hashes match the prior white-logo evidence. No application behavior or installer logic changed; the build identity was advanced to distinguish the new download.

All six Revit releases and the installer compiled with zero warnings/errors. Package verification inspected the actual Windows `RT_GROUP_ICON` resources: all seven frames match the black icon. It also verified that the white internal ICO and PNGs remain embedded, the six release DLL pairs match the exact 14-file payload, and every payload assembly has the current build identity and retained features.

The current-payload installer engine suite passed **194 checks**. An isolated upgrade from the actual previously shipped Build 20261022-01 payload passed **89 checks**, including current bytes/identity for all six Revit years and preservation of registration paths and unrelated add-ins. The baseline ZIP was confirmed to be present byte for byte in the previous EXE. Historical packages remain available and were not overwritten.

Evidence: `validation-installer-20261023-01/`. Prior broader installer/script tests are preserved in `VALIDATION-V2.0-Build-20261022-01.md`; unchanged functional suites and UI layout cases were not repeated for this icon-only change.

Checks ran under Linux and isolated filesystem fixtures. Native Windows/Revit execution was not tested here. Revit 2022 requires 2022.1 or a later 2022 update. To install or update, close Revit, run the new EXE and select **Install / update KA MEP** for the desired Revit versions; the installer runs per user without administrator elevation. Info should show **Version 2.0 | Build 20261023-01**.
