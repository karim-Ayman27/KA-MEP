# KA MEP V2.0 — Model Review & Cleanup validation

Completed 2026-10-21. Public version **V2.0**, assembly version **2.0.0**, build identity **20261020-02**.

**No installer EXE was exported for this work, as requested by the user.** Previous EXEs remain historical and do not contain these changes. Installer sources support the six-version selection; final embedded-payload/EXE and actual-payload upgrade checks must run when a new installer is requested.

## Current code and DLL checks

- All six final Revit builds passed with **zero warnings and errors**. References: 2022.1.1, 2023.0.1, 2024.0.0, 2025.0.2, 2026.0.4, 2027.0.0. Revit 2022–2024 target .NET Framework 4.8; 2025–2026 target .NET 8 Windows; 2027 targets .NET 10 Windows. Revit 2022.1 is the minimum verified reference level, not the original 2022 release.
- Independent PE metadata inspection verified each of the six Revit DLLs references the matching RevitAPI/RevitAPIUI major version and runtime. All contain the new Model Review command/controller/service/form and retained tools, and all Core DLLs contain the new Excel exporter and existing exporters. Every DLL has informational identity `2.0.0+20261020-02`. SHA256 receipts: `validation-model-review/assembly-receipt.json`.
- Model Review detached logic: **29 checks**, including 100 score-bound/monotonicity cases, partial-scan protection, explicit cleanup eligibility, stale selection keys, 64-bit element identities, and merging overlapping duplicate groups without double counting.
- Model Review Excel: **40 checks** covering the three worksheets, numeric score, partial-scan unavailable state, frozen headers, filters, print settings, Arabic text and exact identifiers, inert formula-like strings, atomic overwrite and failure cleanup.
- Existing regression suites rerun: **54 quantity/Excel/naming checks**, **20 Tag Assistant layout groups** (including 300 randomized cases), **23 Tag Assistant model cases**, and **39 Sheet Parameters model cases**. Console logs are in `validation-model-review/`.
- Model Review UI: **9/9 cases passed**, each exercising the production review window and cleanup confirmation. Cases: 1366×728 at 100%; 1280×680 at 150%/200%; 1024×600 and 876×571 at 100%/150%/200%. Tests cover filters, checked/hidden scope, review-only duplicates, score refresh/delta, incomplete scans, busy states, fixed actions, confirmation text, and all 180 deletion-preview rows. Screenshots at normal and smallest/high-scale sizes were visually reviewed. See `MODEL-REVIEW-LAYOUT-RESULTS.txt` and the layout test README.
- Hub/installer-source presentation: **3 paired cases / 6 forms passed** under Mono/Xvfb with the six version choices. This did not execute the Windows installer or create a distribution EXE.
- Installer script-source work previously passed **5,866 isolated filesystem assertions**, including all 63 non-empty year subsets. Final packaged installer checks are deliberately deferred because no new EXE/payload was exported.

## Implementation boundaries

Model Review is modeless and binds to one project. Revit access occurs only in the external command or ExternalEvent handler. Imported and linked CAD are separated; placed schedules and panel schedules are considered. Unplaced views are candidates, not errors. Duplicate findings are potential matches from native duplicate-instance warnings and rounded straight-MEP/point-family signatures. They are review-only, not automatic deletion targets.

Model Health is a disclosed KA MEP review score: 100 minus capped penalties for imported CAD, unplaced views, duplicate groups and other warnings. It is not an Autodesk rating or a performance/correctness guarantee. Partial scans show no score and cannot clean. Refresh recomputes counts/score; Excel exports the last scanned snapshot.

Cleanup targets only explicitly checked eligible CAD imports and unplaced views. Active/starting/template/primary-dependent views, pinned/grouped elements and other-user ownership are protected. A global DocumentChanged generation rejects stale scans/previews even for unsaved edits or Undo/Redo; any document change requires a fresh review. VersionGuid is only secondary metadata, not the in-session stale guard.

Deletion preview commits inside a rollback-capable TransactionGroup to measure the complete observed deletion set, including updater effects, then rolls the group back. Application checks the current selection and dependencies again, rolls back changed deletion scope or unexpected created elements, and assimilates an accepted operation into one Undo. The user sees the exact deleted-element list and must type DELETE and click the deletion button. Cancel refreshes the review and clears checks. This transaction behavior has been code-reviewed and compiled, but not exercised in live Revit here.

## Runtime limits

No native Windows/Revit runtime is available in this workspace. Loading in Revit, actual scanning and deletion, worksharing, external-event lifecycle, updater effects, transaction rollback/Undo, and live PDF/DWG exports remain subject to the manual checks in `MODEL-REVIEW-SMOKE-TEST.md` and `REVIT-SMOKE-TEST.md`. Mono explicit control/font scaling does not certify Windows per-monitor DPI or Revit-hosted rendering.

The prior packaged release's evidence remains in `VALIDATION-V2.0-Build-20261020-01.md`. Historical installer hashes and runtime statements do not apply to an unbuilt new installer.

## Reproduce without creating an installer

Use .NET SDK 10 with `scripts/Build.ps1 -UsePackageRevitApi`. Run the six console projects named above and the linked WinForms layout harness. Do not run `scripts/Build-Installer.ps1` until an installer is requested. The build and verification logs and assembly receipt are retained under `validation-model-review/`.
