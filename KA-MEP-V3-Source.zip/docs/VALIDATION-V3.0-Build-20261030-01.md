# KA MEP V3.0 — Build 20261030-01 validation

Checked **2026-11-01**; assembly identity **3.0.0+20261030-01**. The user explicitly requested the editable source ZIP and then a Windows installer. This build adds the **read-only Claude Desktop MCP connection** while retaining HVAC Spaces, Clash Manager and the earlier tools.

## Implemented and reviewed

The Revit ribbon/Hub exposes a connection window, disabled by default. Enable binds it to the selected project and starts an authenticated IPv4 loopback bridge. The MCP helper runs as a separate .NET Framework 4.8 stdio process and exposes six read-only tools. No public listener, arbitrary execution, edit tool or Claude API key is provided. Model data requested through tools reaches the Claude conversation.

Every Revit read executes through a bounded, document-bound ExternalEvent queue. A session projectKey guards other tool calls; switching to a different project rejects reads until the bound project is active again. Stop/close/document closure cancels queued requests and removes the per-year connection profile. Authentication rotates on re-enable. The local profile has an exclusive ownership lease and current-user Windows ACL; Stop cleanup no longer depends on parsing possibly damaged JSON. Cancellation is checked between bounded native reads, although a native API call itself cannot be interrupted.

The service returns project context, selection, category-filtered elements, parameters, sheets and warnings. It preserves 64-bit element identifiers as strings, keeps parameter names distinct, separates raw internal-unit values from formatted display values, and discloses bounded or truncated results. The first version reads host elements only; it lists direct-link metadata but does not inspect linked contents. Native warnings are materialized by Revit before bounded processing.

Protocol work corrected malformed connection-file handling, duplicate active JSON-RPC IDs, scalar/strict JSON errors and project-info link pagination. The companion implements initialize/version negotiation, initialized notification, ping, tools/list, tools/call, cancellation and bounded UTF-8 newline framing. Loopback messages are authenticated, length-prefixed and bounded; socket workers never read a Revit object.

## Completed checks

| Check | Result |
| --- | --- |
| Real loopback transport | **23/23** scenarios: auth, malformed/partial/oversized frames, correlation, four-worker bound, cancellation, disconnect, shutdown and real deadlines |
| MCP protocol engine | **37/37** cases: lifecycle, supported versions, exact tool schemas, arguments, IDs, errors, active request identity and cancellation |
| Actual helper stdio subprocess | **9/9** scenarios |
| Production MCP form under Mono/Xvfb | **9/9** viewport/font-scale cases, including actual rendered project-label glyph assertion; screenshots reviewed |
| Hub/Setup detached presentation | **3/3 paired cases** at 100/150/200%; eleven Hub launchers accessible; no installer operation invoked |
| Installer extraction/logic with the final embedded payload | **232** checks (pre-package logic subset: 163) |
| Install/uninstall script isolated-filesystem tests | **10,711** checks; production Windows guards retained |
| Revit API-reference builds | **6/6** targets, zero warnings/errors |
| Helper and test builds | Zero warnings/errors |
| Assembly inspection | All six DLL pairs have matching API references, target runtime, current build identity, new MCP classes and retained earlier tools |

The final helper's SHA256 is `318bd4c126b187e81ae93c7ba2ee7c1b05d60066b76bbdbfe3f762ed9fdaab20`; it was rebuilt after the connection-file error fix and copied to all six release roots. The Core DLL used by transport/protocol tests and helper matches the packaged release Core (`b4158e0d75ebfca3886ae591c618720393ee0ff5e1b89c9afda299fabf54357c`). The helper has no Revit API reference.

Evidence: [validation-v3-mcp-20261030-01](validation-v3-mcp-20261030-01/), including `build-all.log`, `assembly-receipt.json`, transport/server/stdio logs, `mcp-layout/`, Hub matrix, installer tests and subsequent package checks. Prior [Clash/Size evidence](VALIDATION-V3.0-Build-20261028-01.md) and [HVAC evidence](VALIDATION-V3.0-Build-20261026-01.md) remain historical records; their earlier no-installer boundary was superseded by the user's explicit packaging request.

## Packaging and native limits

Source packaging validates its manifest and every archived byte; it includes editable projects, assets, scripts, tests, docs and six current release folders. Installer packaging uses exactly **26 payload files**: two scripts and four files per Revit version (Revit/Core DLLs, MCP helper EXE and its runtime config). Package checks compare embedded inputs byte-for-byte, inspect build identity and the existing black external/ribbon and white internal logos. Final packaging verification passed: the EXE contains the exact 26 current files, all seven external icon frames and the expected internal/ribbon assets. The full embedded-payload tests passed 232 checks. The source ZIP was created before the installer and then finalized to include these completed packaging records.

**Native Windows/Revit, Claude Desktop and desktop Excel were not executed here.** API compilation, real local TCP/stdio tests and detached WinForms checks do not prove native API behavior, Windows ACLs, Revit callback ordering, actual Claude interoperability, model geometry or Excel print fidelity. The [MCP](MCP-SMOKE-TEST.md), [Clash](CLASH-MANAGER-SMOKE-TEST.md) and [Spaces](HVAC-SPACES-SMOKE-TEST.md) checklists remain pending. Revit 2022 requires Autodesk's 2022.1 update or later.

The new connection cannot edit the model, build families, generate tags or run arbitrary scripts. Numeric read values require their declared unit basis; paginated results must not be combined across changed projectKey/modelRevision values. Closing Claude Desktop is necessary before replacing its running helper during updates.

The files remain **unsigned** because no trusted code-signing certificate was supplied. Karim Ayman author/company/vendor metadata does not itself change Revit's Unknown Publisher trust prompt. No trust store was modified. The original V2 installer is preserved unchanged, SHA256 `5425faa33b8f11ad9a79e7e348ade185189f7928a79dafb0ffa5d296a22338ac`.
