# KA MEP V2.0 — Sheet Parameters release

Package date: 2026-10-20. Public label **Version 2.0**, assembly version **2.0.0**, build **20261020-01**.

Installer: `KA-MEP-Setup-V2.0-Full-2024-2025-2026-Build-20261020-01.exe`

SHA256: `123b3daf02eae0467aead81a480af75fd79f5256bc14518c6343238e2db87fba` (789,504 bytes).

## Current release checks

- Final builds for Revit 2024 (.NET Framework 4.8 x64), 2025 and 2026 (.NET 8 Windows x64), and the installer: **zero warnings and errors**. Matching compile-only API packages are 2024.0.0, 2025.0.2 and 2026.0.4. No Autodesk API binaries are distributed.
- Detached Sheet Parameters model: **39 checks passed**. Coverage includes staging without mutating originals, exact parameter identity even with duplicate names, checked-sheet scope, read-only protection, text/integer/Yes-No validation, unit-bearing input retention for Revit preflight, required names/numbers, final-number collisions and swaps/cycles, issued/cloud revision locks, batch eligibility, old/new review and reset.
- Sheet Parameters UI: **9/9 final cases passed**, each exercising the production main form and batch-value dialog. Viewports are 1366×728 at 100%, 1280×680 at 150%/200%, and 1024×600 and 876×571 at 100%/150%/200%. Tests cover actual text-editor interaction, Yes/No checkbox staging, persistent drafts/checks, duplicate-name identities, filtering, read-only rows, batch values and skipped targets, validation/correction, revision assignment, review/reset and accepting a valid draft. Footer buttons stay fixed; content remains scroll-reachable. Final standard and small/high-scale screenshots were visually reviewed, including actual cell text rendering. See `SHEET-EDITOR-LAYOUT-RESULTS.txt` and `tests/SheetEditorLayout.Tests/README.md`.
- Current Hub and installer branding layouts: **6 form cases passed** under Mono/Xvfb. Checked supplied logo assets, visibility, aspect preservation, Revit-version selection and fixed action buttons. Screenshots were reviewed.
- Existing quantity/Excel and sheet-naming regressions: **54 checks passed**, including V2.0 report branding. Existing Tag Assistant model checks: **23/23 passed**; layout engine: **20 groups passed**, including 300 randomized cases. No quantity, export or Tag Assistant behavior was intentionally removed.
- Final embedded installer payload: **58 C# checks passed**, covering supported-version selection, exact extraction and path validation.
- Production install/uninstall scripts: **384 checks passed** using isolated test directories. Coverage includes all seven non-empty version subsets, changed-byte replacement, preservation of unselected versions/unrelated files, and rollback after injected copied-file corruption. Only test copies have their Windows guard removed and AppData redirected.
- Actual-payload upgrade: **34 checks passed** installing the previous V1.0 payload and upgrading it with the final V2.0 payload in an isolated directory. Verified all six assembly versions/hashes, replacement of every old binary, equality with the new payload, unchanged registration identity/path for all three Revit years, and preservation of an unrelated add-in. This is not an execution test of the Windows installer UI or of Revit.
- Package verifier confirmed an x64 GUI EXE, embedded payload digest, exactly eight allowed files, byte-for-byte equality with current release outputs, and Version/Build identity in every assembly. The new Sheet Parameters command/service/form/model and the existing Tag Assistant, quantity/Excel and PDF/DWG classes are present in all three Revit builds.
- Branding verifier parsed actual Windows icon resources and checked all seven supplied-logo frames, plus embedded PNG/ICO resources in the installer and Revit assemblies. No external image files are needed.

## Implementation review

All model writes occur on the Revit command thread after the detached editor closes. The service revalidates parameter identity, raw-value fingerprints, data types, read-only/global-parameter state, sheet ownership and revision membership. Numeric values are parsed in project units. Sheet-number exchanges use temporary unique numbers inside the same transaction. Any rejected write or error-level Revit failure rolls back the batch; a successful batch has one Undo. Reporting distinguishes committed values from failures, and failed Apply attempts reopen the retained drafts for correction.

The editor targets sheet instance parameters, including sheet-bound Shared/Project Parameters. Current Revision is displayed as calculated/read-only. Revision controls assign existing additional revisions; issued and cloud-required assignments are protected by this tool. Global revision definitions, Title Block instance/type parameters and Project Information are outside this editor.

## Runtime limits and retained evidence

No native Windows/Revit runtime is available in this workspace. Actual parameter writes, unit parsing in a live document, worksharing behavior, revision schedules, transaction rollback/Undo and PDF/DWG exports need the checks in `REVIT-SMOKE-TEST.md`. Mono uses explicit font/control scaling and does not certify Windows per-monitor DPI or Revit-hosted rendering.

Earlier V1.0 evidence remains available for nine Tag Assistant UI cases and 60 takeoff UI cases; those suites were not rerun for this release. Their source behavior was retained. Example workbooks contain synthetic data.

## Reproduce

Run `scripts/Build.ps1 -UsePackageRevitApi`, then `scripts/Build-Installer.ps1`. Verify the result with `python3 scripts/Verify-Package.py` (Pillow required). Run the console projects under `tests/SheetEditor.Tests`, `tests/PipeTakeoff.Tests`, `tests/TagLayout.Tests`, `tests/TagAssistant.Tests` and `installer/tests/KAMEP.Setup.Tests.csproj`. Installer script checks use `installer/tests/ScriptTests.ps1`; the real-payload upgrade test is `installer/tests/UpgradePayloadSmoke.ps1 -BaselinePayload <previous-V1-payload.zip>`. UI harness instructions are in their respective README files.

See `SHEET-PARAMETERS.ar.md` for the user guide and the artifact JSON receipt for exact payload hashes.
