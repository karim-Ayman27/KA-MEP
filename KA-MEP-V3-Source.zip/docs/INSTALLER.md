> Build 20261023-01: أيقونة ملف EXE الخارجية سوداء؛ اللوجو داخل واجهة التثبيت وRevit يظل أبيض شفافًا. نتائج فحوص الحزمة موثقة في VALIDATION.md؛ التشغيل الأصلي على Windows/Revit لم يُختبر هنا.

# KA MEP Windows installer

`KA-MEP-Setup-V2.0-Full-2022-2023-2024-2025-2026-2027-Build-20261023-01.exe` is a single Windows executable containing the Revit 2022.1+, 2023, 2024, 2025, 2026 and 2027 add-in binaries and the same `Install.ps1` / `Uninstall.ps1` scripts included in the source release. The user does not need to extract a ZIP, install a SDK, download dependencies, or run a script manually.

## Install

1. Save your work and close Revit.
2. Run `KA-MEP-Setup-V2.0-Full-2022-2023-2024-2025-2026-2027-Build-20261023-01.exe` normally, using the Windows account that runs Revit.
3. Select any combination of Revit 2022.1+, 2023, 2024, 2025, 2026 and 2027. Only checked versions are changed. Leave **Install / update KA MEP** selected and click **Install KA MEP**.
4. Once setup reports success, start Revit and open **KA MEP → Workspace → KA MEP**. Open **Model Review & Cleanup** to inspect imported CAD, views not placed on sheets, and duplicate findings, then use **Refresh** to update the KA MEP health score. **Sheet Parameters** remains available directly from **KA MEP → Sheets → Sheet Parameters**, and Tag Assistant from **KA MEP → Annotation → Tag Assistant**. Pipe Takeoff, Duct Takeoff, Cable Tray Takeoff, Conduit Takeoff, Sheet Export, and Info remain available.

The installer writes only the selected versions' files under `%APPDATA%\Autodesk\Revit\Addins\<year>\`, with a separate folder for each selected year from 2022 through 2027. It is a per-user installer and requests no administrator rights. To uninstall, run the same EXE, select the Revit versions, choose **Uninstall KA MEP**, and click **Uninstall KA MEP**. It is not registered in Windows Apps & Features.

Windows 10/11 x64, .NET Framework 4.8, and Windows PowerShell 5.1 are required. The Revit 2022.1+, 2023 and 2024 builds use .NET Framework 4.8. Revit 2025 and 2026 provide the .NET 8 runtime; Revit 2027 provides .NET 10. The installer itself uses .NET Framework 4.8. Revit 2022 must have the Autodesk 2022.1 update or a later 2022 update installed. The EXE is currently unsigned.

The public release label is **V2.0** (assembly version 2.0.0). This installer updates earlier KA MEP V1.0 and V2.0 packages in place using the same add-in identity, install locations, and per-user registration. The current build is **20261023-01**, visible in Setup, Workspace and Info. Info also has expandable details showing the assembly path actually loaded by Revit.

Use **Install / update KA MEP**, select the Revit year you run and keep the same Windows account. This build refines Tag Assistant with selection-first defaults, element review, nearby placement, and measured count/distance confirmation; it retains Model Review & Cleanup and all six Revit release targets; confirm **Version 2.0 | Build 20261023-01** in Info after updating. This installer manages the normal per-user KA MEP registration; independently installed copies at other paths are not removed automatically.

Sheet Parameters shows sheet instance parameters, stages individual or bulk edits for review, and assigns existing project revisions as additional revisions on selected sheets. Read-only or computed values remain visible. Current Revision is calculated by Revit; issued revisions and cloud-driven assignments are protected. This tool does not edit project-wide revision definitions or title-block type parameters. See [the Arabic guide](SHEET-PARAMETERS.ar.md).

## Logs and behavior

- Setup refuses to run while any `Revit.exe` process is open. It never closes or kills Revit.
- The bundled payload is checked against its embedded SHA-256 digest, validated against an exact file allowlist, extracted to a unique temporary folder, and removed after use.
- System Windows PowerShell runs the bundled script with `-NoProfile -NonInteractive -ExecutionPolicy Bypass -File`, passing only the selected Revit version. No network connection is used.
- Setup stays responsive while running, shows the script output, and retains a UTF-8 log under `%LOCALAPPDATA%\KAMEP\Logs`. The log path appears in the window.
- Existing installations use the installation scripts' ownership checks, file locking checks, backup/rollback, and previous Pipe Takeoff registration migration. All selected versions are validated before updates; rollback is per Revit version rather than one transaction across all selected versions.

## Build from source

Build all six release folders first, then run:

```powershell
./scripts/Build.ps1 -RevitVersion All -UsePackageRevitApi
./scripts/Build-Installer.ps1
```

Use the matching installed Revit API references instead if required by your development environment. The installer build requires the .NET 8 or newer SDK and restores the .NET Framework 4.8 reference-assembly package. Building all add-in releases, including Revit 2027, requires the .NET 10 SDK. Packaging rejects stale release DLL versions and build identifiers, compresses exactly twelve DLLs and two scripts, and emits the EXE plus its SHA-256 sidecar in `artifacts/`. `-OutputDirectory` overrides that location. The compiled EXE has no adjacent application dependencies; its only dependencies are the Windows components listed above.

Package checks distinguish the black executable icon from the white embedded UI resources. Current build evidence and prior isolated upgrade results are recorded in `VALIDATION.md`. Interactive setup, installation/uninstallation on Windows, and behavior inside Revit require Windows/Revit smoke testing before distribution as a tested release.

## Brand assets

The Windows executable file icon uses the black transparent KA monogram from `installer/Setup.ico`. The installer header, its shared window icon, and Revit branding retain the white transparent monogram from `assets/branding/`; the header retains its dark surface. Both ICOs include 16, 24, 32, 48, 64, 128 and 256px frames. Revit uses embedded white PNGs for its primary ribbon button and Info, and the white ICO for its forms. No external image path is required after installation. See assets/branding/README.md for provenance.

The script parameter accepts `All`, one year, or a comma-separated subset such as `2022,2024,2027`. Invalid/duplicate entries are rejected before filesystem changes.
