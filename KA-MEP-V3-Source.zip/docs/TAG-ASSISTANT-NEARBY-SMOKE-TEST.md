# Nearby Tag Assistant — manual Revit checks

Not executed runtime evidence. Test in disposable copies on each supported Revit version (2022.1+, 2023–2027), with Info showing Build 20261024-01. Use the correct year-specific DLLs. The current installer contains these DLLs; live Revit checks below remain unexecuted.

- Open with no selection: Selection scope, zero enabled categories, no accidental whole-view batch.
- Select pipes plus fittings/flex: only main categories enabled initially. Select only fittings: those can be enabled. Arrange selected existing tags includes their categories.
- Create a mix of long and short projected runs at 1:50 and 1:100; verify the 5-paper-mm filter and its visible reasons. A vertical riser projecting to a point is not accidentally filtered as a short run.
- Exclude individual elements, search/filter and change scope; exclusions persist. Include/exclude visible affects only visible rows. Cancel writes nothing.
- A 51-candidate batch with default limit50 cannot apply. Reducing the selection or raising the limit explicitly allows it; no silent first-N truncation.
- Dense and sparse groups with varied tag family widths: measured nearby label centers stay within the configured maximum. Crowded elements are skipped, not displaced far away.
- Estimated preview labels do not fit, but a compact actual family does: the measured review remains accessible. Actual all-skipped batches create/move nothing.
- Blank or question-mark-only new tags are skipped with a reason. Already tagged hosts (including hidden and primary-view tags) get no duplicate.
- A long straight run crossing a rectangular crop: anchor is on the visible section. No new nearby label lies outside drawing crop. Repeat in rotated plan and section.
- Irregular or split crop: nearby mode reports its limitation explicitly; no silent switch to a distant layout.
- Existing tags, text notes and relevant point-family bounds block nearby label positions. Unreadable or over-limit obstacles prevent unverified nearby execution.
- Arrange existing far-away tags: types retained, labels brought near hosts when space exists. Skipped existing tags remain in place and obstruct the remaining proposals. No tags are deleted automatically.
- In Scope & types, select a Tag family and verify Tag type contains only its types for that category. Use families with multiple types and identical type names across different families. Create uses the chosen exact type. Arrange preserves existing types while Keep each existing tag's family / type is checked; uncheck it to apply the chosen replacement family/type. Missing/unloaded compatible families cannot create an invalid batch.
- Check H/V text, rotating families, leader-free/straight/elbow styles, attached leaders and existing free endpoints. Changes to label size after placement trigger rollback for nearby batches.
- Select Right angle (90°) with each of the six placement patterns, H/V text, both sides and rotated plans/sections. The leader's two projected segments remain horizontal/vertical in the active view; label head positions and row/column alignment do not move when routing changes. Axis-aligned end/head pairs may render one straight segment, without an artificial zero-length bend.
- Repeat right-angle routing on existing free endpoints moved away from host anchors: endpoints remain where the user placed them. New or attached leaders use a supported free endpoint near the host. Unsupported leader conditions/families are reported and skipped or rolled back, never silently accepted as diagonal.
- In Revit 2027, include tags with a free leader start and verify right-angle routing explicitly handles attachment and checks the resulting shape after regeneration. Cancelled measured review and failed placement leave original tag/head/end/start state intact.
- Every nonempty measured batch shows requested/planned/skipped counts and maximum label-center distance before writes. Cancel preserves the model. One Undo restores successful batches.
- Verify five optional group patterns still work and report their potentially larger distance. Pick origin is disabled for nearby mode.
- Verify black transparent KA MEP and Info ribbon logos on the light ribbon. Other white logos in the Workspace, Info window and installer remain unchanged.
- Test the four settings tabs, family/type dropdowns, review checkbox interaction and fixed buttons at 100%,150%,200% scaling on small Windows displays.

Record model fixture, Revit point release and actual results separately. Compiling against an API and detached Mono tests do not validate runtime transactions, visibility, family bounds or leader behavior.
