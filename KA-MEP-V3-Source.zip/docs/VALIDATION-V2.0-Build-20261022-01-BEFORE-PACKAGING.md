# KA MEP V2.0 — white transparent logo validation

Completed 2026-10-22. Public version **V2.0**, assembly version **2.0.0**, build identity **20261022-01**. **No installer EXE was exported**, as previously requested. Historical installers do not contain this update.

## Change

The original supplied KA monogram was converted to pure white on an alpha-transparent canvas, with the original silhouette retained and the mark centered. A 1024px master, five PNG icon sizes and seven ICO frames were produced. The previous black assets were archived; the original upload is unchanged.

The Hub and installer logo PictureBoxes now have transparent backgrounds over their existing dark headers. Revit Home/Info buttons and all branded window icons consume the replaced embedded resources. `installer/Setup.ico` is identical to the shared ICO. Frames use 32-bit DIB plus legacy AND masks for .NET Framework/System.Drawing compatibility; no white tile, outline or shadow was added.

## Checks completed

- All **six Revit builds** passed with **zero warnings/errors**, for Revit2022.1+,2023,2024,2025,2026,2027, using the existing matching APIs and runtimes.
- PE metadata verification passed for each DLL pair: current identity, correct RevitAPI/RevitAPIUI major versions and runtime, and retained tool classes. `assembly-receipt.json` records SHA256 hashes.
- Binary resource inspection verified every final white PNG size and ICO is embedded in each Revit DLL; see `embedded-assets.txt`.
- Pixel checks passed for white RGB on every visible PNG pixel, transparent corners, correct dimensions and centered half-alpha bounds. All seven 32-bit ICO frames retain alpha, have legacy AND masks and decode successfully; the installer icon matches byte for byte. The original upload's SHA256 remains unchanged. See `asset-receipt.json`.
- Existing branding layout harness passed **3/3 paired cases — 6 forms**: Hub and Setup at 1366×728/100%,1280×680/150%,1280×680/200%. Screenshots of both normal forms and Setup at 200% were visually reviewed: white logo visible against the existing dark header, transparent cutouts, no white rectangle, preserved aspect ratio. Logs/screenshots and source hashes are in `validation-white-logo/ui/`.
- `Verify-Package.py` was updated to inspect alpha bounds and white foreground instead of searching for black pixels. Its syntax was checked; the package/EXE verifier was not executed because no new installer was built.

Only branding resources, two PictureBox background properties and build identity changed in the application. Functional suites were not repeated for this visual update. Prior Tag Assistant build/tests and runtime boundaries are preserved in `VALIDATION-V2.0-Build-20261021-01.md`.

## Limits

UI verification used Mono/Xvfb with explicit control/font scaling. No native Windows/Revit session, installer operation or new packaged installer was exercised. The installer UI was loaded through the detached harness, not by running Setup. Revit ribbon rendering remains a native smoke check.

White icons intentionally have no contrast tile; their appearance on host-controlled light backgrounds depends on the Windows/Revit theme. The application and Setup headers remain dark. `logo-on-navy.png` is a preview composite only; the distributed logo assets remain transparent.

Final build, metadata, embedded-resource and asset receipts are under `validation-white-logo/`. The release DLLs are in `release/2022` through `release/2027`. Existing installations are unchanged until a later installation/update.
