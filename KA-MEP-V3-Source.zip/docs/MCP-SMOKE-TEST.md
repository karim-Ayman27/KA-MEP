# Claude MCP — Windows / live Revit smoke test

**Pending manual validation; this checklist is not executed evidence.** Native Revit and Claude Desktop were not run in the current build environment. Run this on Windows with Revit **2022.1+, 2023, 2024, 2025, 2026 and 2027**, using the matching installed add-in and helper for each year. Record the exact Revit point release, Claude Desktop version, KA MEP build ID, Windows version, fixture and observed result separately.

Use Claude Desktop and Revit under the same Windows account on the same PC. Use a disposable project copy containing known MEP elements, Rooms/Spaces, Doors/Windows, instance and type parameters, sheets including a placeholder, loaded and unloaded Revit links, and existing native warnings. Have a second project and a second Revit process available for isolation checks. Compare results with Revit itself.

## Installation and first connection

| Check | Expected result |
|---|---|
| Install or upgrade each selected Revit year | Its add-in folder contains matching `KAMEP.Revit.dll`, `KAMEP.Core.dll`, `KAMEP.Mcp.Server.exe` and `.exe.config`; unrelated years and files are preserved. |
| Open Claude MCP from KA MEP Workspace ribbon and Hub | The project title and helper availability are correct. The window starts Disabled; merely opening it does not grant access. Reopening restores the existing window. |
| Invoke with no project or in Family Editor | A project-open message appears; no connection starts. |
| Choose Enable | State becomes Enabled after Revit accepts the external event. `%LOCALAPPDATA%\KAMEP\MCP\connection-<year>.json` exists with current-user access restrictions. Do not copy its token into evidence. |
| Choose Save Claude config… | A separate JSON snippet is saved with `ka-mep-revit-<year>`, an absolute installed helper path and `--connection-file` pointing to that year's profile. The snippet contains no session token and does not edit Claude settings. |
| Try saving the snippet as `claude_desktop_config.json` or over the connection profile | The save is refused with instructions to use a separate snippet. |
| Merge into `%APPDATA%\Claude\claude_desktop_config.json`, retaining an existing unrelated server; fully quit/restart Claude | Existing entries remain intact. KA MEP loads via stdio and advertises exactly the six tools below. No API key, public HTTP endpoint or router port forwarding is required. |
| Inspect the local bridge | The listener is loopback-only; the helper uses the local session token. A missing/incorrect token cannot read the project. Record outcomes without recording tokens. |

## Read-only tool results

Start with `ka_revit_project_info`, verify the returned project, and use its exact `projectKey` in subsequent calls. For the example arguments below, substitute the real key and identities returned by Revit; Element IDs must remain JSON strings.

| Tool / check | Expected result |
|---|---|
| `ka_revit_project_info` with `{ "limit": 50 }` | Correct title, project name/number, Revit year, workshared flag, active view and session key. Link instance names omit directories; loaded state agrees with Revit. Pagination applies to links. |
| `ka_revit_selection` with `{ "projectKey": "KEY", "limit": 50 }` | Matches the current host selection, including identity/name/category/type/level where available. Empty selection returns an empty result. Selecting linked content exposes at most its host link instance. |
| `ka_revit_find_elements` with `{ "projectKey": "KEY", "category": "Pipes", "limit": 50 }` | Correct host instances, ordered by numeric ID. A `query` matches element names without case sensitivity; it does not search arbitrary parameters. Repeat with every supported category in the [guide](MCP-CLAUDE.ar.md). |
| `ka_revit_element_parameters` with `{ "projectKey": "KEY", "elementId": "123", "includeType": true }` | Values match Revit. Instance/type parameters and duplicate names remain distinguishable by owner/parameter ID and `isType`. Repeat with `uniqueId`, no value, a read-only value, a built-in negative parameter ID and `includeType: false`. |
| Numeric parameter units | `rawValue` uses Revit internal units and invariant numeric formatting; `displayValue` follows project formatting. Confirm a known length against the Properties palette; do not treat raw length as millimetres. |
| `ka_revit_sheets` with `{ "projectKey": "KEY" }` | Sheet number/name/identity and placeholder status match Revit; ordering is numeric element ID. |
| `ka_revit_warnings` with `{ "projectKey": "KEY" }` | Existing native warnings match Revit, including severity, definition ID and failing/additional element IDs. No warnings are deleted or suppressed. |
| Host/linked model boundary | Linked model contents never appear as host elements or parameters; link metadata remains available through Project Info. |
| Read-only behavior across all six tools | No transactions, model edits, save, selection changes or new Undo entries are caused by these reads. Requested data appears in the Claude conversation; the AI interaction is not offline. |

## Bounds, project binding and shutdown

| Check | Expected result |
|---|---|
| Default page, `limit: 1`, `limit: 200`, nonzero `offset` | Default limit is 50. `returned`, `hasMore`, `nextOffset` and returned items agree. Parameter pages apply to parameters, not element identity. |
| Change the model between pages | `modelRevision` changes; discard old pages and restart. Selection and active view may change without a revision change, so hold selection constant while paging it. |
| More than 20,000 candidate elements or warning records | `truncated` and `notes` disclose the scan cap. Filter/order/page results describe only the examined subset; `hasMore: false` does not claim whole-model completeness. |
| More than 2,000 instance/type parameters, long text or warnings with large ID arrays | Bounds and truncation notes are visible. Warning arrays cap at 100 IDs per failing/additional array and 5,000 IDs across one response; text limits are disclosed. No truncated result is described as complete. |
| Invalid category, limit 0/201, unknown argument, missing key, numeric rather than string element ID | The request is rejected with an actionable error. Unsupported/editing tools are absent and calls cannot mutate the model. |
| Missing element, mismatched `elementId`/`uniqueId`, expired or wrong project key | The request fails without falling back to another element/project. Refresh identity with Project Info and retry. |
| Activate another project while the connection stays open | Reads fail rather than reading the other project. Returning to the bound project restores reads. Opening the tool for a different project closes the previous connection. |
| Enable in a second Revit process of the same year/account | The second connection cannot take ownership; its failure does not break the first. Different years use separate profiles and Claude server entries. |
| Revit busy with a modal dialog/command, cancellation or timeout | Reads wait or fail cleanly; no partial mutation occurs. Revit and the connection window remain usable after finishing the command and retrying. |
| Choose Stop during queued work | Queued reads fail; the listener stops and the profile is removed when possible. If removal fails, the old token is still invalid. Claude cannot read until Enable is chosen again. |
| Enable again after Stop | A new `projectKey` is issued; the old key is rejected. Project Info obtains the new key without hand-editing the session profile. |
| Close the connection window, close the bound document or exit Revit | Connection and pending reads end without an unhandled exception. Reopening starts Disabled. |
| Restart after a Revit crash/stale profile | Stale data cannot grant access to a project. Enabling a fresh session restores operation and invalidates old identity. |
| Missing/outdated helper or missing helper `.config` | Enable/config actions are unavailable or report the matching-helper repair requirement; reinstalling the correct year resolves it. |
| Small display and 100%, 150%, 200% scaling; long/Arabic project/path names | Enable, Stop, Save Claude config and Close remain reachable; instructions scroll; paths, project identity, disclosure, status and activity remain readable. |
| Request activity | Only last tool, time, outcome and completed count appear; requested element/parameter payloads and tokens are not displayed. |

Record pass/fail and evidence per year. Keep connection secrets out of screenshots and logs. A successful build, protocol test, transport test, detached window test or packaged installer check does not replace this native Windows/Revit/Claude run.
