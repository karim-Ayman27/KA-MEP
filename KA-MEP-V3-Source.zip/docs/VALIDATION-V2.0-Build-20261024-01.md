# KA MEP V2.0 — ribbon contrast, tag families/right-angle leaders, grouped Model Health

Packaged 2026-10-25. Public version **V2.0**, assembly version **2.0.0**, build **20261024-01** (work started 2026-10-24).

Installer: `artifacts/KA-MEP-Setup-V2.0-Full-2022-2023-2024-2025-2026-2027-Build-20261024-01.exe`  
Size: **2,183,680 bytes**  
SHA256: `5425faa33b8f11ad9a79e7e348ade185189f7928a79dafb0ffa5d296a22338ac`

## Result

- The KA MEP Home and Info ribbon logos use separate black, transparent PNGs. Their geometry/alpha exactly match the existing white assets. Internal white UI/window logos and the black installer file icon retain their previous hashes.
- Tag Assistant exposes a category-specific **Tag family** selector and a filtered **Tag type** selector. Existing tags retain their family/type by default; the adjacent checkbox explicitly enables replacement. **Right angle (90°)** changes leader geometry without moving planned tag heads or changing pattern alignment.
- Orthogonal leaders use a Free endpoint; existing Free endpoints are retained. Compatible attached/new leaders use the host anchor, and Revit 2027 uses an Attached leader start. The service checks endpoint, tag head and elbow after regeneration and rejects unsupported geometry. Collinear endpoints stay straight. Near-elements verification failures roll back the batch; other patterns retain their existing per-item rollback behavior.
- Model Review opens with one summary row per issue/check or native warning definition. Each row reports occurrences and distinct affected IDs; raw findings and the health formula are unchanged. Detail drilldown is required for cleanup, and changing review/filter scope clears cleanup checks. Excel retains every Detail row and adds grouped issue counts to Summary.

## Automated checks

All six Revit targets and the installer compiled with **zero warnings and zero errors**. PE metadata inspection confirms matching RevitAPI/RevitAPIUI major versions and .NET targets, current build identity, new feature methods/resources, and retained tools in each release pair.

- Tag layout: **34 test groups**, including all six patterns with unchanged heads/bounds/skips under orthogonal routing, axis-aligned and coincident endpoints, translations, invalid input and crop warnings. Existing randomized nearby/layout cases remain included.
- Detached Tag Assistant behavior: **41 cases**.
- Model Review model/score/grouping: **51 checks**, including 100 score cases, stable group identities, exact 64-bit IDs and rejection of group keys as cleanup approvals.
- Model Review Excel: **50 checks**, including grouped Summary counts, unchanged Detail rows/score, distinct affected IDs, inert formula-like text, formatting and atomic failure behavior.
- Quantity/Excel/naming regression: **54 checks**.
- Model Review UI: **9/9 layout cases**, plus a supplemental smallest-screen 200% scrolled-grid capture; grouped presentation, drilldown, filter resets and explicit cleanup verified.
- Tag Assistant UI: **9/9 layout cases**. Family/type filtering, explicit replacement, missing-family handling and orthogonal preview alignment verified. A supplemental check found the Tag type editor clipped on the narrowest window; settings now receive more width there. The final matrix includes the actual open dropdown at 876×571/200%. Scrolled family/leader captures cover access to controls. Initial Xvfb startup races and pre-fix attempts are retained as historical evidence; all six release pairs and the installer were rebuilt after the responsive UI fix.
- Current-payload installer engine: **194 checks**.
- Actual previous Build **20261023-01 → 20261024-01** payload upgrade: **89 checks**, using isolated AppData fixtures. The baseline ZIP was verified byte-for-byte inside the previously shipped EXE. Existing registration paths and unrelated add-ins are preserved.

Package verification inspected the actual EXE: seven Windows icon frames match the black external logo; white internal assets and black ribbon assets are present; the exact fourteen-file payload matches the twelve current release DLLs and two installer scripts; no Autodesk API DLLs are bundled. Build identity and SHA256 sidecar match.

Evidence and receipts: `validation-v2-20261024-01/`. Earlier packages and validation histories remain unchanged.

## Runtime limits and update

Checks ran on Linux, using Mono/Xvfb with explicit font scaling for UI cases. Native Windows/Revit execution was **not tested** here. Orthogonal geometry checks validate API head/elbow/end coordinates, not every family's rendered attachment, leader crossing or native DPI behavior. See `TAG-ASSISTANT-NEARBY-SMOKE-TEST.md`, `MODEL-REVIEW-SMOKE-TEST.md` and `REVIT-SMOKE-TEST.md` for live verification.

Revit 2022 requires 2022.1 or a later 2022 update. Close Revit, run the EXE under the same Windows account and choose **Install / update KA MEP**. The installer is per-user and does not request administrator elevation. Confirm **Version 2.0 | Build 20261024-01** in Info.
