# تطوير KA MEP من السورس

السورس **V3.0 / Build 20261030-01** يضم المشاريع والاختبارات والأصول والسكربتات والتوثيق، مع ملفات البناء الحالية في `release/2022` حتى `release/2027`. ملف `SOURCE-MANIFEST.json` داخل ZIP يسجل مسارات الملفات وأحجامها وSHA256؛ و`release/SHA256SUMS.txt` يسجل ملفات التشغيل. لا تتضمن الحزمة كلمات مرور أو شهادة توقيع أو ملف اتصال شخصي بـClaude.

## المتطلبات والبناء

استخدم Windows للتطوير والاختبار داخل Revit، و.NET 10 SDK لبناء كل الإصدارات، وPowerShell. مشروع 2022–2024 يستخدم .NET Framework 4.8، و2025–2026 يستخدم .NET 8 Windows، و2027 يستخدم .NET 10 Windows. ملفات C# تضبط مستوى اللغة عند 7.3 للمشاركة بين الأهداف.

من جذر الحزمة:

```powershell
# مراجع API من حزم NuGet المعرّفة في المشروع، للبناء فقط
.\scripts\Build.ps1 -UsePackageRevitApi

# أو إصدار واحد ومراجع نسخة Revit المثبتة محليًا
.\scripts\Build.ps1 -RevitVersion 2026 -RevitApiDir 'C:\Program Files\Autodesk\Revit 2026'
```

البناء يجمع DLL المناسبة لكل سنة، ثم يجمع برنامج MCP مرة واحدة وينسخ ملفيه إلى مجلدات الإصدارات المطلوبة. لا تشغّل عمليات البناء ذات المراجع المشتركة إلى Core بالتوازي. افتح ملفات `.csproj` في Visual Studio/Rider؛ لا يلزم وجود Solution لاستخدام سكربت البناء.

## هيكل الكود

| المسار | الوظيفة |
| --- | --- |
| `src/PipeTakeoff.Core` | الحسابات والتقارير، نماذج البيانات، بروتوكول النقل المحلي؛ لا يعتمد على Revit API |
| `src/PipeTakeoff.Revit` | أوامر Revit والواجهات والخدمات؛ `RevitCompat` يعزل اختلافات الإصدارات |
| `src/KAMEP.Mcp.Server` | برنامج console بـ.NET Framework 4.8؛ MCP JSON-RPC عبر stdin/stdout، ثم اتصال محلي مصادق عليه؛ لا يحمّل Revit API |
| `assets` و`src/Shared` | الصور وهوية الإصدار المشتركة |
| `installer` و`scripts` | التثبيت للمستخدم الحالي والبناء والتحقق والتغليف |
| `tests` و`docs` | الاختبارات والتوثيق ونتائج التحقق وقوائم التجربة اليدوية |

الربط الحالي يسمح بست أدوات قراءة فقط. الطلب القادم من الشبكة لا يقرأ Revit؛ يضع طلبًا محدودًا في طابور `McpConnectionController`، وينفذ `McpReadService` داخل `ExternalEvent` المرتبط بالمشروع. لا تستدعِ API من Thread خلفي، ولا تضف تنفيذ كود عام أو أوامر تعديل دون تصميم مراجعة/Transaction واضحة. ملف جلسة الاتصال في LocalAppData خاص بالمستخدم ويُنشأ عند Enable؛ لا تضمه للسورس أو للمثبّت.

## الاختبارات والتغليف

```powershell
dotnet run --project tests/McpTransport.Tests -c Release
dotnet build tests/McpServer.Tests -c Release
.\tests\McpServer.Tests\bin\Release\net48\KAMEP.McpServer.Tests.exe
python tests/McpServer.Tests/stdio_integration.py src/KAMEP.Mcp.Server/bin/Release/net48/KAMEP.Mcp.Server.exe

# بعد إنهاء التعديلات والبناء والتحقق
python scripts/Build-SourcePackage.py
.\scripts\Build-Installer.ps1
python scripts/Verify-Package.py
```

Python 3 مطلوب للسكربتات المذكورة؛ `Verify-Package.py` يحتاج Pillow. اختبارات WinForms المنفصلة لا تحاكي Revit؛ الاختبار الأصلي موضح في قوائم MCP وClash وSpaces. لتغيير إصدار التسليم عدّل `Version` و`ReleaseLabel` و`BuildId` في `Directory.Build.props` ثم أعد بناء الإصدارات الستة قبل التغليف. ملفات API المرجعية ليست جزءًا من الحزمة المثبتة.

اغلق Revit وClaude Desktop قبل تحديث الملفات. بيانات المؤلف محفوظة؛ التوقيع الرقمي مرحلة منفصلة تتطلب شهادة موثوقة. [دليل MCP](MCP-CLAUDE.ar.md) يوضح إعداد Claude دون تعديل ملف إعداداته تلقائيًا.
