# MCP Connection UI evidence — Build 20261030-01

The detached production `McpConnectionForm` passed all nine layout and behavior cases on 2026-11-01. The linked production source and test project compiled with .NET SDK 8.0.425: zero warnings and zero errors.

Cases: 1366×728 at 100%; 1280×680 at 150% and 200%; 1024×600 at 100%, 150%, and 200%; 876×571 at 100%, 150%, and 200%.

Assertions cover visible and unclipped controls; native button text fit; rendered project-label glyphs after setting a title containing an ampersand and Arabic; scroll reachability of every setup instruction and tool; disabled, enabled, stopped, missing-helper and no-project states; explicit controller events; close lifecycle; bounded scrollable status; metadata-only activity and payload suppression.

Visual inspection confirmed the project title, disclosure, state, actions and status in [normal size](screenshots/1366x728_100_enabled.png) and [small viewport at 200%](screenshots/876x571_200_enabled.png). Full screenshots and each case log are alongside this file. The current form needed no additional production change during final validation.

This is actual WinForms rendering under Mono/Xvfb with simulated font/control scaling and a deterministic DejaVu Sans fallback. It does not establish Windows per-monitor DPI, live Revit, or Claude Desktop integration behavior. The harmless GTK fallback warning is retained in the raw logs.

Reproduce:

```sh
/workspace/.dotnet/dotnet build tests/McpConnectionLayout.Tests/McpConnectionLayout.Tests.csproj -c Release --no-restore
python3 tests/McpConnectionLayout.Tests/Run-Mcp-Layout.py
```

Production form SHA-256: `b923f16df0c029e781b00ac66c9410fe20cb988de27023b44b25c155c03e1c69`.
