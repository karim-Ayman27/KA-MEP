# KA MEP V2.0 — final installer validation

Packaged on 2026-10-22 following the user's explicit request to export the latest installer. Public version **V2.0**, assembly version **2.0.0**, build **20261022-01**.

Installer: `artifacts/KA-MEP-Setup-V2.0-Full-2022-2023-2024-2025-2026-2027-Build-20261022-01.exe`  
Size: **2,055,168 bytes**  
SHA256: `31421e140646cee5758eb26e39694ada61f5478234779ee0372928493f746d76`

## Included changes

The package contains all six Revit releases, the refined nearby Tag Assistant with element review and distance/count limits, Sheet Parameters, Model Review & Cleanup, existing MEP quantities and Excel reports, PDF/DWG sheet export, and the white transparent logo. The installer feature description now mentions nearby placement and the five additional patterns.

The 12 release DLLs were compared byte for byte with the latest verified white-logo build receipts before packaging. Their six-version API/runtime checks, zero-warning/error builds and prior logic/UI evidence remain in `validation-white-logo/`, `validation-tag-nearby/` and the archived validation reports. No add-in logic changed during packaging.

## Final package checks

- Installer compilation succeeded with **zero warnings and errors**.
- `scripts/Verify-Package.py` passed against the actual exported EXE: Windows x64 GUI PE; seven embedded Windows icon frames exactly matching the white alpha ICO; white transparent centered PNG resources in Setup and every Revit DLL; exact 14-file payload with matching file bytes and SHA256; current identity and required feature classes in all six Revit versions; no Autodesk API binaries bundled; per-user `asInvoker` manifest.
- **194** installer engine checks passed using the current embedded payload, including extraction validation, invalid paths/selections, all 63 nonempty version subsets and matching API/runtime references.
- **5,866** isolated script assertions passed for install/update/uninstall behavior, all 63 nonempty year subsets and filesystem protections.
- Real previous **V1.0 Build 20261019-01 → V2.0 Build 20261022-01** payload update: **74 checks passed**.
- Real previous **V2.0 Build 20261020-01 → V2.0 Build 20261022-01** payload update: **74 checks passed**.
- Both upgrade checks confirm six target years, current DLL bytes/build, the same add-in GUID and paths for previous installations, replacement of old DLLs, and preservation of unrelated add-ins. Baseline ZIP bytes were verified against the historical shipped EXEs.

Logs and package/baseline receipts are in `validation-installer-20261022-01/`. The SHA256 sidecar is adjacent to the EXE. Prior white-logo UI evidence covers Hub/Setup at 100%,150%,200%; the only subsequent UI change is the installer log's feature-description text.

## Runtime limits

These are Linux compilation, package-inspection, Mono UI and isolated filesystem checks. They do not constitute native Windows/Revit execution. The isolated upgrade tests redirect AppData and remove the Windows guard only in temporary script copies; production scripts remain unchanged. No user's actual installation was modified.

Revit 2022 requires 2022.1 or newer within that release. Native loading, tag-family behavior, model-review cleanup, Undo/worksharing and PDF/DWG runtime behavior remain subject to the manual checks in `REVIT-SMOKE-TEST.md`, `TAG-ASSISTANT-NEARBY-SMOKE-TEST.md` and `MODEL-REVIEW-SMOKE-TEST.md`.

To update, close Revit, run the new EXE using the same Windows account, choose the relevant Revit versions and **Install / update KA MEP**. Confirm **Version 2.0 | Build 20261022-01** in Info afterward. Installation is per-user and does not request administrator elevation.
