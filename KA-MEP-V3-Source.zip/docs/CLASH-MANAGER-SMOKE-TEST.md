# V3 Clash Manager — manual Revit and Excel smoke-test checklist

**Status: procedure only; not executed by this document.** Every unchecked box is pending. Build, parser/exporter unit tests and UI layout probes do not establish native Revit geometry, modeless event handling or Excel runtime compatibility. The V3.0 / Build 20261030-01 package includes this feature; the old V2 installer does not. The user explicitly requested source and installer packages; packaging is separate from native acceptance.

Use disposable project copies and the intended V3 DLL for each exact Revit target. Source targets cover **2022.1, 2023, 2024, 2025, 2026 and 2027**; record each native run separately. These targets are not claims of completed runtime validation. See the [Arabic usage guide](CLASH-MANAGER.ar.md).

## Run record

| Field | Record before running |
| --- | --- |
| Tester / date | Pending |
| Revit version / full build | Pending |
| Add-in version / build / DLL hash | Pending |
| Host / linked fixture paths or hashes | Pending |
| Revit / Navisworks report producer version / settings / report hash | Pending |
| Element IDs / UniqueIds / source and link instance IDs | Pending |
| Link translation / rotation / reflection | Pending |
| Phase / design options / active and inspection view settings | Pending |
| Display resolution / scaling | Pending |
| Excel version / build or other viewer | Pending |
| Exports / screenshots / failures | Pending |
| Overall result | Not run |

Record observed results and evidence beside each check; do not infer a pass from a dialog or workbook merely opening. Reset fixtures between edits so a previous failure does not mask another.

## Fixture and report preparation

Prepare two writable Revit projects, A and B. In A, use simple measured solids with known volumes, plus a directly loaded link with a nonidentity translation/rotation. Retain original report IDs after moving elements. Add a repeated placement of the same link and an unloaded link variant. Keep an independently verified baseline before changing geometry.

| Fixture / report row | Expected current result after explicit source resolution |
| --- | --- |
| Two supported solids intersect by substantially more than 1 mm³ | `Unsolved` / red |
| Same two identities moved fully apart after report creation | `Solved` / green |
| Solids whose bounds overlap but volumes do not | `Solved`; bounds overlap alone must not become `Unsolved` |
| Face/edge contact with zero volume | `Solved` under the recorded hard-volume criterion |
| Supported intersection above / at / below 1 mm³ | Compare with exact `Check basis`; above is `Unsolved`, at/below can be `Solved` when complete |
| Several small solid intersections, each ≤1 mm³ but combined upper bound >1 mm³ | `NeedsReview`; no unsupported union-volume claim |
| Missing/deleted element, unloaded or ambiguous source | `NeedsReview` / amber, never `Solved` |
| Mesh-only, open/degenerate, unsupported or over-limit geometry; Boolean failure | `NeedsReview` with a useful note, never a false clear result |
| Clearance / Duplicate test | `NeedsReview` even if no hard intersection exists |
| Unknown test | `NeedsReview` until the explicit hard-test assumption is enabled |

Prepare genuine HTML exports from the recorded Revit and Navisworks versions, covering ordinary tables and detailed pair layouts where available. Include `Resolved`/`Approved`/`Closed` source statuses, mixed test types, repeated test names, repeated identical rows, Arabic and formula-like text, and source model names. Prepare a custom table requiring manual mapping, a table using UniqueIds, and malformed or unsupported files.

## Import, mapping and presentation

- [ ] `KA MEP → Model → Clash Manager` opens once for its project as a modeless window. No project / family document is handled without an unexpected exception.
- [ ] Browse and drag-and-drop accept one local `.htm`/`.html` file. Multiple-file and invalid-file drops are not accepted; invalid browse/import paths produce a clear error. Cover unsupported extensions, UNC paths, missing files, reports exceeding 16 MiB and reports exceeding 20,000 clashes. A failed import leaves the previous usable report intact.
- [ ] Compare actual imported row counts, test/name/category/source/ID fields and notes with each original report. Repeated identical rows may collapse; distinct tests must remain separate. Missing or ambiguous report IDs are retained for review, never guessed from arbitrary numbers.
- [ ] All new rows are gray `Unchecked`; imported `Resolved`, `Approved` or `Closed` remains historical text in `Imported status`.
- [ ] A readable unrecognized table opens manual mapping. Select the correct table, header setting, distinct identifier columns for both elements and optional source/type/status columns. Verify numeric-ID-only, UniqueId-only and combined ID/UniqueId reports. A table without usable identifiers does not become a fabricated clash pair. Cancel mapping and verify that the previous report remains usable.
- [ ] HTML scripts, frames, external styles/images and resource URLs are never executed or fetched. Markup is handled as report text; encoded Arabic and formula-like values remain readable.
- [ ] Search, status and test filters yield the expected visible set and counts. Check multiselect, details, keyboard `F5`/`Ctrl+E`, long IDs and long model names.
- [ ] At 100%, 125%, 150% and 200% scaling on the intended desktop size, inspect both tabs and manual mapping. Buttons, errors, footer, scrollbars and grid headers remain usable; no hidden required action is assumed accessible.

## Source identity and current checks

- [ ] Host–host, host–link and link–link pairs resolve to the intended elements with exact reported and resolved IDs/UniqueIds. Verify linked transforms independently in a section/3D view.
- [ ] For a UniqueId-only row, resolve the current numeric element ID without editing the report. For a combined-reference row, mismatched ID and UniqueId produce `NeedsReview`; explicit source selection does not override that mismatch.
- [ ] A contradictory reported/current category produces `NeedsReview` with a stale-ID/category-language explanation. Case and whitespace differences alone are tolerated. Confirm that numeric-only reports cannot prove identity reuse before their first resolved UniqueId pin.
- [ ] Repeated link placements with the same report filename require explicit `Link <instance ID>` selection. Identical numeric IDs in different documents never silently choose a source.
- [ ] Apply sources to selected rows only; their result becomes `Unchecked` and prior resolution clears. Apply `Auto` again and verify automatic resolution is restored without carrying an obsolete override.
- [ ] Unload/reload a link, remove a source, delete an element, mismatch ID versus UniqueId, or change a previously resolved identity. Refresh produces a clear review note; none is counted as solved because it is absent. Nested-only links are not treated as direct sources.
- [ ] Both sides referencing the same physical element require review. An ElementType or link container ID does not stand in for a clash object.
- [ ] Run all geometry cases above with `Refresh visible` and `Refresh selected`; compare states, colors, current category/model, check time, note and basis with independently measured expectations. Only the rows requested at the start are checked. Under a status filter, rows may leave the visible set as their state changes; restore `All statuses` to inspect the completed results.
- [ ] Move/rotate a direct link after import and refresh. Check uses its current transform. Test a supported mirrored link/family placement; inspect its basis and actual geometry, or record `NeedsReview` if Revit cannot read valid solids.
- [ ] Change active-view detail, section box, phase or temporary hiding. Hard checks do not falsely clear a pair because the current view clips/hides it; inspect any geometry-unavailable review note.
- [ ] Clearance and Duplicate remain review-only. Unknown remains review until `Treat unknown tests as hard clashes` is explicitly checked; the assumption appears in `Basis` and the export. Toggling it invalidates Unknown results.
- [ ] Confirm the current UI check uses 1 mm³ volume tolerance. A report's distance/tolerance text, including other units, does not silently override it. No distance-clearance or duplicate-compliance claim is produced.

## Modeless lifetime, cancellation and invalidation

- [ ] During a sufficiently large refresh, Revit/manager remain responsive between batches. Progress is coherent, repeated refresh requests do not overlap, and import/mapping/export controls cannot mutate the in-progress request.
- [ ] Start with already checked rows and refresh again. Every requested row first becomes `Unchecked`. Cancel partway through: completed checks remain, while the remaining requested rows stay `Unchecked` without an old check time/basis. Work stops between batches; allow an in-progress native geometry call to finish. A later refresh completes normally.
- [ ] Edit the host or change/reload/move a relevant link after a completed refresh. **All** report results, including filtered-out rows, become `Unchecked` with no current check time/basis. Refresh establishes new results.
- [ ] Make a model change during a batched refresh. The interrupted run cannot later restore stale green results or export them as current; recorded outcomes must match invalidation behavior.
- [ ] While A's manager is open or has queued work, activate project B. Refresh, 3D focus and export for A must not act on B. Return to A and refresh successfully.
- [ ] Close A with its manager open, close the manager during a pending request, and reopen the tool. No action runs against an invalid document or disposed form; shutdown does not leave a repeating event or orphan window.

## Focused 3D and model effects

- [ ] Select one pair and use `View pair in 3D`, then double-click. A dedicated `KA MEP - Clash Inspection...` view frames the current elements with the chosen margin and attempts zoom-to-fit; no historical report point substitutes for their bounds. Record any automatic zoom failure message.
- [ ] An unrelated existing view with the same stem is not reused or changed. Existing user view template, section box and temporary visibility remain intact. Repeated focus reuses the tool-owned valid view in the session.
- [ ] Change margin and verify framing in host coordinates, including translated/rotated/mirrored links. Record any visibility limitations from inspection-view phase/design options.
- [ ] Toggle temporary isolation on/off. Host elements isolate individually; linked elements isolate their **whole containing link instances**, with the section box narrowing the view. Disabling it on the next focus clears the inspection view's prior temporary isolation.
- [ ] Delete the managed view or assign it a template and focus again. The tool handles the unavailable view safely and creates its own replacement if needed.
- [ ] Focus with a missing element, unloaded/ambiguous link, invalid bounds or nonwritable document fails clearly without leaving partial view changes. If view activation/transaction fails, record rollback behavior.
- [ ] Inspect model/Undo changes: focus creates/modifies its inspection view and visibility; checking does not move, resize, delete or reconnect MEP geometry. Focus alone does not certify a row as checked, and the tool's own focus transaction does not invalidate the existing checks. A subsequent user model edit still invalidates all report results.

## Excel evidence

- [ ] Export a known filtered subset containing all four states. Open it in the recorded viewer without repair warnings; confirm exactly `Summary`, `Clashes`, `Info` and expected visible row count. Selecting one row must not silently restrict export to that row.
- [ ] Summary counts match the exported rows and state colors/text. `Clashes` preserves names, tests, current versus imported states, both IDs/categories/models, reported values, source overrides, resolved identity, notes, basis and timestamps.
- [ ] `Info` contains source path/hash, producer/import/export time, Revit/release, export filters and check limitations. Unknown-test assumptions and hard-volume criteria remain auditable in each applicable row.
- [ ] Report distance/clash-point text retains its original units/format without invented conversion. IDs/UniqueIds remain exact text; Arabic and formula-like fields are literal text, not formulas or external links.
- [ ] Export after cancellation or invalidation. `Unchecked`/`NeedsReview` is represented faithfully, no prior result is relabeled as current, and the user can distinguish unchecked rows from solved rows.
- [ ] Inspect filters, frozen headers, column widths, colors and print setup. Excel filters do not recalculate stored Summary totals; the file is a static snapshot.
- [ ] Locked/unwritable destinations and text exceeding Excel's cell limit fail clearly. Existing output is not replaced with a partial workbook after a failed export.

Record remaining failures and rerun affected cases after fixes. Leave every unexecuted Revit version/scenario marked **Pending / Not run**; do not substitute source compilation for native results.
