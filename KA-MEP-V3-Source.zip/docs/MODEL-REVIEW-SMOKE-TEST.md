# Model Review & Cleanup — live Revit checks

This checklist is **not executed evidence**. It requires Windows and live Revit. Run it independently in Revit 2022.1+, 2023, 2024, 2025, 2026 and 2027 with the DLL built for that year. Record the Revit point release, KA MEP build ID, project fixture and observed outcome.

Use a disposable project copy containing placed and unplaced plans, sections, drafting views, schedules, a panel schedule, a view template, a panel schedule template, primary/dependent views, a configured starting view, imported and linked DWGs, and coincident MEP elements. Include a workshared fixture when checking ownership.

| Check | Expected result |
|---|---|
| Open from the Model ribbon and Hub card | One Model Review window opens; the loaded version/build matches Info. |
| Work in Revit while the window stays open | Model editing remains available. Refresh waits until Revit can process its external event. |
| Minimize and reopen the tool | The existing review is restored instead of opening duplicate controllers. |
| Change the active document with a review open | Requests cannot inspect or modify the wrong project. Opening the tool for the new project creates a review for that project. |
| Close a document or close the window while Refresh is queued | No operation targets a closed/wrong document and no unhandled exception occurs. |
| Scan imported vs linked CAD | Imports and links are separated; owner-view information and element IDs agree with Revit. Links do not contribute to score or cleanup. |
| Place an unplaced plan, schedule and panel schedule on sheets, then Refresh | Each leaves the unplaced list. Views already placed, including schedules, are not falsely listed. |
| Inspect view and panel schedule templates | Templates are excluded from unplaced-view findings. |
| Review active, starting, primary/dependent and pinned/grouped items | Protected items are review-only with a concrete reason. |
| Create coincident straight pipes/ducts/trays/conduits and point-based MEP families | Applicable matches appear as potential groups, not proven redundant elements; type/phase/workset/design-option differences remain separate. |
| Native duplicate warning overlaps a geometry-signature group | Overlapping groups are merged and not counted again as an ordinary warning. Additional warning context elements are not incorrectly treated as duplicate members. |
| Curved or unsupported MEP geometry | Scope notes disclose signature exclusions; the tool does not claim comprehensive duplicate coverage. |
| Show in Revit for CAD, view and duplicate findings | Correct IDs are selected/shown; a single view opens. A missing element asks for Refresh. |
| Scan many instances of the same issue | Default summary displays one row per check or stable Revit warning definition; Occurrences counts raw findings and Affected elements counts distinct IDs. The health score equals the original occurrence-based score. |
| Two different native warning definitions with identical display text | Remain distinct issue groups; repeated occurrences of one warning definition are grouped together. |
| Search summary by an individual member name or Element ID | Matching issue is shown once with full group counts. Show in Revit inspects the whole selected group; no cleanup checkboxes are offered. |
| Review issue details, All individual findings, and Issue summary | Drilldown shows only selected issue members or all findings as requested. No group row can authorize deletion. Returning to summary or changing detail scope clears checks. |
| Apply kind/search filters after checking individual items | All checks clear when the filter changes; no hidden selection survives into a cleanup request. Check cleanup candidates checks only eligible visible detail rows. Clear checks clears all. |
| Press Preview cleanup with only eligible CAD/views checked | No deletion is committed by preview. The full dependent deletion list is visible and readable, including on small/high-DPI displays. |
| Cancel confirmation, close it or press Enter without explicit delete action | No cleanup is committed; cancel refreshes the review and clears checks. DELETE enables only the explicit delete button. |
| Change a selected element, another model item, or any other open project after scanning, before preview | Stale review is rejected and requires Refresh. This must work without saving the project. |
| Change the model after preview before application, using a test callback if needed | Stale preview is rejected. Compare this behavior after Undo/Redo as well. |
| Delete an eligible unplaced view containing annotations | The preview lists its dependent elements; successful cleanup deletes exactly the reviewed operation. Undo once restores it. |
| Try an item with pinned/grouped/owned-by-other dependent content | Cleanup is blocked without partial deletion. |
| Failure handling during cleanup | Revit errors roll back the whole operation; the result does not claim success or suppress existing warnings. |
| A test updater alters deletion dependencies | Changed/unreviewed deletion scope causes rollback, or the documented supported boundary is clearly reported; never silently claim exact reviewed deletion after extra deletion. |
| Successful cleanup, manual repair and Undo followed by Refresh | Counts, timestamp and score reflect the current state; change from the previous complete scan is accurate. |
| Partial scan from an injected reader failure | Health is unavailable; cleanup is blocked; coverage explains the failed check. |
| Export review to Excel | The workbook opens without repair; Detail includes all scan findings despite UI filters; Summary shows grouped issue occurrence/affected-element counts alongside the original counts and score; Info shows timestamp, score status, formula and scope. Text that begins with '=' stays text. |
| 1366×728, 1024×600, 876×571 at 100%, 150%, 200% | Refresh, close, review details and deletion confirmation remain reachable; text and grid contents are rendered. |

For score arithmetic, two imported CAD instances, three unplaced views, one duplicate group and four other warnings produce **80/100**. Remove one CAD instance and Refresh: the expected score is **85/100** unless other counts changed. Test capped penalties too: reducing six imports to five leaves the CAD penalty at 25; reducing five to four changes it to 20.

Record actual results and any differences in a separate validation record. A successful compile or detached UI test does not establish live Revit behavior.
