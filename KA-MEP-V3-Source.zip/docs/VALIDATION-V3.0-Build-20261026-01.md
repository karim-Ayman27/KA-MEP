# KA MEP V3.0 — HVAC Spaces development validation

Validated **2026-10-28**. Assembly version **3.0.0**, build **20261026-01** (work began 2026-10-26). This is source/DLL development evidence. **No V3 installer/EXE was created or published.** The latest published installer remains V2.0 / Build 20261024-01 and does not contain HVAC Spaces.

## Implemented behavior

- A new **HVAC Spaces** ribbon command and Hub launcher read host MEP Spaces and separately show architectural Room names/numbers, Space names/numbers, level, phase and Space area. Loaded direct Revit Links are the default source; host geometry is optional. The UI provides model/view/selection scope, phase and link choice, search, level/status filters, Refresh and fixed-footer Excel export with Ctrl+E.
- Physical clearance uses sampled Floor top to Ceiling underside, falling back to the nearest overhead slab underside where no intervening ceiling exists. Linked transforms and mapped phases are respected. Connected finish-floor layers are handled; ambiguous, variable, mixed or incomplete samples retain their range but cannot claim one complete height. Space analytical upper limits are never substituted for physical clearance.
- Architectural Doors/Windows use phase-specific Room relationships and exact document/link/Room identity. Counts and nominal width × height areas are shown per associated Space. Shared openings can belong to both adjacent Rooms; unique report totals deduplicate physical source instances. Missing dimensions suppress complete areas while retaining counts and known subtotals. Incomplete collection/association leaves complete counts unknown instead of zero.
- The formatted static XLSX contains **Spaces, Summary, Measurements, Openings and Info**. It retains filters, frozen headings/first column, typed numeric values, exact text IDs, leading zeros, source details and print settings. Totals use the exported visible rows; source-wide scan coverage is labelled separately. File replacement is atomic, and formula-like model text remains inert text.
- Compact layout keeps actions and result rows accessible at enlarged fonts. Native preferred button sizes, measured grid text heights and wrapping-aware Hub cards resolve clipping found during the initial UI checks.

## Completed checks

| Check | Result |
| --- | --- |
| Space geometry/model | 67 assertions, including 100 transformed/sloped cases |
| Opening association, quantities and dimensions | 106 assertions |
| HVAC five-sheet Excel export | 144 assertions |
| Existing quantity/Excel/naming regression | 54 assertions |
| Existing Model Review Excel regression | 50 assertions |
| Production HVAC form under Mono/Xvfb | **9/9** cases: 1366×728 at 100%; 1280×680 at 150/200%; 1024×600 and 876×571 at 100/150/200% |
| Hub/Setup linked-form presentation | **3/3 paired cases** at 100/150/200%; all nine Hub launchers accessible after scrolling; no installer operation invoked |
| Final Revit reference builds | **6/6**, zero warnings and zero errors, after final UI edits |
| Assembly metadata inspection | Matching RevitAPI/RevitAPIUI major versions, runtime, V3 build identity, new feature classes and retained V2 tools in all six DLL pairs |
| Independent sample workbook read | Valid ZIP and five worksheets read with openpyxl; no formula cells |

The layout harness verifies snapshot/refresh/filter/export behavior, missing versus zero quantities, shared-door totals, room/source details, stale-setting rejection, Ctrl+E, native button text fit and a results viewport with a header plus two readable rows. Final smallest-screen screenshots were visually inspected. Initial failed layout attempts remain in the evidence directory as history.

| Revit target | Runtime |
| --- | --- |
| 2022.1+ / 2023 / 2024 | .NET Framework 4.8 |
| 2025 / 2026 | .NET 8 Windows |
| 2027 | .NET 10 Windows |

Final build outputs are in `release/<year>/KAMEP.Revit.dll` and `KAMEP.Core.dll`. Evidence: [validation-v3-spaces-20261026-01](validation-v3-spaces-20261026-01/). Relevant records are `build-all.log`, `assembly-receipt.json`, `source-fingerprint.json`, `spaces-layout-matrix.log`, `spaces-layout/screenshots/`, `branding-layout-wrap/`, the calculation/report logs, `example-workbook-receipt.json` and `ui-visual-review.txt`.

## Runtime limits

**Native Windows/Revit and desktop Excel were not run here.** API-reference compilation, detached tests and explicit Mono font/control scaling do not prove native Revit execution, every model geometry, Windows DPI behavior or Excel print fidelity. The Linux fallback font did not render the Arabic Room name correctly in UI captures; Unicode workbook values and Arabic search are tested, while native Windows glyph shaping/fallback remains pending.

Heights are sampled rather than certified extrema throughout a room. Only supported Floor/Ceiling surfaces in the selected phase/main or primary option participate. Direct loaded links are included; nested links are explicitly excluded. Opening area is nominal width × height, not net glazing, rough opening or clear opening area. One unassociated/read-failed opening can make counts in that source uncertain; known detail records remain available. The tool does not calculate HVAC loads or modify the Revit model.

See [Arabic usage guide](HVAC-SPACES.ar.md) and the **pending** [manual Revit/Excel smoke-test checklist](HVAC-SPACES-SMOKE-TEST.md). The [example workbook](../artifacts/KA-MEP-V3-HVAC-Spaces-Example.xlsx) contains simulated data for illustration, not measurements from a user model.

## Preserved release boundary

The prior V2 installer is unchanged: **2,183,680 bytes**, SHA256 `5425faa33b8f11ad9a79e7e348ade185189f7928a79dafb0ffa5d296a22338ac`. Its validation history remains in [VALIDATION-V2.0-Build-20261024-01.md](VALIDATION-V2.0-Build-20261024-01.md), and its source checkpoint is preserved in `artifacts/source-archive/KA-MEP-V2.0-Build-20261024-01-source.zip`.

**Do not create a V3 installer/EXE until the user explicitly requests it.**
