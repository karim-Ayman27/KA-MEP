import concurrent.futures, os, subprocess, time
from pathlib import Path
runtime=Path('/workspace/.ka-mep-layout-runtime/root')
project=Path('/workspace/RevitPipeTakeoff')
out=Path('/workspace/.ka-mep-layout-runtime/tag-assistant-near-host')
(out/'screenshots').mkdir(parents=True, exist_ok=True)
cases=['1366x728_100','1280x680_150','1280x680_200','1024x600_100','1024x600_150','1024x600_200','876x571_100','876x571_150','876x571_200']
def run(index_case):
    index,case=index_case
    display=181+index
    socket=Path('/tmp/.X11-unix/X'+str(display))
    if socket.exists(): raise RuntimeError('Display already exists: '+str(display))
    env=os.environ.copy(); env.update(DISPLAY=':'+str(display),MONO_CFG_DIR=str(runtime/'etc'),MONO_PATH=str(runtime/'usr/lib/mono/4.5')+':/workspace/.dotnet/sdk/8.0.425/Microsoft/Microsoft.NET.Build.Extensions/net461/lib',LD_LIBRARY_PATH=str(runtime/'usr/lib'))
    with (out/(case+'.xvfb.log')).open('w') as xlog:
        x=subprocess.Popen([str(runtime/'usr/bin/Xvfb'),':'+str(display),'-screen','0','1600x1000x24','-nolisten','tcp','-ac'],env=env,stdout=xlog,stderr=subprocess.STDOUT)
        try:
            for _ in range(100):
                if socket.exists(): break
                if x.poll() is not None: raise RuntimeError('Xvfb stopped for '+case)
                time.sleep(.1)
            else: raise RuntimeError('Xvfb did not start for '+case)
            p=subprocess.run([str(runtime/'usr/bin/mono'),'tests/TagAssistantLayout.Tests/bin/Release/net48/KAMEP.TagAssistantLayout.Tests.exe','--case='+case,'--screenshots='+str(out/'screenshots')],cwd=project,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=120)
            (out/(case+'.log')).write_text(p.stdout)
            return case,p.returncode,p.stdout
        finally:
            x.terminate(); x.wait(timeout=10)
failed=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    for case,code,output in pool.map(run,enumerate(cases)):
        print(output,flush=True)
        if code: failed.append(case)
print('MATRIX RESULT: '+str(9-len(failed))+'/9 passed',flush=True)
if failed: raise SystemExit('Failed: '+','.join(failed))
