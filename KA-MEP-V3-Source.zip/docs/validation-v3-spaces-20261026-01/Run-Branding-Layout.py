import os, subprocess, time, sys
from pathlib import Path
root=Path('/workspace/.ka-mep-layout-runtime/root')
out=Path('/workspace/RevitPipeTakeoff/docs/validation-v3-spaces-20261026-01/branding-layout'); (out/'screenshots').mkdir(parents=True,exist_ok=True)
env=os.environ.copy(); env.update(DISPLAY=':291', MONO_CFG_DIR=str(root/'etc'), MONO_PATH=str(root/'usr/lib/mono/4.5')+':/workspace/.dotnet/sdk/8.0.425/Microsoft/Microsoft.NET.Build.Extensions/net461/lib', LD_LIBRARY_PATH=str(root/'usr/lib'))
cases=sys.argv[1:] or ['1366x728_100','1280x680_150','1280x680_200']
Path('/tmp/.X11-unix').mkdir(parents=True, exist_ok=True)
with (out/'xvfb.log').open('w') as xlog:
    x=subprocess.Popen([str(root/'usr/bin/Xvfb'),':291','-screen','0','1600x1000x24','-nolisten','tcp','-ac'],env=env,stdout=xlog,stderr=subprocess.STDOUT)
    try:
        for i in range(50):
            if Path('/tmp/.X11-unix/X291').exists(): break
            if x.poll() is not None: raise RuntimeError('Xvfb stopped; see log')
            time.sleep(.1)
        failures=[]
        for case in cases:
            p=subprocess.run([str(root/'usr/bin/mono'),'tests/BrandingLayout.Tests/bin/Release/net48/KAMEP.BrandingLayout.Tests.exe','--case='+case,'--screenshots='+str(out/'screenshots')],cwd='/workspace/RevitPipeTakeoff',env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=50)
            (out/(case+'.log')).write_text(p.stdout)
            print(p.stdout,flush=True)
            if p.returncode: failures.append(case)
        if failures: raise SystemExit('Failed: '+','.join(failures))
    finally:
        x.terminate(); x.wait(timeout=10)
