# KA MEP V2.0 — nearby Tag Assistant validation

Code and DLL checks completed on 2026-10-22. Public version **V2.0**, assembly version **2.0.0**, build identity **20261021-01**.

**No installer EXE was exported, as requested.** Existing EXEs in `artifacts/` are historical and do not contain this update. DLLs are in the six `release/<year>/` directories; the previously installed copy on a user's computer is unchanged until a later installation/update.

## Implemented behavior

Tag Assistant defaults to selected elements only and the new Near elements pattern. Empty selection cannot silently become a whole-view creation batch. Defaults are 3-paper-mm offset, 1.5-paper-mm spacing, 20-paper-mm maximum label-center distance and 50 tags per batch. Larger batches require an explicit limit change, up to 500; no first-N truncation occurs.

The element review supports persistent exclusions. Mixed creation selections leave fitting/flex categories unchecked initially; deliberate fitting-only selections remain usable. The optional 5-paper-mm visible projected-length filter applies only when creating curve tags; unknown lengths and end-on risers remain eligible. Existing tags are retained, and blank/question-mark-only new labels are skipped.

Near elements uses measured family bounds and nearby positions inside a rectangular drawing crop. Crowded placements are skipped instead of being sent farther away. Skipped existing tags stay in their original locations and become fixed obstacles for the remaining layout. All nonempty measured batches receive a count/distance review before applying; failed nearby verification rolls back the whole batch. The previous five group patterns remain available explicitly.

## Completed checks

- Six Revit builds passed with **zero warnings and errors** using .NET SDK 10: references 2022.1.1,2023.0.1,2024.0.0,2025.0.2,2026.0.4,2027.0.0. Revit 2022–2024 target .NET Framework 4.8;2025–2026 target .NET8 Windows;2027 targets.NET10 Windows. Revit 2022.1 is the minimum verified reference level.
- PE metadata inspection passed for all six DLL pairs: matching RevitAPI/RevitAPIUI major versions, runtime and informational identity `2.0.0+20261021-01`, plus new nearby options/engine and retained tool classes. SHA256 receipts are in `validation-tag-nearby/assembly-receipt.json`.
- Core tag layout: **30 groups passed**, including 300 legacy randomized cases,60 dense nearby randomized scenes, distance/crop/obstacle checks, preserved legacy pattern behavior and a 500-tag/500-obstacle bounded-search case.
- Detached Tag Assistant model: **38/38 cases passed**, covering selection-first defaults, explicit counts, per-element exclusions, paper units, short-run filtering, mixed fitting opt-in, all-estimated-skipped access to actual measurement and nearby crop behavior.
- Existing feature regressions: **54** quantity/Excel/naming checks, **39** Sheet Parameters cases, **29** Model Review checks (including 100 score cases) and **40** Model Review Excel checks passed.
- Detached UI: **9/9 cases passed** on final source. Cases: 1366×728 at 100%;1280×680 at 150%/200%;1024×600 and 876×571 at 100%/150%/200%. Checks cover all four tabs, six patterns, element review/exclusions, selection/mode behavior, fixed action buttons and visible schematic labels. Normal and smallest/high-scale screenshots were visually reviewed. Final logs, screenshots, runner and source hashes are in `validation-tag-nearby/ui/`.
- Independent read-only audit found no blocking source defect in selection/count guards, measured distance/crop enforcement, preserved skipped-tag obstacles or rollback flow.

Build and test logs are in `validation-tag-nearby/`. These checks compile code and exercise detached logic; they do not certify live Revit behavior.

## Runtime boundaries

No native Windows/Revit runtime is available here. The UI harness uses Mono/Xvfb and explicit control/font scaling; it does not certify Windows per-monitor DPI or Revit-hosted rendering.

Collision checks cover label rectangles, text notes and readable supported MEP point-family bounds. They do not cover every model edge, dimension or leader crossing. More than 5000 preview obstacles fails conservatively before writes. Irregular/split crops are unavailable for Near elements; the tool gives a reason instead of switching patterns automatically. Existing free leader endpoints are preserved and may require manual correction.

Final text bounds are verified with leaders disabled; leaders are restored afterward. Actual Revit family/leader behavior, post-commit effects, worksharing, rollback/Undo and visibility require the manual checks in `TAG-ASSISTANT-NEARBY-SMOKE-TEST.md` and `REVIT-SMOKE-TEST.md`. No live model was modified or tested in this workspace.

Earlier Model Review/installer-source validation is preserved in `VALIDATION-V2.0-Build-20261020-02.md`; the earlier packaged-release evidence is in `VALIDATION-V2.0-Build-20261020-01.md`. Their installer hashes do not describe a new package.

## Reproduce without packaging

Use .NET SDK 10 with `scripts/Build.ps1 -UsePackageRevitApi`, then `docs/validation-tag-nearby/Verify-Assemblies.ps1`. Run the six console projects named in the evidence directory and the detached TagAssistantLayout harness. Do not run `scripts/Build-Installer.ps1` until a new installer is requested.
