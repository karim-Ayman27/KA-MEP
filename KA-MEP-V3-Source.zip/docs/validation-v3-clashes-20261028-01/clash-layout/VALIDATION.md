# Detached Clash Manager layout validation

Run date: 2026-10-29 UTC. Result: **9/9 cases passed** against the production `ClashManagerForm` and `ClashMappingForm`, linked into the net48 layout harness.

This is Mono/Xvfb evidence with simulated font/control scaling. It is **not** native Windows DPI, live Revit, model geometry, or ExternalEvent validation. The test data is illustrative; green fixture states are not model-check results.

## Reproduce

```sh
DOTNET_CLI_HOME=/workspace/.dotnet-home NUGET_PACKAGES=/workspace/.nuget DOTNET_NOLOGO=1 /workspace/.dotnet/dotnet build tests/ClashManagerLayout.Tests/ClashManagerLayout.Tests.csproj -c Release --no-restore
python3 docs/validation-v3-clashes-20261028-01/Run-Clashes-Layout.py
```

The runner uses the existing runtime under `/workspace/.ka-mep-layout-runtime/root`, independent displays 311–319, and three parallel workers. The build completed with zero warnings and errors; see `../clash-ui-build.log`. The complete execution log is `../clash-layout-matrix.log`; each case also has a separate log in this directory. Source hashes are in `source-sha256.txt`.

| Client size | Simulated scale | Result |
|---|---:|---|
| 1366 × 728 | 100% | PASS |
| 1280 × 680 | 150% | PASS |
| 1280 × 680 | 200% | PASS |
| 1024 × 600 | 100% | PASS |
| 1024 × 600 | 150% | PASS |
| 1024 × 600 | 200% | PASS |
| 876 × 571 | 100% | PASS |
| 876 × 571 | 150% | PASS |
| 876 × 571 | 200% | PASS |

## Exercised behavior

The harness covers local HTML drag/drop guards, import display, all four current-state filters and color labels, test and Unicode search filters, selection-independent visible export, import provenance, 64-bit IDs, selected/visible refresh scopes, explicit source mapping and Auto reset, stale identity/result clearing, 3D focus event arguments, unknown-test opt-in, busy/cancel states, and long status text. Mapping coverage includes all 18 fields, table switching, header interpretation, missing/duplicate identifier rejection, numeric IDs, and Unique ID alternatives.

Layout checks assert complete ancestor bounds for fixed actions, filters and grids; all source/check/focus options can be scrolled into view; mapping fields and actions remain reachable; scaled grid rows and headers fit their fonts; and the main grid retains at least its header and two full rows. The harness corrects Mono's repeated `ScrollControlIntoView` overshoot by moving the actual scroll position, then checks full screen bounds. It does not bypass clipping assertions.

## Visual review

There are 36 screenshots: results, details, mapping, and final stale/long-status state for each case. Reviewed all nine results screenshots, normal/100% and small/200% pair details and mapping, and the small/200% final state. Browse, tabs, filters, footer actions and grid scrollbars remain visible. At 876 × 571 / 200%, the grid displays two full rows; extra columns use horizontal scrolling and pair options use vertical scrolling. The long status is ellipsized without enlarging the footer. All four state labels retain text plus distinct green/red/amber/grey indicators.

The detached renderer logs its built-in color-scheme fallback because GTK is absent. Arabic search behavior passes, but the Arabic-leading fixture name appears blank in the grid screenshots; these captures do not establish native Windows Arabic glyph rendering.

## Issues corrected during this run

The first small/200% run exposed width expansion from implicit table-layout columns and excessive import-caption height. Explicit percentage columns now constrain the form and mapping preview to available width; a bounded import caption preserves grid height. Pair controls were flattened within their scrolling table. The initial failure log is retained as `initial-876x571_200.log`; the case-named logs and screenshots are the final passing run.
