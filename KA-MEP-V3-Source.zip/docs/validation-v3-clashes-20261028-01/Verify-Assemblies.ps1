$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$props = [xml](Get-Content -LiteralPath (Join-Path $root 'Directory.Build.props') -Raw)
$identity = [string]$props.Project.PropertyGroup.Version + '+' + [string]$props.Project.PropertyGroup.BuildId
$rows = @()
foreach ($year in 2022..2027) {
    $file = Join-Path $root "release/$year/KAMEP.Revit.dll"
    $stream = [IO.File]::OpenRead($file)
    $pe = [System.Reflection.PortableExecutable.PEReader]::new($stream)
    try {
        $reader = [System.Reflection.Metadata.PEReaderExtensions]::GetMetadataReader($pe)
        $apiRefs = @{}
        foreach ($handle in $reader.AssemblyReferences) {
            $reference = $reader.GetAssemblyReference($handle)
            $name = $reader.GetString($reference.Name)
            if ($name -in @('RevitAPI', 'RevitAPIUI')) {
                if ($reference.Version.Major -ne ($year - 2000)) { throw "Wrong API reference $year $name" }
                $apiRefs[$name] = $reference.Version.ToString()
            }
        }
        if ($apiRefs.Count -ne 2) { throw "Missing API references for $year" }
        $bytes = [IO.File]::ReadAllBytes($file)
        $raw = [Text.Encoding]::UTF8.GetString($bytes)
        $runtime = if ($year -le 2024) { '.NETFramework,Version=v4.8' } elseif ($year -eq 2027) { '.NETCoreApp,Version=v10.0' } else { '.NETCoreApp,Version=v8.0' }
        if (-not $raw.Contains('Karim Ayman')) { throw "Missing publisher metadata for $year" }
        if ($pe.PEHeaders.PEHeader.CertificateTableDirectory.Size -ne 0) { throw "Unexpected Authenticode data in unsigned development build $year" }
        if (-not $raw.Contains($runtime) -or -not $raw.Contains($identity)) { throw "Wrong runtime or build for $year" }
        foreach ($feature in @('ClashManagerCommand','ClashManagerController','ClashManagerForm','ClashMappingForm','ClashRevitService','ClashVerificationPolicy','SpaceTakeoffCommand','SpaceTakeoffForm','SpaceTakeoffReader','SpaceOpeningReader','ModelReviewCommand','ModelReviewController','ModelReviewForm','ModelReviewService','SheetEditorCommand','TagAssistantCommand','SheetExportCommand','CableTrayTakeoffCommand','ConduitTakeoffCommand','get_MaximumTags','get_ExcludedCandidateKeys','get_NearHostAvailable','get_FamilyDisplayName','get_TypeDisplayName','ApplyOrthogonalLeader','ReviewIssueGrouping','RibbonLogoBytes')) {
            if (-not $raw.Contains($feature)) { throw "Missing $feature in $year" }
        }
        $core = Join-Path $root "release/$year/KAMEP.Core.dll"
        $coreRaw = [Text.Encoding]::UTF8.GetString([IO.File]::ReadAllBytes($core))
        foreach ($feature in @($identity,'ClashHtmlImporter','ClashXlsxExporter','ClashRecord','ClashColumnMapping','SpaceOpeningDimensions','SpaceTakeoffXlsxExporter','SpaceSurfaceIndex','SpaceHeightEngine','SpaceOpeningSummary','ModelReviewXlsxExporter','DuctXlsxExporter','ElectricalXlsxExporter','TagLayoutEngine','NearHost','get_SkippedKeys','get_AllowedBounds','OrthogonalElbow','get_OrthogonalLeaders')) {
            if (-not $coreRaw.Contains($feature)) { throw "Missing core $feature in $year" }
        }
        $rows += [pscustomobject]@{ Revit=$year; Runtime=$runtime; ApiReferences=$apiRefs; Company='Karim Ayman'; AuthenticodeSignaturePresent=$false; RevitSha256=(Get-FileHash $file -Algorithm SHA256).Hash.ToLower(); CoreSha256=(Get-FileHash $core -Algorithm SHA256).Hash.ToLower() }
        Write-Host "PASS $year matching API references, runtime, feature classes and $identity"
    }
    finally { $pe.Dispose(); $stream.Dispose() }
}
[pscustomobject]@{Build=$identity; Status='V3 development DLLs verified; no installer built or published'; VerifiedUtc=[DateTime]::UtcNow.ToString('O'); Releases=$rows} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $root 'docs/validation-v3-clashes-20261028-01/assembly-receipt.json') -Encoding utf8
