# Validation of syntax, recovery file states, and the unsupported-platform guard.
# This does not exercise Authenticode, certificate stores, SignTool, or native
# Windows ReplaceFile failure injection.
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$script = Join-Path $root 'scripts/Sign-Release.ps1'
$errors = $null; $tokens = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile($script, [ref]$tokens, [ref]$errors)
if ($errors.Count) { throw ($errors | Out-String) }
Write-Host 'PASS PowerShell syntax parse.'
$sets = @((Get-Command $script).ParameterSets)
if (@($sets | Where-Object { $_.Name -eq 'Assemblies' }).Count -ne 1 -or
    @($sets | Where-Object { $_.Name -eq 'Installer' }).Count -ne 1) { throw 'Separate assembly and installer modes are missing.' }
Write-Host 'PASS Separate assembly and installer parameter sets.'
$recovery = $ast.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Restore-SigningPlan' }, $true)
if (-not $recovery) { throw 'Production recovery helper not found.' }
. ([scriptblock]::Create($recovery.Extent.Text))
$fixtures = Join-Path ([IO.Path]::GetTempPath()) ('ka-mep-signing-recovery-' + [Guid]::NewGuid().ToString('N'))
try {
    [void][IO.Directory]::CreateDirectory($fixtures)
    $originalFixture = Join-Path $fixtures 'original.txt'; [IO.File]::WriteAllText($originalFixture, 'original')
    $signedFixture = Join-Path $fixtures 'signed.txt'; [IO.File]::WriteAllText($signedFixture, 'signed')
    function New-Plan([string] $name, [bool] $existed, [bool] $committed) {
        $directory = Join-Path $fixtures $name; [void][IO.Directory]::CreateDirectory($directory)
        return [pscustomobject]@{ Target = (Join-Path $directory 'target'); Backup = (Join-Path $directory 'backup'); Stage = (Join-Path $directory 'stage');
            Existed = $existed; Committed = $committed; OriginalHash = (Get-FileHash $originalFixture -Algorithm SHA256).Hash; SignedHash = (Get-FileHash $signedFixture -Algorithm SHA256).Hash }
    }
    $plan = New-Plan 'completed-replacement' $true $true
    [IO.File]::WriteAllText($plan.Target, 'signed'); [IO.File]::WriteAllText($plan.Backup, 'original')
    Restore-SigningPlan $plan
    if ([IO.File]::ReadAllText($plan.Target) -ne 'original') { throw 'Completed replacement was not restored.' }
    Write-Host 'PASS Completed replacement restores original bytes.'
    $plan = New-Plan 'partial-replacement-missing-target' $true $false
    [IO.File]::WriteAllText($plan.Backup, 'original'); [IO.File]::WriteAllText($plan.Stage, 'signed')
    Restore-SigningPlan $plan
    if ([IO.File]::ReadAllText($plan.Target) -ne 'original') { throw 'Partial replacement lost its sole backup.' }
    Write-Host 'PASS Partial replacement restores the sole backup even before Committed.'
    $plan = New-Plan 'original-unchanged' $true $false
    [IO.File]::WriteAllText($plan.Target, 'original'); [IO.File]::WriteAllText($plan.Stage, 'signed')
    Restore-SigningPlan $plan
    if ([IO.File]::ReadAllText($plan.Target) -ne 'original') { throw 'Unchanged original was altered.' }
    Write-Host 'PASS Failed replacement preserves an unchanged original.'
    $plan = New-Plan 'missing-recovery-copy' $true $false
    [IO.File]::WriteAllText($plan.Target, 'signed')
    $rejected = $false; try { Restore-SigningPlan $plan } catch { $rejected = $true }
    if (-not $rejected -or [IO.File]::ReadAllText($plan.Target) -ne 'signed') { throw 'Missing backup was silently accepted or target deleted.' }
    Write-Host 'PASS Missing backup fails recovery and preserves remaining data.'
    foreach ($completed in @($true, $false)) {
        $plan = New-Plan ('new-checksum-' + $completed) $false $completed
        [IO.File]::WriteAllText($plan.Target, 'signed')
        Restore-SigningPlan $plan
        if (Test-Path -LiteralPath $plan.Target) { throw 'New checksum was not removed during recovery.' }
    }
    Write-Host 'PASS New checksum is removed after completed or partial move.'
    $plan = New-Plan 'changed-checksum' $false $true
    [IO.File]::WriteAllText($plan.Target, 'changed')
    $rejected = $false; try { Restore-SigningPlan $plan } catch { $rejected = $true }
    if (-not $rejected -or [IO.File]::ReadAllText($plan.Target) -ne 'changed') { throw 'Recovery deleted an externally changed checksum.' }
    Write-Host 'PASS Externally changed checksum is preserved and recovery fails visibly.'
}
finally { if (Test-Path -LiteralPath $fixtures) { Remove-Item -LiteralPath $fixtures -Recurse -Force } }
if ([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT) {
    Write-Host 'SKIP Unsupported-platform guard on Windows. No signing operation was invoked.'
    return
}
$scratch = Join-Path ([IO.Path]::GetTempPath()) ('ka-mep-signing-guard-' + [Guid]::NewGuid().ToString('N'))
try {
    [void][IO.Directory]::CreateDirectory((Join-Path $scratch 'scripts'))
    [void][IO.Directory]::CreateDirectory((Join-Path $scratch 'release/2022'))
    $copy = Join-Path $scratch 'scripts/Sign-Release.ps1'
    Copy-Item -LiteralPath $script -Destination $copy
    $marker = Join-Path $scratch 'release/2022/unchanged-marker.txt'
    [IO.File]::WriteAllText($marker, 'A marker for guard validation, not an assembly.')
    $before = (Get-FileHash -LiteralPath $marker -Algorithm SHA256).Hash
    $rejected = $false
    try { & $copy -CertificateThumbprint ('0' * 40) -RevitVersion 2022 }
    catch { $rejected = $_.Exception.Message.Contains('Authenticode signing requires Windows') }
    if (-not $rejected) { throw 'Unsupported-platform invocation was not rejected with the intended prerequisite message.' }
    if ((Get-FileHash -LiteralPath $marker -Algorithm SHA256).Hash -ne $before) { throw 'Unsupported-platform guard changed its fixture.' }
    if (@(Get-ChildItem -LiteralPath $scratch -Recurse -Directory | Where-Object { $_.Name.StartsWith('.ka-mep-signing-') }).Count) { throw 'Unsupported-platform guard staged output files.' }
    Write-Host 'PASS Unsupported-platform refusal before file staging; fixture unchanged.'
}
finally { if (Test-Path -LiteralPath $scratch) { Remove-Item -LiteralPath $scratch -Recurse -Force } }
Write-Host 'LIMIT: Windows certificate checks, signing, timestamping, trusted verification, and native ReplaceFile failure behavior remain untested.'
