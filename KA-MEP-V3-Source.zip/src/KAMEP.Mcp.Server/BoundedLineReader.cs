using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using PipeTakeoff.Core.Mcp;

namespace KAMEP.Mcp.Server
{
    internal sealed class InputLine
    {
        public string Text { get; set; }
        public bool TooLarge { get; set; }
        public bool InvalidEncoding { get; set; }
    }

    /// <summary>Never buffers an unbounded line, even if the client omits a newline.</summary>
    internal sealed class BoundedLineReader
    {
        private readonly Stream stream;
        private readonly byte[] readBuffer = new byte[4096];
        private readonly byte[] lineBuffer = new byte[McpLimits.MaxRequestBytes + 1];
        private int readOffset;
        private int readCount;
        private static readonly Encoding StrictUtf8 = new UTF8Encoding(false, true);

        public BoundedLineReader(Stream stream) { this.stream = stream; }

        public async Task<InputLine> ReadAsync(CancellationToken cancellationToken)
        {
            int lineCount = 0;
            bool tooLarge = false;
            bool hasInput = false;
            while (true)
            {
                if (readOffset == readCount)
                {
                    readCount = await stream.ReadAsync(readBuffer, 0, readBuffer.Length, cancellationToken).ConfigureAwait(false);
                    readOffset = 0;
                    if (readCount == 0) return !hasInput ? null : Decode(lineCount, tooLarge);
                }
                byte value = readBuffer[readOffset++];
                hasInput = true;
                if (value == 10) return Decode(lineCount, tooLarge);
                if (lineCount < lineBuffer.Length) lineBuffer[lineCount++] = value;
                else tooLarge = true;
            }
        }

        private InputLine Decode(int count, bool tooLarge)
        {
            if (count > 0 && lineBuffer[count - 1] == 13) count--;
            if (tooLarge || count > McpLimits.MaxRequestBytes) return new InputLine { TooLarge = true };
            try { return new InputLine { Text = StrictUtf8.GetString(lineBuffer, 0, count) }; }
            catch (DecoderFallbackException) { return new InputLine { InvalidEncoding = true }; }
        }
    }
}
