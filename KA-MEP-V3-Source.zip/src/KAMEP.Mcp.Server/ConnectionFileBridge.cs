using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using PipeTakeoff.Core.Mcp;

namespace KAMEP.Mcp.Server
{
    /// <summary>Reads only the explicitly configured connection record; there is no general file-access tool.</summary>
    public sealed class ConnectionFileBridge
    {
        private const int MaxConnectionBytes = 16384;
        private readonly string connectionPath;

        public ConnectionFileBridge(string connectionPath)
        {
            this.connectionPath = ValidatePath(connectionPath);
        }

        public async Task<McpWireResponse> CallAsync(McpWireRequest request, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            McpConnection connection;
            try
            {
                connection = ReadConnection();
            }
            catch (Exception exception) when (exception is IOException || exception is InvalidDataException || exception is UnauthorizedAccessException || exception is ArgumentException || exception is System.Runtime.Serialization.SerializationException || exception is System.Xml.XmlException)
            {
                return McpWireResponse.Fail(request.RequestId, "connection_unavailable", "The KA MEP connection is unavailable. In this Revit session, enable MCP and use its generated Claude Desktop configuration.");
            }
            return await McpLoopbackClient.Call(connection, request, cancellationToken).ConfigureAwait(false);
        }

        private McpConnection ReadConnection()
        {
            byte[] bytes;
            // Revit writes an atomic replacement. Read a fresh record on every request to pick up token/port rotation.
            using (var stream = new FileStream(connectionPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
            {
                if (stream.Length <= 0 || stream.Length > MaxConnectionBytes) throw new InvalidDataException("Invalid connection record.");
                bytes = new byte[(int)stream.Length];
                int offset = 0;
                while (offset < bytes.Length)
                {
                    int read = stream.Read(bytes, offset, bytes.Length - offset);
                    if (read == 0) throw new InvalidDataException("Incomplete connection record.");
                    offset += read;
                }
                if (stream.ReadByte() != -1) throw new InvalidDataException("Connection record changed.");
            }
            string json;
            try { json = new UTF8Encoding(false, true).GetString(bytes); }
            catch (DecoderFallbackException) { throw new InvalidDataException("Invalid connection record."); }
            if (!JsonSyntax.IsValid(json)) throw new InvalidDataException("Invalid connection record.");
            var connection = McpWireCodec.Deserialize<McpConnection>(bytes);
            if (connection == null || connection.Protocol != 1 || connection.Port < 1 || connection.Port > 65535 || connection.ProcessId <= 0 ||
                connection.Token == null || connection.Token.Length != 64 || connection.Token.Any(character => !IsHex(character)))
                throw new InvalidDataException("Invalid connection record.");
            return connection;
        }

        private static bool IsHex(char value)
        {
            return value >= '0' && value <= '9' || value >= 'a' && value <= 'f' || value >= 'A' && value <= 'F';
        }

        public static string ValidatePath(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || !Path.IsPathRooted(path) || path.StartsWith(@"\\", StringComparison.Ordinal) || path.StartsWith("//", StringComparison.Ordinal))
                throw new ArgumentException("--connection-file must be an absolute local file path.");
            string fullPath = Path.GetFullPath(path);
            if (Path.DirectorySeparatorChar == '\\')
            {
                if (fullPath.Length < 3 || fullPath[1] != ':' || fullPath[2] != '\\' || path.Length < 3 || path[1] != ':' || path[2] != '\\')
                    throw new ArgumentException("--connection-file must use an absolute local drive path.");
                var drive = new DriveInfo(Path.GetPathRoot(fullPath));
                if (drive.DriveType == DriveType.Network || drive.DriveType == DriveType.NoRootDirectory || drive.DriveType == DriveType.Unknown)
                    throw new ArgumentException("--connection-file must be on a local drive.");
                if (fullPath.IndexOf(':', 2) >= 0) throw new ArgumentException("Alternate data streams are not supported.");
            }
            return fullPath;
        }
    }
}
