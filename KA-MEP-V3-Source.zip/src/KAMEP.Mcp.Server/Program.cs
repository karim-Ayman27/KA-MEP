using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace KAMEP.Mcp.Server
{
    internal static class Program
    {
        public static int Main(string[] args)
        {
            try
            {
                if (args.Length != 2 || args[0] != "--connection-file")
                {
                    Console.Error.WriteLine("Usage: KAMEP.Mcp.Server.exe --connection-file <absolute local connection.json path>");
                    return 2;
                }
                var bridge = new ConnectionFileBridge(args[1]);
                return RunAsync(new McpProtocolEngine(bridge.CallAsync)).GetAwaiter().GetResult();
            }
            catch (ArgumentException)
            {
                Console.Error.WriteLine("KA MEP MCP requires --connection-file with an absolute local file path.");
                return 2;
            }
            catch (Exception)
            {
                Console.Error.WriteLine("KA MEP MCP stopped because its local input or output stream failed.");
                return 1;
            }
        }

        private static async Task<int> RunAsync(McpProtocolEngine engine)
        {
            using (var lifetime = new CancellationTokenSource())
            using (var output = new StreamWriter(Console.OpenStandardOutput(), new UTF8Encoding(false)) { AutoFlush = true, NewLine = "\n" })
            using (var outputGate = new SemaphoreSlim(1, 1))
            {
                var reader = new BoundedLineReader(Console.OpenStandardInput());
                var tasks = new HashSet<Task>();
                ConsoleCancelEventHandler cancelHandler = (sender, args) => { args.Cancel = true; lifetime.Cancel(); };
                Console.CancelKeyPress += cancelHandler;
                try
                {
                    while (!lifetime.IsCancellationRequested)
                    {
                        InputLine line = await reader.ReadAsync(lifetime.Token).ConfigureAwait(false);
                        if (line == null) break;
                        Task<string> response = line.TooLarge ? Task.FromResult(McpProtocolEngine.OversizedInputError()) :
                            line.InvalidEncoding ? Task.FromResult(McpProtocolEngine.InvalidEncodingError()) : engine.ProcessLineAsync(line.Text, lifetime.Token);
                        Task write = WriteResponseAsync(response, output, outputGate);
                        tasks.RemoveWhere(task => task.IsCompleted && !task.IsFaulted);
                        tasks.Add(write);
                        // The engine admits at most eight bridge calls. Fast requests are flushed before reading
                        // more input so an indefinitely fast producer cannot queue an unbounded output backlog.
                        if (response.IsCompleted) await write.ConfigureAwait(false);
                        foreach (Task task in tasks) if (task.IsFaulted) await task.ConfigureAwait(false);
                    }
                }
                catch (OperationCanceledException) { }
                finally
                {
                    lifetime.Cancel();
                    Console.CancelKeyPress -= cancelHandler;
                }
                await Task.WhenAll(tasks).ConfigureAwait(false);
                return 0;
            }
        }

        private static async Task WriteResponseAsync(Task<string> responseTask, StreamWriter output, SemaphoreSlim outputGate)
        {
            string response = await responseTask.ConfigureAwait(false);
            if (response == null) return;
            await outputGate.WaitAsync().ConfigureAwait(false);
            try { await output.WriteLineAsync(response).ConfigureAwait(false); }
            finally { outputGate.Release(); }
        }
    }
}
