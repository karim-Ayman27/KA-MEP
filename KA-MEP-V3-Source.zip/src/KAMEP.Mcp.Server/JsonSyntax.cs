using System;
using System.Collections.Generic;
using System.Text;

namespace KAMEP.Mcp.Server
{
    /// <summary>JavaScriptSerializer accepts JavaScript extensions. MCP permits strict JSON only.</summary>
    internal sealed class JsonSyntax
    {
        private readonly string text;
        private int offset;
        private JsonSyntax(string text) { this.text = text; }

        public static bool IsValid(string text)
        {
            if (text == null) return false;
            var parser = new JsonSyntax(text);
            if (!parser.Value(0)) return false;
            parser.WhiteSpace();
            return parser.offset == text.Length;
        }

        private bool Value(int depth)
        {
            if (depth > 64) return false;
            WhiteSpace();
            if (offset >= text.Length) return false;
            char value = text[offset];
            if (value == '{') return Object(depth + 1);
            if (value == '[') return Array(depth + 1);
            if (value == '"') { string ignored; return String(out ignored); }
            if (value == 't') return Literal("true");
            if (value == 'f') return Literal("false");
            if (value == 'n') return Literal("null");
            return Number();
        }

        private bool Object(int depth)
        {
            offset++;
            WhiteSpace();
            if (Take('}')) return true;
            var keys = new HashSet<string>(StringComparer.Ordinal);
            while (true)
            {
                string key;
                if (!String(out key) || !keys.Add(key)) return false;
                WhiteSpace();
                if (!Take(':') || !Value(depth)) return false;
                WhiteSpace();
                if (Take('}')) return true;
                if (!Take(',')) return false;
                WhiteSpace();
            }
        }

        private bool Array(int depth)
        {
            offset++;
            WhiteSpace();
            if (Take(']')) return true;
            while (true)
            {
                if (!Value(depth)) return false;
                WhiteSpace();
                if (Take(']')) return true;
                if (!Take(',')) return false;
            }
        }

        private bool String(out string result)
        {
            result = null;
            if (!Take('"')) return false;
            var value = new StringBuilder();
            while (offset < text.Length)
            {
                char character = text[offset++];
                if (character == '"') { result = value.ToString(); return true; }
                if (character < 32) return false;
                if (character != '\\') { value.Append(character); continue; }
                if (offset == text.Length) return false;
                character = text[offset++];
                switch (character)
                {
                    case '"': case '\\': case '/': value.Append(character); break;
                    case 'b': value.Append('\b'); break;
                    case 'f': value.Append('\f'); break;
                    case 'n': value.Append('\n'); break;
                    case 'r': value.Append('\r'); break;
                    case 't': value.Append('\t'); break;
                    case 'u':
                        if (offset + 4 > text.Length) return false;
                        int code = 0;
                        for (int index = 0; index < 4; index++)
                        {
                            char digit = text[offset++];
                            int hex = digit >= '0' && digit <= '9' ? digit - '0' : digit >= 'a' && digit <= 'f' ? digit - 'a' + 10 : digit >= 'A' && digit <= 'F' ? digit - 'A' + 10 : -1;
                            if (hex < 0) return false;
                            code = code * 16 + hex;
                        }
                        value.Append((char)code);
                        break;
                    default: return false;
                }
            }
            return false;
        }

        private bool Number()
        {
            Take('-');
            if (!Take('0'))
            {
                if (offset >= text.Length || text[offset] < '1' || text[offset] > '9') return false;
                while (offset < text.Length && Digit(text[offset])) offset++;
            }
            if (Take('.'))
            {
                int start = offset;
                while (offset < text.Length && Digit(text[offset])) offset++;
                if (start == offset) return false;
            }
            if (Take('e') || Take('E'))
            {
                if (!Take('+')) Take('-');
                int start = offset;
                while (offset < text.Length && Digit(text[offset])) offset++;
                if (start == offset) return false;
            }
            return true;
        }

        private bool Literal(string value)
        {
            if (offset + value.Length > text.Length || string.CompareOrdinal(text, offset, value, 0, value.Length) != 0) return false;
            offset += value.Length;
            return true;
        }

        private bool Take(char value)
        {
            if (offset >= text.Length || text[offset] != value) return false;
            offset++;
            return true;
        }

        private void WhiteSpace()
        {
            while (offset < text.Length && (text[offset] == ' ' || text[offset] == '\t' || text[offset] == '\r' || text[offset] == '\n')) offset++;
        }

        private static bool Digit(char value) { return value >= '0' && value <= '9'; }
    }
}
