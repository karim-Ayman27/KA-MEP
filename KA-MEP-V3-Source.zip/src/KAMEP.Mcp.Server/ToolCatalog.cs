using System;
using System.Collections.Generic;
using PipeTakeoff.Core.Mcp;

namespace KAMEP.Mcp.Server
{
    public static class ToolCatalog
    {
        public const string ProjectInfo = "ka_revit_project_info";
        public const string Selection = "ka_revit_selection";
        public const string FindElements = "ka_revit_find_elements";
        public const string ElementParameters = "ka_revit_element_parameters";
        public const string Sheets = "ka_revit_sheets";
        public const string Warnings = "ka_revit_warnings";

        private static readonly string[] Names =
        {
            ProjectInfo, Selection, FindElements, ElementParameters, Sheets, Warnings
        };

        public static bool Contains(string name)
        {
            return Array.IndexOf(Names, name) >= 0;
        }

        public static object[] List()
        {
            return new[]
            {
                Tool(ProjectInfo, "Read the active Revit project identity and page its link instances with offset and limit. Call first, then pass its projectKey to other tools. Reads require that project to remain active; re-enabling MCP issues a new key.", PageProperties(), new string[0]),
                Tool(Selection, "Read the current Revit selection in the identified project, with bounded paging.", PagedProperties(), new[] { "projectKey" }),
                Tool(FindElements, "Find elements in one supported category in the identified project. Optional query filters element names; returned IDs are strings.", FindProperties(), new[] { "projectKey", "category" }),
                Tool(ElementParameters, "Read parameters for an element in the identified project. Supply elementId as a string or uniqueId; includeType also includes type parameters.", ParameterProperties(), new[] { "projectKey" }, true),
                Tool(Sheets, "Read sheets in the identified project, with bounded paging.", PagedProperties(), new[] { "projectKey" }),
                Tool(Warnings, "Read existing Revit warnings in the identified project, with bounded paging.", PagedProperties(), new[] { "projectKey" })
            };
        }

        private static Dictionary<string, object> Tool(string name, string description, Dictionary<string, object> properties, string[] required, bool requireElement = false)
        {
            var schema = new Dictionary<string, object>
            {
                { "type", "object" }, { "properties", properties }, { "additionalProperties", false }
            };
            if (required.Length != 0) schema["required"] = required;
            if (requireElement)
                schema["anyOf"] = new object[]
                {
                    new { required = new[] { "elementId" } },
                    new { required = new[] { "uniqueId" } }
                };
            return new Dictionary<string, object>
            {
                { "name", name }, { "description", description }, { "inputSchema", schema },
                { "annotations", new { readOnlyHint = true, destructiveHint = false, idempotentHint = true, openWorldHint = false } }
            };
        }

        private static Dictionary<string, object> PageProperties()
        {
            return new Dictionary<string, object>(StringComparer.Ordinal)
            {
                { "offset", new { type = "integer", minimum = 0, maximum = 100000, @default = 0 } },
                { "limit", new { type = "integer", minimum = 1, maximum = 200, @default = 50 } }
            };
        }

        private static Dictionary<string, object> PagedProperties()
        {
            var properties = PageProperties();
            properties["projectKey"] = new { type = "string", minLength = 1, maxLength = 64, description = "Exact projectKey returned by ka_revit_project_info." };
            return properties;
        }

        private static Dictionary<string, object> FindProperties()
        {
            var properties = PagedProperties();
            properties["category"] = new Dictionary<string, object> { { "type", "string" }, { "enum", McpLimits.Categories } };
            properties["query"] = new { type = "string", maxLength = 160 };
            return properties;
        }

        private static Dictionary<string, object> ParameterProperties()
        {
            var properties = PagedProperties();
            properties["elementId"] = new { type = "string", pattern = "^[1-9][0-9]{0,18}$", description = "Positive signed 64-bit Revit element ID, encoded as a string without rounding." };
            properties["uniqueId"] = new { type = "string", minLength = 1, maxLength = 128 };
            properties["includeType"] = new { type = "boolean", @default = false };
            return properties;
        }
    }
}
