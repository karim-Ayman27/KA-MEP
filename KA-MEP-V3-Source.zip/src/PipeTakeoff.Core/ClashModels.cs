using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace PipeTakeoff.Core
{
    public enum ClashState { Unchecked, Unsolved, Solved, NeedsReview }
    public enum ClashTestKind { Unknown, Hard, Clearance, Duplicate }

    public sealed class ClashElementReference
    {
        public long? ElementId { get; set; }
        public string UniqueId { get; set; } = "";
        public string SourceHint { get; set; } = "";
        public string ReportedCategory { get; set; } = "";
        public string ReportedName { get; set; } = "";
        public string RawText { get; set; } = "";
        // Empty means resolve from report provenance, or require a unique match.
        public string SourceOverrideKey { get; set; } = "";
        public string ResolvedSourceKey { get; set; } = "";
        public string ResolvedSourceName { get; set; } = "";
        public long? ResolvedElementId { get; set; }
        public string ResolvedUniqueId { get; set; } = "";
        public string ResolvedCategory { get; set; } = "";
        public string ResolvedName { get; set; } = "";
        public string ResolutionNote { get; set; } = "";
        public string IdLabel { get { return ElementId.HasValue ? ElementId.Value.ToString(CultureInfo.InvariantCulture) : UniqueId; } }
        public string CategoryLabel { get { return string.IsNullOrWhiteSpace(ResolvedCategory) ? ReportedCategory : ResolvedCategory; } }
    }

    public sealed class ClashRecord
    {
        public string Key { get; set; } = "";
        public string Name { get; set; } = "";
        public string TestName { get; set; } = "";
        public ClashTestKind TestKind { get; set; }
        public string ImportedStatus { get; set; } = "";
        public string DistanceText { get; set; } = "";
        public string ClashPointText { get; set; } = "";
        public string AssignedTo { get; set; } = "";
        public string Description { get; set; } = "";
        public ClashElementReference Element1 { get; set; } = new ClashElementReference();
        public ClashElementReference Element2 { get; set; } = new ClashElementReference();
        public ClashState State { get; set; } = ClashState.Unchecked;
        public string CheckNote { get; set; } = "Not checked against the current Revit model.";
        public string CheckBasis { get; set; } = "";
        public DateTime? CheckedAt { get; set; }
        public Dictionary<string, string> ExtraFields { get; set; } = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public void Invalidate(string reason)
        {
            State = ClashState.Unchecked; CheckedAt = null; CheckBasis = "";
            CheckNote = reason ?? "The model changed. Refresh clash status.";
        }
    }

    public sealed class ClashReport
    {
        public string Title { get; set; } = "";
        public string SourcePath { get; set; } = "";
        public string SourceSha256 { get; set; } = "";
        public string Producer { get; set; } = "";
        public DateTime ImportedAt { get; set; } = DateTime.Now;
        public List<ClashRecord> Rows { get; set; } = new List<ClashRecord>();
        public List<string> Notes { get; set; } = new List<string>();
    }

    public sealed class ClashModelSource
    {
        public string Key { get; set; } = "";
        public string DisplayName { get; set; } = "";
        public string DocumentTitle { get; set; } = "";
        public string PathHint { get; set; } = "";
        public long? LinkInstanceId { get; set; }
        public bool IsLoaded { get; set; } = true;
        public override string ToString() { return DisplayName; }
    }

    public sealed class ClashCheckOptions
    {
        public bool AssumeHardForUnknown { get; set; }
        public double IntersectionVolumeToleranceCubicMillimeters { get; set; } = 1;
    }

    public sealed class ClashCheckResult
    {
        public ClashState State { get; set; } = ClashState.NeedsReview;
        public string Note { get; set; } = "";
        public string Basis { get; set; } = "";
        public DateTime CheckedAt { get; set; } = DateTime.Now;
        public void ApplyTo(ClashRecord row)
        {
            row.State = State; row.CheckNote = Note; row.CheckBasis = Basis; row.CheckedAt = CheckedAt;
        }
    }

    public sealed class ClashTablePreview
    {
        public int TableIndex { get; set; }
        public List<string> Headers { get; set; } = new List<string>();
        public List<List<string>> PreviewRows { get; set; } = new List<List<string>>();
        public int DataRowCount { get; set; }
        public override string ToString() { return "Table " + (TableIndex + 1).ToString(CultureInfo.InvariantCulture) + " — " + DataRowCount + " rows"; }
    }

    public sealed class ClashColumnMapping
    {
        public int TableIndex { get; set; }
        public bool HasHeaderRow { get; set; } = true;
        public int NameColumn { get; set; } = -1;
        public int TestNameColumn { get; set; } = -1;
        public int TestKindColumn { get; set; } = -1;
        public int Id1Column { get; set; } = -1;
        public int Id2Column { get; set; } = -1;
        public int UniqueId1Column { get; set; } = -1;
        public int UniqueId2Column { get; set; } = -1;
        public int Category1Column { get; set; } = -1;
        public int Category2Column { get; set; } = -1;
        public int Name1Column { get; set; } = -1;
        public int Name2Column { get; set; } = -1;
        public int Source1Column { get; set; } = -1;
        public int Source2Column { get; set; } = -1;
        public int StatusColumn { get; set; } = -1;
        public int DescriptionColumn { get; set; } = -1;
        public int DistanceColumn { get; set; } = -1;
        public int ClashPointColumn { get; set; } = -1;
        public int AssignedToColumn { get; set; } = -1;
    }

    public sealed class ClashExportOptions
    {
        public string ProjectTitle { get; set; } = "";
        public string RevitVersion { get; set; } = "";
        public string Release { get; set; } = "";
        public string FilterDescription { get; set; } = "";
        public DateTime ExportedAt { get; set; } = DateTime.Now;
    }

    public static class ClashSummary
    {
        public static IDictionary<ClashState, int> Count(IEnumerable<ClashRecord> rows)
        {
            if (rows == null) throw new ArgumentNullException(nameof(rows));
            var result = Enum.GetValues(typeof(ClashState)).Cast<ClashState>().ToDictionary(value => value, value => 0);
            foreach (var row in rows) { if (row == null || !result.ContainsKey(row.State)) throw new ArgumentException("Invalid clash row/status."); result[row.State]++; }
            return result;
        }
    }
}
