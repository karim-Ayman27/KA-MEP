namespace PipeTakeoff.Core
{
    /// <summary>Report captions follow the assembly version built for this release.</summary>
    public static class ReportBranding
    {
        public static string VersionLabel
        {
            get { return "KA MEP V" + typeof(ReportBranding).Assembly.GetName().Version.ToString(2); }
        }
    }
}
