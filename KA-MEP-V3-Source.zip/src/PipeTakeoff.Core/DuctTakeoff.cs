using System;
using System.Collections.Generic;
using System.Linq;

namespace PipeTakeoff.Core
{
    public static class DuctStandardFields
    {
        public static List<FieldDefinition> Create()
        {
            return new List<FieldDefinition>
            {
                Field("ElementId", "Element ID"), Field("Category", "Category"),
                Field("Family", "Family"), Field("Type", "Type"),
                Field("SystemName", "Duct System"), Field("SystemType", "System Type"),
                Field("Level", "Reference Level"), Field("Shape", "Shape"),
                Field("Size", "Size (project format)"), Field("SectionLabel", "Section / connectors (mm)"),
                Field("FittingKind", "Fitting Kind"), Field("Angle", "Angle (degrees)", true),
                Field("Diameter", "Diameter (mm)", true), Field("Width", "Width (mm)", true),
                Field("Height", "Height (mm)", true), Field("Length", "Straight Length (m)", true),
                Field("Area", "Known Area (m²)", true), Field("AreaSource", "Area Source / Status"),
                Field("Mark", "Mark"), Field("Comments", "Comments"),
                Field("SectionKey", "Canonical Section Key")
            };
        }

        private static FieldDefinition Field(string key, string header, bool numeric = false)
        { return new FieldDefinition { Key = key, Header = header, IsNumeric = numeric }; }
    }

    public sealed class DuctSummaryRow
    {
        public string Category { get; set; } = "";
        public string Shape { get; set; } = "";
        public string Size { get; set; } = "";
        public string FittingKind { get; set; } = "";
        public double? AngleDegrees { get; set; }
        public string SystemName { get; set; } = "";
        public string Family { get; set; } = "";
        public string Type { get; set; } = "";
        public int Count { get; set; }
        public double TotalLengthMeters { get; set; }
        /// <summary>Sum of available measurements; inspect MissingAreaCount before treating this as complete.</summary>
        public double TotalAreaSquareMeters { get; set; }
        public int MissingAreaCount { get; set; }
    }

    public static class DuctTakeoffEngine
    {
        public static List<PipeRecord> Filter(IEnumerable<PipeRecord> records, TakeoffOptions options)
        { return TakeoffEngine.Filter(records, options); }

        /// <summary>The caller supplies already filtered records. Section keys come from canonical connector dimensions.</summary>
        public static List<DuctSummaryRow> Summarize(IEnumerable<PipeRecord> records, TakeoffOptions options)
        {
            if (records == null) throw new ArgumentNullException(nameof(records));
            if (options == null) throw new ArgumentNullException(nameof(options));
            var groups = new Dictionary<GroupKey, DuctSummaryRow>();
            foreach (PipeRecord record in records)
            {
                if (record == null) throw new ArgumentException("A duct record is missing.", nameof(records));
                string category = RequiredText(record, "Category");
                if (category != "Duct" && category != "Duct Fitting")
                    throw Invalid(record, "Category (expected Duct or Duct Fitting)");
                string shape = RequiredText(record, "Shape");
                string section = RequiredText(record, "SectionKey");
                double length = category == "Duct" ? RequiredMeasurement(record, "Length") : 0;
                double? area = OptionalMeasurement(record, "Area");
                double? angle = OptionalMeasurement(record, "Angle");
                if (angle.HasValue) angle = Math.Round(angle.Value, 6, MidpointRounding.AwayFromZero);
                var key = new GroupKey(category, shape, section, TakeoffEngine.Text(record.Get("FittingKind")), angle,
                    options.GroupBySystem ? TakeoffEngine.Text(record.Get("SystemName")) : "",
                    options.GroupByFamily ? TakeoffEngine.Text(record.Get("Family")) : "",
                    options.GroupByType ? TakeoffEngine.Text(record.Get("Type")) : "");
                DuctSummaryRow row;
                if (!groups.TryGetValue(key, out row))
                {
                    string size = TakeoffEngine.Text(record.Get("SectionLabel"));
                    if (string.IsNullOrWhiteSpace(size)) size = TakeoffEngine.Text(record.Get("Size"));
                    if (string.IsNullOrWhiteSpace(size)) size = section;
                    row = new DuctSummaryRow
                    {
                        Category = category, Shape = shape, Size = size, FittingKind = key.FittingKind,
                        AngleDegrees = angle, SystemName = key.System, Family = key.Family, Type = key.Type
                    };
                    groups.Add(key, row);
                }
                checked { row.Count++; if (!area.HasValue) row.MissingAreaCount++; }
                row.TotalLengthMeters += length;
                row.TotalAreaSquareMeters += area ?? 0;
                if (!TakeoffEngine.IsFinite(row.TotalLengthMeters) || !TakeoffEngine.IsFinite(row.TotalAreaSquareMeters))
                    throw new ArgumentException("A duct quantity total is outside the supported numeric range.", nameof(records));
            }
            return groups.OrderBy(pair => pair.Key.Category, StringComparer.Ordinal)
                .ThenBy(pair => pair.Key.Shape, StringComparer.Ordinal)
                .ThenBy(pair => pair.Key.Section, StringComparer.Ordinal)
                .ThenBy(pair => pair.Key.FittingKind, StringComparer.Ordinal)
                .ThenBy(pair => pair.Key.Angle)
                .ThenBy(pair => pair.Key.System, StringComparer.Ordinal)
                .ThenBy(pair => pair.Key.Family, StringComparer.Ordinal)
                .ThenBy(pair => pair.Key.Type, StringComparer.Ordinal)
                .Select(pair => pair.Value).ToList();
        }

        internal static double RequiredMeasurement(PipeRecord record, string key)
        {
            double value;
            if (!TakeoffEngine.TryNumber(record.Get(key), out value) || value < 0) throw Invalid(record, key);
            return value;
        }

        internal static double? OptionalMeasurement(PipeRecord record, string key)
        {
            object raw = record.Get(key);
            if (raw == null || (raw is string && string.IsNullOrWhiteSpace((string)raw))) return null;
            return RequiredMeasurement(record, key);
        }

        private static string RequiredText(PipeRecord record, string key)
        {
            string value = TakeoffEngine.Text(record.Get(key));
            if (string.IsNullOrWhiteSpace(value)) throw Invalid(record, key);
            return value;
        }

        private static ArgumentException Invalid(PipeRecord record, string key)
        { return new ArgumentException("Duct element " + TakeoffEngine.Text(record.Get("ElementId")) + " has a missing or invalid " + key + " value."); }

        private sealed class GroupKey : IEquatable<GroupKey>
        {
            internal readonly string Category, Shape, Section, FittingKind, System, Family, Type;
            internal readonly double? Angle;
            internal GroupKey(string category, string shape, string section, string fittingKind, double? angle, string system, string family, string type)
            { Category = category; Shape = shape; Section = section; FittingKind = fittingKind; Angle = angle; System = system; Family = family; Type = type; }

            public bool Equals(GroupKey other)
            {
                return other != null && Category == other.Category && Shape == other.Shape && Section == other.Section &&
                    FittingKind == other.FittingKind && Angle == other.Angle && System == other.System && Family == other.Family && Type == other.Type;
            }
            public override bool Equals(object obj) { return Equals(obj as GroupKey); }
            public override int GetHashCode()
            {
                unchecked
                {
                    int hash = Category.GetHashCode();
                    foreach (string part in new[] { Shape, Section, FittingKind, System, Family, Type }) hash = (hash * 397) ^ part.GetHashCode();
                    return (hash * 397) ^ Angle.GetHashCode();
                }
            }
        }
    }
}
