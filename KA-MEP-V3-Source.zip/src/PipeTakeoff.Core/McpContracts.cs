using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Xml;

namespace PipeTakeoff.Core.Mcp
{
    [DataContract]
    public sealed class McpArguments
    {
        [DataMember(Name="projectKey", EmitDefaultValue=false)] public string ProjectKey { get; set; }
        [DataMember(Name="category", EmitDefaultValue=false)] public string Category { get; set; }
        [DataMember(Name="query", EmitDefaultValue=false)] public string Query { get; set; }
        [DataMember(Name="elementId", EmitDefaultValue=false)] public string ElementId { get; set; }
        [DataMember(Name="uniqueId", EmitDefaultValue=false)] public string UniqueId { get; set; }
        [DataMember(Name="offset")] public int Offset { get; set; }
        [DataMember(Name="limit")] public int Limit { get; set; } = 50;
        [DataMember(Name="includeType")] public bool IncludeType { get; set; }
    }
    [DataContract]
    public sealed class McpWireRequest
    {
        [DataMember(Name="protocol")] public int Protocol { get; set; } = 1;
        [DataMember(Name="token")] public string Token { get; set; }
        [DataMember(Name="requestId")] public string RequestId { get; set; }
        [DataMember(Name="tool")] public string Tool { get; set; }
        [DataMember(Name="arguments")] public McpArguments Arguments { get; set; } = new McpArguments();
    }
    [DataContract]
    public sealed class McpWireResponse
    {
        [DataMember(Name="protocol")] public int Protocol { get; set; } = 1;
        [DataMember(Name="requestId")] public string RequestId { get; set; }
        [DataMember(Name="success")] public bool Success { get; set; }
        [DataMember(Name="errorCode", EmitDefaultValue=false)] public string ErrorCode { get; set; }
        [DataMember(Name="error", EmitDefaultValue=false)] public string Error { get; set; }
        [DataMember(Name="payloadJson", EmitDefaultValue=false)] public string PayloadJson { get; set; }
        public static McpWireResponse Fail(string id, string code, string message) { return new McpWireResponse { RequestId=id, Success=false, ErrorCode=code, Error=message }; }
    }
    [DataContract]
    public sealed class McpConnection
    {
        [DataMember(Name="protocol")] public int Protocol { get; set; } = 1;
        [DataMember(Name="port")] public int Port { get; set; }
        [DataMember(Name="token")] public string Token { get; set; }
        [DataMember(Name="processId")] public int ProcessId { get; set; }
        [DataMember(Name="projectKey")] public string ProjectKey { get; set; }
        [DataMember(Name="projectTitle")] public string ProjectTitle { get; set; }
        [DataMember(Name="startedUtc")] public string StartedUtc { get; set; }
    }
    [DataContract]
    public sealed class McpReadResult
    {
        [DataMember(Name="projectKey")] public string ProjectKey { get; set; }
        [DataMember(Name="projectTitle")] public string ProjectTitle { get; set; }
        [DataMember(Name="modelRevision")] public long ModelRevision { get; set; }
        [DataMember(Name="capturedUtc")] public string CapturedUtc { get; set; }
        [DataMember(Name="offset")] public int Offset { get; set; }
        [DataMember(Name="returned")] public int Returned { get; set; }
        [DataMember(Name="hasMore")] public bool HasMore { get; set; }
        [DataMember(Name="nextOffset", EmitDefaultValue=false)] public int? NextOffset { get; set; }
        [DataMember(Name="truncated")] public bool Truncated { get; set; }
        [DataMember(Name="notes")] public List<string> Notes { get; set; } = new List<string>();
        [DataMember(Name="project", EmitDefaultValue=false)] public McpProjectData Project { get; set; }
        [DataMember(Name="elements", EmitDefaultValue=false)] public List<McpElementData> Elements { get; set; }
        [DataMember(Name="parameters", EmitDefaultValue=false)] public List<McpParameterData> Parameters { get; set; }
        [DataMember(Name="sheets", EmitDefaultValue=false)] public List<McpSheetData> Sheets { get; set; }
        [DataMember(Name="warnings", EmitDefaultValue=false)] public List<McpWarningData> Warnings { get; set; }
    }
    [DataContract]
    public sealed class McpProjectData
    {
        [DataMember(Name="revitVersion")] public string RevitVersion { get; set; }
        [DataMember(Name="number")] public string Number { get; set; }
        [DataMember(Name="name")] public string Name { get; set; }
        [DataMember(Name="isWorkshared")] public bool IsWorkshared { get; set; }
        [DataMember(Name="activeViewId")] public string ActiveViewId { get; set; }
        [DataMember(Name="activeViewName")] public string ActiveViewName { get; set; }
        [DataMember(Name="links")] public List<McpLinkData> Links { get; set; } = new List<McpLinkData>();
    }
    [DataContract]
    public sealed class McpElementData
    {
        [DataMember(Name="elementId")] public string ElementId { get; set; }
        [DataMember(Name="uniqueId")] public string UniqueId { get; set; }
        [DataMember(Name="name")] public string Name { get; set; }
        [DataMember(Name="category")] public string Category { get; set; }
        [DataMember(Name="family")] public string Family { get; set; }
        [DataMember(Name="type")] public string Type { get; set; }
        [DataMember(Name="level")] public string Level { get; set; }
    }
    [DataContract]
    public sealed class McpParameterData
    {
        [DataMember(Name="parameterId")] public string ParameterId { get; set; }
        [DataMember(Name="name")] public string Name { get; set; }
        [DataMember(Name="storageType")] public string StorageType { get; set; }
        [DataMember(Name="rawValue")] public string RawValue { get; set; }
        [DataMember(Name="displayValue")] public string DisplayValue { get; set; }
        [DataMember(Name="specId")] public string SpecId { get; set; }
        [DataMember(Name="hasValue")] public bool HasValue { get; set; }
        [DataMember(Name="isReadOnly")] public bool IsReadOnly { get; set; }
        [DataMember(Name="isType")] public bool IsType { get; set; }
        [DataMember(Name="ownerId")] public string OwnerId { get; set; }
    }
    [DataContract]
    public sealed class McpSheetData
    {
        [DataMember(Name="elementId")] public string ElementId { get; set; }
        [DataMember(Name="uniqueId")] public string UniqueId { get; set; }
        [DataMember(Name="number")] public string Number { get; set; }
        [DataMember(Name="name")] public string Name { get; set; }
        [DataMember(Name="isPlaceholder")] public bool IsPlaceholder { get; set; }
    }
    [DataContract]
    public sealed class McpWarningData
    {
        [DataMember(Name="description")] public string Description { get; set; }
        [DataMember(Name="severity")] public string Severity { get; set; }
        [DataMember(Name="failureDefinitionId")] public string FailureDefinitionId { get; set; }
        [DataMember(Name="failingIds")] public List<string> FailingIds { get; set; }
        [DataMember(Name="additionalIds")] public List<string> AdditionalIds { get; set; }
    }
    [DataContract]
    public sealed class McpLinkData
    {
        [DataMember(Name="instanceId")] public string InstanceId { get; set; }
        [DataMember(Name="uniqueId")] public string UniqueId { get; set; }
        [DataMember(Name="name")] public string Name { get; set; }
        [DataMember(Name="isLoaded")] public bool IsLoaded { get; set; }
    }
    public static class McpLimits
    {
        public const int MaxRequestBytes=65536, MaxResponseBytes=1048576, MaxPage=200, MaxOffset=100000;
        public static readonly string[] Tools = { "ka_revit_project_info", "ka_revit_selection", "ka_revit_find_elements", "ka_revit_element_parameters", "ka_revit_sheets", "ka_revit_warnings" };
        public static readonly string[] Categories = { "Pipes", "PipeFittings", "Ducts", "DuctFittings", "CableTrays", "CableTrayFittings", "Conduits", "ConduitFittings", "MechanicalEquipment", "PlumbingFixtures", "Rooms", "Spaces", "Doors", "Windows" };
        public static void ValidateRequest(McpWireRequest request)
        {
            if (request==null || request.Protocol!=1 || string.IsNullOrEmpty(request.RequestId) || request.RequestId.Length>80) throw new InvalidDataException("Invalid bridge request.");
            if (!Tools.Contains(request.Tool, StringComparer.Ordinal)) throw new InvalidDataException("Unsupported read-only tool.");
            var a=request.Arguments;
            if (a==null) throw new InvalidDataException("Arguments are required.");
            if (a.Limit<1 || a.Limit>MaxPage || a.Offset<0 || a.Offset>MaxOffset) throw new InvalidDataException("Use limit 1–200 and offset 0–100000.");
            if (a.ProjectKey!=null && a.ProjectKey.Length>64) throw new InvalidDataException("Invalid project key.");
            if (request.Tool!="ka_revit_project_info" && string.IsNullOrWhiteSpace(a.ProjectKey)) throw new InvalidDataException("Read project info first and supply its projectKey.");
            if (a.Query!=null && a.Query.Length>160) throw new InvalidDataException("Search text exceeds 160 characters.");
            if (request.Tool=="ka_revit_find_elements" && !Categories.Contains(a.Category, StringComparer.Ordinal)) throw new InvalidDataException("Choose a supported category.");
            if (a.UniqueId!=null && a.UniqueId.Length>128) throw new InvalidDataException("Invalid UniqueId.");
            if (a.ElementId!=null) { long id; if (a.ElementId.Length>19 || !long.TryParse(a.ElementId, NumberStyles.None, CultureInfo.InvariantCulture, out id) || id<=0) throw new InvalidDataException("Element ID must be a positive 64-bit integer string."); }
            if (request.Tool=="ka_revit_element_parameters" && string.IsNullOrWhiteSpace(a.ElementId) && string.IsNullOrWhiteSpace(a.UniqueId)) throw new InvalidDataException("Supply elementId or uniqueId.");
        }
    }
    public static class McpWireCodec
    {
        public static byte[] Serialize<T>(T value)
        {
            using (var stream=new MemoryStream()) { new DataContractJsonSerializer(typeof(T)).WriteObject(stream,value); return stream.ToArray(); }
        }
        public static T Deserialize<T>(byte[] bytes)
        {
            if (bytes==null || bytes.Length==0 || bytes.Length>McpLimits.MaxResponseBytes) throw new InvalidDataException("Invalid bridge message size.");
            var quotas=new XmlDictionaryReaderQuotas { MaxDepth=24, MaxArrayLength=McpLimits.MaxResponseBytes, MaxStringContentLength=McpLimits.MaxResponseBytes, MaxBytesPerRead=4096, MaxNameTableCharCount=65536 };
            using (var reader=JsonReaderWriterFactory.CreateJsonReader(bytes,quotas)) { return (T)new DataContractJsonSerializer(typeof(T)).ReadObject(reader); }
        }
        public static string Json<T>(T value) { return Encoding.UTF8.GetString(Serialize(value)); }
    }
}
