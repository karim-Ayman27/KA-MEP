using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Xml;
using static PipeTakeoff.Core.XlsxExporter;

namespace PipeTakeoff.Core
{
    public sealed class SpaceTakeoffExportOptions
    {
        public bool HeightsInMillimeters { get; set; }
        public string FilterDescription { get; set; } = "";
    }

    /// <summary>Writes a static HVAC space report from the exact supplied snapshot rows.</summary>
    public static class SpaceTakeoffXlsxExporter
    {
        private const string Ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        private const string DocumentRelNs = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        private const string PackageRelNs = "http://schemas.openxmlformats.org/package/2006/relationships";
        private const int HeaderRow = 5;
        private const int MaxRows = 1048576;

        public static void Export(string path, SpaceTakeoffSnapshot snapshot, SpaceTakeoffExportOptions options = null)
        {
            if (string.IsNullOrWhiteSpace(path)) throw new ArgumentException("Choose an Excel file path.", nameof(path));
            Validate(snapshot);
            options = options ?? new SpaceTakeoffExportOptions();
            string fullPath = Path.GetFullPath(path);
            if (!string.Equals(Path.GetExtension(fullPath), ".xlsx", StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("The export file must use the .xlsx extension.", nameof(path));
            string directory = Path.GetDirectoryName(fullPath);
            if (!Directory.Exists(directory)) throw new DirectoryNotFoundException("The export folder does not exist: " + directory);
            var tables = new[] { Spaces(snapshot, options), Summary(snapshot), Measurements(snapshot, options), Openings(snapshot), Info(snapshot, options) };
            foreach (var table in tables)
            {
                if (table.Rows.Count > MaxRows - HeaderRow) throw new ArgumentException("The " + table.Name + " sheet exceeds Excel's row limit.");
                foreach (double value in table.Rows.SelectMany(row => row).OfType<double>()) Number(value, true, "Report value or aggregate");
            }
            string temporary = Path.Combine(directory, "." + Path.GetFileName(fullPath) + "." + Guid.NewGuid().ToString("N") + ".tmp");
            try
            {
                using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                using (var archive = new ZipArchive(stream, ZipArchiveMode.Create))
                {
                    Package(archive, tables);
                    WriteStyles(archive);
                    for (int i = 0; i < tables.Length; i++) Sheet(archive, i, tables[i], snapshot);
                }
                if (File.Exists(fullPath)) File.Replace(temporary, fullPath, null);
                else File.Move(temporary, fullPath);
            }
            finally
            {
                try { if (File.Exists(temporary)) File.Delete(temporary); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }

        private static void Validate(SpaceTakeoffSnapshot snapshot)
        {
            if (snapshot == null) throw new ArgumentNullException(nameof(snapshot));
            if (snapshot.Rows == null || snapshot.Notes == null || snapshot.Options == null)
                throw new ArgumentException("Snapshot rows, notes and measurement settings are required.", nameof(snapshot));
            snapshot.Options.Validate();
            if (snapshot.Rows.Count > MaxRows - HeaderRow) throw new ArgumentException("The space report exceeds Excel's row limit.");
            var ids = new HashSet<long>();
            long sampleCount = 0, openingCount = 0;
            foreach (var row in snapshot.Rows)
            {
                if (row == null || row.Samples == null || row.Notes == null || row.Openings == null || row.OpeningNotes == null)
                    throw new ArgumentException("A space row or its measurement/opening collection is missing.");
                if (!ids.Add(row.SpaceId)) throw new ArgumentException("A space appears more than once in the export: " + row.SpaceId.ToString(CultureInfo.InvariantCulture));
                Number(row.AreaSquareMeters, false, "Space area");
                Number(row.BaseElevationMeters, true, "Space base elevation");
                Number(row.ClearHeightMeters, false, "Clear height");
                Number(row.MinHeightMeters, false, "Minimum height");
                Number(row.MaxHeightMeters, false, "Maximum height");
                if (!Enum.IsDefined(typeof(SpaceMeasurementStatus), row.Status) || !Enum.IsDefined(typeof(SpaceHeightBasis), row.HeightBasis))
                    throw new ArgumentException("A space measurement status or height basis is invalid.");
                if (row.MinHeightMeters.HasValue && row.MaxHeightMeters.HasValue && row.MinHeightMeters > row.MaxHeightMeters)
                    throw new ArgumentException("A minimum sampled height exceeds its maximum.");
                if (row.Status == SpaceMeasurementStatus.Measured && (!row.ClearHeightMeters.HasValue || row.ClearHeightMeters <= 0))
                    throw new ArgumentException("A measured space must have a positive physical clear height.");
                sampleCount += row.Samples.Count;
                if (sampleCount > MaxRows - HeaderRow) throw new ArgumentException("The measurement sheet exceeds Excel's row limit.");
                openingCount += row.Openings.Count;
                if (openingCount > MaxRows - HeaderRow) throw new ArgumentException("The opening sheet exceeds Excel's row limit.");
                var openingIds = new HashSet<string>(StringComparer.Ordinal);
                foreach (var opening in row.Openings)
                {
                    if (opening == null || opening.Source == null || opening.Rooms == null || opening.SpaceIds == null)
                        throw new ArgumentException("An opening or its source/association collection is missing.");
                    if (!openingIds.Add(opening.Source.Key)) throw new ArgumentException("An opening appears more than once in one Space: " + opening.Source.Key);
                    if (!Enum.IsDefined(typeof(SpaceOpeningKind), opening.Kind) || !Enum.IsDefined(typeof(SpaceOpeningAssociationStatus), opening.AssociationStatus))
                        throw new ArgumentException("An opening kind or association status is invalid.");
                    Number(opening.WidthMeters, false, "Opening width"); Number(opening.HeightMeters, false, "Opening height");
                    Number(opening.AreaSquareMeters, false, "Opening nominal area");
                    if (opening.Rooms.Any(room => room == null || room.Source == null)) throw new ArgumentException("An opening Room identity is missing.");
                }
                foreach (var sample in row.Samples)
                {
                    if (sample == null) throw new ArgumentException("A measurement sample is missing.");
                    Number(sample.X, true, "Sample X"); Number(sample.Y, true, "Sample Y");
                    Number(sample.BaseElevationMeters, true, "Sample base elevation");
                    Number(sample.FloorElevationMeters, true, "Floor elevation");
                    Number(sample.OverheadElevationMeters, true, "Overhead elevation");
                    Number(sample.HeightMeters, false, "Sample height");
                    if (!Enum.IsDefined(typeof(SpaceMeasurementStatus), sample.Status) || !Enum.IsDefined(typeof(SpaceHeightBasis), sample.HeightBasis))
                        throw new ArgumentException("A sample status or height basis is invalid.");
                }
            }
        }

        private static void Number(double? value, bool signed, string label)
        {
            if (value.HasValue && (double.IsNaN(value.Value) || double.IsInfinity(value.Value) || (!signed && value.Value < 0)))
                throw new ArgumentException(label + " must be a finite " + (signed ? "number." : "nonnegative number."));
        }

        private static ReportTable Spaces(SpaceTakeoffSnapshot snapshot, SpaceTakeoffExportOptions options)
        {
            string unit = options.HeightsInMillimeters ? "mm" : "m";
            var table = new ReportTable("Spaces", "HVAC SPACE TAKEOFF", "Areas: m² | Heights: " + unit + " | Blank opening counts mean unverified/incomplete coverage; nominal areas use width × height.",
                new[] { "Room number", "Room name", "Space number", "Space name", "Level", "Phase", "Area (m²)", "Clear height (" + unit + ")", "Min sampled (" + unit + ")", "Max sampled (" + unit + ")", "Upper boundary", "Measurement status", "Measured / total samples", "Space element ID", "Room identity source", "Review notes",
                    "Door count", "Door nominal area (m²)", "Door known-area subtotal (m²)", "Doors missing dimensions", "Window count", "Window nominal area (m²)", "Window known-area subtotal (m²)", "Windows missing dimensions", "Opening coverage", "Opening review notes", "Room document", "Room link instance ID", "Room element ID", "Room unique ID" },
                new[] { 16, 30, 16, 30, 22, 20, 15, 17, 17, 17, 20, 34, 20, 24, 44, 66, 15, 22, 25, 22, 15, 22, 25, 22, 38, 66, 30, 24, 24, 44 });
            table.Numeric = new HashSet<int> { 6, 7, 8, 9, 16, 17, 18, 19, 20, 21, 22, 23 };
            table.Whole = new HashSet<int> { 16, 19, 20, 23 };
            if (options.HeightsInMillimeters) table.Whole.UnionWith(new[] { 7, 8, 9 });
            foreach (var row in snapshot.Rows)
            {
                var totals = OpeningTotals(row);
                table.Rows.Add(new object[] { row.RoomNumber, row.RoomName, row.SpaceNumber, row.SpaceName, row.LevelName, row.PhaseName,
                    row.AreaSquareMeters, Height(row.Status == SpaceMeasurementStatus.Measured ? row.ClearHeightMeters : null, options),
                    Height(row.MinHeightMeters, options), Height(row.MaxHeightMeters, options), Basis(row.HeightBasis), row.StatusLabel,
                    row.SamplesMeasured.ToString(CultureInfo.InvariantCulture) + " / " + row.SamplesAttempted.ToString(CultureInfo.InvariantCulture),
                    row.SpaceId.ToString(CultureInfo.InvariantCulture), row.RoomIdentitySource, string.Join(Environment.NewLine, row.Notes),
                    totals.DoorCount, totals.DoorAreaSquareMeters, totals.DoorKnownAreaSquareMeters, totals.DoorMissingDimensionCount,
                    totals.WindowCount, totals.WindowAreaSquareMeters, totals.WindowKnownAreaSquareMeters, totals.WindowMissingDimensionCount,
                    OpeningCoverage(row, totals), string.Join(Environment.NewLine, row.OpeningNotes),
                    SourceDocument(row.RoomSource), SourceLink(row.RoomSource), SourceId(row.RoomSource), row.RoomUniqueId });
            }
            return table;
        }

        private static ReportTable Summary(SpaceTakeoffSnapshot snapshot)
        {
            var table = new ReportTable("Summary", "HVAC SPACE SUMMARY", "Exported rows only | Shared openings count for each associated Room; unique opening totals deduplicate source document + link instance + element ID.",
                new[] { "Summary group", "Level", "Phase", "Spaces", "Known area (m²)", "Area unavailable", "Uniform measured", "Need height review", "Ceiling basis", "Slab basis", "Mixed / no basis", "Measurement coverage",
                    "Door Room associations observed", "Window Room associations observed", "Door Room-associated known area (m²)", "Window Room-associated known area (m²)",
                    "Unique door count (complete)", "Unique window count (complete)", "Unique doors observed", "Unique windows observed", "Unique door nominal area (m²)", "Unique window nominal area (m²)",
                    "Unique door known-area subtotal (m²)", "Unique window known-area subtotal (m²)", "Unique doors missing dimensions", "Unique windows missing dimensions", "Rooms with opening count unavailable", "Opening total coverage" },
                new[] { 24, 28, 24, 14, 20, 18, 20, 20, 18, 18, 20, 75, 25, 25, 29, 29, 24, 24, 22, 22, 25, 25, 29, 29, 27, 27, 30, 85 });
            table.Numeric = new HashSet<int> { 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26 };
            table.Whole = new HashSet<int> { 3, 5, 6, 7, 8, 9, 10, 12, 13, 16, 17, 18, 19, 24, 25, 26 };
            table.TotalFirst = true;
            table.Rows.Add(SummaryRow("EXPORTED TOTAL", "All exported levels", "All exported phases", snapshot.Rows));
            foreach (var group in snapshot.Rows.GroupBy(row => new { row.LevelName, row.PhaseName })
                .OrderBy(group => group.Key.LevelName, StringComparer.CurrentCultureIgnoreCase)
                .ThenBy(group => group.Key.PhaseName, StringComparer.CurrentCultureIgnoreCase))
                table.Rows.Add(SummaryRow("Level / phase", group.Key.LevelName, group.Key.PhaseName, group.ToList()));
            return table;
        }

        private static object[] SummaryRow(string group, string level, string phase, IList<SpaceTakeoffRow> rows)
        {
            int measured = rows.Count(row => row.Status == SpaceMeasurementStatus.Measured && row.ClearHeightMeters.HasValue);
            var associated = rows.Select(OpeningTotals).ToList();
            int unavailable = associated.Count(totals => !totals.Complete);
            var unique = SpaceOpeningSummary.ForUniqueOpenings(rows.SelectMany(row => row.Openings), unavailable == 0);
            var observedUnique = rows.SelectMany(row => row.Openings).GroupBy(opening => opening.Source.Key, StringComparer.Ordinal).Select(openings => openings.First()).ToList();
            return new object[] { group, level, phase, rows.Count, rows.Where(row => row.AreaSquareMeters.HasValue).Sum(row => row.AreaSquareMeters.Value),
                rows.Count(row => !row.AreaSquareMeters.HasValue), measured, rows.Count - measured,
                rows.Count(row => row.HeightBasis == SpaceHeightBasis.Ceiling), rows.Count(row => row.HeightBasis == SpaceHeightBasis.Slab),
                rows.Count(row => row.HeightBasis == SpaceHeightBasis.None || row.HeightBasis == SpaceHeightBasis.Mixed),
                "Uniform measured = one sampled clear height accepted. Other rows retain their review status and any measured range. Area is the Revit Space area, not the linked Room area.",
                rows.Sum(row => row.Openings.Count(opening => opening.Kind == SpaceOpeningKind.Door)), rows.Sum(row => row.Openings.Count(opening => opening.Kind == SpaceOpeningKind.Window)), associated.Sum(t => t.DoorKnownAreaSquareMeters), associated.Sum(t => t.WindowKnownAreaSquareMeters),
                unique.DoorCount, unique.WindowCount, observedUnique.Count(opening => opening.Kind == SpaceOpeningKind.Door), observedUnique.Count(opening => opening.Kind == SpaceOpeningKind.Window), unique.DoorAreaSquareMeters, unique.WindowAreaSquareMeters,
                unique.DoorKnownAreaSquareMeters, unique.WindowKnownAreaSquareMeters, unique.DoorMissingDimensionCount, unique.WindowMissingDimensionCount, unavailable,
                (unavailable == 0 ? "All exported Room opening counts verified. " : "Incomplete opening coverage: complete counts and total areas are blank. ") +
                "Observed Room associations include a shared opening once per exported Space. Unique totals count the source opening once across this group's exported rows; group unique totals may overlap. Known-area subtotals exclude missing dimensions. Nominal width × height is not net glazing, frame-free area or wall deduction." };
        }

        private static ReportTable Measurements(SpaceTakeoffSnapshot snapshot, SpaceTakeoffExportOptions options)
        {
            string unit = options.HeightsInMillimeters ? "mm" : "m";
            var table = new ReportTable("Measurements", "HEIGHT MEASUREMENT TRACE", "XY and elevations: host-project coordinates in m | Height: " + unit + " | Sources include document, link instance and element ID.",
                new[] { "Space element ID", "Room number", "Space number", "Sample", "X (m)", "Y (m)", "Space base Z (m)", "Floor top Z (m)", "Overhead bottom Z (m)", "Sample height (" + unit + ")", "Upper boundary", "Sample status", "Floor document", "Floor link instance ID", "Floor element ID", "Floor name", "Overhead document", "Overhead link instance ID", "Overhead element ID", "Overhead name", "Sample notes" },
                new[] { 24, 16, 16, 12, 18, 18, 20, 20, 22, 20, 20, 34, 30, 24, 24, 38, 30, 25, 24, 38, 66 });
            table.Numeric = new HashSet<int> { 3, 4, 5, 6, 7, 8, 9 };
            table.Whole = options.HeightsInMillimeters ? new HashSet<int> { 3, 9 } : new HashSet<int> { 3 };
            foreach (var row in snapshot.Rows)
                foreach (var sample in row.Samples)
                    table.Rows.Add(new object[] { row.SpaceId.ToString(CultureInfo.InvariantCulture), row.RoomNumber, row.SpaceNumber, sample.SampleNumber,
                        sample.X, sample.Y, sample.BaseElevationMeters, sample.FloorElevationMeters, sample.OverheadElevationMeters,
                        Height(sample.HeightMeters, options), Basis(sample.HeightBasis), sample.StatusLabel,
                        SourceDocument(sample.FloorSource), SourceLink(sample.FloorSource), SourceId(sample.FloorSource), SourceName(sample.FloorSource),
                        SourceDocument(sample.OverheadSource), SourceLink(sample.OverheadSource), SourceId(sample.OverheadSource), SourceName(sample.OverheadSource), sample.Notes });
            return table;
        }

        private static ReportTable Openings(SpaceTakeoffSnapshot snapshot)
        {
            var table = new ReportTable("Openings", "DOOR / WINDOW ASSOCIATION TRACE", "One row per exported Space–opening association | Size / width / height: m | Nominal area: m² | Shared openings intentionally repeat for each associated Room.",
                new[] { "Space element ID", "Room number", "Room name", "Space number", "Room document", "Room link instance ID", "Room element ID", "Room unique ID", "Opening kind", "Opening document", "Opening link instance ID", "Opening element ID", "Opening unique ID", "Family", "Type", "Size (W × H)", "Width (m)", "Height (m)", "Nominal area (m²)", "Shared opening", "Association status", "Association source / notes", "Dimension source", "Dimension notes" },
                new[] { 24, 16, 30, 16, 30, 24, 24, 44, 18, 30, 24, 24, 44, 34, 34, 30, 18, 18, 22, 20, 28, 66, 50, 66 });
            table.Numeric = new HashSet<int> { 16, 17, 18 };
            foreach (var row in snapshot.Rows)
                foreach (var opening in row.Openings)
                    table.Rows.Add(new object[] { row.SpaceId.ToString(CultureInfo.InvariantCulture), row.RoomNumber, row.RoomName, row.SpaceNumber,
                        SourceDocument(row.RoomSource), SourceLink(row.RoomSource), SourceId(row.RoomSource), row.RoomUniqueId,
                        opening.Kind.ToString(), SourceDocument(opening.Source), SourceLink(opening.Source), SourceId(opening.Source), opening.UniqueId,
                        opening.FamilyName, opening.TypeName, SpaceOpeningDimensions.FormatSize(opening.WidthMeters, opening.HeightMeters, false, CultureInfo.InvariantCulture),
                        opening.WidthMeters, opening.HeightMeters, opening.AreaSquareMeters,
                        opening.IsShared ? "Yes" : "No",
                        opening.AssociationStatus.ToString(), opening.AssociationNotes, opening.DimensionSource, opening.DimensionNotes });
            return table;
        }

        private static ReportTable Info(SpaceTakeoffSnapshot snapshot, SpaceTakeoffExportOptions options)
        {
            var table = new ReportTable("Info", "REPORT INFORMATION", "Read the measurement method, source coverage and review notes together with the exported quantities.", new[] { "Property", "Value" }, new[] { 42, 120 });
            Action<string, object> add = (key, value) => table.Rows.Add(new[] { (object)key, value });
            add("Application", "KA MEP — HVAC Spaces Takeoff"); add("Release / build", snapshot.Release);
            add("Project", snapshot.ProjectTitle); add("Revit version", snapshot.RevitVersion);
            add("Scanned at (source timestamp)", snapshot.ScannedAt.ToString("O", CultureInfo.InvariantCulture));
            add("Scan coverage", snapshot.IsComplete ? "Completed configured scan; individual rows can still require review." : "Incomplete scan — review source/geometry notes before using quantities.");
            add("Scope", snapshot.ScopeLabel); add("Export filters", string.IsNullOrWhiteSpace(options.FilterDescription) ? "As supplied by the takeoff window; exported rows define this report." : options.FilterDescription);
            add("Area units / basis", "m²; Revit Space area. Linked Room names/numbers are identity data and do not replace the Space area.");
            add("Height units", options.HeightsInMillimeters ? "mm for clear/sample heights. XY coordinates and elevations remain in m." : "m for clear/sample heights, XY coordinates and elevations.");
            add("Physical measurement method", "Vertical samples from physical floor top surfaces to ceiling undersides, or the nearest overhead slab underside where no ceiling occurs before that slab. No analytical Space height or upper limit is substituted for a physical measurement.");
            add("Single clear height", "Shown only for rows with an accepted uniform sampled height. Variable, mixed, partial and missing measurements keep a blank clear-height cell and an explicit review status. Sampled min/max remain available where physical measurements exist. These are sampled values, not guaranteed extrema across every point of a room.");
            add("Sampling limits", "Finite interior sampling can miss local steps, openings, beams or small ceiling patches. Review the Measurements sheet and the model. This report is not a cooling-load calculation or a certified room survey.");
            add("Geometry sources", (snapshot.Options.IncludeHostGeometry ? "Current model" : "Current model excluded") + "; " + (snapshot.Options.IncludeLinkedGeometry ? "loaded linked models enabled" : "linked models excluded"));
            add("Phase element ID", snapshot.Options.PhaseId.ToString(CultureInfo.InvariantCulture));
            add("Floor search tolerance (m)", snapshot.Options.FloorSearchToleranceMeters);
            add("Maximum height search (m)", snapshot.Options.MaximumHeightMeters);
            add("Sampling grid per axis", snapshot.Options.SampleGridSize);
            add("Height variation tolerance (m)", snapshot.Options.HeightVariationToleranceMeters);
            add("Opening quantity basis", "Door/window counts belong to the verified architectural Room matched to each exported Space. The Openings sheet identifies each source opening and its phase-aware Room association. An unverified Room or partial opening scan has blank counts, never a presumed zero.");
            add("Opening size", "The Openings sheet shows each individual opening's nominal Size (W × H) in m, alongside numeric Width (m) and Height (m). Unknown marks an unavailable dimension; different opening sizes remain separate records. Opening dimensions stay in m when clear/sample heights use mm.");
            add("Opening nominal area", "m²; nominal width × height from available instance/type dimensions. This is not net glazing area, frame-free opening area, wall deduction or a heat-transfer calculation. Missing or nonpositive dimensions leave nominal area blank.");
            add("Opening area completeness", "A complete category area is shown only when its Room opening scan is complete and every counted opening has usable dimensions. Known-area subtotal includes only measured dimensions; missing-dimension counts describe observed openings only and do not estimate unobserved openings. A verified empty category has count and area zero.");
            add("Shared opening totals", "An opening serving two Rooms is counted once in each exported Space's Room association quantities. Summary labels Room-association totals separately from unique source-opening totals. Unique totals deduplicate document + link instance + element ID across exported rows only; level/phase group unique totals can overlap and must not be added to reproduce the overall unique count.");
            add("Opening detail scope", "The Openings worksheet contains associations for exported Spaces only. Excluded/filtered Spaces and unrelated source-scan openings do not contribute to Summary quantities. The shared flag considers all associated source Rooms, including Rooms outside the export.");
            var scan = snapshot.OpeningScan;
            add("Source opening scan coverage", scan != null && scan.Complete ? "Configured source opening scan completed; per-Room association and dimension review still applies." : "Source opening scan incomplete or unavailable; consult each exported Room's coverage and notes.");
            if (scan != null && scan.Openings != null)
            {
                var scanned = scan.Openings.Where(opening => opening != null && opening.Source != null).GroupBy(opening => opening.Source.Key, StringComparer.Ordinal).Select(group => group.First()).ToList();
                var exportedKeys = new HashSet<string>(snapshot.Rows.SelectMany(row => row.Openings).Select(opening => opening.Source.Key), StringComparer.Ordinal);
                add("Source scan: distinct openings observed", scanned.Count);
                add("Source scan: not in exported rows", scanned.Count(opening => !exportedKeys.Contains(opening.Source.Key)));
                add("Source scan: unassociated / lookup failed", scanned.Count(opening => opening.AssociationStatus == SpaceOpeningAssociationStatus.Unassociated || opening.AssociationStatus == SpaceOpeningAssociationStatus.LookupFailed));
                add("Source scan count scope", "These source-scan context counts can include filtered-out Rooms and unassociated openings. They are not exported-room inventory totals and are never added to Summary.");
            }
            if (scan != null && scan.Notes != null)
                for (int i = 0; i < scan.Notes.Count; i++) add("Opening scan note " + (i + 1).ToString(CultureInfo.InvariantCulture), scan.Notes[i]);
            add("Static totals", "Summary is calculated from exported rows at export time. Excel filters do not recalculate stored totals. No average room height is inferred.");
            add("Identifiers and text", "Element and link IDs and room/space numbers are stored as text to preserve exact digits and leading zeros. All model strings are inert text, including formula-like names. Excel cell text is limited to 32767 characters; invalid XML characters are replaced.");
            add("Addin creator", "Karim Ayman"); add("Tel", "01032638143"); add("LinkedIn", "karimayman27"); add("Email", "mech.karim.ayman@gmail.com");
            for (int i = 0; i < snapshot.Notes.Count; i++) add("Scan note " + (i + 1).ToString(CultureInfo.InvariantCulture), snapshot.Notes[i]);
            return table;
        }

        private static SpaceOpeningTotals OpeningTotals(SpaceTakeoffRow row)
        { return SpaceOpeningSummary.ForSpace(row.Openings, row.RoomIdentityVerified && row.OpeningsComplete); }
        private static string OpeningCoverage(SpaceTakeoffRow row, SpaceOpeningTotals totals)
        {
            if (!row.RoomIdentityVerified) return "Room unverified — counts unavailable";
            if (!totals.Complete) return "Partial opening scan — counts unavailable";
            return totals.DoorMissingDimensionCount > 0 || totals.WindowMissingDimensionCount > 0 ? "Counts verified; dimensions incomplete" : "Counts and nominal dimensions verified";
        }

        private static object Height(double? value, SpaceTakeoffExportOptions options) { return value.HasValue ? (object)(value.Value * (options.HeightsInMillimeters ? 1000.0 : 1.0)) : null; }
        private static string SourceDocument(SpaceSurfaceSource source) { return source == null ? "" : source.DocumentTitle; }
        private static string SourceName(SpaceSurfaceSource source) { return source == null ? "" : source.ElementName; }
        private static string SourceId(SpaceSurfaceSource source) { return source == null ? "" : source.ElementId.ToString(CultureInfo.InvariantCulture); }
        private static string SourceLink(SpaceSurfaceSource source) { return source == null ? "" : source.LinkInstanceId < 0 ? "Host" : source.LinkInstanceId.ToString(CultureInfo.InvariantCulture); }
        private static string Basis(SpaceHeightBasis basis)
        {
            return basis == SpaceHeightBasis.Ceiling ? "Ceiling underside" : basis == SpaceHeightBasis.Slab ? "Slab underside" : basis == SpaceHeightBasis.Mixed ? "Mixed ceiling/slab" : "Not established";
        }

        private static void Package(ZipArchive archive, IList<ReportTable> tables)
        {
            AddXml(archive, "[Content_Types].xml", w =>
            {
                const string types = "http://schemas.openxmlformats.org/package/2006/content-types";
                w.WriteStartElement("Types", types);
                EmptyNs(w, "Default", types, "Extension", "rels", "ContentType", "application/vnd.openxmlformats-package.relationships+xml");
                EmptyNs(w, "Default", types, "Extension", "xml", "ContentType", "application/xml");
                EmptyNs(w, "Override", types, "PartName", "/xl/workbook.xml", "ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml");
                EmptyNs(w, "Override", types, "PartName", "/xl/styles.xml", "ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml");
                for (int i = 0; i < tables.Count; i++) EmptyNs(w, "Override", types, "PartName", "/xl/worksheets/sheet" + (i + 1) + ".xml", "ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml");
                w.WriteEndElement();
            });
            AddXml(archive, "_rels/.rels", w =>
            {
                w.WriteStartElement("Relationships", PackageRelNs);
                EmptyNs(w, "Relationship", PackageRelNs, "Id", "rId1", "Type", DocumentRelNs + "/officeDocument", "Target", "xl/workbook.xml"); w.WriteEndElement();
            });
            AddXml(archive, "xl/_rels/workbook.xml.rels", w =>
            {
                w.WriteStartElement("Relationships", PackageRelNs);
                for (int i = 0; i < tables.Count; i++) EmptyNs(w, "Relationship", PackageRelNs, "Id", "rId" + (i + 1), "Type", DocumentRelNs + "/worksheet", "Target", "worksheets/sheet" + (i + 1) + ".xml");
                EmptyNs(w, "Relationship", PackageRelNs, "Id", "rId" + (tables.Count + 1), "Type", DocumentRelNs + "/styles", "Target", "styles.xml"); w.WriteEndElement();
            });
            AddXml(archive, "xl/workbook.xml", w =>
            {
                w.WriteStartElement("workbook", Ns); w.WriteAttributeString("xmlns", "r", null, DocumentRelNs);
                Start(w, "bookViews"); EmptyElement(w, "workbookView", "activeTab", "1"); w.WriteEndElement();
                Start(w, "sheets");
                for (int i = 0; i < tables.Count; i++)
                { Start(w, "sheet", "name", tables[i].Name, "sheetId", (i + 1).ToString(CultureInfo.InvariantCulture)); w.WriteAttributeString("r", "id", DocumentRelNs, "rId" + (i + 1)); w.WriteEndElement(); }
                w.WriteEndElement(); Start(w, "definedNames");
                for (int i = 0; i < tables.Count; i++)
                {
                    Start(w, "definedName", "name", "_xlnm.Print_Titles", "localSheetId", i.ToString(CultureInfo.InvariantCulture)); w.WriteString("'" + tables[i].Name + "'!$1:$5"); w.WriteEndElement();
                    Start(w, "definedName", "name", "_xlnm.Print_Area", "localSheetId", i.ToString(CultureInfo.InvariantCulture));
                    w.WriteString("'" + tables[i].Name + "'!$A$1:$" + Column(tables[i].Headers.Length) + "$" + (tables[i].Rows.Count + HeaderRow).ToString(CultureInfo.InvariantCulture)); w.WriteEndElement();
                }
                w.WriteEndElement(); w.WriteEndElement();
            });
        }

        private static void Sheet(ZipArchive archive, int index, ReportTable table, SpaceTakeoffSnapshot snapshot)
        {
            AddXml(archive, "xl/worksheets/sheet" + (index + 1) + ".xml", w =>
            {
                int last = table.Rows.Count + HeaderRow; string lastColumn = Column(table.Headers.Length);
                w.WriteStartElement("worksheet", Ns);
                Start(w, "sheetPr"); EmptyElement(w, "tabColor", "rgb", table.Name == "Summary" ? "FF007F78" : table.Name == "Info" ? "FF8395A1" : "FF142D42"); EmptyElement(w, "pageSetUpPr", "fitToPage", "1"); w.WriteEndElement();
                EmptyElement(w, "dimension", "ref", "A1:" + lastColumn + last);
                Start(w, "sheetViews"); Start(w, "sheetView", "workbookViewId", "0", "showGridLines", "0", "tabSelected", table.Name == "Summary" ? "1" : "0");
                EmptyElement(w, "pane", "xSplit", "1", "ySplit", "5", "topLeftCell", "B6", "activePane", "bottomRight", "state", "frozen");
                EmptyElement(w, "selection", "pane", "topRight", "activeCell", "B1", "sqref", "B1"); EmptyElement(w, "selection", "pane", "bottomLeft", "activeCell", "A6", "sqref", "A6"); EmptyElement(w, "selection", "pane", "bottomRight", "activeCell", "B6", "sqref", "B6"); w.WriteEndElement(); w.WriteEndElement();
                EmptyElement(w, "sheetFormatPr", "defaultRowHeight", "28"); Start(w, "cols");
                for (int i = 0; i < table.Widths.Length; i++) EmptyElement(w, "col", "min", (i + 1).ToString(CultureInfo.InvariantCulture), "max", (i + 1).ToString(CultureInfo.InvariantCulture), "width", table.Widths[i].ToString(CultureInfo.InvariantCulture), "customWidth", "1");
                w.WriteEndElement(); Start(w, "sheetData");
                Banner(w, 1, "KA MEP  |  " + table.Title, 1, 34);
                Banner(w, 2, snapshot.ProjectTitle + "  |  " + snapshot.Release + "  |  " + snapshot.ScannedAt.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture), 12, 30);
                Banner(w, 3, (snapshot.IsComplete ? "" : "INCOMPLETE SCAN — ") + table.Subtitle, 0, table.Name == "Info" ? 42 : 32);
                Start(w, "row", "r", "5", "ht", "44", "customHeight", "1");
                for (int i = 0; i < table.Headers.Length; i++) WriteCell(w, HeaderRow, i + 1, table.Headers[i], false, 1);
                w.WriteEndElement();
                for (int i = 0; i < table.Rows.Count; i++)
                {
                    int rowNumber = i + HeaderRow + 1; object[] values = table.Rows[i];
                    int lines = values.Select((value, col) => table.Numeric.Contains(col) ? 1 : Lines(Convert.ToString(value, CultureInfo.InvariantCulture), table.Widths[col] - 4)).Max();
                    Start(w, "row", "r", rowNumber.ToString(CultureInfo.InvariantCulture), "ht", Math.Min(180, Math.Max(30, lines * 15 + 10)).ToString(CultureInfo.InvariantCulture), "customHeight", "1");
                    for (int c = 0; c < values.Length; c++)
                    {
                        bool numeric = table.Numeric.Contains(c) || (table.Name == "Info" && c == 1 && (values[c] is double || values[c] is int));
                        int style = numeric ? table.Whole.Contains(c) ? 3 : 2 : 0;
                        if (table.TotalFirst && i == 0) style = numeric ? table.Whole.Contains(c) ? 6 : 5 : 4;
                        else if (table.Name == "Info" && c == 0) style = 12;
                        WriteCell(w, rowNumber, c + 1, values[c], numeric, style);
                    }
                    w.WriteEndElement();
                }
                w.WriteEndElement();
                EmptyElement(w, "autoFilter", "ref", "A5:" + lastColumn + last);
                Start(w, "mergeCells", "count", "3"); for (int i = 1; i <= 3; i++) EmptyElement(w, "mergeCell", "ref", "A" + i + ":" + lastColumn + i); w.WriteEndElement();
                EmptyElement(w, "printOptions", "horizontalCentered", "1", "gridLines", "0");
                EmptyElement(w, "pageMargins", "left", "0.25", "right", "0.25", "top", "0.55", "bottom", "0.55", "header", "0.22", "footer", "0.22");
                EmptyElement(w, "pageSetup", "paperSize", table.Headers.Length > 12 ? "8" : "9", "orientation", "landscape", "fitToWidth", table.Headers.Length > 20 ? "2" : "1", "fitToHeight", "0");
                Start(w, "headerFooter"); w.WriteElementString("oddHeader", Ns, "&L&\"Calibri,Bold\"&11&K142D42KA MEP V3.0&C&\"Calibri,Regular\"&10HVAC Spaces Takeoff&R&A");
                w.WriteElementString("oddFooter", Ns, "&L&\"Calibri,Regular\"&9&K687F8CKarim Ayman&CPage &P of &N&R&D"); w.WriteEndElement(); w.WriteEndElement();
            });
        }

        private static void Banner(XmlWriter w, int row, string text, int style, int height)
        { Start(w, "row", "r", row.ToString(CultureInfo.InvariantCulture), "ht", height.ToString(CultureInfo.InvariantCulture), "customHeight", "1"); WriteCell(w, row, 1, text, false, style); w.WriteEndElement(); }
        private static int Lines(string value, int width) { return (value ?? "").Split('\n').Sum(line => Math.Max(1, (line.Length + width - 1) / width)); }
        private static void EmptyElement(XmlWriter w, string name, params string[] attributes) { Start(w, name, attributes); w.WriteEndElement(); }
        private static void EmptyNs(XmlWriter w, string name, string ns, params string[] attributes)
        { w.WriteStartElement(name, ns); for (int i = 0; i < attributes.Length; i += 2) w.WriteAttributeString(attributes[i], attributes[i + 1]); w.WriteEndElement(); }
        private static string Column(int count) { string result = ""; while (count > 0) { count--; result = (char)('A' + count % 26) + result; count /= 26; } return result; }

        private sealed class ReportTable
        {
            internal ReportTable(string name, string title, string subtitle, string[] headers, int[] widths)
            { Name = name; Title = title; Subtitle = subtitle; Headers = headers; Widths = widths; }
            internal string Name, Title, Subtitle;
            internal string[] Headers;
            internal int[] Widths;
            internal bool TotalFirst;
            internal HashSet<int> Numeric = new HashSet<int>();
            internal HashSet<int> Whole = new HashSet<int>();
            internal List<object[]> Rows = new List<object[]>();
        }
    }
}
