using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace PipeTakeoff.Core
{
    /// <summary>Detached values used by sheet filename composition. No Revit API access.</summary>
    public sealed class SheetNameRecord
    {
        public IDictionary<string, string> Values { get; set; } = new Dictionary<string, string>(StringComparer.Ordinal);
        public string Fallback { get; set; }
    }

    public sealed class SheetNameOptions
    {
        public IList<string> ParameterKeys { get; set; } = new List<string>();
        public string Separator { get; set; } = "_";
        public string Prefix { get; set; }
        public string Suffix { get; set; }
    }

    public static class SheetFileNaming
    {
        public const int MaximumStemLength = 100;

        public static List<string> BuildNames(IList<SheetNameRecord> sheets, SheetNameOptions options)
        {
            if (sheets == null) throw new ArgumentNullException(nameof(sheets));
            if (options == null) throw new ArgumentNullException(nameof(options));
            var names = new List<string>();
            var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var sheet in sheets)
            {
                var parts = new List<string>();
                if (!string.IsNullOrWhiteSpace(options.Prefix)) parts.Add(options.Prefix.Trim());
                foreach (var key in options.ParameterKeys ?? new List<string>())
                {
                    string value;
                    // A visible placeholder keeps missing parameters from silently shifting filename parts.
                    parts.Add(sheet.Values != null && sheet.Values.TryGetValue(key, out value) && !string.IsNullOrWhiteSpace(value)
                        ? value.Trim() : "NA");
                }
                if (options.ParameterKeys == null || options.ParameterKeys.Count == 0)
                    parts.Add(string.IsNullOrWhiteSpace(sheet.Fallback) ? "Sheet" : sheet.Fallback);
                if (!string.IsNullOrWhiteSpace(options.Suffix)) parts.Add(options.Suffix.Trim());
                var stem = SafeStem(string.Join(options.Separator ?? "_", parts), sheet.Fallback);
                var unique = stem;
                int suffix = 2;
                while (!used.Add(unique))
                {
                    var tail = "_" + (suffix++).ToString(CultureInfo.InvariantCulture);
                    unique = Truncate(stem, MaximumStemLength - tail.Length).TrimEnd(' ', '.') + tail;
                }
                names.Add(unique);
            }
            return names;
        }

        public static string SafeStem(string value, string fallback = "Sheet", int limit = MaximumStemLength)
        {
            if (limit < 8) throw new ArgumentOutOfRangeException(nameof(limit), "A filename limit of at least eight characters is required.");
            string text = Sanitize(value);
            if (text.Length == 0) text = Sanitize(fallback);
            if (text.Length == 0) text = "Sheet";
            text = Truncate(text, limit).TrimEnd(' ', '.');
            var head = text.Split('.')[0].TrimEnd(' ', '.').ToUpperInvariant();
            if (head == "CON" || head == "PRN" || head == "AUX" || head == "NUL" || head == "CONIN$" || head == "CONOUT$"
                || (head.Length == 4 && (head.StartsWith("COM", StringComparison.Ordinal) || head.StartsWith("LPT", StringComparison.Ordinal))
                    && "123456789¹²³".IndexOf(head[3]) >= 0))
                text = "_" + Truncate(text, limit - 1).TrimEnd(' ', '.');
            return text;
        }

        private static string Sanitize(string value)
        {
            const string invalid = "<>:\"/\\|?*";
            var input = value ?? "";
            var chars = input.ToCharArray();
            for (int i = 0; i < chars.Length; i++)
            {
                char c = chars[i];
                if (c < 32 || invalid.IndexOf(c) >= 0 || (char.IsHighSurrogate(c) && (i + 1 >= chars.Length || !char.IsLowSurrogate(chars[i + 1])))
                    || (char.IsLowSurrogate(c) && (i == 0 || !char.IsHighSurrogate(chars[i - 1])))) chars[i] = '_';
            }
            return new string(chars).Trim().TrimEnd(' ', '.');
        }

        private static string Truncate(string text, int length)
        {
            if (text.Length <= length) return text;
            if (char.IsHighSurrogate(text[length - 1])) length--;
            return text.Substring(0, length);
        }
    }
}
