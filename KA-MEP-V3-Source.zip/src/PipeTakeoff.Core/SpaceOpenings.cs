using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace PipeTakeoff.Core
{
    public enum SpaceOpeningKind { Door, Window }
    public enum SpaceOpeningAssociationStatus { Associated, OutsideExportedRooms, Unassociated, LookupFailed }

    /// <summary>A phase-specific Room in one physical document/link placement.</summary>
    public sealed class SpaceOpeningRoomIdentity
    {
        public SpaceSurfaceSource Source { get; set; }
        public string UniqueId { get; set; } = "";
        public string Number { get; set; } = "";
        public string Name { get; set; } = "";
        public string Key { get { return Source == null || string.IsNullOrWhiteSpace(UniqueId) ? "" : Source.Key + "|" + UniqueId; } }
    }

    /// <summary>One physical family instance. Dimensions are nominal metres, not clear opening or glazing measurements.</summary>
    public sealed class SpaceOpeningRecord
    {
        public SpaceOpeningKind Kind { get; set; }
        public SpaceSurfaceSource Source { get; set; }
        public string UniqueId { get; set; } = "";
        public string FamilyName { get; set; } = "";
        public string TypeName { get; set; } = "";
        public double? WidthMeters { get; set; }
        public double? HeightMeters { get; set; }
        public double? AreaSquareMeters { get { return SpaceOpeningDimensions.NominalArea(WidthMeters, HeightMeters); } }
        public string DimensionSource { get; set; } = "";
        public string DimensionNotes { get; set; } = "";
        public SpaceOpeningAssociationStatus AssociationStatus { get; set; } = SpaceOpeningAssociationStatus.Unassociated;
        public string AssociationNotes { get; set; } = "";
        public List<SpaceOpeningRoomIdentity> Rooms { get; set; } = new List<SpaceOpeningRoomIdentity>();
        public List<long> SpaceIds { get; set; } = new List<long>();
        public bool IsShared { get { return Rooms.Where(room => room != null && room.Key.Length > 0).Select(room => room.Key).Distinct(StringComparer.Ordinal).Skip(1).Any(); } }
    }

    public sealed class SpaceOpeningTotals
    {
        public bool Complete { get; internal set; }
        public int? DoorCount { get; internal set; }
        public int? WindowCount { get; internal set; }
        public double? DoorAreaSquareMeters { get; internal set; }
        public double? WindowAreaSquareMeters { get; internal set; }
        public double DoorKnownAreaSquareMeters { get; internal set; }
        public double WindowKnownAreaSquareMeters { get; internal set; }
        public int DoorMissingDimensionCount { get; internal set; }
        public int WindowMissingDimensionCount { get; internal set; }
    }

    public sealed class SpaceOpeningScanResult
    {
        public List<SpaceOpeningRecord> Openings { get; set; } = new List<SpaceOpeningRecord>();
        public bool Complete { get; set; }
        public List<string> Notes { get; set; } = new List<string>();
        public IEnumerable<SpaceOpeningRecord> UnassociatedOpenings
        {
            get { return Openings.Where(opening => opening.AssociationStatus == SpaceOpeningAssociationStatus.Unassociated || opening.AssociationStatus == SpaceOpeningAssociationStatus.LookupFailed); }
        }
        public IEnumerable<SpaceOpeningRecord> OutsideExportedRooms
        {
            get { return Openings.Where(opening => opening.AssociationStatus == SpaceOpeningAssociationStatus.OutsideExportedRooms); }
        }
        /// <summary>Unique physical openings associated with exported Spaces, never the sum of Space counts.</summary>
        public SpaceOpeningTotals Totals
        {
            get { return SpaceOpeningSummary.ForUniqueOpenings(Openings.Where(opening => opening.SpaceIds.Count > 0), Complete); }
        }
    }

    public static class SpaceOpeningDimensions
    {
        private const double MetresPerFoot = 0.3048;
        /// <summary>Input values must already be verified as Revit length parameters.</summary>
        public static double? PositiveLengthMeters(double? instanceFeet, double? typeFeet)
        {
            double? instanceMeters = ToPositiveMeters(instanceFeet);
            return instanceMeters ?? ToPositiveMeters(typeFeet);
        }
        public static double? NominalArea(double? widthMeters, double? heightMeters)
        {
            if (!Positive(widthMeters) || !Positive(heightMeters)) return null;
            double area = widthMeters.Value * heightMeters.Value;
            return Positive(area) ? area : (double?)null;
        }
        /// <summary>Nominal width × height with explicit units; an unavailable side remains Unknown.</summary>
        public static string FormatSize(double? widthMeters, double? heightMeters, bool inMillimeters, IFormatProvider formatProvider)
        {
            var provider = formatProvider ?? CultureInfo.InvariantCulture;
            return FormatSizeLength(widthMeters, inMillimeters, provider) + " × " +
                FormatSizeLength(heightMeters, inMillimeters, provider) + (inMillimeters ? " mm" : " m");
        }
        private static string FormatSizeLength(double? meters, bool inMillimeters, IFormatProvider provider)
        {
            if (!Positive(meters)) return "Unknown";
            double value = meters.Value * (inMillimeters ? 1000 : 1);
            if (!Positive(value)) return "Unknown";
            // Keep customary display precision without rounding a small positive length to zero.
            string format = inMillimeters ? "0" : "0.###";
            if (Math.Round(value, inMillimeters ? 0 : 3) == 0) format = "G";
            return value.ToString(format, provider);
        }
        private static bool Positive(double? value)
        {
            return value.HasValue && SpaceTakeoffOptions.Finite(value.Value) && value.Value > 0;
        }
        private static double? ToPositiveMeters(double? feet)
        {
            if (!Positive(feet)) return null;
            double meters = feet.Value * MetresPerFoot;
            return Positive(meters) ? meters : (double?)null;
        }
    }

    public static class SpaceOpeningSummary
    {
        public static SpaceOpeningTotals ForSpace(IEnumerable<SpaceOpeningRecord> openings, bool complete)
        {
            return ForUniqueOpenings(openings, complete);
        }

        public static SpaceOpeningTotals ForUniqueOpenings(IEnumerable<SpaceOpeningRecord> openings, bool complete)
        {
            if (openings == null) throw new ArgumentNullException(nameof(openings));
            var records = openings.ToList();
            // Unknown physical identity must not manufacture either an extra opening or a complete zero.
            if (records.Any(opening => opening == null || opening.Source == null || opening.AssociationStatus == SpaceOpeningAssociationStatus.LookupFailed)) complete = false;
            var unique = records.Where(opening => opening != null && opening.Source != null)
                .GroupBy(opening => opening.Source.Key, StringComparer.Ordinal).Select(group => group.First()).ToList();
            var doors = unique.Where(opening => opening.Kind == SpaceOpeningKind.Door).ToList();
            var windows = unique.Where(opening => opening.Kind == SpaceOpeningKind.Window).ToList();
            var result = new SpaceOpeningTotals { Complete = complete,
                DoorCount = complete ? doors.Count : (int?)null, WindowCount = complete ? windows.Count : (int?)null,
                DoorKnownAreaSquareMeters = doors.Where(opening => opening.AreaSquareMeters.HasValue).Sum(opening => opening.AreaSquareMeters.Value),
                WindowKnownAreaSquareMeters = windows.Where(opening => opening.AreaSquareMeters.HasValue).Sum(opening => opening.AreaSquareMeters.Value),
                DoorMissingDimensionCount = doors.Count(opening => !opening.AreaSquareMeters.HasValue),
                WindowMissingDimensionCount = windows.Count(opening => !opening.AreaSquareMeters.HasValue) };
            result.DoorAreaSquareMeters = complete && result.DoorMissingDimensionCount == 0 && SpaceTakeoffOptions.Finite(result.DoorKnownAreaSquareMeters)
                ? result.DoorKnownAreaSquareMeters : (double?)null;
            result.WindowAreaSquareMeters = complete && result.WindowMissingDimensionCount == 0 && SpaceTakeoffOptions.Finite(result.WindowKnownAreaSquareMeters)
                ? result.WindowKnownAreaSquareMeters : (double?)null;
            return result;
        }
    }

    public static class SpaceOpeningAssociation
    {
        /// <summary>Joins only exact, verified Room identities. Room text and physical proximity are never used.</summary>
        public static void Assign(IList<SpaceTakeoffRow> rows, IEnumerable<SpaceOpeningRecord> openings, bool scanComplete)
        {
            if (rows == null) throw new ArgumentNullException(nameof(rows));
            if (openings == null) throw new ArgumentNullException(nameof(openings));
            var supplied = openings.ToList();
            if (supplied.Any(opening => opening == null || opening.Source == null || opening.AssociationStatus == SpaceOpeningAssociationStatus.LookupFailed)) scanComplete = false;
            var records = supplied.Where(opening => opening != null).ToList();
            var matches = new Dictionary<string, List<SpaceTakeoffRow>>(StringComparer.Ordinal);
            foreach (var row in rows)
            {
                row.Openings.Clear();
                row.OpeningsComplete = scanComplete && row.RoomIdentityVerified;
                if (!row.RoomIdentityVerified) continue;
                string key = row.RoomSource.Key + "|" + row.RoomUniqueId;
                List<SpaceTakeoffRow> roomRows;
                if (!matches.TryGetValue(key, out roomRows)) matches.Add(key, roomRows = new List<SpaceTakeoffRow>());
                roomRows.Add(row);
            }
            foreach (var opening in records)
            {
                opening.SpaceIds.Clear();
                var identities = opening.Rooms.Where(room => room != null && room.Key.Length > 0)
                    .GroupBy(room => room.Key, StringComparer.Ordinal).Select(group => group.First()).ToList();
                foreach (var identity in identities)
                {
                    List<SpaceTakeoffRow> roomRows;
                    if (!matches.TryGetValue(identity.Key, out roomRows)) continue;
                    foreach (var row in roomRows)
                    {
                        if (opening.Source == null) { row.OpeningsComplete = false; continue; }
                        if (!row.Openings.Any(existing => existing.Source != null && existing.Source.Key == opening.Source.Key)) row.Openings.Add(opening);
                        if (!opening.SpaceIds.Contains(row.SpaceId)) opening.SpaceIds.Add(row.SpaceId);
                    }
                }
                if (opening.AssociationStatus != SpaceOpeningAssociationStatus.LookupFailed)
                    opening.AssociationStatus = opening.SpaceIds.Count > 0 ? SpaceOpeningAssociationStatus.Associated
                        : identities.Count > 0 ? SpaceOpeningAssociationStatus.OutsideExportedRooms : SpaceOpeningAssociationStatus.Unassociated;
            }
        }
    }
}
