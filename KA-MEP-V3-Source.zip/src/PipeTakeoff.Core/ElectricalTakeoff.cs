using System;
using System.Collections.Generic;
using System.Linq;

namespace PipeTakeoff.Core
{
    public static class ElectricalStandardFields
    {
        public static List<FieldDefinition> Create()
        {
            return new List<FieldDefinition>
            {
                Field("ElementId", "Element ID"), Field("Category", "Category"),
                Field("Family", "Family"), Field("Type", "Type"),
                Field("SystemName", "Service Type"), Field("Level", "Reference Level"),
                Field("Size", "Size (project format)"), Field("SectionLabel", "Section / connectors (mm)"),
                Field("Width", "Width (mm)", true), Field("Height", "Height (mm)", true),
                Field("Diameter", "Diameter (mm)", true), Field("Length", "Straight Length (m)", true),
                Field("FittingKind", "Fitting Kind"), Field("Angle", "Angle (degrees)", true),
                Field("Mark", "Mark"), Field("Comments", "Comments"), Field("SectionKey", "Canonical Section Key")
            };
        }

        private static FieldDefinition Field(string key, string header, bool numeric = false)
        { return new FieldDefinition { Key = key, Header = header, IsNumeric = numeric }; }
    }

    public sealed class ElectricalSummaryRow
    {
        public string Category { get; set; } = "";
        public string Size { get; set; } = "";
        public string FittingKind { get; set; } = "";
        public double? AngleDegrees { get; set; }
        public string SystemName { get; set; } = "";
        public string Family { get; set; } = "";
        public string Type { get; set; } = "";
        public int Count { get; set; }
        public double TotalLengthMeters { get; set; }
    }

    public static class ElectricalTakeoffEngine
    {
        public static List<PipeRecord> Filter(IEnumerable<PipeRecord> records, TakeoffOptions options)
        { return TakeoffEngine.Filter(records, options); }

        /// <summary>Groups already-filtered records by exact canonical sections, keeping both systems and fittings separate.</summary>
        public static List<ElectricalSummaryRow> Summarize(IEnumerable<PipeRecord> records, TakeoffOptions options)
        {
            if (records == null) throw new ArgumentNullException(nameof(records));
            if (options == null) throw new ArgumentNullException(nameof(options));
            var groups = new Dictionary<GroupKey, ElectricalSummaryRow>();
            foreach (PipeRecord record in records)
            {
                if (record == null) throw new ArgumentException("An electrical takeoff record is missing.", nameof(records));
                string category = RequiredText(record, "Category");
                bool straight = IsStraight(category);
                if (!straight && category != "Cable Tray Fitting" && category != "Conduit Fitting")
                    throw Invalid(record, "Category (expected Cable Tray, Cable Tray Fitting, Conduit, or Conduit Fitting)");
                // An unresolved section must be supplied as an element-specific key by the model reader.
                // Empty section identities are never silently grouped together.
                string section = RequiredText(record, "SectionKey");
                foreach (string dimension in new[] { "Width", "Height", "Diameter" }) ValidateDimension(record, dimension);
                double length = straight ? Measurement(record, "Length") : 0;
                double? angle = straight ? null : OptionalMeasurement(record, "Angle");
                if (angle.HasValue)
                {
                    if (angle.Value > 360) throw Invalid(record, "Angle (degrees)");
                    angle = Math.Round(angle.Value, 6, MidpointRounding.AwayFromZero);
                }
                string kind = straight ? "" : TakeoffEngine.Text(record.Get("FittingKind"));
                var key = new GroupKey(category, section, kind, angle,
                    options.GroupBySystem ? TakeoffEngine.Text(record.Get("SystemName")) : "",
                    options.GroupByFamily ? TakeoffEngine.Text(record.Get("Family")) : "",
                    options.GroupByType ? TakeoffEngine.Text(record.Get("Type")) : "");
                ElectricalSummaryRow row;
                if (!groups.TryGetValue(key, out row))
                {
                    string size = TakeoffEngine.Text(record.Get("SectionLabel"));
                    if (string.IsNullOrWhiteSpace(size)) size = TakeoffEngine.Text(record.Get("Size"));
                    if (string.IsNullOrWhiteSpace(size)) size = section;
                    row = new ElectricalSummaryRow
                    {
                        Category = category, Size = size, FittingKind = kind, AngleDegrees = angle,
                        SystemName = key.Service, Family = key.Family, Type = key.Type
                    };
                    groups.Add(key, row);
                }
                checked { row.Count++; }
                row.TotalLengthMeters += length;
                if (!TakeoffEngine.IsFinite(row.TotalLengthMeters))
                    throw new ArgumentException("An electrical takeoff total is outside the supported numeric range.", nameof(records));
            }
            return groups.OrderBy(pair => pair.Key.Category, StringComparer.Ordinal)
                .ThenBy(pair => pair.Key.Section, StringComparer.Ordinal)
                .ThenBy(pair => pair.Key.Kind, StringComparer.Ordinal)
                .ThenBy(pair => pair.Key.Angle)
                .ThenBy(pair => pair.Key.Service, StringComparer.Ordinal)
                .ThenBy(pair => pair.Key.Family, StringComparer.Ordinal)
                .ThenBy(pair => pair.Key.Type, StringComparer.Ordinal)
                .Select(pair => pair.Value).ToList();
        }

        internal static bool IsStraight(string category)
        { return category == "Cable Tray" || category == "Conduit"; }

        private static double Measurement(PipeRecord record, string key)
        {
            double value;
            if (!TakeoffEngine.TryNumber(record.Get(key), out value) || value < 0) throw Invalid(record, key);
            return value;
        }

        private static double? OptionalMeasurement(PipeRecord record, string key)
        {
            object value = record.Get(key);
            return value == null || (value is string && string.IsNullOrWhiteSpace((string)value)) ? (double?)null : Measurement(record, key);
        }

        private static void ValidateDimension(PipeRecord record, string key)
        {
            double? value = OptionalMeasurement(record, key);
            if (value.HasValue && value.Value <= 0) throw Invalid(record, key);
        }

        private static string RequiredText(PipeRecord record, string key)
        {
            string value = TakeoffEngine.Text(record.Get(key));
            if (string.IsNullOrWhiteSpace(value)) throw Invalid(record, key);
            return value;
        }

        private static ArgumentException Invalid(PipeRecord record, string key)
        { return new ArgumentException("Electrical element " + TakeoffEngine.Text(record.Get("ElementId")) + " has a missing or invalid " + key + " value."); }

        private sealed class GroupKey : IEquatable<GroupKey>
        {
            internal readonly string Category, Section, Kind, Service, Family, Type;
            internal readonly double? Angle;
            internal GroupKey(string category, string section, string kind, double? angle, string service, string family, string type)
            { Category = category; Section = section; Kind = kind; Angle = angle; Service = service; Family = family; Type = type; }
            public bool Equals(GroupKey other)
            {
                return other != null && Category == other.Category && Section == other.Section && Kind == other.Kind &&
                    Angle == other.Angle && Service == other.Service && Family == other.Family && Type == other.Type;
            }
            public override bool Equals(object obj) { return Equals(obj as GroupKey); }
            public override int GetHashCode()
            {
                unchecked
                {
                    int hash = Category.GetHashCode();
                    foreach (string value in new[] { Section, Kind, Service, Family, Type }) hash = hash * 397 ^ value.GetHashCode();
                    return hash * 397 ^ Angle.GetHashCode();
                }
            }
        }
    }
}
