using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace PipeTakeoff.Core
{
    public static class TakeoffEngine
    {
        public static void ValidateFilters(TakeoffOptions options)
        {
            if (options == null) throw new ArgumentNullException(nameof(options));
            if (options.Filters == null) throw new ArgumentException("The filter list is missing.", nameof(options));
            if (!Enum.IsDefined(typeof(FilterMatch), options.Match))
                throw new ArgumentException("The filter matching mode is invalid.", nameof(options));
            for (int i = 0; i < options.Filters.Count; i++)
            {
                FilterRule rule = options.Filters[i];
                string prefix = "Filter " + (i + 1).ToString(CultureInfo.InvariantCulture) + ": ";
                if (rule == null || rule.Field == null || string.IsNullOrWhiteSpace(rule.Field.Key))
                    throw new ArgumentException(prefix + "select a parameter.", nameof(options));
                if (!Enum.IsDefined(typeof(FilterOperator), rule.Operator))
                    throw new ArgumentException(prefix + "the operator is invalid.", nameof(options));
                if (IsEmptyOperator(rule.Operator)) continue;
                if (IsOrderedOperator(rule.Operator) && !rule.Field.IsNumeric)
                    throw new ArgumentException(prefix + "ordered comparisons require a numeric parameter.", nameof(options));
                if (rule.Field.IsNumeric && !IsTextOperator(rule.Operator))
                {
                    double number;
                    if (!TryNumber(rule.Value, out number))
                        throw new ArgumentException(prefix + "enter a finite number for " + rule.Field.Header + ".", nameof(options));
                }
            }
        }

        public static List<PipeRecord> Filter(IEnumerable<PipeRecord> records, TakeoffOptions options)
        {
            if (records == null) throw new ArgumentNullException(nameof(records));
            ValidateFilters(options);
            var result = new List<PipeRecord>();
            foreach (PipeRecord record in records)
            {
                if (record == null) throw new ArgumentException("A pipe record is missing.", nameof(records));
                bool matches = options.Filters.Count == 0 ||
                    (options.Match == FilterMatch.All
                        ? options.Filters.All(rule => Matches(record, rule))
                        : options.Filters.Any(rule => Matches(record, rule)));
                if (matches) result.Add(record);
            }
            return result;
        }

        // The caller supplies the already filtered records. Diameter is always a grouping key.
        public static List<SummaryRow> Summarize(IEnumerable<PipeRecord> records, TakeoffOptions options)
        {
            if (records == null) throw new ArgumentNullException(nameof(records));
            if (options == null) throw new ArgumentNullException(nameof(options));
            var groups = new Dictionary<GroupKey, SummaryRow>();
            foreach (PipeRecord record in records)
            {
                if (record == null) throw new ArgumentException("A pipe record is missing.", nameof(records));
                double diameter = Measurement(record, "Diameter");
                double length = Measurement(record, "Length");
                var key = new GroupKey(
                    Math.Round(diameter, 6, MidpointRounding.AwayFromZero),
                    options.GroupBySystem ? Text(record.Get("SystemName")) : "",
                    options.GroupByFamily ? Text(record.Get("Family")) : "",
                    options.GroupByType ? Text(record.Get("Type")) : "");
                SummaryRow row;
                if (!groups.TryGetValue(key, out row))
                {
                    row = new SummaryRow
                    {
                        DiameterMillimeters = key.Diameter,
                        SystemName = key.System,
                        Family = key.Family,
                        Type = key.Type
                    };
                    groups.Add(key, row);
                }
                checked { row.Count++; }
                row.TotalLengthMeters += length;
                if (!IsFinite(row.TotalLengthMeters))
                    throw new ArgumentException("The total pipe length is outside the supported numeric range.", nameof(records));
            }
            return groups.Values.OrderBy(row => row.DiameterMillimeters)
                .ThenBy(row => row.SystemName, StringComparer.OrdinalIgnoreCase)
                .ThenBy(row => row.Family, StringComparer.OrdinalIgnoreCase)
                .ThenBy(row => row.Type, StringComparer.OrdinalIgnoreCase).ToList();
        }

        internal static string Text(object value)
        {
            return value == null ? "" : Convert.ToString(value, CultureInfo.InvariantCulture) ?? "";
        }

        internal static bool IsFinite(double value)
        {
            return !double.IsNaN(value) && !double.IsInfinity(value);
        }

        internal static bool TryNumber(object value, out double number)
        {
            if (value == null) { number = 0; return false; }
            string text = value as string;
            if (text != null)
            {
                // Deliberately do not accept thousands separators: 1.25 must never become 125
                // when the current culture uses a comma decimal separator.
                return (double.TryParse(text, NumberStyles.Float, CultureInfo.CurrentCulture, out number) ||
                        double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out number)) && IsFinite(number);
            }
            if (value is bool || value is DateTime || value is char) { number = 0; return false; }
            try { number = Convert.ToDouble(value, CultureInfo.InvariantCulture); return IsFinite(number); }
            catch (FormatException) { number = 0; return false; }
            catch (InvalidCastException) { number = 0; return false; }
            catch (OverflowException) { number = 0; return false; }
        }

        internal static double Measurement(PipeRecord record, string key)
        {
            double value;
            if (!TryNumber(record.Get(key), out value) || value < 0)
                throw new ArgumentException("Pipe " + Text(record.Get("ElementId")) + " has a missing or invalid " + key + " value.");
            return value;
        }

        private static bool Matches(PipeRecord record, FilterRule rule)
        {
            object value = record.Get(rule.Field.Key);
            string actual = Text(value);
            bool empty = string.IsNullOrWhiteSpace(actual);
            if (rule.Operator == FilterOperator.IsEmpty) return empty;
            if (rule.Operator == FilterOperator.IsNotEmpty) return !empty;
            // Missing parameters do not satisfy value comparisons, including negative comparisons.
            if (empty) return false;
            string expected = rule.Value ?? "";
            if (rule.Operator == FilterOperator.Contains)
                return actual.IndexOf(expected, StringComparison.OrdinalIgnoreCase) >= 0;
            if (rule.Operator == FilterOperator.DoesNotContain)
                return actual.IndexOf(expected, StringComparison.OrdinalIgnoreCase) < 0;
            if (!rule.Field.IsNumeric)
            {
                bool equal = string.Equals(actual, expected, StringComparison.OrdinalIgnoreCase);
                return rule.Operator == FilterOperator.Equals ? equal : !equal;
            }
            double left, right;
            if (!TryNumber(value, out left) || !TryNumber(expected, out right)) return false;
            // Accommodate Revit internal-unit conversion roundoff without changing engineering precision.
            double tolerance = Math.Max(1e-9, Math.Max(Math.Abs(left), Math.Abs(right)) * 1e-12);
            bool equalNumber = Math.Abs(left - right) <= tolerance;
            switch (rule.Operator)
            {
                case FilterOperator.Equals: return equalNumber;
                case FilterOperator.NotEquals: return !equalNumber;
                case FilterOperator.GreaterThan: return !equalNumber && left > right;
                case FilterOperator.GreaterOrEqual: return equalNumber || left > right;
                case FilterOperator.LessThan: return !equalNumber && left < right;
                case FilterOperator.LessOrEqual: return equalNumber || left < right;
                default: return false;
            }
        }

        private static bool IsOrderedOperator(FilterOperator op)
        {
            return op == FilterOperator.GreaterThan || op == FilterOperator.GreaterOrEqual ||
                   op == FilterOperator.LessThan || op == FilterOperator.LessOrEqual;
        }
        private static bool IsTextOperator(FilterOperator op)
        {
            return op == FilterOperator.Contains || op == FilterOperator.DoesNotContain;
        }
        private static bool IsEmptyOperator(FilterOperator op)
        {
            return op == FilterOperator.IsEmpty || op == FilterOperator.IsNotEmpty;
        }

        private sealed class GroupKey : IEquatable<GroupKey>
        {
            internal readonly double Diameter;
            internal readonly string System;
            internal readonly string Family;
            internal readonly string Type;
            internal GroupKey(double diameter, string system, string family, string type)
            { Diameter = diameter; System = system; Family = family; Type = type; }
            public bool Equals(GroupKey other)
            {
                return other != null && Diameter == other.Diameter && System == other.System && Family == other.Family && Type == other.Type;
            }
            public override bool Equals(object obj) { return Equals(obj as GroupKey); }
            public override int GetHashCode()
            {
                unchecked
                {
                    int hash = Diameter.GetHashCode();
                    hash = (hash * 397) ^ System.GetHashCode();
                    hash = (hash * 397) ^ Family.GetHashCode();
                    return (hash * 397) ^ Type.GetHashCode();
                }
            }
        }
    }
}
