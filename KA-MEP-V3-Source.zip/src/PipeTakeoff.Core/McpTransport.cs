using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;

namespace PipeTakeoff.Core.Mcp
{
    /// <summary>A bounded, authenticated bridge on 127.0.0.1. This is not an HTTP server.</summary>
    public sealed class McpLoopbackServer : IDisposable
    {
        private const int WorkerCount = 4;
        private readonly Func<McpWireRequest, CancellationToken, Task<McpWireResponse>> handler;
        private readonly object gate = new object();
        private readonly HashSet<TcpClient> clients = new HashSet<TcpClient>();
        private TcpListener listener;
        private CancellationTokenSource shutdown;
        private Task[] workers;
        private byte[] secret;
        private bool disposed;

        public McpLoopbackServer(Func<McpWireRequest, CancellationToken, Task<McpWireResponse>> handler)
        {
            this.handler = handler ?? throw new ArgumentNullException(nameof(handler));
        }

        public int Start(string token)
        {
            var decoded = McpTransportSecurity.DecodeToken(token);
            lock (gate)
            {
                if (disposed) throw new ObjectDisposedException(nameof(McpLoopbackServer));
                if (listener != null) throw new InvalidOperationException("The local bridge is already running.");
                var starting = new TcpListener(IPAddress.Loopback, 0);
                try { starting.Start(WorkerCount); }
                catch (SocketException) { starting.Stop(); throw new IOException("The local bridge could not open a loopback port."); }
                listener = starting;
                secret = decoded;
                shutdown = new CancellationTokenSource();
                workers = new Task[WorkerCount];
                // Fixed workers also bound handlers that ignore their cancellation token.
                for (var i = 0; i < workers.Length; i++) workers[i] = AcceptWorkerAsync(starting, shutdown.Token);
                return ((IPEndPoint)starting.LocalEndpoint).Port;
            }
        }

        private async Task AcceptWorkerAsync(TcpListener accepting, CancellationToken stopping)
        {
            while (!stopping.IsCancellationRequested)
            {
                TcpClient client = null;
                try
                {
                    client = await accepting.AcceptTcpClientAsync().ConfigureAwait(false);
                    lock (gate)
                    {
                        if (disposed) { client.Dispose(); return; }
                        clients.Add(client);
                    }
                    client.NoDelay = true;
                    await HandleAsync(client, stopping).ConfigureAwait(false);
                }
                catch (Exception)
                {
                    // No request, token, payload, or native exception is logged or echoed.
                    // Shutdown closes the listener and every client to release socket awaits.
                    if (stopping.IsCancellationRequested) return;
                    // A failed listener must not create a hot retry loop.
                    if (client == null) return;
                }
                finally
                {
                    if (client != null)
                    {
                        lock (gate) clients.Remove(client);
                        client.Dispose();
                    }
                }
            }
        }

        private async Task HandleAsync(TcpClient client, CancellationToken stopping)
        {
            using (var requestLifetime = CancellationTokenSource.CreateLinkedTokenSource(stopping))
            using (requestLifetime.Token.Register(() => McpTransportFrames.Close(client)))
            {
                requestLifetime.CancelAfter(McpTransportFrames.RequestTimeoutMilliseconds);
                var stream = client.GetStream();
                McpWireRequest request;
                try
                {
                    byte[] bytes;
                    using (var reading = CancellationTokenSource.CreateLinkedTokenSource(requestLifetime.Token))
                    using (reading.Token.Register(() => McpTransportFrames.Close(client)))
                    {
                        reading.CancelAfter(McpTransportFrames.NetworkTimeoutMilliseconds);
                        bytes = await McpTransportFrames.ReadAsync(stream, McpLimits.MaxRequestBytes, reading.Token).ConfigureAwait(false);
                    }
                    request = McpWireCodec.Deserialize<McpWireRequest>(bytes);
                }
                catch (Exception)
                {
                    await TryRespondAsync(stream, McpWireResponse.Fail(null, "invalid_request", "The local bridge request was malformed, incomplete, or too large."), requestLifetime.Token).ConfigureAwait(false);
                    return;
                }

                // Authentication precedes semantic request validation and handler dispatch.
                if (request == null || !McpTransportSecurity.Matches(secret, request.Token))
                {
                    await TryRespondAsync(stream, McpWireResponse.Fail(null, "authentication_failed", "The local bridge connection is not authorized."), requestLifetime.Token).ConfigureAwait(false);
                    return;
                }
                request.Token = null;
                try { McpLimits.ValidateRequest(request); }
                catch (Exception)
                {
                    var id = request.RequestId != null && request.RequestId.Length <= 80 ? request.RequestId : null;
                    await TryRespondAsync(stream, McpWireResponse.Fail(id, "invalid_request", "The local bridge request is not supported or has invalid arguments."), requestLifetime.Token).ConfigureAwait(false);
                    return;
                }

                using (var monitoring = CancellationTokenSource.CreateLinkedTokenSource(requestLifetime.Token))
                {
                    var disconnect = MonitorDisconnectAsync(client, requestLifetime, monitoring.Token);
                    try
                    {
                        requestLifetime.Token.ThrowIfCancellationRequested();
                        McpWireResponse response;
                        try
                        {
                            response = await handler(request, requestLifetime.Token).ConfigureAwait(false);
                            if (response == null) response = McpWireResponse.Fail(request.RequestId, "bridge_error", "The local bridge returned no response.");
                        }
                        catch (OperationCanceledException) { return; }
                        catch (Exception) { response = McpWireResponse.Fail(request.RequestId, "bridge_error", "The local bridge could not complete this read request."); }
                        requestLifetime.Token.ThrowIfCancellationRequested();
                        // A handler may reuse a response object. Correlation belongs to this
                        // call, so do not mutate an object that another worker could be using.
                        var correlated = new McpWireResponse
                        {
                            Protocol = 1,
                            RequestId = request.RequestId,
                            Success = response.Success,
                            ErrorCode = response.ErrorCode,
                            Error = response.Error,
                            PayloadJson = response.PayloadJson
                        };
                        await TryRespondAsync(stream, correlated, requestLifetime.Token).ConfigureAwait(false);
                    }
                    catch (OperationCanceledException) { }
                    finally
                    {
                        monitoring.Cancel();
                        await disconnect.ConfigureAwait(false);
                    }
                }
            }
        }

        private static async Task MonitorDisconnectAsync(TcpClient client, CancellationTokenSource requestLifetime, CancellationToken stopping)
        {
            try
            {
                while (!stopping.IsCancellationRequested)
                {
                    // Readability with no bytes means EOF. Extra bytes violate the single-call protocol.
                    if (client.Client.Poll(0, SelectMode.SelectRead))
                    {
                        requestLifetime.Cancel();
                        return;
                    }
                    await Task.Delay(100, stopping).ConfigureAwait(false);
                }
            }
            catch (OperationCanceledException) { }
            catch (Exception) { try { requestLifetime.Cancel(); } catch (Exception) { } }
        }

        private static async Task TryRespondAsync(NetworkStream stream, McpWireResponse response, CancellationToken token)
        {
            try
            {
                var bytes = McpWireCodec.Serialize(response);
                if (bytes.Length > McpLimits.MaxResponseBytes)
                    bytes = McpWireCodec.Serialize(McpWireResponse.Fail(response.RequestId, "response_too_large", "The local bridge response exceeded its size limit. Request a smaller page."));
                await McpTransportFrames.WriteAsync(stream, bytes, McpLimits.MaxResponseBytes, token).ConfigureAwait(false);
            }
            catch (Exception) { /* A disconnected peer cannot receive an error response. */ }
        }

        public void Dispose()
        {
            TcpClient[] closing;
            CancellationTokenSource cancellation;
            Task[] finishing;
            lock (gate)
            {
                if (disposed) return;
                disposed = true;
                if (listener != null) listener.Stop();
                cancellation = shutdown;
                finishing = workers;
                closing = new TcpClient[clients.Count];
                clients.CopyTo(closing);
            }
            if (cancellation != null)
            {
                try { cancellation.Cancel(); } catch (AggregateException) { }
                foreach (var client in closing) McpTransportFrames.Close(client);
                // Do not block Revit's UI thread while an ExternalEvent is being cancelled.
                Task.WhenAll(finishing).ContinueWith(_ => cancellation.Dispose(), CancellationToken.None, TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
            }
        }
    }

    public static class McpLoopbackClient
    {
        public static async Task<McpWireResponse> Call(McpConnection connection, McpWireRequest request, CancellationToken token)
        {
            if (connection == null || connection.Protocol != 1 || connection.Port < 1 || connection.Port > 65535)
                throw new IOException("The local bridge connection is invalid. Enable MCP in Revit again.");
            try { McpTransportSecurity.DecodeToken(connection.Token); }
            catch (ArgumentException) { throw new IOException("The local bridge connection token is invalid. Enable MCP in Revit again."); }
            if (request == null) throw new ArgumentNullException(nameof(request));
            McpLimits.ValidateRequest(request);
            // Do not modify the caller's request or retain its connection token in shared state.
            var wire = new McpWireRequest { Protocol = request.Protocol, Token = connection.Token, RequestId = request.RequestId, Tool = request.Tool, Arguments = request.Arguments };
            var bytes = McpWireCodec.Serialize(wire);
            if (bytes.Length > McpLimits.MaxRequestBytes) throw new IOException("The local bridge request exceeded its size limit.");
            token.ThrowIfCancellationRequested();
            using (var client = new TcpClient(AddressFamily.InterNetwork))
            using (var lifetime = CancellationTokenSource.CreateLinkedTokenSource(token))
            using (lifetime.Token.Register(() => McpTransportFrames.Close(client)))
            {
                lifetime.CancelAfter(McpTransportFrames.RequestTimeoutMilliseconds);
                try
                {
                    // No DNS, hostname, URL, external address, or configurable bind address is accepted.
                    using (var connecting = CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token))
                    using (connecting.Token.Register(() => McpTransportFrames.Close(client)))
                    {
                        connecting.CancelAfter(McpTransportFrames.NetworkTimeoutMilliseconds);
                        await client.ConnectAsync(IPAddress.Loopback, connection.Port).ConfigureAwait(false);
                    }
                    client.NoDelay = true;
                    var stream = client.GetStream();
                    await McpTransportFrames.WriteAsync(stream, bytes, McpLimits.MaxRequestBytes, lifetime.Token).ConfigureAwait(false);
                    var responseBytes = await McpTransportFrames.ReadAsync(stream, McpLimits.MaxResponseBytes, lifetime.Token).ConfigureAwait(false);
                    var response = McpWireCodec.Deserialize<McpWireResponse>(responseBytes);
                    if (response == null || response.Protocol != 1 || !string.Equals(response.RequestId, wire.RequestId, StringComparison.Ordinal))
                        throw new IOException("The local bridge returned an invalid protocol or request correlation.");
                    return response;
                }
                catch (Exception exception)
                {
                    token.ThrowIfCancellationRequested();
                    if (lifetime.IsCancellationRequested) throw new IOException("The local bridge request timed out. Check that Revit is available and try again.");
                    if (exception is IOException && exception.Message == "The local bridge returned an invalid protocol or request correlation.") throw;
                    throw new IOException("The local bridge connection failed or returned an invalid response. Check that MCP is enabled in Revit.");
                }
            }
        }
    }

    internal static class McpTransportSecurity
    {
        internal static byte[] DecodeToken(string token)
        {
            if (token == null || token.Length != 64) throw new ArgumentException("A 256-bit hexadecimal local bridge token is required.", nameof(token));
            var bytes = new byte[32];
            for (var i = 0; i < bytes.Length; i++)
            {
                var high = Hex(token[i * 2]);
                var low = Hex(token[i * 2 + 1]);
                if (high < 0 || low < 0) throw new ArgumentException("A 256-bit hexadecimal local bridge token is required.", nameof(token));
                bytes[i] = (byte)((high << 4) | low);
            }
            return bytes;
        }

        internal static bool Matches(byte[] expected, string candidate)
        {
            var validLength = candidate != null && candidate.Length == 64;
            var difference = validLength ? 0 : 1;
            for (var i = 0; i < 32; i++)
            {
                var high = validLength ? Hex(candidate[i * 2]) : -1;
                var low = validLength ? Hex(candidate[i * 2 + 1]) : -1;
                difference |= high >> 31;
                difference |= low >> 31;
                difference |= expected[i] ^ ((high << 4) | low);
            }
            return difference == 0;
        }

        private static int Hex(char value)
        {
            if (value >= '0' && value <= '9') return value - '0';
            if (value >= 'a' && value <= 'f') return value - 'a' + 10;
            if (value >= 'A' && value <= 'F') return value - 'A' + 10;
            return -1;
        }
    }

    internal static class McpTransportFrames
    {
        internal const int NetworkTimeoutMilliseconds = 5000;
        internal const int RequestTimeoutMilliseconds = 30000;

        internal static void Close(TcpClient client) { try { client.Dispose(); } catch (Exception) { } }

        internal static async Task<byte[]> ReadAsync(NetworkStream stream, int maximum, CancellationToken token)
        {
            var header = new byte[4];
            await ReadExactlyAsync(stream, header, token).ConfigureAwait(false);
            var count = ((uint)header[0] << 24) | ((uint)header[1] << 16) | ((uint)header[2] << 8) | header[3];
            if (count == 0 || count > maximum) throw new InvalidDataException("The local bridge frame exceeded its size limit.");
            var bytes = new byte[(int)count];
            await ReadExactlyAsync(stream, bytes, token).ConfigureAwait(false);
            return bytes;
        }

        private static async Task ReadExactlyAsync(NetworkStream stream, byte[] bytes, CancellationToken token)
        {
            var offset = 0;
            while (offset < bytes.Length)
            {
                token.ThrowIfCancellationRequested();
                var count = await stream.ReadAsync(bytes, offset, bytes.Length - offset, token).ConfigureAwait(false);
                if (count == 0) throw new EndOfStreamException("The local bridge frame was incomplete.");
                offset += count;
            }
        }

        internal static async Task WriteAsync(NetworkStream stream, byte[] bytes, int maximum, CancellationToken token)
        {
            if (bytes == null || bytes.Length == 0 || bytes.Length > maximum) throw new InvalidDataException("The local bridge frame exceeded its size limit.");
            var count = bytes.Length;
            var header = new[] { (byte)(count >> 24), (byte)(count >> 16), (byte)(count >> 8), (byte)count };
            await stream.WriteAsync(header, 0, header.Length, token).ConfigureAwait(false);
            await stream.WriteAsync(bytes, 0, bytes.Length, token).ConfigureAwait(false);
        }
    }
}
