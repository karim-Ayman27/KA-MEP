using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Xml;
using static PipeTakeoff.Core.XlsxExporter;

namespace PipeTakeoff.Core
{
    /// <summary>Exports the exact supplied clash rows and their current check evidence; does not check or filter models.</summary>
    public static class ClashXlsxExporter
    {
        private const string Ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        private const string DocumentRelNs = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        private const string PackageRelNs = "http://schemas.openxmlformats.org/package/2006/relationships";
        private const int HeaderRow = 5;
        private const int MaxRows = 1048576;
        private const int MaxCellCharacters = 32767;

        public static void Export(string path, ClashReport report, ClashExportOptions options = null)
        {
            if (string.IsNullOrWhiteSpace(path)) throw new ArgumentException("Choose an Excel file path.", nameof(path));
            Validate(report);
            options = options ?? new ClashExportOptions();
            string fullPath = Path.GetFullPath(path);
            if (!string.Equals(Path.GetExtension(fullPath), ".xlsx", StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("The export file must use the .xlsx extension.", nameof(path));
            string directory = Path.GetDirectoryName(fullPath);
            if (!Directory.Exists(directory)) throw new DirectoryNotFoundException("The export folder does not exist: " + directory);

            var tables = new[] { Summary(report), Clashes(report), Info(report, options) };
            string metadata = (string.IsNullOrWhiteSpace(options.ProjectTitle) ? report.Title : options.ProjectTitle) + "  |  " + options.Release + "  |  Exported " + Timestamp(options.ExportedAt);
            ValidateText(metadata);
            foreach (var table in tables)
            {
                if (table.Rows.Count > MaxRows - HeaderRow) throw new ArgumentException("The " + table.Name + " sheet exceeds Excel's row limit.");
                foreach (var row in table.Rows)
                    foreach (string value in row.OfType<string>()) ValidateText(value);
            }

            string temporary = Path.Combine(directory, "." + Path.GetFileName(fullPath) + "." + Guid.NewGuid().ToString("N") + ".tmp");
            try
            {
                using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                using (var archive = new ZipArchive(stream, ZipArchiveMode.Create))
                {
                    Package(archive, tables);
                    Styles(archive);
                    for (int i = 0; i < tables.Length; i++) Sheet(archive, i, tables[i], metadata);
                }
                if (File.Exists(fullPath)) File.Replace(temporary, fullPath, null);
                else File.Move(temporary, fullPath);
            }
            finally
            {
                try { if (File.Exists(temporary)) File.Delete(temporary); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }

        private static void Validate(ClashReport report)
        {
            if (report == null) throw new ArgumentNullException(nameof(report));
            if (report.Rows == null || report.Notes == null) throw new ArgumentException("Report rows and notes are required.", nameof(report));
            if (report.Rows.Count > MaxRows - HeaderRow) throw new ArgumentException("The clash report exceeds Excel's row limit.");
            var keys = new HashSet<string>(StringComparer.Ordinal);
            foreach (var row in report.Rows)
            {
                if (row == null || row.Element1 == null || row.Element2 == null || row.ExtraFields == null)
                    throw new ArgumentException("A clash row, element reference or source field collection is missing.");
                if (string.IsNullOrWhiteSpace(row.Key) || !keys.Add(row.Key))
                    throw new ArgumentException("Each exported clash must have a distinct, nonblank key.");
                if (!Enum.IsDefined(typeof(ClashState), row.State) || !Enum.IsDefined(typeof(ClashTestKind), row.TestKind))
                    throw new ArgumentException("A clash status or test kind is invalid.");
                ValidateReference(row.Element1); ValidateReference(row.Element2);
                if (row.State == ClashState.Solved && (!Resolved(row.Element1) || !Resolved(row.Element2) ||
                    !row.CheckedAt.HasValue || string.IsNullOrWhiteSpace(row.CheckBasis)))
                    throw new ArgumentException("A Solved clash requires both resolved model sources and elements, a check time and check basis. Missing or ambiguous models need review.");
            }
        }

        private static void ValidateReference(ClashElementReference reference)
        {
            if ((reference.ElementId.HasValue && reference.ElementId.Value <= 0) ||
                (reference.ResolvedElementId.HasValue && reference.ResolvedElementId.Value <= 0))
                throw new ArgumentException("Reported and resolved element IDs must be positive when present.");
        }

        private static bool Resolved(ClashElementReference reference)
        { return !string.IsNullOrWhiteSpace(reference.ResolvedSourceKey) && reference.ResolvedElementId.HasValue; }

        private static void ValidateText(string value)
        {
            // Never silently truncate provenance or check evidence at Excel's per-cell limit.
            if (value != null && value.Length > MaxCellCharacters)
                throw new ArgumentException("A clash report cell exceeds Excel's 32,767-character limit. Shorten the source field before exporting.");
        }

        private static ReportTable Summary(ClashReport report)
        {
            var table = new ReportTable("Summary", "CLASH REPORT SUMMARY", "Current results for the exported rows only. Imported report status is retained separately in Clashes.",
                new[] { "Status", "Count", "Meaning" }, new[] { 24, 16, 108 });
            table.Numeric.Add(1);
            table.Rows.Add(new object[] { "Total exported", report.Rows.Count, "Exact supplied rows; totals follow the current export filter." });
            var counts = ClashSummary.Count(report.Rows);
            foreach (ClashState state in Enum.GetValues(typeof(ClashState)))
            {
                table.Rows.Add(new object[] { state.ToString(), counts[state], Meaning(state) });
                table.States.Add(table.Rows.Count - 1, state);
            }
            return table;
        }

        private static string Meaning(ClashState state)
        {
            switch (state)
            {
                case ClashState.Solved: return "Checked: both elements resolved in the current model; supported geometry check found no remaining hard intersection. Read the check basis and timestamp.";
                case ClashState.Unsolved: return "Checked: a current hard intersection remains according to the recorded check basis.";
                case ClashState.NeedsReview: return "Inconclusive: missing/unloaded/ambiguous source, unsupported geometry or test criteria, or a check failure. Requires review; never counted as solved.";
                default: return "Not checked against the current model, or prior results were invalidated. Imported status does not establish a current result.";
            }
        }

        private static ReportTable Clashes(ClashReport report)
        {
            var table = new ReportTable("Clashes", "CLASH CHECK REGISTER", "Green = Solved | Red = Unsolved | Amber = NeedsReview | Gray = Unchecked. Names and source fields remain literal text.",
                new[] { "Name", "Test", "Current status", "Imported status", "Element 1 ID", "Element 1 category", "Element 1 name", "Element 1 model",
                    "Element 2 ID", "Element 2 category", "Element 2 name", "Element 2 model", "Check note", "Check basis", "Checked at", "Test kind",
                    "Distance (reported)", "Clash point (reported)", "Assigned to", "Comments", "Element 1 reported category", "Element 1 reported name", "Element 1 reported model",
                    "Element 2 reported category", "Element 2 reported name", "Element 2 reported model", "Element 1 reference audit", "Element 2 reference audit", "Source extra fields", "Clash key" },
                new[] { 34, 28, 20, 20, 24, 24, 32, 32, 24, 24, 32, 32, 62, 62, 30, 18, 24, 34, 26, 52, 26, 32, 36, 26, 32, 36, 72, 72, 72, 38 });
            foreach (var row in report.Rows)
            {
                table.States.Add(table.Rows.Count, row.State);
                table.Rows.Add(new object[] { row.Name, row.TestName, row.State.ToString(), row.ImportedStatus,
                    row.Element1.IdLabel, row.Element1.CategoryLabel, ElementName(row.Element1), ModelName(row.Element1),
                    row.Element2.IdLabel, row.Element2.CategoryLabel, ElementName(row.Element2), ModelName(row.Element2),
                    row.CheckNote, row.CheckBasis, row.CheckedAt.HasValue ? Timestamp(row.CheckedAt.Value) : "", row.TestKind.ToString(),
                    row.DistanceText, row.ClashPointText, row.AssignedTo, row.Description,
                    row.Element1.ReportedCategory, row.Element1.ReportedName, row.Element1.SourceHint,
                    row.Element2.ReportedCategory, row.Element2.ReportedName, row.Element2.SourceHint,
                    ReferenceAudit(row.Element1), ReferenceAudit(row.Element2), Json(row.ExtraFields.OrderBy(field => field.Key, StringComparer.Ordinal)), row.Key });
            }
            return table;
        }

        private static string ElementName(ClashElementReference reference)
        { return string.IsNullOrWhiteSpace(reference.ResolvedName) ? reference.ReportedName : reference.ResolvedName; }

        private static string ModelName(ClashElementReference reference)
        {
            if (!string.IsNullOrWhiteSpace(reference.ResolvedSourceName)) return reference.ResolvedSourceName;
            if (!string.IsNullOrWhiteSpace(reference.ResolvedSourceKey)) return reference.ResolvedSourceKey;
            return string.IsNullOrWhiteSpace(reference.SourceHint) ? "Unresolved source" : reference.SourceHint + " (reported; unresolved)";
        }

        private static string ReferenceAudit(ClashElementReference reference)
        {
            return Json(new[] {
                Field("ReportedElementId", Id(reference.ElementId)), Field("ReportedUniqueId", reference.UniqueId), Field("ReportedModel", reference.SourceHint),
                Field("ReportedCategory", reference.ReportedCategory), Field("ReportedName", reference.ReportedName), Field("SourceOverrideKey", reference.SourceOverrideKey),
                Field("ResolvedSourceKey", reference.ResolvedSourceKey), Field("ResolvedSourceName", reference.ResolvedSourceName), Field("ResolvedElementId", Id(reference.ResolvedElementId)),
                Field("ResolvedUniqueId", reference.ResolvedUniqueId), Field("ResolvedCategory", reference.ResolvedCategory), Field("ResolvedName", reference.ResolvedName),
                Field("ResolutionNote", reference.ResolutionNote), Field("RawText", reference.RawText) });
        }

        private static KeyValuePair<string, string> Field(string key, string value) { return new KeyValuePair<string, string>(key, value); }
        private static string Id(long? value) { return value.HasValue ? value.Value.ToString(CultureInfo.InvariantCulture) : ""; }
        private static string Timestamp(DateTime value) { return value.ToString("yyyy-MM-dd'T'HH:mm:ss.fffffffK", CultureInfo.InvariantCulture); }

        private static string Json(IEnumerable<KeyValuePair<string, string>> values)
        { return "{\n" + string.Join(",\n", values.Select(pair => "  " + Quote(pair.Key) + ": " + Quote(pair.Value))) + "\n}"; }

        private static string Quote(string value)
        {
            var result = new StringBuilder("\"");
            foreach (char character in value ?? "")
            {
                if (character == '\\' || character == '"') result.Append('\\').Append(character);
                else if (character < 32) result.Append("\\u").Append(((int)character).ToString("x4", CultureInfo.InvariantCulture));
                else result.Append(character);
            }
            return result.Append('"').ToString();
        }

        private static ReportTable Info(ClashReport report, ClashExportOptions options)
        {
            var table = new ReportTable("Info", "CLASH REPORT INFORMATION", "Provenance, scope and check limitations travel with this static workbook.", new[] { "Property", "Value" }, new[] { 34, 122 });
            AddInfo(table, "Project", options.ProjectTitle); AddInfo(table, "Report title", report.Title);
            AddInfo(table, "Source report path", report.SourcePath); AddInfo(table, "Source SHA-256", report.SourceSha256);
            AddInfo(table, "Source producer", report.Producer); AddInfo(table, "Imported at", Timestamp(report.ImportedAt));
            AddInfo(table, "Exported at", Timestamp(options.ExportedAt)); AddInfo(table, "Revit version", options.RevitVersion);
            AddInfo(table, "KA MEP release", options.Release); AddInfo(table, "Export filter", string.IsNullOrWhiteSpace(options.FilterDescription) ? "Not specified; all supplied rows are exported." : options.FilterDescription);
            AddInfo(table, "Exported clash rows", report.Rows.Count);
            AddInfo(table, "Scope", "Static export of exactly the supplied rows. Summary counts are computed from those rows only. The exporter does not rerun checks or certify that a saved result remains current after the recorded check time.");
            AddInfo(table, "Current vs imported status", "Current status is a separate model-check result. An imported Resolved, Approved or Closed status is preserved as source text and never automatically becomes Solved.");
            AddInfo(table, "Hard-clash criterion", "A supported hard-clash check resolves both elements and tests current solid geometry. An explicitly assumed hard test must be disclosed in Check basis. Read each row's basis for the applied tolerance and method; bounding-box overlap alone is not proof of a hard intersection.");
            AddInfo(table, "Clearance / duplicate tests", "Clearance, duplicate and unknown test criteria need review unless the supported check explicitly establishes the applicable criterion. A lack of hard intersection does not prove clearance compliance.");
            AddInfo(table, "Missing model or element", "A missing, unloaded, ambiguous, deleted or unresolvable source/element requires review. Absence cannot establish Solved; check the source assignment and resolution notes.");
            AddInfo(table, "Reported dimensions and coordinates", "Distance and clash point are source report text, with original units/format retained. They are not recalculated or converted by this exporter; missing units remain unspecified.");
            AddInfo(table, "Element identity", "Element ID columns preserve reported IDs as exact text. Category, name and model use resolved values where available; reported fields and reference audit retain original values, resolved IDs/unique IDs, source overrides and resolution notes. IDs are scoped to their source document/link instance.");
            AddInfo(table, "Source extra fields", "Unmapped source fields and reference audit are JSON text. They remain literal cell content, including formula-like values. Cell content exceeding Excel's limit is rejected rather than truncated.");
            AddInfo(table, "Time format", "ISO 8601, preserving available fractions and UTC/local offset; a timestamp without an offset was supplied with unspecified time zone.");
            AddInfo(table, "Status legend", "Solved = green; Unsolved = red; NeedsReview = amber; Unchecked = gray. Status labels and explanations are present for readers who do not distinguish these colors.");
            AddInfo(table, "Creator", "KA MEP | Karim Ayman | 01032638143");
            for (int i = 0; i < report.Notes.Count; i++) AddInfo(table, "Source note " + (i + 1).ToString(CultureInfo.InvariantCulture), report.Notes[i]);
            return table;
        }

        private static void AddInfo(ReportTable table, string label, object value) { table.Rows.Add(new[] { (object)label, value }); }

        private static void Package(ZipArchive archive, IList<ReportTable> tables)
        {
            AddXml(archive, "[Content_Types].xml", w =>
            {
                const string types = "http://schemas.openxmlformats.org/package/2006/content-types";
                w.WriteStartElement("Types", types);
                EmptyNs(w, "Default", types, "Extension", "rels", "ContentType", "application/vnd.openxmlformats-package.relationships+xml");
                EmptyNs(w, "Default", types, "Extension", "xml", "ContentType", "application/xml");
                EmptyNs(w, "Override", types, "PartName", "/xl/workbook.xml", "ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml");
                EmptyNs(w, "Override", types, "PartName", "/xl/styles.xml", "ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml");
                for (int i = 0; i < tables.Count; i++) EmptyNs(w, "Override", types, "PartName", "/xl/worksheets/sheet" + (i + 1) + ".xml", "ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml");
                w.WriteEndElement();
            });
            AddXml(archive, "_rels/.rels", w =>
            {
                w.WriteStartElement("Relationships", PackageRelNs);
                EmptyNs(w, "Relationship", PackageRelNs, "Id", "rId1", "Type", DocumentRelNs + "/officeDocument", "Target", "xl/workbook.xml"); w.WriteEndElement();
            });
            AddXml(archive, "xl/_rels/workbook.xml.rels", w =>
            {
                w.WriteStartElement("Relationships", PackageRelNs);
                for (int i = 0; i < tables.Count; i++) EmptyNs(w, "Relationship", PackageRelNs, "Id", "rId" + (i + 1), "Type", DocumentRelNs + "/worksheet", "Target", "worksheets/sheet" + (i + 1) + ".xml");
                EmptyNs(w, "Relationship", PackageRelNs, "Id", "rId" + (tables.Count + 1), "Type", DocumentRelNs + "/styles", "Target", "styles.xml"); w.WriteEndElement();
            });
            AddXml(archive, "xl/workbook.xml", w =>
            {
                w.WriteStartElement("workbook", Ns); w.WriteAttributeString("xmlns", "r", null, DocumentRelNs);
                Start(w, "bookViews"); EmptyElement(w, "workbookView", "activeTab", "0"); w.WriteEndElement();
                Start(w, "sheets");
                for (int i = 0; i < tables.Count; i++)
                { Start(w, "sheet", "name", tables[i].Name, "sheetId", (i + 1).ToString(CultureInfo.InvariantCulture)); w.WriteAttributeString("r", "id", DocumentRelNs, "rId" + (i + 1)); w.WriteEndElement(); }
                w.WriteEndElement(); Start(w, "definedNames");
                for (int i = 0; i < tables.Count; i++)
                {
                    Start(w, "definedName", "name", "_xlnm.Print_Titles", "localSheetId", i.ToString(CultureInfo.InvariantCulture)); w.WriteString("'" + tables[i].Name + "'!$1:$5"); w.WriteEndElement();
                    Start(w, "definedName", "name", "_xlnm.Print_Area", "localSheetId", i.ToString(CultureInfo.InvariantCulture));
                    w.WriteString("'" + tables[i].Name + "'!$A$1:$" + Column(tables[i].Headers.Length) + "$" + (tables[i].Rows.Count + HeaderRow).ToString(CultureInfo.InvariantCulture)); w.WriteEndElement();
                }
                w.WriteEndElement(); w.WriteEndElement();
            });
        }

        private static void Sheet(ZipArchive archive, int index, ReportTable table, string metadata)
        {
            AddXml(archive, "xl/worksheets/sheet" + (index + 1) + ".xml", w =>
            {
                int last = table.Rows.Count + HeaderRow; string lastColumn = Column(table.Headers.Length);
                w.WriteStartElement("worksheet", Ns);
                Start(w, "sheetPr"); EmptyElement(w, "tabColor", "rgb", table.Name == "Summary" ? "FF007F78" : table.Name == "Info" ? "FF8395A1" : "FF142D42"); EmptyElement(w, "pageSetUpPr", "fitToPage", "1"); w.WriteEndElement();
                EmptyElement(w, "dimension", "ref", "A1:" + lastColumn + last);
                Start(w, "sheetViews"); Start(w, "sheetView", "workbookViewId", "0", "showGridLines", "0", "tabSelected", index == 0 ? "1" : "0");
                EmptyElement(w, "pane", "xSplit", "1", "ySplit", "5", "topLeftCell", "B6", "activePane", "bottomRight", "state", "frozen");
                EmptyElement(w, "selection", "pane", "topRight", "activeCell", "B1", "sqref", "B1"); EmptyElement(w, "selection", "pane", "bottomLeft", "activeCell", "A6", "sqref", "A6"); EmptyElement(w, "selection", "pane", "bottomRight", "activeCell", "B6", "sqref", "B6"); w.WriteEndElement(); w.WriteEndElement();
                EmptyElement(w, "sheetFormatPr", "defaultRowHeight", "30"); Start(w, "cols");
                for (int i = 0; i < table.Widths.Length; i++) EmptyElement(w, "col", "min", (i + 1).ToString(CultureInfo.InvariantCulture), "max", (i + 1).ToString(CultureInfo.InvariantCulture), "width", table.Widths[i].ToString(CultureInfo.InvariantCulture), "customWidth", "1");
                w.WriteEndElement(); Start(w, "sheetData");
                Banner(w, 1, "KA MEP  |  " + table.Title, 22, 38);
                Banner(w, 2, metadata, 12, 32);
                Banner(w, 3, table.Subtitle, 0, 36);
                Start(w, "row", "r", "5", "ht", "44", "customHeight", "1");
                for (int i = 0; i < table.Headers.Length; i++) WriteCell(w, HeaderRow, i + 1, table.Headers[i], false, 1);
                w.WriteEndElement();
                for (int i = 0; i < table.Rows.Count; i++)
                {
                    int rowNumber = i + HeaderRow + 1; object[] values = table.Rows[i];
                    // Audit JSON remains available in the formula bar without forcing every register row to a full page.
                    int visibleColumns = table.Name == "Clashes" ? 20 : values.Length;
                    int lines = values.Take(visibleColumns).Select((value, column) => Lines(Convert.ToString(value, CultureInfo.InvariantCulture), table.Widths[column] - 4)).Max();
                    Start(w, "row", "r", rowNumber.ToString(CultureInfo.InvariantCulture), "ht", Math.Min(180, Math.Max(34, lines * 15 + 10)).ToString(CultureInfo.InvariantCulture), "customHeight", "1");
                    for (int column = 0; column < values.Length; column++)
                    {
                        bool numeric = table.Numeric.Contains(column) || (table.Name == "Info" && column == 1 && values[column] is int);
                        int style = numeric ? 3 : 0;
                        if (table.Name == "Summary" && i == 0) style = numeric ? 6 : 4;
                        else if (table.Name == "Summary" && column < 2) style = (numeric ? 18 : 14) + (int)table.States[i];
                        else if (table.Name == "Clashes" && column == 2) style = 14 + (int)table.States[i];
                        else if (table.Name == "Info" && column == 0) style = 12;
                        WriteCell(w, rowNumber, column + 1, values[column], numeric, style);
                    }
                    w.WriteEndElement();
                }
                w.WriteEndElement();
                EmptyElement(w, "autoFilter", "ref", "A5:" + lastColumn + last);
                Start(w, "mergeCells", "count", "3"); for (int i = 1; i <= 3; i++) EmptyElement(w, "mergeCell", "ref", "A" + i + ":" + lastColumn + i); w.WriteEndElement();
                EmptyElement(w, "printOptions", "horizontalCentered", "1", "gridLines", "0");
                EmptyElement(w, "pageMargins", "left", "0.25", "right", "0.25", "top", "0.55", "bottom", "0.55", "header", "0.22", "footer", "0.22");
                EmptyElement(w, "pageSetup", "paperSize", table.Name == "Clashes" ? "8" : "9", "orientation", "landscape", "fitToWidth", table.Name == "Clashes" ? "3" : "1", "fitToHeight", "0");
                Start(w, "headerFooter"); w.WriteElementString("oddHeader", Ns, "&L&\"Calibri,Bold\"&11&K142D42KA MEP&C&\"Calibri,Regular\"&10Clash Check Report&R&A");
                w.WriteElementString("oddFooter", Ns, "&L&\"Calibri,Regular\"&9&K687F8CKarim Ayman&CPage &P of &N&R&D"); w.WriteEndElement(); w.WriteEndElement();
            });
        }

        private static void Styles(ZipArchive archive)
        {
            AddXml(archive, "xl/styles.xml", w =>
            {
                w.WriteStartElement("styleSheet", Ns);
                Start(w, "numFmts", "count", "2"); EmptyElement(w, "numFmt", "numFmtId", "164", "formatCode", "#,##0.000"); EmptyElement(w, "numFmt", "numFmtId", "165", "formatCode", "0.######"); w.WriteEndElement();
                Start(w, "fonts", "count", "8");
                Font(w, false, "FF243C4B", 11); Font(w, true, "FFFFFFFF", 11); Font(w, true, "FF142D42", 11);
                Font(w, true, "FF465766", 11); Font(w, true, "FF912C2C", 11); Font(w, true, "FF22603B", 11); Font(w, true, "FF805600", 11); Font(w, true, "FFFFFFFF", 18); w.WriteEndElement();
                Start(w, "fills", "count", "9"); Fill(w, "none", null); Fill(w, "gray125", null);
                foreach (string color in new[] { "FF142D42", "FF007F78", "FFF0F6F8", "FFE8EDF1", "FFFDE5E5", "FFDFF1E4", "FFFFF0CC" }) Fill(w, "solid", color); w.WriteEndElement();
                Start(w, "borders", "count", "2");
                Start(w, "border"); foreach (string side in new[] { "left", "right", "top", "bottom", "diagonal" }) EmptyElement(w, side); w.WriteEndElement();
                Start(w, "border"); foreach (string side in new[] { "left", "right", "top" }) EmptyElement(w, side);
                Start(w, "bottom", "style", "hair"); EmptyElement(w, "color", "rgb", "FFD7E3E8"); w.WriteEndElement(); EmptyElement(w, "diagonal"); w.WriteEndElement(); w.WriteEndElement();
                Start(w, "cellStyleXfs", "count", "1"); EmptyElement(w, "xf", "numFmtId", "0", "fontId", "0", "fillId", "0", "borderId", "0"); w.WriteEndElement();
                Start(w, "cellXfs", "count", "23");
                // Keep styles 0..13 compatible with the shared literal-string cell writer and its row banding.
                Xf(w, 0, 0, 0); Xf(w, 0, 1, 2); Xf(w, 164, 0, 0); Xf(w, 1, 0, 0);
                Xf(w, 0, 1, 3); Xf(w, 164, 1, 3); Xf(w, 1, 1, 3); Xf(w, 165, 0, 0);
                Xf(w, 0, 0, 4); Xf(w, 164, 0, 4); Xf(w, 1, 0, 4); Xf(w, 165, 0, 4); Xf(w, 0, 2, 0); Xf(w, 0, 2, 4);
                for (int i = 0; i < 4; i++) Xf(w, 0, 3 + i, 5 + i);
                for (int i = 0; i < 4; i++) Xf(w, 1, 3 + i, 5 + i);
                Xf(w, 0, 7, 2); w.WriteEndElement();
                Start(w, "cellStyles", "count", "1"); EmptyElement(w, "cellStyle", "name", "Normal", "xfId", "0", "builtinId", "0"); w.WriteEndElement(); w.WriteEndElement();
            });
        }

        private static void Font(XmlWriter w, bool bold, string color, int size)
        { Start(w, "font"); if (bold) EmptyElement(w, "b"); EmptyElement(w, "sz", "val", size.ToString(CultureInfo.InvariantCulture)); EmptyElement(w, "color", "rgb", color); EmptyElement(w, "name", "val", "Calibri"); w.WriteEndElement(); }
        private static void Fill(XmlWriter w, string pattern, string color)
        { Start(w, "fill"); Start(w, "patternFill", "patternType", pattern); if (color != null) { EmptyElement(w, "fgColor", "rgb", color); EmptyElement(w, "bgColor", "indexed", "64"); } w.WriteEndElement(); w.WriteEndElement(); }
        private static void Xf(XmlWriter w, int format, int font, int fill)
        {
            Start(w, "xf", "numFmtId", format.ToString(CultureInfo.InvariantCulture), "fontId", font.ToString(CultureInfo.InvariantCulture), "fillId", fill.ToString(CultureInfo.InvariantCulture),
                "borderId", "1", "xfId", "0", "applyNumberFormat", "1", "applyFont", "1", "applyFill", "1", "applyBorder", "1", "applyAlignment", "1");
            EmptyElement(w, "alignment", "vertical", "center", "horizontal", format == 0 ? "left" : "right", "wrapText", "1", "indent", "1"); w.WriteEndElement();
        }
        private static void Banner(XmlWriter w, int row, string text, int style, int height)
        { Start(w, "row", "r", row.ToString(CultureInfo.InvariantCulture), "ht", height.ToString(CultureInfo.InvariantCulture), "customHeight", "1"); WriteCell(w, row, 1, text, false, style); w.WriteEndElement(); }
        private static int Lines(string value, int width) { return (value ?? "").Split('\n').Sum(line => Math.Max(1, (line.Length + width - 1) / width)); }
        private static void EmptyElement(XmlWriter w, string name, params string[] attributes) { Start(w, name, attributes); w.WriteEndElement(); }
        private static void EmptyNs(XmlWriter w, string name, string ns, params string[] attributes)
        { w.WriteStartElement(name, ns); for (int i = 0; i < attributes.Length; i += 2) w.WriteAttributeString(attributes[i], attributes[i + 1]); w.WriteEndElement(); }
        private static string Column(int count) { string result = ""; while (count > 0) { count--; result = (char)('A' + count % 26) + result; count /= 26; } return result; }

        private sealed class ReportTable
        {
            internal ReportTable(string name, string title, string subtitle, string[] headers, int[] widths)
            { Name = name; Title = title; Subtitle = subtitle; Headers = headers; Widths = widths; }
            internal string Name, Title, Subtitle;
            internal string[] Headers;
            internal int[] Widths;
            internal HashSet<int> Numeric = new HashSet<int>();
            internal Dictionary<int, ClashState> States = new Dictionary<int, ClashState>();
            internal List<object[]> Rows = new List<object[]>();
        }
    }
}
