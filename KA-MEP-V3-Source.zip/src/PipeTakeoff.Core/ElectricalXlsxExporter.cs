using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using static PipeTakeoff.Core.XlsxExporter;

namespace PipeTakeoff.Core
{
    /// <summary>Native Excel takeoff with separate cable-tray and conduit quantities, fitting counts, and export metadata.</summary>
    public static class ElectricalXlsxExporter
    {
        private const int MaxRows = 1048576;

        public static void Export(string path, IList<PipeRecord> filteredRecords, TakeoffOptions options, ExportMetadata metadata)
        {
            if (string.IsNullOrWhiteSpace(path)) throw new ArgumentException("Choose an Excel file path.", nameof(path));
            if (filteredRecords == null) throw new ArgumentNullException(nameof(filteredRecords));
            TakeoffEngine.ValidateFilters(options);
            ValidateColumns(options.Columns);
            if (filteredRecords.Count > MaxRows - 2) throw new ArgumentException("The detail sheet exceeds Excel's row limit. Apply a filter and export again.", nameof(filteredRecords));
            List<ElectricalSummaryRow> summary = ElectricalTakeoffEngine.Summarize(filteredRecords, options);
            if (summary.Count > MaxRows - 2) throw new ArgumentException("The summary sheet exceeds Excel's row limit.", nameof(filteredRecords));
            double trayLength = summary.Where(row => row.Category == "Cable Tray").Sum(row => row.TotalLengthMeters);
            double conduitLength = summary.Where(row => row.Category == "Conduit").Sum(row => row.TotalLengthMeters);
            double totalLength = trayLength + conduitLength;
            if (!TakeoffEngine.IsFinite(totalLength)) throw new ArgumentException("An electrical takeoff total is outside the supported numeric range.", nameof(filteredRecords));
            var info = CreateInfo(filteredRecords, summary, options, metadata ?? new ExportMetadata(), trayLength, conduitLength);
            if (info.Count > MaxRows - 1) throw new ArgumentException("The information sheet exceeds Excel's row limit.", nameof(options));
            string fullPath = Path.GetFullPath(path);
            if (!string.Equals(Path.GetExtension(fullPath), ".xlsx", StringComparison.OrdinalIgnoreCase)) throw new ArgumentException("The export file must use the .xlsx extension.", nameof(path));
            string directory = Path.GetDirectoryName(fullPath);
            if (!Directory.Exists(directory)) throw new DirectoryNotFoundException("The export folder does not exist: " + directory);
            string temporary = Path.Combine(directory, "." + Path.GetFileName(fullPath) + "." + Guid.NewGuid().ToString("N") + ".tmp");
            try
            {
                using (var file = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                using (var archive = new ZipArchive(file, ZipArchiveMode.Create))
                {
                    int summaryColumns = 7 + (options.GroupBySystem ? 1 : 0) + (options.GroupByFamily ? 1 : 0) + (options.GroupByType ? 1 : 0);
                    WriteContentTypes(archive); WriteRelationships(archive);
                    WriteWorkbook(archive, new[] { options.Columns.Count, summaryColumns, 2 }, new[] { filteredRecords.Count + 2, summary.Count + 2, info.Count + 1 });
                    WriteStyles(archive);
                    WriteDetails(archive, filteredRecords, options.Columns, totalLength);
                    WriteSummary(archive, summary, options, filteredRecords.Count, trayLength, conduitLength);
                    WriteInfo(archive, info);
                }
                if (File.Exists(fullPath)) File.Replace(temporary, fullPath, null);
                else File.Move(temporary, fullPath);
            }
            finally
            {
                try { if (File.Exists(temporary)) File.Delete(temporary); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }

        private static void WriteDetails(ZipArchive archive, IList<PipeRecord> records, IList<FieldDefinition> columns, double totalLength)
        {
            AddXml(archive, "xl/worksheets/sheet1.xml", w =>
            {
                var headers = columns.Select(field => field.Header).ToList();
                BeginSheet(w, columns.Count, records.Count + 2, headers); Header(w, headers);
                for (int i = 0; i < records.Count; i++)
                {
                    int row = i + 2;
                    Start(w, "row", "r", row.ToString(CultureInfo.InvariantCulture));
                    for (int c = 0; c < columns.Count; c++)
                    {
                        FieldDefinition field = columns[c];
                        object value = field.Key == "Length" && !ElectricalTakeoffEngine.IsStraight(TakeoffEngine.Text(records[i].Get("Category"))) ? null : records[i].Get(field.Key);
                        WriteCell(w, row, c + 1, value, field.IsNumeric, field.IsNumeric ? (field.Key == "Length" ? 2 : 7) : 0);
                    }
                    w.WriteEndElement();
                }
                int totalRow = records.Count + 2;
                Start(w, "row", "r", totalRow.ToString(CultureInfo.InvariantCulture), "ht", "34", "customHeight", "1");
                bool labelWritten = false;
                for (int c = 0; c < columns.Count; c++)
                {
                    if (columns[c].Key == "Length") WriteCell(w, totalRow, c + 1, totalLength, true, 5);
                    else if (!labelWritten) { WriteCell(w, totalRow, c + 1, "TOTAL — STRAIGHT SEGMENTS", false, 4); labelWritten = true; }
                    else WriteCell(w, totalRow, c + 1, null, false, 4);
                }
                w.WriteEndElement(); EndSheet(w, columns.Count, records.Count + 1);
            });
        }

        private static void WriteSummary(ZipArchive archive, IList<ElectricalSummaryRow> rows, TakeoffOptions options, int count, double trayLength, double conduitLength)
        {
            var headers = new List<string> { "Category", "Section / connectors (mm)", "Fitting Kind", "Angle (degrees)" };
            if (options.GroupBySystem) headers.Add("Service Type");
            if (options.GroupByFamily) headers.Add("Family");
            if (options.GroupByType) headers.Add("Type");
            headers.AddRange(new[] { "Element Count", "Cable Tray Length (m)", "Conduit Length (m)" });
            AddXml(archive, "xl/worksheets/sheet2.xml", w =>
            {
                BeginSheet(w, headers.Count, rows.Count + 2, headers, "Summary"); Header(w, headers);
                for (int i = 0; i < rows.Count; i++)
                {
                    ElectricalSummaryRow item = rows[i]; int row = i + 2; int column = 1;
                    Start(w, "row", "r", row.ToString(CultureInfo.InvariantCulture));
                    WriteCell(w, row, column++, item.Category, false, 0);
                    WriteCell(w, row, column++, item.Size, false, 0);
                    WriteCell(w, row, column++, item.FittingKind, false, 0);
                    WriteCell(w, row, column++, item.AngleDegrees.HasValue ? (object)item.AngleDegrees.Value : null, true, 7);
                    if (options.GroupBySystem) WriteCell(w, row, column++, item.SystemName, false, 0);
                    if (options.GroupByFamily) WriteCell(w, row, column++, item.Family, false, 0);
                    if (options.GroupByType) WriteCell(w, row, column++, item.Type, false, 0);
                    WriteCell(w, row, column++, item.Count, true, 3);
                    WriteCell(w, row, column++, item.Category == "Cable Tray" ? (object)item.TotalLengthMeters : null, true, 2);
                    WriteCell(w, row, column, item.Category == "Conduit" ? (object)item.TotalLengthMeters : null, true, 2);
                    w.WriteEndElement();
                }
                int totalRow = rows.Count + 2;
                Start(w, "row", "r", totalRow.ToString(CultureInfo.InvariantCulture), "ht", "34", "customHeight", "1");
                WriteCell(w, totalRow, 1, "TOTAL", false, 4);
                for (int column = 2; column <= headers.Count - 3; column++) WriteCell(w, totalRow, column, null, false, 4);
                WriteCell(w, totalRow, headers.Count - 2, count, true, 6);
                WriteCell(w, totalRow, headers.Count - 1, trayLength, true, 5);
                WriteCell(w, totalRow, headers.Count, conduitLength, true, 5);
                w.WriteEndElement(); EndSheet(w, headers.Count, rows.Count + 1);
            });
        }

        private static List<KeyValuePair<string, object>> CreateInfo(IList<PipeRecord> records, IList<ElectricalSummaryRow> summary,
            TakeoffOptions options, ExportMetadata metadata, double trayLength, double conduitLength)
        {
            var info = new List<KeyValuePair<string, object>>();
            Action<string, object> add = (key, value) => info.Add(new KeyValuePair<string, object>(key, value));
            add("Project", metadata.Project); add("Application", ReportBranding.VersionLabel + " — Electrical Takeoff");
            add("Revit version", metadata.RevitVersion); add("Scope", metadata.Scope);
            add("Exported at (workstation local time)", metadata.ExportedAt.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
            add("Exported element count", records.Count);
            add("Cable tray segment count", summary.Where(row => row.Category == "Cable Tray").Sum(row => row.Count));
            add("Cable tray fitting count", summary.Where(row => row.Category == "Cable Tray Fitting").Sum(row => row.Count));
            add("Conduit segment count", summary.Where(row => row.Category == "Conduit").Sum(row => row.Count));
            add("Conduit fitting count", summary.Where(row => row.Category == "Conduit Fitting").Sum(row => row.Count));
            add("Total cable tray straight length (m)", trayLength); add("Total conduit straight length (m)", conduitLength);
            add("Summary group count", summary.Count);
            var grouping = new List<string> { "Category", "Canonical connector section key", "Fitting kind", "Angle rounded to 6 decimal degrees (missing is distinct)" };
            if (options.GroupBySystem) grouping.Add("Service Type");
            if (options.GroupByFamily) grouping.Add("Family");
            if (options.GroupByType) grouping.Add("Type");
            add("Summary grouping", string.Join(" + ", grouping));
            add("Dimensions", "Millimeters (mm). Canonical dimensions identify sections; every fitting connector and its size contributes to the key, including repeated connector sizes. Formatted Size is display text only. Unresolved sections use an element-specific key and are not merged.");
            add("Length", "Meters (m), straight cable tray and conduit segments only. Fitting lengths stay blank; fittings are counted. No connector-to-connector estimate or zero substitute is used for missing straight lengths.");
            add("Service Type", "The Revit cable tray/conduit Service Type parameter. A blank value means the model does not provide it; no piping system is inferred.");
            add("Quantity scope", "Model quantities only; no allowance is added for waste, couplings, supports, cable fill, insulation, fabrication, or procurement. Only the included categories and scope are exported.");
            add("Precision", "Numeric values retain measurement precision. Lengths display three decimals; display rounding does not change totals.");
            add("Additional numeric parameters", "Values use Revit project units; column headers identify units where available.");
            add("Filter matching", options.Match == FilterMatch.All ? "All rules (AND)" : "Any rule (OR)");
            add("Filter comparison", "Text ignores case. Missing values match IsEmpty and fail value comparisons. Numeric equality tolerates conversion roundoff (max(1e-9, magnitude * 1e-12)).");
            add("Totals", "Totals include all exported records. Excel AutoFilter does not recalculate these static totals. Cable tray and conduit lengths remain separate in Summary and Info.");
            add("Text handling", "Text is stored as text, never formulas, limited to 32767 characters; invalid XML characters are replaced with U+FFFD.");
            add("Addin creator", "Karim Ayman"); add("Tel", "01032638143");
            add("LinkedIn", "karimayman27"); add("Email", "mech.karim.ayman@gmail.com");
            if (options.Filters.Count == 0) add("Filters", "None");
            else for (int i = 0; i < options.Filters.Count; i++)
            {
                FilterRule rule = options.Filters[i];
                add("Filter " + (i + 1), rule.Field.Header + " " + rule.Operator + " " + (rule.Value ?? ""));
            }
            return info;
        }
    }
}
