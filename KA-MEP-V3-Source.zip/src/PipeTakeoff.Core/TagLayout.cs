using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace PipeTakeoff.Core
{
    public enum TagLayoutPattern { HorizontalRow, VerticalColumn, TwoColumns, StaggeredRows, DiagonalRow, NearHost }
    public enum TagLayoutSide { Positive, Negative }

    /// <summary>A point in the active view plane. The caller owns the unit conversion.</summary>
    public struct TagPoint
    {
        public TagPoint(double x, double y) { X = x; Y = y; }
        public double X { get; }
        public double Y { get; }
    }

    /// <summary>Axis-aligned predicted text bounds; touching edges do not intersect.</summary>
    public struct TagRectangle
    {
        public TagRectangle(double left, double bottom, double right, double top)
        { Left = left; Bottom = bottom; Right = right; Top = top; }
        public double Left { get; }
        public double Bottom { get; }
        public double Right { get; }
        public double Top { get; }
        public double Width { get { return Right - Left; } }
        public double Height { get { return Top - Bottom; } }
        public bool Intersects(TagRectangle other)
        { return Left < other.Right && Right > other.Left && Bottom < other.Top && Top > other.Bottom; }
    }

    public sealed class TagLayoutItem
    {
        public TagLayoutItem(string key, TagPoint anchor, double width, double height)
        { Key = key; Anchor = anchor; Width = width; Height = height; }
        public string Key { get; }
        public TagPoint Anchor { get; }
        public double Width { get; }
        public double Height { get; }
        /// <summary>Optional projected host footprint. NearHost keeps labels outside every supplied host footprint.</summary>
        public TagRectangle? HostBounds { get; set; }
    }

    public sealed class TagLayoutOptions
    {
        public TagLayoutPattern Pattern { get; set; } = TagLayoutPattern.VerticalColumn;
        public TagLayoutSide Side { get; set; } = TagLayoutSide.Positive;
        public double Spacing { get; set; } = 1;
        public double Offset { get; set; } = 1;
        public double Shoulder { get; set; } = 1;
        /// <summary>Replace only leader elbows with view-axis right angles; never rearrange tag heads.</summary>
        public bool OrthogonalLeaders { get; set; }
        public double AngleDegrees { get; set; } = 45;
        public int Columns { get; set; } = 3;
        /// <summary>Optional pattern center. When supplied, replaces automatic placement outside source anchors.</summary>
        public TagPoint? Origin { get; set; }
        /// <summary>NearHost only: maximum anchor-to-label-center distance in caller units.</summary>
        public double MaximumDistance { get; set; } = 20;
        /// <summary>NearHost only: permitted annotation area for text bounds and leader shoulders.</summary>
        public TagRectangle? AllowedBounds { get; set; }
    }

    public sealed class TagPlacement
    {
        internal TagPlacement(TagLayoutItem item, TagPoint head, TagPoint elbow, int bank)
        {
            Key = item.Key; Anchor = item.Anchor; Head = head; Elbow = elbow; Bank = bank;
            Bounds = new TagRectangle(head.X - item.Width / 2, head.Y - item.Height / 2,
                head.X + item.Width / 2, head.Y + item.Height / 2);
        }
        public string Key { get; }
        public TagPoint Anchor { get; }
        public TagPoint Head { get; }
        public TagPoint Elbow { get; }
        public TagRectangle Bounds { get; }
        /// <summary>-1 for the negative-side bank, +1 for the positive-side bank.</summary>
        public int Bank { get; }
    }

    public sealed class TagLayoutResult
    {
        internal TagLayoutResult(List<TagPlacement> placements, List<string> warnings, List<string> skippedKeys = null)
        { Placements = placements.AsReadOnly(); Warnings = warnings.AsReadOnly(); SkippedKeys = (skippedKeys ?? new List<string>()).AsReadOnly(); }
        public IReadOnlyList<TagPlacement> Placements { get; }
        public IReadOnlyList<string> Warnings { get; }
        /// <summary>NearHost candidates with no safe bounded placement; the caller must not create or move these tags.</summary>
        public IReadOnlyList<string> SkippedKeys { get; }
    }

    /// <summary>
    /// Deterministic view-plane layout. Text rectangles, not arbitrary Revit geometry, are kept apart.
    /// The leader shoulder is parallel and equal in length within each bank; the anchor-to-elbow
    /// segments may cross. Obstacle intersections are reported and never silently rearrange a pattern.
    /// </summary>
    public static class TagLayoutEngine
    {
        public const int MaximumItems = 10000;
        public const int MaximumObstacles = 5000;
        public const double MaximumCoordinate = 1e12;
        private const double MachineEpsilon = 2.2204460492503131e-16;

        public static TagLayoutResult Arrange(IEnumerable<TagLayoutItem> items, TagLayoutOptions options,
            IEnumerable<TagRectangle> obstacles = null)
        {
            if (items == null) throw new ArgumentNullException(nameof(items));
            if (options == null) throw new ArgumentNullException(nameof(options));
            ValidateOptions(options);
            var source = items.Take(MaximumItems + 1).ToList();
            if (source.Count > MaximumItems) throw new ArgumentException("At most 10,000 tags can be arranged in one operation.", nameof(items));
            var keys = new HashSet<string>(StringComparer.Ordinal);
            foreach (var item in source)
            {
                if (item == null) throw new ArgumentException("A tag item cannot be null.", nameof(items));
                if (string.IsNullOrWhiteSpace(item.Key) || !keys.Add(item.Key))
                    throw new ArgumentException("Each tag requires a nonempty, unique key.", nameof(items));
                ValidatePoint(item.Anchor, "Anchor");
                ValidateDistance(item.Width, "Width", false);
                ValidateDistance(item.Height, "Height", false);
                if (item.HostBounds.HasValue) ValidateRectangle(item.HostBounds.Value, "Host bounds");
            }
            var obstacleList = obstacles == null ? new List<TagRectangle>() : obstacles.Take(MaximumObstacles + 1).ToList();
            if (obstacleList.Count > MaximumObstacles) throw new ArgumentException("At most 5,000 obstacle rectangles can be checked in one operation.", nameof(obstacles));
            foreach (var obstacle in obstacleList) ValidateRectangle(obstacle, "Obstacle");
            var placements = new List<TagPlacement>();
            var warnings = new List<string>();
            if (source.Count == 0) return new TagLayoutResult(placements, warnings);
            if (options.Pattern == TagLayoutPattern.NearHost) return WithLeaderStyle(ArrangeNearHost(source, options, obstacleList), source, options);

            double minX = source.Min(x => x.Anchor.X), maxX = source.Max(x => x.Anchor.X);
            double minY = source.Min(x => x.Anchor.Y), maxY = source.Max(x => x.Anchor.Y);
            double midX = Midpoint(minX, maxX), midY = Midpoint(minY, maxY);
            // A few ULPs of padding keep even zero-gap layouts disjoint after adding a large origin.
            double magnitude = Math.Max(1, Math.Max(Math.Max(Math.Abs(minX), Math.Abs(maxX)), Math.Max(Math.Abs(minY), Math.Abs(maxY))));
            if (options.Origin.HasValue) magnitude = Math.Max(magnitude, Math.Max(Math.Abs(options.Origin.Value.X), Math.Abs(options.Origin.Value.Y)));
            magnitude = Math.Max(magnitude, source.Max(x => Math.Max(x.Width, x.Height)) * source.Count + options.Offset + options.Shoulder);
            double gap = options.Spacing + magnitude * MachineEpsilon * 32;
            int side = options.Side == TagLayoutSide.Positive ? 1 : -1;

            switch (options.Pattern)
            {
                case TagLayoutPattern.HorizontalRow:
                {
                    var ordered = OrderX(source);
                    double height = source.Max(x => x.Height);
                    var center = options.Origin ?? new TagPoint(midX, side > 0 ? maxY + options.Offset + height / 2 : minY - options.Offset - height / 2);
                    AddLine(placements, ordered, new TagPoint(1, 0), center, gap, new TagPoint(0, -side * options.Shoulder), side);
                    break;
                }
                case TagLayoutPattern.VerticalColumn:
                {
                    double width = source.Max(x => x.Width);
                    var center = options.Origin ?? new TagPoint(side > 0 ? maxX + options.Offset + width / 2 : minX - options.Offset - width / 2, midY);
                    AddLine(placements, OrderY(source), new TagPoint(0, -1), center, gap, new TagPoint(-side * options.Shoulder, 0), side);
                    break;
                }
                case TagLayoutPattern.TwoColumns:
                {
                    var ordered = OrderX(source);
                    int leftCount = source.Count == 1 && side > 0 ? 0 : (source.Count + 1) / 2;
                    var left = ordered.Take(leftCount).ToList();
                    var right = ordered.Skip(leftCount).ToList();
                    AddColumnBank(placements, left, -1, options, gap, minX, maxX, midY);
                    AddColumnBank(placements, right, 1, options, gap, minX, maxX, midY);
                    break;
                }
                case TagLayoutPattern.StaggeredRows:
                {
                    var ordered = OrderY(source);
                    int columns = Math.Min(options.Columns, source.Count);
                    double pitchX = source.Max(x => x.Width) + gap, pitchY = source.Max(x => x.Height) + gap;
                    var points = new List<TagPoint>();
                    for (int i = 0; i < source.Count; i++)
                    {
                        int row = i / columns, column = i % columns;
                        // One-column grids remain a straight column.
                        double stagger = columns > 1 && row % 2 == 1 ? pitchX / 2 : 0;
                        points.Add(new TagPoint(column * pitchX + stagger, -row * pitchY));
                    }
                    var extent = Extents(ordered, points);
                    double height = extent.Height;
                    var center = options.Origin ?? new TagPoint(midX, side > 0 ? maxY + options.Offset + height / 2 : minY - options.Offset - height / 2);
                    AddCentered(placements, ordered, points, extent, center, new TagPoint(0, -side * options.Shoulder), side);
                    break;
                }
                case TagLayoutPattern.DiagonalRow:
                {
                    double angle = options.AngleDegrees * Math.PI / 180;
                    var direction = new TagPoint(Math.Cos(angle), Math.Sin(angle));
                    var normal = new TagPoint(-direction.Y, direction.X);
                    var ordered = source.OrderBy(x => Dot(x.Anchor, direction)).ThenBy(x => Dot(x.Anchor, normal)).ThenBy(x => x.Key, StringComparer.Ordinal).ToList();
                    double minAlong = source.Min(x => Dot(x.Anchor, direction)), maxAlong = source.Max(x => Dot(x.Anchor, direction));
                    double edge = side > 0 ? source.Max(x => Dot(x.Anchor, normal)) : source.Min(x => Dot(x.Anchor, normal));
                    double halfHeight = source.Max(x => ProjectionSize(x, normal)) / 2;
                    double across = edge + side * (options.Offset + halfHeight);
                    double along = Midpoint(minAlong, maxAlong);
                    var center = options.Origin ?? new TagPoint(direction.X * along + normal.X * across, direction.Y * along + normal.Y * across);
                    AddLine(placements, ordered, direction, center, gap, new TagPoint(-side * normal.X * options.Shoulder, -side * normal.Y * options.Shoulder), side);
                    break;
                }
            }

            foreach (var placement in placements)
            {
                ValidatePoint(placement.Head, "Calculated tag head");
                ValidatePoint(placement.Elbow, "Calculated leader elbow");
                ValidateRectangle(placement.Bounds, "Calculated text bounds");
            }
            int collisionCount = 0;
            foreach (var placement in placements)
            {
                if (!obstacleList.Any(x => x.Intersects(placement.Bounds))) continue;
                collisionCount++;
                if (collisionCount <= 20) warnings.Add("Tag '" + placement.Key + "' overlaps a supplied obstacle. Review its position before applying.");
            }
            if (collisionCount > 20) warnings.Add((collisionCount - 20).ToString(CultureInfo.InvariantCulture) + " additional tags overlap supplied obstacles.");
            return WithLeaderStyle(new TagLayoutResult(placements, warnings), source, options);
        }

        /// <summary>Returns an axis-aligned L bend without changing either endpoint. If the
        /// endpoints already share an axis, the path collapses to a straight axis-aligned line.</summary>
        public static TagPoint OrthogonalElbow(TagPoint end, TagPoint head, TagLayoutPattern pattern)
        {
            ValidatePoint(end, "Leader endpoint");
            ValidatePoint(head, "Leader head");
            if (!Enum.IsDefined(typeof(TagLayoutPattern), pattern)) throw new ArgumentOutOfRangeException(nameof(pattern));
            bool verticalShoulder = pattern == TagLayoutPattern.HorizontalRow || pattern == TagLayoutPattern.StaggeredRows;
            return verticalShoulder ? new TagPoint(head.X, end.Y) : new TagPoint(end.X, head.Y);
        }

        private static TagLayoutResult WithLeaderStyle(TagLayoutResult layout, IList<TagLayoutItem> items, TagLayoutOptions options)
        {
            if (!options.OrthogonalLeaders) return layout;
            var byKey = items.ToDictionary(x => x.Key, StringComparer.Ordinal);
            var placements = layout.Placements.Select(p => new TagPlacement(byKey[p.Key], p.Head,
                OrthogonalElbow(p.Anchor, p.Head, options.Pattern), p.Bank)).ToList();
            var warnings = layout.Warnings.ToList();
            if (options.Pattern == TagLayoutPattern.NearHost && options.AllowedBounds.HasValue)
            {
                int outside = placements.Count(p => !Contains(options.AllowedBounds.Value, p.Elbow));
                if (outside != 0) warnings.Add(outside.ToString(CultureInfo.InvariantCulture) +
                    " right-angle leader elbows extend outside the annotation area. Their heads were not moved; these leaders require review and may be rejected during application.");
            }
            return new TagLayoutResult(placements, warnings, layout.SkippedKeys.ToList());
        }

        private sealed class LocalPosition
        {
            public TagPoint Head;
            public double DistanceSquared;
            public int Preference;
            public int Level;
        }

        private static TagLayoutResult ArrangeNearHost(List<TagLayoutItem> source, TagLayoutOptions options, List<TagRectangle> obstacles)
        {
            var placed = new List<TagPlacement>();
            var warnings = new List<string>();
            var skipped = new List<string>();
            var fixedBounds = obstacles.Concat(source.Where(x => x.HostBounds.HasValue).Select(x => x.HostBounds.Value)).ToList();
            int preferredSide = options.Side == TagLayoutSide.Positive ? 1 : -1;
            double maxDistanceSquared = options.MaximumDistance * options.MaximumDistance;
            // Sorting by geometry and key makes greedy placement independent of collector enumeration order.
            foreach (var item in OrderY(source))
            {
                double magnitude = Math.Max(1, Math.Max(Math.Abs(item.Anchor.X), Math.Abs(item.Anchor.Y)));
                magnitude = Math.Max(magnitude, Math.Max(item.Width, item.Height) + options.MaximumDistance + options.Shoulder);
                double padding = magnitude * MachineEpsilon * 32;
                double gap = options.Spacing + padding;
                double clearance = Math.Max(options.Offset, gap);
                var host = item.HostBounds ?? new TagRectangle(item.Anchor.X, item.Anchor.Y, item.Anchor.X, item.Anchor.Y);
                double left = Math.Min(item.Anchor.X, host.Left) - clearance - item.Width / 2;
                double right = Math.Max(item.Anchor.X, host.Right) + clearance + item.Width / 2;
                double bottom = Math.Min(item.Anchor.Y, host.Bottom) - clearance - item.Height / 2;
                double top = Math.Max(item.Anchor.Y, host.Top) + clearance + item.Height / 2;
                var directions = preferredSide > 0
                    ? new[] { new TagPoint(0, 1), new TagPoint(1, 0), new TagPoint(-1, 0), new TagPoint(0, -1), new TagPoint(1, 1), new TagPoint(-1, 1), new TagPoint(1, -1), new TagPoint(-1, -1) }
                    : new[] { new TagPoint(0, -1), new TagPoint(-1, 0), new TagPoint(1, 0), new TagPoint(0, 1), new TagPoint(-1, -1), new TagPoint(1, -1), new TagPoint(-1, 1), new TagPoint(1, 1) };
                var candidates = new List<LocalPosition>();
                // Bounded search: eight directions at thirteen outward levels, never an unbounded spiral.
                for (int level = 0; level <= 12; level++)
                {
                    double extra = options.MaximumDistance * level / 12;
                    for (int directionIndex = 0; directionIndex < directions.Length; directionIndex++)
                    {
                        var direction = directions[directionIndex];
                        double step = direction.X != 0 && direction.Y != 0 ? extra / Math.Sqrt(2) : extra;
                        var head = new TagPoint(direction.X > 0 ? right + step : direction.X < 0 ? left - step : item.Anchor.X,
                            direction.Y > 0 ? top + step : direction.Y < 0 ? bottom - step : item.Anchor.Y);
                        double dx = head.X - item.Anchor.X, dy = head.Y - item.Anchor.Y;
                        double distanceSquared = dx * dx + dy * dy;
                        if (distanceSquared <= maxDistanceSquared)
                            candidates.Add(new LocalPosition { Head = head, DistanceSquared = distanceSquared, Preference = directionIndex, Level = level });
                    }
                }
                var search = new TagRectangle(item.Anchor.X - options.MaximumDistance - item.Width / 2 - gap,
                    item.Anchor.Y - options.MaximumDistance - item.Height / 2 - gap,
                    item.Anchor.X + options.MaximumDistance + item.Width / 2 + gap,
                    item.Anchor.Y + options.MaximumDistance + item.Height / 2 + gap);
                var nearby = fixedBounds.Where(x => x.Intersects(search)).Concat(placed.Select(x => x.Bounds).Where(x => x.Intersects(search))).ToList();
                TagPlacement chosen = null;
                foreach (var candidate in candidates.OrderBy(x => x.DistanceSquared).ThenBy(x => x.Preference).ThenBy(x => x.Level))
                {
                    int bank = candidate.Head.X > item.Anchor.X ? 1 : candidate.Head.X < item.Anchor.X ? -1 : preferredSide;
                    var elbow = new TagPoint(candidate.Head.X - bank * options.Shoulder, candidate.Head.Y);
                    var placement = new TagPlacement(item, candidate.Head, elbow, bank);
                    if (!Representable(placement.Bounds) || !WithinCoordinates(elbow)) continue;
                    if (options.AllowedBounds.HasValue && (!Contains(options.AllowedBounds.Value, placement.Bounds) || !Contains(options.AllowedBounds.Value, elbow))) continue;
                    if (nearby.Any(bounds => OverlapsWithGap(placement.Bounds, bounds, gap))) continue;
                    chosen = placement;
                    break;
                }
                if (chosen == null)
                {
                    skipped.Add(item.Key);
                    if (skipped.Count <= 20) warnings.Add("Tag '" + item.Key + "' was skipped: no clear position fits near its host within the maximum distance and annotation area. Reduce the group or review it manually.");
                }
                else placed.Add(chosen);
            }
            if (skipped.Count > 20) warnings.Add((skipped.Count - 20).ToString(CultureInfo.InvariantCulture) + " additional tags were skipped because no clear nearby position was available.");
            return new TagLayoutResult(placed, warnings, skipped);
        }

        private static bool OverlapsWithGap(TagRectangle a, TagRectangle b, double gap)
        { return a.Left < b.Right + gap && a.Right > b.Left - gap && a.Bottom < b.Top + gap && a.Top > b.Bottom - gap; }
        private static bool Contains(TagRectangle outer, TagRectangle inner)
        { return inner.Left >= outer.Left && inner.Right <= outer.Right && inner.Bottom >= outer.Bottom && inner.Top <= outer.Top; }
        private static bool Contains(TagRectangle outer, TagPoint point)
        { return point.X >= outer.Left && point.X <= outer.Right && point.Y >= outer.Bottom && point.Y <= outer.Top; }
        private static bool WithinCoordinates(TagPoint point)
        { return Finite(point.X) && Finite(point.Y) && Math.Abs(point.X) <= MaximumCoordinate && Math.Abs(point.Y) <= MaximumCoordinate; }
        private static bool Representable(TagRectangle bounds)
        { return bounds.Left < bounds.Right && bounds.Bottom < bounds.Top && WithinCoordinates(new TagPoint(bounds.Left, bounds.Bottom)) && WithinCoordinates(new TagPoint(bounds.Right, bounds.Top)); }

        private static void AddColumnBank(List<TagPlacement> result, List<TagLayoutItem> items, int side,
            TagLayoutOptions options, double gap, double minX, double maxX, double midY)
        {
            if (items.Count == 0) return;
            double width = items.Max(x => x.Width);
            TagPoint center;
            if (options.Origin.HasValue)
                center = new TagPoint(options.Origin.Value.X + side * ((maxX - minX) / 2 + options.Offset + width / 2 + gap / 2), options.Origin.Value.Y);
            else
                center = new TagPoint((side > 0 ? maxX : minX) + side * (options.Offset + width / 2 + gap / 2), midY);
            AddLine(result, OrderY(items), new TagPoint(0, -1), center, gap, new TagPoint(-side * options.Shoulder, 0), side);
        }

        private static void AddLine(List<TagPlacement> result, IList<TagLayoutItem> items, TagPoint direction,
            TagPoint center, double gap, TagPoint shoulder, int bank)
        {
            // Disjoint projection intervals guarantee disjoint axis-aligned text rectangles,
            // including unequal label widths, near-horizontal diagonals and negative angles.
            double cursor = 0;
            var points = new List<TagPoint>();
            foreach (var item in items)
            {
                double size = ProjectionSize(item, direction);
                double distance = cursor + size / 2;
                points.Add(new TagPoint(direction.X * distance, direction.Y * distance));
                cursor += size + gap;
            }
            double middle = (cursor - gap) / 2;
            for (int i = 0; i < items.Count; i++)
            {
                // Keep every head on the same line. Using an axis-aligned bounds center here
                // would move an unequal-width diagonal bank away from its intended normal offset.
                var head = new TagPoint(center.X + (points[i].X - direction.X * middle),
                    center.Y + (points[i].Y - direction.Y * middle));
                result.Add(new TagPlacement(items[i], head, new TagPoint(head.X + shoulder.X, head.Y + shoulder.Y), bank));
            }
        }

        private static void AddCentered(List<TagPlacement> result, IList<TagLayoutItem> items, IList<TagPoint> points,
            TagRectangle extent, TagPoint center, TagPoint shoulder, int bank)
        {
            double x = Midpoint(extent.Left, extent.Right), y = Midpoint(extent.Bottom, extent.Top);
            for (int i = 0; i < items.Count; i++)
            {
                var head = new TagPoint(center.X + (points[i].X - x), center.Y + (points[i].Y - y));
                result.Add(new TagPlacement(items[i], head, new TagPoint(head.X + shoulder.X, head.Y + shoulder.Y), bank));
            }
        }

        private static TagRectangle Extents(IList<TagLayoutItem> items, IList<TagPoint> points)
        {
            double left = double.PositiveInfinity, right = double.NegativeInfinity;
            double bottom = double.PositiveInfinity, top = double.NegativeInfinity;
            for (int i = 0; i < items.Count; i++)
            {
                left = Math.Min(left, points[i].X - items[i].Width / 2); right = Math.Max(right, points[i].X + items[i].Width / 2);
                bottom = Math.Min(bottom, points[i].Y - items[i].Height / 2); top = Math.Max(top, points[i].Y + items[i].Height / 2);
            }
            return new TagRectangle(left, bottom, right, top);
        }

        private static List<TagLayoutItem> OrderX(IEnumerable<TagLayoutItem> items)
        { return items.OrderBy(x => x.Anchor.X).ThenBy(x => x.Anchor.Y).ThenBy(x => x.Key, StringComparer.Ordinal).ToList(); }
        private static List<TagLayoutItem> OrderY(IEnumerable<TagLayoutItem> items)
        { return items.OrderByDescending(x => x.Anchor.Y).ThenBy(x => x.Anchor.X).ThenBy(x => x.Key, StringComparer.Ordinal).ToList(); }
        private static double ProjectionSize(TagLayoutItem item, TagPoint direction)
        { return Math.Abs(direction.X) * item.Width + Math.Abs(direction.Y) * item.Height; }
        private static double Dot(TagPoint a, TagPoint b) { return a.X * b.X + a.Y * b.Y; }
        private static double Midpoint(double a, double b) { return a + (b - a) / 2; }

        private static void ValidateOptions(TagLayoutOptions options)
        {
            if (!Enum.IsDefined(typeof(TagLayoutPattern), options.Pattern)) throw new ArgumentOutOfRangeException(nameof(options.Pattern));
            if (!Enum.IsDefined(typeof(TagLayoutSide), options.Side)) throw new ArgumentOutOfRangeException(nameof(options.Side));
            ValidateDistance(options.Spacing, "Spacing", true);
            ValidateDistance(options.Offset, "Offset", true);
            ValidateDistance(options.Shoulder, "Shoulder", true);
            if (!Finite(options.AngleDegrees) || options.AngleDegrees < -180 || options.AngleDegrees > 180)
                throw new ArgumentOutOfRangeException(nameof(options.AngleDegrees), "Angle must be between -180 and 180 degrees.");
            if (options.Columns < 1 || options.Columns > MaximumItems) throw new ArgumentOutOfRangeException(nameof(options.Columns));
            if (options.Origin.HasValue) ValidatePoint(options.Origin.Value, "Origin");
            if (options.Pattern == TagLayoutPattern.NearHost)
            {
                ValidateDistance(options.MaximumDistance, "Maximum distance", false);
                if (options.AllowedBounds.HasValue) ValidateRectangle(options.AllowedBounds.Value, "Allowed annotation bounds");
                if (options.Origin.HasValue) throw new ArgumentException("Near-host placement uses each element's position. A shared pattern origin is not supported.", nameof(options.Origin));
            }
        }
        private static void ValidatePoint(TagPoint point, string name)
        {
            if (!Finite(point.X) || !Finite(point.Y) || Math.Abs(point.X) > MaximumCoordinate || Math.Abs(point.Y) > MaximumCoordinate)
                throw new ArgumentOutOfRangeException(name, "Coordinates must be finite and within +/- 1,000,000,000,000 caller units.");
        }
        private static void ValidateDistance(double value, string name, bool allowZero)
        {
            if (!Finite(value) || (allowZero ? value < 0 : value <= 0) || value > MaximumCoordinate)
                throw new ArgumentOutOfRangeException(name, "Distances must be finite, positive (or zero for spacing/offset/shoulder), and no greater than 1,000,000,000,000 caller units.");
        }
        private static void ValidateRectangle(TagRectangle rectangle, string name)
        {
            ValidatePoint(new TagPoint(rectangle.Left, rectangle.Bottom), name);
            ValidatePoint(new TagPoint(rectangle.Right, rectangle.Top), name);
            if (rectangle.Left >= rectangle.Right || rectangle.Bottom >= rectangle.Top)
                throw new ArgumentException("A rectangle must have positive representable width and height.", name);
        }
        private static bool Finite(double value) { return !double.IsNaN(value) && !double.IsInfinity(value); }
    }
}
