using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace PipeTakeoff.Core
{
    /// <summary>Reads report text only. No browser, XML entity resolver, script engine or resource fetching is used.</summary>
    public static class ClashHtmlImporter
    {
        public const int MaximumFileBytes = 16 * 1024 * 1024;
        public const int MaximumClashes = 20000;
        private const int MaximumNodes = 250000;
        private const int MaximumDepth = 128;
        private const int MaximumTables = 4096;
        private const int MaximumRows = 100000;
        private const int MaximumCells = 128;
        private const int MaximumCellCharacters = 131072;
        private static readonly TimeSpan RegexTimeout = TimeSpan.FromSeconds(1);
        private static readonly Regex IdPattern = Rx(@"(?:^|[\n;|])\s*(?:Revit\s*Id|Element\s*Id)\s*(?:[:=#]\s*|\s+)([^\r\n;|]*)");
        private static readonly Regex NativeRevitIdPattern = Rx(@":\s*id\s+([0-9]+)\s*$");
        private static readonly Regex UniquePattern = Rx(@"(?:^|[\n;|])\s*(?:Revit\s*)?Unique\s*Id\s*(?:[:=#]\s*|\s+)([^\r\n;|]*)");
        private static readonly Regex WholeUniquePattern = Rx(@"^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}-[a-f0-9]{8,16}$");
        private static readonly Regex DigitsPattern = Rx(@"^[0-9]+$");

        public static ClashReport ImportFile(string path, ClashColumnMapping mapping = null)
        {
            byte[] bytes = ReadFile(path);
            var report = ImportText(Decode(bytes), path, mapping);
            report.SourceSha256 = Hash(bytes);
            return report;
        }

        public static ClashReport ImportText(string html, string sourceName, ClashColumnMapping mapping = null)
        {
            var document = Parse(html);
            var report = new ClashReport
            {
                SourcePath = sourceName ?? "",
                SourceSha256 = Hash(Encoding.UTF8.GetBytes(html)),
                Title = FirstText(document, "title", "h1")
            };
            if (string.IsNullOrWhiteSpace(report.Title)) report.Title = string.IsNullOrWhiteSpace(sourceName) ? "Imported clash report" : Path.GetFileName(sourceName);
            string identification = FirstText(document, "title") + "\n" + string.Join("\n", document.Nodes.Where(n => IsHeading(n.Tag)).Take(20).Select(n => Text(n)));
            string reportIdentification = FirstText(document, "title") + "\n" + string.Join("\n", document.Nodes.Where(n => n.Tag == "h1").Take(20).Select(n => Text(n)));
            // Test names are user-authored and cannot establish native Revit semantics.
            bool revitInterference = !Contains(reportIdentification, "navisworks") &&
                (Contains(reportIdentification, "interference report") || (Contains(reportIdentification, "revit") && Contains(reportIdentification, "interference")));
            report.Producer = revitInterference ? "Revit interference report" : Contains(identification, "navisworks") || Contains(Text(document.Root, 8192, false), "navisworks") ? "Navisworks" : "HTML report";
            var state = new ImportState(report, revitInterference);
            if (mapping != null)
            {
                if (mapping.TableIndex < 0 || mapping.TableIndex >= document.Tables.Count) throw new InvalidDataException("The selected table is no longer present in the HTML report.");
                if ((mapping.Id1Column < 0 && mapping.UniqueId1Column < 0) || (mapping.Id2Column < 0 && mapping.UniqueId2Column < 0)) throw new InvalidDataException("Map an element ID or UniqueId column for each element.");
                var table = document.Tables[mapping.TableIndex];
                var rows = TableRows(table);
                ValidateMapping(mapping, rows);
                var headers = mapping.HasHeaderRow && rows.Count > 0 ? Cells(rows[0]).Select(Text).ToList() : new List<string>();
                for (int i = mapping.HasHeaderRow ? 1 : 0; i < rows.Count; i++)
                {
                    var cells = Cells(rows[i]).Select(Text).ToList();
                    if (cells.All(string.IsNullOrWhiteSpace) || SameHeader(cells, headers)) continue;
                    AddMapped(state, cells, headers, mapping, Context(table), rows[i], true);
                }
                report.Notes.Add("Columns were selected manually. Element references still require verification in the current model.");
            }
            else
            {
                foreach (var table in document.Tables)
                {
                    if (ClaimedAncestor(table, state.Claimed)) continue;
                    ParseTable(state, table);
                }
                ParseBlocks(state, document);
            }
            if (report.Rows.Count == 0) throw new InvalidDataException("No recognizable clash rows were found. Select a report table and map the two element ID or UniqueId columns. The importer supports common Navisworks and Revit interference HTML layouts; this report may use another layout.");
            int missing = report.Rows.Count(r => !HasReference(r.Element1) || !HasReference(r.Element2));
            if (missing > 0) report.Notes.Add(missing.ToString(CultureInfo.InvariantCulture) + " clash rows have missing or unrecognized Revit references. Original element text was retained for review; no IDs were guessed.");
            if (state.Duplicates > 0) report.Notes.Add(state.Duplicates.ToString(CultureInfo.InvariantCulture) + " identical repeated report rows were collapsed; clashes from distinct tests remain separate.");
            report.Notes.Add("Imported statuses are historical report values. Every imported clash is Unchecked until checked against the current Revit model.");
            return report;
        }

        public static IList<ClashTablePreview> InspectFile(string path) { return InspectTables(Decode(ReadFile(path))); }

        public static IList<ClashTablePreview> InspectTables(string html)
        {
            var document = Parse(html);
            var result = new List<ClashTablePreview>();
            for (int i = 0; i < document.Tables.Count; i++)
            {
                var rows = TableRows(document.Tables[i]);
                if (rows.Count == 0) continue;
                result.Add(new ClashTablePreview
                {
                    TableIndex = i,
                    Headers = Cells(rows[0]).Select(n => ShortText(Text(n), 400)).ToList(),
                    PreviewRows = rows.Skip(1).Take(5).Select(r => Cells(r).Select(n => ShortText(Text(n), 400)).ToList()).ToList(),
                    DataRowCount = Math.Max(0, rows.Count - 1)
                });
            }
            return result;
        }

        private static void ParseTable(ImportState state, Node table)
        {
            var rows = TableRows(table);
            string context = Context(table);
            for (int h = 0; h < Math.Min(rows.Count, 20); h++)
            {
                var headers = Cells(rows[h]).Select(Text).ToList();
                var mapping = GuessMapping(headers);
                if (!HasBothColumns(mapping)) continue;
                for (int i = h + 1; i < rows.Count; i++)
                {
                    var row = rows[i];
                    var cells = Cells(row).Select(Text).ToList();
                    if (cells.All(string.IsNullOrWhiteSpace) || SameHeader(cells, headers)) continue;
                    if (cells.Count == 1) { context = ContextTest(cells[0]).Length > 0 ? cells[0] : cells[0] + "\n" + context; continue; }
                    var repeatedMapping = GuessMapping(cells);
                    if (HasBothColumns(repeatedMapping)) { mapping = repeatedMapping; headers = cells; continue; }
                    AddMapped(state, cells, headers, mapping, context, row);
                }
                if (rows.Skip(h + 1).Any(r => state.Claimed.Contains(r))) return;
            }
            var fields = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var fieldNodes = new Dictionary<string, Node>(StringComparer.OrdinalIgnoreCase);
            foreach (var row in rows)
            {
                var cells = Cells(row);
                if (cells.Count == 2)
                {
                    string key = Label(Text(cells[0]));
                    if (IsFieldLabel(key) && !fields.ContainsKey(key)) { fields[key] = Text(cells[1]); fieldNodes[key] = cells[1]; }
                }
            }
            string item1 = Get(fields, "item1", "element1", "firstelement");
            string item2 = Get(fields, "item2", "element2", "secondelement");
            if (item1.Length > 0 && item2.Length > 0)
            {
                AddFields(state, fields, item1, item2, context, table,
                    GetNode(fieldNodes, "item1", "element1", "firstelement"), GetNode(fieldNodes, "item2", "element2", "secondelement"));
                return;
            }
            if (state.RevitInterference)
            {
                foreach (var row in rows)
                {
                    var cells = Cells(row).Select(Text).ToList();
                    if (cells.Count < 2 || cells.Count > 3) continue;
                    var first = Reference(cells[cells.Count - 2], true);
                    var second = Reference(cells[cells.Count - 1], true);
                    if (!HasReference(first) || !HasReference(second)) continue;
                    Add(state, new ClashRecord { Name = cells.Count == 3 ? cells[0] : "Interference " + (state.Report.Rows.Count + 1).ToString(CultureInfo.InvariantCulture), TestName = ContextTest(context), TestKind = ClashTestKind.Hard, Element1 = first, Element2 = second }, row);
                }
            }
        }

        private static void AddMapped(ImportState state, IList<string> cells, IList<string> headers, ClashColumnMapping map, string context, Node origin, bool manual = false)
        {
            var nodes = Cells(origin);
            var row = new ClashRecord
            {
                Name = At(cells, map.NameColumn), TestName = At(cells, map.TestNameColumn),
                ImportedStatus = At(cells, map.StatusColumn), Description = At(cells, map.DescriptionColumn),
                DistanceText = At(cells, map.DistanceColumn), ClashPointText = At(cells, map.ClashPointColumn), AssignedTo = At(cells, map.AssignedToColumn),
                Element1 = Reference(At(cells, map.Id1Column), state.RevitInterference, manual || IsExplicitIdHeader(At(headers, map.Id1Column)), At(nodes, map.Id1Column)),
                Element2 = Reference(At(cells, map.Id2Column), state.RevitInterference, manual || IsExplicitIdHeader(At(headers, map.Id2Column)), At(nodes, map.Id2Column))
            };
            ApplyReferenceColumns(row.Element1, cells, map.UniqueId1Column, map.Category1Column, map.Name1Column, map.Source1Column);
            ApplyReferenceColumns(row.Element2, cells, map.UniqueId2Column, map.Category2Column, map.Name2Column, map.Source2Column);
            if (row.TestName.Length == 0) row.TestName = ContextTest(context);
            string testKind = At(cells, map.TestKindColumn);
            row.TestKind = state.RevitInterference ? ClashTestKind.Hard : testKind.Length > 0 ? Kind(testKind) : ContextKind(context);
            for (int i = 0; i < cells.Count; i++)
            {
                string key = i < headers.Count && !string.IsNullOrWhiteSpace(headers[i]) ? headers[i] : "Column " + (i + 1).ToString(CultureInfo.InvariantCulture);
                AddExtra(row, key, cells[i]);
            }
            if (row.Name.Length == 0) row.Name = "Clash " + (state.Report.Rows.Count + 1).ToString(CultureInfo.InvariantCulture);
            Add(state, row, origin);
        }

        private static void ApplyReferenceColumns(ClashElementReference reference, IList<string> cells, int unique, int category, int name, int source)
        {
            string value = At(cells, unique);
            if (value.Length > 0)
            {
                string candidate = ReadUniqueId(value);
                reference.UniqueId = reference.UniqueId.Length == 0 || string.Equals(reference.UniqueId, candidate, StringComparison.OrdinalIgnoreCase) ? candidate : "";
                if (reference.RawText.Length == 0) reference.RawText = value;
                else if (reference.RawText != value) reference.RawText += "\nUniqueId: " + value;
            }
            if (At(cells, category).Length > 0) reference.ReportedCategory = At(cells, category);
            if (At(cells, name).Length > 0) reference.ReportedName = At(cells, name);
            if (At(cells, source).Length > 0) reference.SourceHint = At(cells, source);
        }

        private static ClashColumnMapping GuessMapping(IList<string> headers)
        {
            var map = new ClashColumnMapping();
            for (int i = 0; i < headers.Count; i++)
            {
                string label = Label(headers[i]);
                switch (label)
                {
                    case "name": case "clash": case "clashname": case "clashnumber": case "clashid": map.NameColumn = i; break;
                    case "test": case "testname": case "clashtest": case "clashtestname": map.TestNameColumn = i; break;
                    case "testtype": case "clashtype": case "testkind": case "type": case "criterion": case "criteria": map.TestKindColumn = i; break;
                    case "status": case "clashstatus": map.StatusColumn = i; break;
                    case "distance": case "clashdistance": case "penetration": case "penetrationdepth": map.DistanceColumn = i; break;
                    case "point": case "clashpoint": case "clashpointcoordinates": case "center": case "centre": map.ClashPointColumn = i; break;
                    case "assignedto": case "assignee": map.AssignedToColumn = i; break;
                    case "description": case "comments": case "comment": map.DescriptionColumn = i; break;
                    case "item1": case "element1": case "firstelement": case "elementid1": case "element1id": case "revitid1": case "revit1id": map.Id1Column = i; break;
                    case "item2": case "element2": case "secondelement": case "elementid2": case "element2id": case "revitid2": case "revit2id": map.Id2Column = i; break;
                    case "uniqueid1": case "element1uniqueid": case "elementuniqueid1": case "revituniqueid1": map.UniqueId1Column = i; break;
                    case "uniqueid2": case "element2uniqueid": case "elementuniqueid2": case "revituniqueid2": map.UniqueId2Column = i; break;
                    case "category1": case "item1category": case "element1category": map.Category1Column = i; break;
                    case "category2": case "item2category": case "element2category": map.Category2Column = i; break;
                    case "name1": case "item1name": case "element1name": map.Name1Column = i; break;
                    case "name2": case "item2name": case "element2name": map.Name2Column = i; break;
                    case "source1": case "file1": case "model1": case "item1file": case "element1source": map.Source1Column = i; break;
                    case "source2": case "file2": case "model2": case "item2file": case "element2source": map.Source2Column = i; break;
                }
            }
            return map;
        }

        private static bool HasBothColumns(ClashColumnMapping map) { return (map.Id1Column >= 0 || map.UniqueId1Column >= 0) && (map.Id2Column >= 0 || map.UniqueId2Column >= 0); }
        private static bool SameHeader(IList<string> cells, IList<string> headers) { return headers.Count > 0 && cells.Count == headers.Count && cells.Select(Label).SequenceEqual(headers.Select(Label)); }

        private static bool IsExplicitIdHeader(string header)
        {
            string label = Label(header);
            return label == "elementid1" || label == "element1id" || label == "revitid1" || label == "revit1id" || label == "elementid2" || label == "element2id" || label == "revitid2" || label == "revit2id";
        }

        private static void ValidateMapping(ClashColumnMapping mapping, IList<Node> rows)
        {
            int columns = rows.Count == 0 ? 0 : rows.Max(r => Cells(r).Count);
            foreach (var property in typeof(ClashColumnMapping).GetProperties().Where(p => p.Name.EndsWith("Column", StringComparison.Ordinal)))
            {
                int index = (int)property.GetValue(mapping, null);
                if (index < -1 || index >= columns) throw new InvalidDataException("A mapped column is not present in the selected HTML table. Review the column mapping.");
            }
            if ((mapping.Id1Column >= 0 && mapping.Id1Column == mapping.Id2Column) || (mapping.UniqueId1Column >= 0 && mapping.UniqueId1Column == mapping.UniqueId2Column))
                throw new InvalidDataException("Select a separate reference column for each element.");
        }

        private static ClashElementReference Reference(string raw, bool nativeRevit, bool allowBareId = false, Node propertyNode = null)
        {
            var reference = new ClashElementReference { RawText = raw ?? "" };
            string value = propertyNode == null ? (raw ?? "").Trim() : ReferenceText(propertyNode);
            if (allowBareId && DigitsPattern.IsMatch(value)) reference.ElementId = PositiveId(value);
            else
            {
                var ids = IdPattern.Matches(value).Cast<Match>().Select(m => m.Groups[1].Value.Trim().TrimStart('0')).Distinct(StringComparer.Ordinal).ToList();
                if (ids.Count == 1 && DigitsPattern.IsMatch(ids[0])) reference.ElementId = PositiveId(ids[0]);
                // A native Revit interference element has a trailing ': id N'; this is not accepted in other reports.
                if (ids.Count == 0 && nativeRevit)
                {
                    Match match = NativeRevitIdPattern.Match(value);
                    if (match.Success) reference.ElementId = PositiveId(match.Groups[1].Value);
                }
            }
            reference.UniqueId = ReadUniqueId(value);
            reference.ReportedCategory = Field(value, "Category", "Element Category", "Item Category");
            reference.ReportedName = Field(value, "Item Name", "Element Name", "Name", "Family", "Type Name");
            reference.SourceHint = Field(value, "Source File", "File Name", "Source Model", "Model File", "Document", "Source", "File", "Model");
            if (reference.SourceHint.Length == 0)
            {
                string path = Field(value, "Path", "Selection Path");
                if (Contains(path, ".rvt") || Contains(path, ".nwc") || Contains(path, ".nwd")) reference.SourceHint = path;
            }
            if (nativeRevit && value.IndexOf(':') > 0)
            {
                string[] parts = value.Split(':');
                if (reference.ReportedCategory.Length == 0 && !Contains(parts[0], "id")) reference.ReportedCategory = parts[0].Trim();
                if (reference.ReportedName.Length == 0 && parts.Length > 2) reference.ReportedName = string.Join(" : ", parts.Skip(1).Take(parts.Length - 2).Select(part => part.Trim()));
            }
            return reference;
        }

        // Property table groups carry identity meaning: Element > ID is a Revit reference,
        // while Item > ID, Geometry > ID, and unscoped ID must stay unresolved.
        private static string ReferenceText(Node node)
        {
            if (!Descendants(node).Any(child => child.Tag == "table")) return Text(node);
            var text = new StringBuilder();
            AppendProperties(node, "", text);
            if (text.Length > MaximumCellCharacters) throw new InvalidDataException("A report field exceeds the supported text length.");
            return text.ToString().Trim();
        }

        private static void AppendProperties(Node node, string scope, StringBuilder text)
        {
            if (node.Tag == "table")
            {
                string group = scope;
                foreach (var row in TableRows(node))
                {
                    var cells = Cells(row);
                    if (cells.Count == 1)
                    {
                        string heading = Text(cells[0]);
                        if (IsPropertyScope(heading)) group = heading;
                        else AppendProperties(cells[0], group, text);
                    }
                    else if (cells.Count == 2 && !Descendants(cells[0]).Any(child => child.Tag == "table"))
                    {
                        string label = Text(cells[0]);
                        if (Descendants(cells[1]).Any(child => child.Tag == "table")) AppendProperties(cells[1], group + "/" + label, text);
                        else text.Append('\n').Append(PropertyLabel(label, group)).Append(": ").Append(Text(cells[1])).Append('\n');
                    }
                    else if (cells.Count == 3 && IsPropertyScope(Text(cells[0])))
                    {
                        text.Append('\n').Append(PropertyLabel(Text(cells[1]), Text(cells[0]))).Append(": ").Append(Text(cells[2])).Append('\n');
                    }
                    else foreach (var cell in cells) AppendProperties(cell, group, text);
                    if (text.Length > MaximumCellCharacters) throw new InvalidDataException("A report field exceeds the supported text length.");
                }
                return;
            }
            if (!Descendants(node).Any(child => child.Tag == "table")) { text.Append('\n').Append(Text(node)).Append('\n'); return; }
            foreach (var child in node.Children) AppendProperties(child, scope, text);
        }

        private static bool IsPropertyScope(string value)
        {
            return new[] { "element", "revitelement", "revit", "item", "model", "sourcemodel", "file", "sourcefile", "document", "category", "geometry" }.Contains(Label(value));
        }

        private static string PropertyLabel(string label, string scope)
        {
            string key = Label(label), group = Label(scope.Split('/').Last());
            if (scope.Split('/').Select(Label).Any(part => part == "parent" || part == "type" || part == "elementtype" || part == "family" || part == "host" || part == "level" || part == "material" || part == "geometry")) return "Related " + label;
            if (key == "id" && (group == "element" || group == "revitelement")) return "Element ID";
            if (key == "id" && group == "revit") return "Revit ID";
            if (key == "name" || key == "filename" || key == "path")
            {
                if (group == "model" || group == "sourcemodel" || group == "document") return "Source Model";
                if (group == "file" || group == "sourcefile") return "Source File";
                if (key == "name" && group == "category") return "Category";
                if (key == "name" && (group == "element" || group == "revitelement")) return "Element Name";
                if (key == "name" && group == "item") return "Item Name";
            }
            return label;
        }

        private static string ReadUniqueId(string value)
        {
            if (WholeUniquePattern.IsMatch(value)) return value;
            var ids = UniquePattern.Matches(value).Cast<Match>().Select(m => m.Groups[1].Value.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            return ids.Count == 1 && WholeUniquePattern.IsMatch(ids[0]) ? ids[0] : "";
        }

        private static long? PositiveId(string value) { long id; return long.TryParse(value, NumberStyles.None, CultureInfo.InvariantCulture, out id) && id > 0 ? (long?)id : null; }
        private static bool HasReference(ClashElementReference reference) { return reference.ElementId.HasValue || !string.IsNullOrWhiteSpace(reference.UniqueId); }

        private static void ParseBlocks(ImportState state, Document document)
        {
            foreach (var node in document.Nodes.Where(n => n.Tag == "div" || n.Tag == "section" || n.Tag == "article").Reverse())
            {
                if (ClaimedAncestor(node, state.Claimed) || state.ClaimedContainers.Contains(node)) continue;
                if (!Contains(node.ClassName, "clash") && !Contains(node.ClassName, "result")) continue;
                string text = Text(node);
                var first = Rx(@"(?:^|\n)\s*(?:Item|Element)\s*1\s*(?::|\n)\s*").Matches(text);
                var second = Rx(@"(?:^|\n)\s*(?:Item|Element)\s*2\s*(?::|\n)\s*").Matches(text);
                if (first.Count != 1 || second.Count != 1 || first[0].Index >= second[0].Index) continue;
                int start = first[0].Index + first[0].Length;
                string item1 = text.Substring(start, second[0].Index - start);
                string item2 = text.Substring(second[0].Index + second[0].Length);
                var fields = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (string label in new[] { "Clash Name", "Name", "Test Name", "Test Type", "Status", "Distance", "Clash Point", "Assigned To", "Description", "Comments" })
                {
                    string value = Field(text, label);
                    if (value.Length > 0) fields[Label(label)] = value;
                }
                if (!fields.ContainsKey("name") && !fields.ContainsKey("clashname")) fields["name"] = Descendants(node).Where(n => IsHeading(n.Tag)).Select(Text).FirstOrDefault() ?? "";
                AddFields(state, fields, item1, item2, Context(node), node);
            }
        }

        private static void AddFields(ImportState state, IDictionary<string, string> fields, string item1, string item2, string context, Node origin, Node item1Node = null, Node item2Node = null)
        {
            var row = new ClashRecord
            {
                Name = Get(fields, "clashname", "name"), TestName = Get(fields, "testname", "test"),
                ImportedStatus = Get(fields, "status", "clashstatus"), DistanceText = Get(fields, "distance", "penetration"),
                ClashPointText = Get(fields, "clashpoint", "point"), AssignedTo = Get(fields, "assignedto", "assignee"),
                Description = Get(fields, "description", "comments", "comment"),
                Element1 = Reference(item1, state.RevitInterference, false, item1Node), Element2 = Reference(item2, state.RevitInterference, false, item2Node),
                TestKind = state.RevitInterference ? ClashTestKind.Hard : Kind(Get(fields, "testtype", "clashtype", "type", "criterion", "criteria"))
            };
            if (row.TestName.Length == 0) row.TestName = ContextTest(context);
            if (!state.RevitInterference && Get(fields, "testtype", "clashtype", "type", "criterion", "criteria").Length == 0) row.TestKind = ContextKind(context);
            if (row.Name.Length == 0) row.Name = ContextClashName(context);
            if (row.Name.Length == 0) row.Name = "Clash " + (state.Report.Rows.Count + 1).ToString(CultureInfo.InvariantCulture);
            foreach (var field in fields) AddExtra(row, field.Key, field.Value);
            Add(state, row, origin);
        }

        private static void Add(ImportState state, ClashRecord row, Node origin)
        {
            state.Claimed.Add(origin);
            for (var parent = origin.Parent; parent != null; parent = parent.Parent) state.ClaimedContainers.Add(parent);
            row.State = ClashState.Unchecked;
            row.CheckNote = !HasReference(row.Element1) || !HasReference(row.Element2) ? "Not checked. One or both Revit element references are missing or unrecognized; review the original report text and column mapping." : "Not checked against the current Revit model.";
            string canonical = string.Join("\u001f", new[] { row.Name, row.TestName, row.TestKind.ToString(), row.ImportedStatus, row.DistanceText, row.ClashPointText, row.AssignedTo, row.Description, row.Element1.RawText, row.Element1.IdLabel, row.Element1.UniqueId, row.Element1.SourceHint, row.Element1.ReportedCategory, row.Element1.ReportedName, row.Element2.RawText, row.Element2.IdLabel, row.Element2.UniqueId, row.Element2.SourceHint, row.Element2.ReportedCategory, row.Element2.ReportedName });
            canonical += "\u001e" + string.Join("\u001e", row.ExtraFields.OrderBy(field => field.Key, StringComparer.Ordinal).Select(field => field.Key + "\u001f" + field.Value));
            string digest = Hash(Encoding.UTF8.GetBytes(canonical));
            if (!state.Fingerprints.Add(digest)) { state.Duplicates++; return; }
            if (state.Report.Rows.Count >= MaximumClashes) throw new InvalidDataException("The report exceeds the supported limit of 20,000 clash rows. Export a smaller report.");
            row.Key = "clash-" + digest;
            state.Report.Rows.Add(row);
        }

        private static void AddExtra(ClashRecord row, string key, string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return;
            string unique = key;
            for (int i = 2; row.ExtraFields.ContainsKey(unique); i++) unique = key + " (" + i.ToString(CultureInfo.InvariantCulture) + ")";
            row.ExtraFields[unique] = value;
        }

        private static string Field(string text, params string[] labels)
        {
            foreach (string label in labels)
            {
                string expression = @"(?:^|[\n;|])\s*" + Regex.Escape(label).Replace(@"\ ", @"\s*") + @"\s*(?::|=|\n)\s*([^\n;|]+)";
                Match match = Rx(expression).Match(text ?? "");
                if (match.Success) return match.Groups[1].Value.Trim();
            }
            return "";
        }

        private static ClashTestKind Kind(string value)
        {
            string kind = Label(value);
            if (kind == "hard" || kind == "hardclash" || kind == "hardconservative" || kind == "interference") return ClashTestKind.Hard;
            if (kind == "clearance" || kind == "clearanceclash") return ClashTestKind.Clearance;
            if (kind == "duplicate" || kind == "duplicates" || kind == "duplicateclash") return ClashTestKind.Duplicate;
            return ClashTestKind.Unknown;
        }
        private static ClashTestKind ContextKind(string context) { return Kind(Field(context, "Test Type", "Clash Type", "Test Kind", "Criterion", "Criteria", "Type")); }
        private static string ContextTest(string context)
        {
            string value = Field(context, "Test Name", "Clash Test", "Test");
            if (value.Length > 0) return value;
            Match match = Rx(@"(?:^|\n)\s*Test\s*:\s*([^\n]+)").Match(context);
            return match.Success ? match.Groups[1].Value.Trim() : "";
        }
        private static string ContextClashName(string context) { return Field(context, "Clash Name", "Clash"); }
        private static string Get(IDictionary<string, string> fields, params string[] names) { foreach (string name in names) { string value; if (fields.TryGetValue(name, out value) && !string.IsNullOrWhiteSpace(value)) return value; } return ""; }
        private static Node GetNode(IDictionary<string, Node> fields, params string[] names) { foreach (string name in names) { Node value; if (fields.TryGetValue(name, out value)) return value; } return null; }
        private static string At(IList<string> cells, int index) { return index >= 0 && index < cells.Count ? cells[index].Trim() : ""; }
        private static Node At(IList<Node> cells, int index) { return index >= 0 && index < cells.Count ? cells[index] : null; }
        private static string Label(string text) { return new string((text ?? "").Where(char.IsLetterOrDigit).Select(char.ToLowerInvariant).ToArray()); }
        private static bool Contains(string value, string term) { return (value ?? "").IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0; }
        private static Regex Rx(string expression) { return new Regex(expression, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant, RegexTimeout); }
        private static bool IsFieldLabel(string value) { return new[] { "item1", "item2", "element1", "element2", "firstelement", "secondelement", "clashname", "name", "test", "testname", "testtype", "clashtype", "type", "criterion", "criteria", "status", "clashstatus", "distance", "penetration", "clashpoint", "point", "assignedto", "assignee", "description", "comments", "comment" }.Contains(value); }

        private static byte[] ReadFile(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) throw new ArgumentException("Choose an HTML report file.", nameof(path));
            using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                if (stream.Length > MaximumFileBytes) throw new InvalidDataException("HTML report exceeds the 16 MiB import limit. Export a smaller report.");
                using (var output = new MemoryStream())
                {
                    var buffer = new byte[8192]; int count;
                    while ((count = stream.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        if (output.Length + count > MaximumFileBytes) throw new InvalidDataException("HTML report exceeds the 16 MiB import limit.");
                        output.Write(buffer, 0, count);
                    }
                    return output.ToArray();
                }
            }
        }

        private static string Decode(byte[] bytes)
        {
            try
            {
                // BOMs take precedence over declarations, as they do in exported Unicode reports.
                if (HasPrefix(bytes, 0xff, 0xfe, 0, 0)) return new UTF32Encoding(false, false, true).GetString(bytes, 4, bytes.Length - 4);
                if (HasPrefix(bytes, 0, 0, 0xfe, 0xff)) return new UTF32Encoding(true, false, true).GetString(bytes, 4, bytes.Length - 4);
                if (HasPrefix(bytes, 0xff, 0xfe)) return new UnicodeEncoding(false, false, true).GetString(bytes, 2, bytes.Length - 2);
                if (HasPrefix(bytes, 0xfe, 0xff)) return new UnicodeEncoding(true, false, true).GetString(bytes, 2, bytes.Length - 2);
                if (HasPrefix(bytes, 0xef, 0xbb, 0xbf)) return new UTF8Encoding(false, true).GetString(bytes, 3, bytes.Length - 3);
                string prefix = Encoding.ASCII.GetString(bytes, 0, Math.Min(8192, bytes.Length));
                Match declaration = Rx(@"<meta\b[^>]*\bcharset\s*=\s*['""\s]*([a-z0-9_-]+)").Match(prefix);
                if (declaration.Success)
                {
                    string charset = declaration.Groups[1].Value.ToLowerInvariant();
                    if (charset == "windows-1252" || charset == "cp1252" || charset == "iso-8859-1" || charset == "latin1") return DecodeWestern(bytes);
                    if (charset != "utf-8" && charset != "utf8" && charset != "us-ascii") throw new InvalidDataException("The HTML report declares an unsupported character encoding. Save or export it as UTF-8, UTF-16 or Windows-1252 HTML.");
                    return new UTF8Encoding(false, true).GetString(bytes);
                }
                try { return new UTF8Encoding(false, true).GetString(bytes); }
                catch (DecoderFallbackException) { return DecodeWestern(bytes); } // Older Windows exports omit a charset declaration.
            }
            catch (DecoderFallbackException ex) { throw new InvalidDataException("The HTML report contains invalid text for its declared character encoding.", ex); }
        }
        private static bool HasPrefix(byte[] bytes, params byte[] prefix) { return bytes.Length >= prefix.Length && prefix.Where((value, index) => bytes[index] != value).Any() == false; }
        private static string DecodeWestern(byte[] bytes)
        {
            const string controls = "\u20ac\u0081\u201a\u0192\u201e\u2026\u2020\u2021\u02c6\u2030\u0160\u2039\u0152\u008d\u017d\u008f\u0090\u2018\u2019\u201c\u201d\u2022\u2013\u2014\u02dc\u2122\u0161\u203a\u0153\u009d\u017e\u0178";
            var result = new char[bytes.Length];
            for (int i = 0; i < bytes.Length; i++) result[i] = bytes[i] >= 0x80 && bytes[i] <= 0x9f ? controls[bytes[i] - 0x80] : (char)bytes[i];
            return new string(result);
        }
        private static string Hash(byte[] bytes) { using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }
        private static string ShortText(string text, int maximum) { return text.Length <= maximum ? text : text.Substring(0, maximum) + "…"; }

        private sealed class ImportState
        {
            public ImportState(ClashReport report, bool revitInterference) { Report = report; RevitInterference = revitInterference; }
            public readonly ClashReport Report;
            public readonly bool RevitInterference;
            public readonly HashSet<Node> Claimed = new HashSet<Node>();
            public readonly HashSet<Node> ClaimedContainers = new HashSet<Node>();
            public readonly HashSet<string> Fingerprints = new HashSet<string>(StringComparer.Ordinal);
            public int Duplicates;
        }
        private sealed class Node
        {
            public string Tag = "";
            public string Value = "";
            public string ClassName = "";
            public Node Parent;
            public int CellCount;
            public readonly List<Node> Children = new List<Node>();
        }
        private sealed class Document
        {
            public readonly Node Root = new Node { Tag = "root" };
            public readonly List<Node> Nodes = new List<Node>();
            public readonly List<Node> Tables = new List<Node>();
        }

        private static Document Parse(string html)
        {
            if (html == null) throw new ArgumentNullException(nameof(html));
            if (html.Length > MaximumFileBytes || Encoding.UTF8.GetByteCount(html) > MaximumFileBytes) throw new InvalidDataException("HTML report exceeds the 16 MiB import limit. Export a smaller report.");
            var document = new Document();
            var stack = new List<Node> { document.Root };
            int cursor = 0, rowCount = 0;
            while (cursor < html.Length)
            {
                int open = html.IndexOf('<', cursor);
                if (open < 0) { AddText(document, stack[stack.Count - 1], html.Substring(cursor)); break; }
                if (open > cursor) AddText(document, stack[stack.Count - 1], html.Substring(cursor, open - cursor));
                if (StartsAt(html, open, "<!--")) { int endComment = html.IndexOf("-->", open + 4, StringComparison.Ordinal); cursor = endComment < 0 ? html.Length : endComment + 3; continue; }
                int end = TagEnd(html, open + 1);
                if (end < 0) { AddText(document, stack[stack.Count - 1], html.Substring(open)); break; }
                int nameStart = open + 1;
                bool closing = nameStart < end && html[nameStart] == '/';
                if (closing) nameStart++;
                while (nameStart < end && char.IsWhiteSpace(html[nameStart])) nameStart++;
                int nameEnd = nameStart;
                while (nameEnd < end && (char.IsLetterOrDigit(html[nameEnd]) || html[nameEnd] == ':' || html[nameEnd] == '-')) nameEnd++;
                cursor = end + 1;
                if (nameEnd == nameStart) continue;
                string name = html.Substring(nameStart, nameEnd - nameStart).ToLowerInvariant();
                if (closing) { Close(stack, name); continue; }
                if (name == "script" || name == "style" || name == "template" || name == "noscript" || name == "iframe" || name == "object" || name == "svg" || name == "math")
                {
                    cursor = SkipIgnored(html, cursor, name);
                    continue;
                }
                // Optional end tags are common in old Navisworks/Revit exports.
                if (name == "tr") CloseBeforeTable(stack, "tr");
                if (name == "td" || name == "th") { CloseBeforeTable(stack, "td"); CloseBeforeTable(stack, "th"); }
                if (name == "p" && stack[stack.Count - 1].Tag == "p") stack.RemoveAt(stack.Count - 1);
                var node = new Node { Tag = name, Parent = stack[stack.Count - 1] };
                if (name == "div" || name == "section" || name == "article")
                {
                    string attributes = html.Substring(nameEnd, end - nameEnd);
                    Match match = Rx("\\bclass\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))").Match(attributes);
                    if (match.Success) node.ClassName = match.Groups[1].Success ? match.Groups[1].Value : match.Groups[2].Success ? match.Groups[2].Value : match.Groups[3].Value;
                }
                AddNode(document, node);
                if (name == "table") { document.Tables.Add(node); if (document.Tables.Count > MaximumTables) throw new InvalidDataException("HTML report contains too many tables."); }
                if (name == "tr" && ++rowCount > MaximumRows) throw new InvalidDataException("HTML report contains too many table rows.");
                if (name == "td" || name == "th")
                {
                    Node parentRow = Ancestor(node, "tr");
                    if (parentRow != null && ++parentRow.CellCount > MaximumCells) throw new InvalidDataException("HTML report contains a table row with too many cells.");
                }
                if (!IsVoid(name) && (end <= open || html[end - 1] != '/'))
                {
                    if (stack.Count >= MaximumDepth) throw new InvalidDataException("HTML nesting exceeds the supported import limit.");
                    stack.Add(node);
                }
            }
            return document;
        }

        private static void AddText(Document document, Node parent, string value)
        {
            string decoded = WebUtility.HtmlDecode(value).Replace('\u00a0', ' ');
            if (decoded.Length > 0 && !string.IsNullOrWhiteSpace(decoded)) AddNode(document, new Node { Parent = parent, Value = decoded });
        }
        private static void AddNode(Document document, Node node)
        {
            if (document.Nodes.Count >= MaximumNodes) throw new InvalidDataException("HTML report contains too many nodes. Export a smaller report.");
            node.Parent.Children.Add(node); document.Nodes.Add(node);
        }
        private static bool StartsAt(string value, int index, string token) { return index + token.Length <= value.Length && string.Compare(value, index, token, 0, token.Length, StringComparison.Ordinal) == 0; }
        private static int RawClosingTag(string html, int start, string name)
        {
            string token = "</" + name;
            for (int index = html.IndexOf(token, start, StringComparison.OrdinalIgnoreCase); index >= 0; index = html.IndexOf(token, index + token.Length, StringComparison.OrdinalIgnoreCase))
            {
                int after = index + token.Length;
                if (after == html.Length || char.IsWhiteSpace(html[after]) || html[after] == '>' || html[after] == '/') return index;
            }
            return -1;
        }
        private static int SkipIgnored(string html, int cursor, string name)
        {
            if (name == "script" || name == "style" || name == "iframe")
            {
                int close = RawClosingTag(html, cursor, name);
                if (close < 0) return html.Length;
                int end = TagEnd(html, close + 2 + name.Length);
                return end < 0 ? html.Length : end + 1;
            }
            int depth = 1;
            while (cursor < html.Length)
            {
                int open = html.IndexOf('<', cursor);
                if (open < 0) return html.Length;
                if (StartsAt(html, open, "<!--"))
                {
                    int endComment = html.IndexOf("-->", open + 4, StringComparison.Ordinal);
                    cursor = endComment < 0 ? html.Length : endComment + 3;
                    continue;
                }
                int end = TagEnd(html, open + 1);
                if (end < 0) return html.Length;
                int start = open + 1;
                bool closing = start < end && html[start] == '/';
                if (closing) start++;
                while (start < end && char.IsWhiteSpace(html[start])) start++;
                int finish = start;
                while (finish < end && (char.IsLetterOrDigit(html[finish]) || html[finish] == ':' || html[finish] == '-')) finish++;
                string tag = html.Substring(start, finish - start).ToLowerInvariant();
                cursor = end + 1;
                if (tag == name)
                {
                    if (closing && --depth == 0) return cursor;
                    if (!closing && html[end - 1] != '/' && ++depth >= MaximumDepth) throw new InvalidDataException("HTML nesting exceeds the supported import limit.");
                }
                else if (!closing && (tag == "script" || tag == "style" || tag == "iframe")) cursor = SkipIgnored(html, cursor, tag);
            }
            return html.Length;
        }
        private static int TagEnd(string html, int start)
        {
            char quote = '\0';
            for (int i = start; i < html.Length; i++)
            {
                char c = html[i];
                if (quote != '\0') { if (c == quote) quote = '\0'; }
                else if (c == '\'' || c == '"') quote = c;
                else if (c == '>') return i;
            }
            return -1;
        }
        private static void Close(List<Node> stack, string name)
        {
            for (int i = stack.Count - 1; i > 0; i--) if (stack[i].Tag == name) { stack.RemoveRange(i, stack.Count - i); return; }
        }
        private static void CloseBeforeTable(List<Node> stack, string name)
        {
            for (int i = stack.Count - 1; i > 0; i--)
            {
                if (stack[i].Tag == "table") return;
                if (stack[i].Tag == name) { stack.RemoveRange(i, stack.Count - i); return; }
            }
        }
        private static bool IsVoid(string name) { return name == "area" || name == "base" || name == "br" || name == "col" || name == "embed" || name == "hr" || name == "img" || name == "input" || name == "link" || name == "meta" || name == "param" || name == "source" || name == "track" || name == "wbr"; }
        private static bool IsHeading(string name) { return name.Length == 2 && name[0] == 'h' && name[1] >= '1' && name[1] <= '6'; }
        private static Node Ancestor(Node node, string tag) { for (var parent = node.Parent; parent != null; parent = parent.Parent) if (parent.Tag == tag) return parent; return null; }
        private static bool IsAncestor(Node ancestor, Node descendant) { for (var parent = descendant.Parent; parent != null; parent = parent.Parent) if (parent == ancestor) return true; return false; }
        private static bool ClaimedAncestor(Node node, ISet<Node> claimed) { for (var current = node; current != null; current = current.Parent) if (claimed.Contains(current)) return true; return false; }
        private static IEnumerable<Node> Descendants(Node node) { foreach (var child in node.Children) { yield return child; foreach (var descendant in Descendants(child)) yield return descendant; } }
        private static List<Node> TableRows(Node table) { return Descendants(table).Where(n => n.Tag == "tr" && Ancestor(n, "table") == table).ToList(); }
        private static List<Node> Cells(Node row) { return Descendants(row).Where(n => (n.Tag == "td" || n.Tag == "th") && Ancestor(n, "tr") == row).Take(MaximumCells).ToList(); }
        private static string FirstText(Document document, params string[] names) { foreach (string name in names) { var node = document.Nodes.FirstOrDefault(n => n.Tag == name); if (node != null) return Text(node); } return ""; }
        private static string Text(Node node) { return Text(node, MaximumCellCharacters, true); }
        private static string Text(Node node, int maximum, bool failIfLong)
        {
            var buffer = new StringBuilder();
            AppendText(node, buffer, maximum, failIfLong);
            var output = new StringBuilder(buffer.Length);
            bool space = false, line = false;
            foreach (char c in buffer.ToString())
            {
                if (char.IsWhiteSpace(c)) { if (c == '\n' || c == '\r') line = true; else space = true; continue; }
                if (output.Length > 0) { if (line) output.Append('\n'); else if (space) output.Append(' '); }
                output.Append(c); space = false; line = false;
            }
            return output.ToString().Trim();
        }
        private static void AppendText(Node node, StringBuilder text, int maximum, bool failIfLong)
        {
            if (text.Length >= maximum) { if (failIfLong) throw new InvalidDataException("A report field exceeds the supported text length."); return; }
            bool line = node.Tag == "br" || node.Tag == "p" || node.Tag == "div" || node.Tag == "tr" || node.Tag == "td" || node.Tag == "th" || node.Tag == "li" || IsHeading(node.Tag);
            if (line && text.Length > 0) text.Append('\n');
            if (node.Tag.Length == 0)
            {
                int available = Math.Max(0, maximum - text.Length);
                if (node.Value.Length > available && failIfLong) throw new InvalidDataException("A report field exceeds the supported text length.");
                text.Append(node.Value, 0, Math.Min(node.Value.Length, available));
            }
            foreach (var child in node.Children)
            {
                if (!failIfLong && text.Length >= maximum) break;
                AppendText(child, text, maximum, failIfLong);
            }
            if (line && text.Length < maximum) text.Append('\n');
        }
        private static string Context(Node node)
        {
            var pieces = new List<string>();
            for (var current = node; current.Parent != null && pieces.Count < 12; current = current.Parent)
            {
                int index = current.Parent.Children.IndexOf(current);
                for (int i = index - 1, scanned = 0; i >= 0 && pieces.Count < 12 && scanned < 64; i--, scanned++)
                {
                    var sibling = current.Parent.Children[i];
                    string value;
                    if (sibling.Tag == "table")
                    {
                        // Small two-column metadata tables commonly precede Navisworks result tables.
                        var rows = Descendants(sibling).Where(n => n.Tag == "tr" && Ancestor(n, "table") == sibling).Take(21).ToList();
                        if (rows.Count > 20 || rows.Any(r => Cells(r).Count != 2)) continue;
                        var labels = rows.Select(r => Label(Text(Cells(r)[0]))).ToList();
                        if (labels.Any(label => label == "item1" || label == "element1") || !labels.Any(label => label == "testname" || label == "testtype" || label == "clashtype" || label == "type")) continue;
                        value = Text(sibling, 4096, false);
                        if (labels.Any(label => label == "testname" || label == "clashtest" || label == "test"))
                        {
                            pieces.Add(value);
                            return string.Join("\n", pieces);
                        }
                    }
                    else
                    {
                        // A previous report section must not contribute its test type to this section.
                        if (sibling.Children.Any() && Descendants(sibling).Any(n => n.Tag == "table" || IsHeading(n.Tag))) continue;
                        value = Text(sibling, 4096, false);
                    }
                    if (!string.IsNullOrWhiteSpace(value)) pieces.Add(value);
                    if (IsHeading(sibling.Tag))
                    {
                        if (Field(value, "Test Type", "Clash Type", "Test Kind", "Criterion", "Criteria", "Type").Length > 0) continue;
                        if (Rx(@"^Clash\s*(?:[#: ]\s*|[0-9])").IsMatch(value) && !Contains(value, "report") && !Contains(value, "test"))
                        {
                            pieces.Add("Clash Name: " + value);
                            continue;
                        }
                        if (Field(value, "Test Name", "Clash Test", "Test").Length == 0 && !Contains(value, "report") && !Contains(value, "navisworks")) pieces.Add("Test Name: " + value);
                        return string.Join("\n", pieces);
                    }
                }
            }
            return string.Join("\n", pieces);
        }
    }
}
