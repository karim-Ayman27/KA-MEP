using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Xml;
using static PipeTakeoff.Core.XlsxExporter;

namespace PipeTakeoff.Core
{
    public sealed class ModelReviewReport
    {
        public string ProjectTitle { get; set; }
        public string Release { get; set; }
        public DateTime ScannedAt { get; set; }
        public bool IsComplete { get; set; }
        public double HealthScore { get; set; }
        public string HealthExplanation { get; set; }
        public List<ModelReviewReportRow> Rows { get; set; } = new List<ModelReviewReportRow>();
        public List<string> Notes { get; set; } = new List<string>();
    }

    public sealed class ModelReviewReportRow
    {
        public string Kind { get; set; }
        public string IssueKey { get; set; }
        public string IssueTitle { get; set; }
        public string Title { get; set; }
        public string Detail { get; set; }
        public List<long> ElementIds { get; set; } = new List<long>();
        public string CleanupAvailability { get; set; }
    }

    /// <summary>A static, three-sheet review report. Exporting never changes the model.</summary>
    public static class ModelReviewXlsxExporter
    {
        private const string Ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        private const int MaxRows = 1048576;

        public static void Export(string path, ModelReviewReport report)
        {
            if (string.IsNullOrWhiteSpace(path)) throw new ArgumentException("Choose an Excel file path.", nameof(path));
            if (report == null) throw new ArgumentNullException(nameof(report));
            if (report.Rows == null || report.Notes == null) throw new ArgumentException("Report rows and notes are required.", nameof(report));
            if (report.Rows.Count > MaxRows - 1 || report.Notes.Count > MaxRows - 20)
                throw new ArgumentException("The review report exceeds Excel's row limit.", nameof(report));
            if (report.Rows.Any(row => row == null)) throw new ArgumentException("A review finding is missing.", nameof(report));
            if (report.Rows.Any(row => row.ElementIds == null)) throw new ArgumentException("Finding element identifiers are required.", nameof(report));
            if (report.IsComplete && (double.IsNaN(report.HealthScore) || double.IsInfinity(report.HealthScore) ||
                report.HealthScore < 0 || report.HealthScore > 100))
                throw new ArgumentException("A completed review needs a finite score from 0 to 100.", nameof(report));

            string fullPath = Path.GetFullPath(path);
            if (!string.Equals(Path.GetExtension(fullPath), ".xlsx", StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("The export file must use the .xlsx extension.", nameof(path));
            string directory = Path.GetDirectoryName(fullPath);
            if (!Directory.Exists(directory)) throw new DirectoryNotFoundException("The export folder does not exist: " + directory);
            var summary = Summary(report);
            var info = Info(report);
            if (summary.Count > MaxRows - 1 || info.Count > MaxRows - 1)
                throw new ArgumentException("The review report exceeds Excel's row limit.", nameof(report));
            string temporary = Path.Combine(directory, "." + Path.GetFileName(fullPath) + "." + Guid.NewGuid().ToString("N") + ".tmp");
            try
            {
                using (var file = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                using (var archive = new ZipArchive(file, ZipArchiveMode.Create))
                {
                    WriteContentTypes(archive);
                    WriteRelationships(archive);
                    WriteWorkbook(archive, new[] { 5, 3, 2 }, new[] { report.Rows.Count + 1, summary.Count + 1, info.Count + 1 });
                    WriteStyles(archive);
                    WriteDetails(archive, report);
                    WriteSummary(archive, summary);
                    WriteInformation(archive, info);
                }
                if (File.Exists(fullPath)) File.Replace(temporary, fullPath, null);
                else File.Move(temporary, fullPath);
            }
            finally
            {
                try { if (File.Exists(temporary)) File.Delete(temporary); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }

        private static List<SummaryItem> Summary(ModelReviewReport report)
        {
            var issues = report.Rows.GroupBy(IssueKey, StringComparer.Ordinal)
                .OrderBy(group => group.First().Kind, StringComparer.OrdinalIgnoreCase)
                .ThenBy(group => IssueTitle(group.First()), StringComparer.OrdinalIgnoreCase).ToList();
            var rows = new List<SummaryItem>
            {
                new SummaryItem("Project", report.ProjectTitle, "Current document only; linked documents are not scanned."),
                new SummaryItem("Scan status", report.IsComplete ? "Complete" : "Incomplete",
                    report.IsComplete ? "The configured review checks completed. See Info for coverage and limitations."
                        : "Some checks did not complete. Findings are partial and the health score is unavailable."),
                new SummaryItem("KA MEP review score / 100", report.IsComplete ? (object)report.HealthScore : "Unavailable",
                    "Custom review indicator. It is not an Autodesk rating, a performance benchmark, or a guarantee of model correctness."),
                new SummaryItem("Scoring method", report.HealthExplanation, "Counts are taken from the complete scan, not from Excel filters."),
                new SummaryItem("Finding rows (occurrences)", report.Rows.Count, "All underlying occurrences are retained on Detail and used by the scoring method. This is not a unique element count."),
                new SummaryItem("Issue types", issues.Count, "Repeated occurrences of the same issue appear once below. Grouping changes presentation, not the review score.")
            };
            foreach (var group in report.Rows.GroupBy(row => string.IsNullOrWhiteSpace(row.Kind) ? "Unspecified" : row.Kind)
                .OrderBy(group => group.Key, StringComparer.OrdinalIgnoreCase))
                rows.Add(new SummaryItem("Count: " + group.Key, group.Count(), "Finding count for this check. A finding can refer to multiple elements."));
            foreach (var issue in issues)
                rows.Add(new SummaryItem("Issue: " + IssueTitle(issue.First()), issue.Count(),
                    "Occurrences; " + issue.SelectMany(row => row.ElementIds).Distinct().Count().ToString(CultureInfo.InvariantCulture) +
                    " distinct affected elements. Check: " + issue.First().Kind + ". Open Detail for individual findings; this summary does not authorize cleanup."));
            rows.Add(new SummaryItem("Snapshot time", report.ScannedAt.ToString("O", CultureInfo.InvariantCulture),
                "Changes made after the scan are not reflected. Refresh in KA MEP and export again."));
            return rows;
        }

        private static string IssueKey(ModelReviewReportRow row)
        {
            string kind = Normalize(row.Kind);
            string key = Normalize(row.IssueKey);
            if (key.Length == 0) key = kind == "REVITWARNING" ? Normalize(row.Title) : "CHECK";
            return kind + ":" + key;
        }

        private static string IssueTitle(ModelReviewReportRow row)
        {
            if (!string.IsNullOrWhiteSpace(row.IssueTitle)) return row.IssueTitle.Trim();
            switch (Normalize(row.Kind))
            {
                case "CADIMPORT": return "Imported CAD files";
                case "CADLINK": return "Linked CAD files (informational)";
                case "UNPLACEDVIEW": return "Views not placed on sheets";
                case "POTENTIALDUPLICATE": return "Potential duplicate elements";
                case "REVITWARNING": return string.IsNullOrWhiteSpace(row.Title) ? "Revit warning" : row.Title.Trim();
                default: return string.IsNullOrWhiteSpace(row.Kind) ? "Unspecified issue" : row.Kind.Trim();
            }
        }

        private static string Normalize(string value)
        {
            return string.Join(" ", (value ?? "").Split((char[])null, StringSplitOptions.RemoveEmptyEntries)).ToUpperInvariant();
        }

        private static List<KeyValuePair<string, object>> Info(ModelReviewReport report)
        {
            var rows = new List<KeyValuePair<string, object>>();
            Action<string, object> add = (key, value) => rows.Add(new KeyValuePair<string, object>(key, value));
            add("Application", "KA MEP — Model Review & Cleanup");
            add("Release / build", report.Release);
            add("Project", report.ProjectTitle);
            add("Scanned at (source timestamp)", report.ScannedAt.ToString("O", CultureInfo.InvariantCulture));
            add("Scope", "Current document. Imported and linked CAD instances, views not placed on sheets, potential duplicate groups, and Revit warnings. Check the scan notes for exclusions and partial coverage.");
            add("Scan status", report.IsComplete ? "Complete" : "Incomplete — health score unavailable");
            add("Health explanation", report.HealthExplanation);
            add("Review before cleanup", "An unplaced view or imported CAD instance may be intentional. A potential duplicate group requires manual review. This workbook does not approve or perform deletion.");
            add("Snapshot", "This workbook is a static report. Excel filters do not change the stored counts or score. Refresh in KA MEP after model changes to obtain a new score.");
            add("Issue summary", "Summary groups repeated issues by their check or native Revit warning definition. Occurrences count individual findings; affected elements are distinct within each issue. One element can occur in several issues. Every finding remains available on Detail.");
            add("Element identifiers", "Revit element IDs are text to preserve their exact digits. An ID applies only to the document and snapshot identified in this report.");
            add("Text handling", "All model text is stored as text, never executable formulas. Excel cells are limited to 32767 characters; invalid XML characters are replaced. Long cells may require expansion to read fully.");
            add("Addin creator", "Karim Ayman");
            add("Tel", "01032638143");
            add("LinkedIn", "karimayman27");
            add("Email", "mech.karim.ayman@gmail.com");
            for (int i = 0; i < report.Notes.Count; i++) add("Scan note " + (i + 1), report.Notes[i]);
            return rows;
        }

        private static void WriteDetails(ZipArchive archive, ModelReviewReport report)
        {
            AddXml(archive, "xl/worksheets/sheet1.xml", w =>
            {
                var headers = new[] { "Check", "Finding", "Review details", "Element IDs", "Cleanup availability" };
                Begin(w, "Detail", report.Rows.Count + 1, new[] { 24, 40, 80, 30, 42 });
                Header(w, headers);
                for (int i = 0; i < report.Rows.Count; i++)
                {
                    ModelReviewReportRow finding = report.Rows[i];
                    int row = i + 2;
                    Row(w, row, Math.Max(Lines(finding.Detail, 76), Math.Max(Lines(finding.Title, 36), Lines(finding.CleanupAvailability, 38))));
                    WriteCell(w, row, 1, finding.Kind, false, 12);
                    WriteCell(w, row, 2, finding.Title, false, 0);
                    WriteCell(w, row, 3, finding.Detail, false, 0);
                    WriteCell(w, row, 4, string.Join(", ", finding.ElementIds.Select(id => id.ToString(CultureInfo.InvariantCulture))), false, 0);
                    WriteCell(w, row, 5, finding.CleanupAvailability, false, 0);
                    w.WriteEndElement();
                }
                End(w, "E", report.Rows.Count + 1);
            });
        }

        private static void WriteSummary(ZipArchive archive, IList<SummaryItem> rows)
        {
            AddXml(archive, "xl/worksheets/sheet2.xml", w =>
            {
                Begin(w, "Summary", rows.Count + 1, new[] { 36, 65, 85 });
                Header(w, new[] { "Review metric", "Value", "Interpretation" });
                for (int i = 0; i < rows.Count; i++)
                {
                    int row = i + 2;
                    SummaryItem item = rows[i];
                    Row(w, row, Math.Max(Lines(Convert.ToString(item.Value, CultureInfo.InvariantCulture), 60), Lines(item.Explanation, 80)));
                    WriteCell(w, row, 1, item.Name, false, i == 2 ? 4 : 12);
                    bool numeric = item.Value is int || item.Value is double;
                    WriteCell(w, row, 2, item.Value, numeric, i == 2 ? (numeric ? 5 : 4) : numeric ? 7 : 0);
                    WriteCell(w, row, 3, item.Explanation, false, i == 2 ? 4 : 0);
                    w.WriteEndElement();
                }
                End(w, "C", rows.Count + 1);
            });
        }

        private static void WriteInformation(ZipArchive archive, IList<KeyValuePair<string, object>> rows)
        {
            AddXml(archive, "xl/worksheets/sheet3.xml", w =>
            {
                Begin(w, "Info", rows.Count + 1, new[] { 42, 110 });
                Header(w, new[] { "Property", "Value" });
                for (int i = 0; i < rows.Count; i++)
                {
                    int row = i + 2;
                    Row(w, row, Lines(Convert.ToString(rows[i].Value, CultureInfo.InvariantCulture), 100));
                    WriteCell(w, row, 1, rows[i].Key, false, 12);
                    WriteCell(w, row, 2, rows[i].Value, false, 0);
                    w.WriteEndElement();
                }
                End(w, "B", rows.Count + 1);
            });
        }

        private static int Lines(string value, int width)
        {
            return (value ?? "").Split('\n').Sum(line => Math.Max(1, (line.Length + width - 1) / width));
        }

        private static void Row(XmlWriter w, int row, int lines)
        {
            Start(w, "row", "r", row.ToString(CultureInfo.InvariantCulture), "ht",
                Math.Min(300, Math.Max(32, 16 * lines + 12)).ToString(CultureInfo.InvariantCulture), "customHeight", "1");
        }

        private static void Begin(XmlWriter w, string name, int rows, int[] widths)
        {
            w.WriteStartElement("worksheet", Ns);
            Start(w, "sheetPr");
            Empty(w, "tabColor", "rgb", name == "Summary" ? "FF007F78" : name == "Info" ? "FF8395A1" : "FF142D42");
            Empty(w, "pageSetUpPr", "fitToPage", "1");
            w.WriteEndElement();
            Empty(w, "dimension", "ref", "A1:" + (char)('A' + widths.Length - 1) + rows.ToString(CultureInfo.InvariantCulture));
            Start(w, "sheetViews");
            Start(w, "sheetView", "workbookViewId", "0", "showGridLines", "0", "tabSelected", name == "Summary" ? "1" : "0");
            Empty(w, "pane", "xSplit", "1", "ySplit", "1", "topLeftCell", "B2", "activePane", "bottomRight", "state", "frozen");
            Empty(w, "selection", "pane", "topRight", "activeCell", "B1", "sqref", "B1");
            Empty(w, "selection", "pane", "bottomLeft", "activeCell", "A2", "sqref", "A2");
            Empty(w, "selection", "pane", "bottomRight", "activeCell", "B2", "sqref", "B2");
            w.WriteEndElement(); w.WriteEndElement();
            Empty(w, "sheetFormatPr", "defaultRowHeight", "32");
            Start(w, "cols");
            for (int i = 0; i < widths.Length; i++)
            {
                string index = (i + 1).ToString(CultureInfo.InvariantCulture);
                Empty(w, "col", "min", index, "max", index, "width", widths[i].ToString(CultureInfo.InvariantCulture), "customWidth", "1");
            }
            w.WriteEndElement();
            Start(w, "sheetData");
        }

        private static void End(XmlWriter w, string lastColumn, int rows)
        {
            w.WriteEndElement();
            Empty(w, "autoFilter", "ref", "A1:" + lastColumn + rows.ToString(CultureInfo.InvariantCulture));
            Empty(w, "printOptions", "horizontalCentered", "1", "gridLines", "0");
            Empty(w, "pageMargins", "left", "0.25", "right", "0.25", "top", "0.6", "bottom", "0.55", "header", "0.25", "footer", "0.25");
            Empty(w, "pageSetup", "paperSize", "9", "orientation", "landscape", "fitToWidth", "1", "fitToHeight", "0");
            Start(w, "headerFooter");
            w.WriteElementString("oddHeader", Ns, "&L&\"Calibri,Bold\"&12&K142D42" + ReportBranding.VersionLabel + "&C&\"Calibri,Regular\"&10Model Review & Cleanup&R&A");
            w.WriteElementString("oddFooter", Ns, "&L&\"Calibri,Regular\"&9&K687F8CKarim Ayman&CPage &P of &N&R&D");
            w.WriteEndElement();
            w.WriteEndElement();
        }

        private static void Empty(XmlWriter w, string name, params string[] attributes)
        {
            Start(w, name, attributes);
            w.WriteEndElement();
        }

        private sealed class SummaryItem
        {
            internal SummaryItem(string name, object value, string explanation)
            {
                Name = name; Value = value; Explanation = explanation;
            }
            internal string Name;
            internal object Value;
            internal string Explanation;
        }
    }
}
