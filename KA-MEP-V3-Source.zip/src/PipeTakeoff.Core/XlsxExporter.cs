using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Xml;

namespace PipeTakeoff.Core
{
    /// <summary>Writes a native .xlsx workbook without Office automation or third-party packages.</summary>
    public static class XlsxExporter
    {
        private const string SpreadsheetNs = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        private const string DocumentRelNs = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        private const string PackageRelNs = "http://schemas.openxmlformats.org/package/2006/relationships";
        private const int MaxRows = 1048576;
        private const int MaxColumns = 16384;
        private const int MaxTextLength = 32767;

        public static void Export(string path, IList<PipeRecord> filteredRecords, TakeoffOptions options, ExportMetadata metadata)
        {
            if (string.IsNullOrWhiteSpace(path)) throw new ArgumentException("Choose an Excel file path.", nameof(path));
            if (filteredRecords == null) throw new ArgumentNullException(nameof(filteredRecords));
            TakeoffEngine.ValidateFilters(options);
            ValidateColumns(options.Columns);
            if (filteredRecords.Count > MaxRows - 2)
                throw new ArgumentException("The detail sheet exceeds Excel's row limit. Apply a filter and export again.", nameof(filteredRecords));
            List<SummaryRow> summary = TakeoffEngine.Summarize(filteredRecords, options);
            if (summary.Count > MaxRows - 2)
                throw new ArgumentException("The summary sheet exceeds Excel's row limit.", nameof(filteredRecords));
            metadata = metadata ?? new ExportMetadata();
            List<KeyValuePair<string, object>> info = CreateInfo(filteredRecords, summary, options, metadata);
            if (info.Count > MaxRows - 1) throw new ArgumentException("The information sheet exceeds Excel's row limit.", nameof(options));
            string fullPath = Path.GetFullPath(path);
            if (!string.Equals(Path.GetExtension(fullPath), ".xlsx", StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("The export file must use the .xlsx extension.", nameof(path));
            string directory = Path.GetDirectoryName(fullPath);
            if (!Directory.Exists(directory)) throw new DirectoryNotFoundException("The export folder does not exist: " + directory);
            // Build in the destination folder so the final replacement stays on the same volume.
            string temporary = Path.Combine(directory, "." + Path.GetFileName(fullPath) + "." + Guid.NewGuid().ToString("N") + ".tmp");
            try
            {
                using (var file = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                using (var archive = new ZipArchive(file, ZipArchiveMode.Create))
                {
                    WriteContentTypes(archive);
                    WriteRelationships(archive);
                    int summaryColumns = 3 + (options.GroupBySystem ? 1 : 0) + (options.GroupByFamily ? 1 : 0) + (options.GroupByType ? 1 : 0);
                    WriteWorkbook(archive, new[] { options.Columns.Count, summaryColumns, 2 },
                        new[] { filteredRecords.Count + 2, summary.Count + 2, info.Count + 1 });
                    WriteStyles(archive);
                    WriteDetails(archive, filteredRecords, options.Columns);
                    WriteSummary(archive, summary, options);
                    WriteInfo(archive, info);
                }
                if (File.Exists(fullPath)) File.Replace(temporary, fullPath, null);
                else File.Move(temporary, fullPath);
            }
            finally
            {
                // A failed export must never truncate an existing workbook.
                try { if (File.Exists(temporary)) File.Delete(temporary); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }

        internal static void ValidateColumns(IList<FieldDefinition> columns)
        {
            if (columns == null || columns.Count == 0) throw new ArgumentException("Select at least one export column.");
            if (columns.Count > MaxColumns) throw new ArgumentException("The selected columns exceed Excel's column limit.");
            var keys = new HashSet<string>(StringComparer.Ordinal);
            foreach (FieldDefinition field in columns)
            {
                if (field == null || string.IsNullOrWhiteSpace(field.Key)) throw new ArgumentException("An export column is missing its parameter key.");
                if (!keys.Add(field.Key)) throw new ArgumentException("An export column is selected more than once: " + field.Header);
            }
        }

        internal static void WriteContentTypes(ZipArchive archive)
        {
            AddXml(archive, "[Content_Types].xml", w =>
            {
                const string ns = "http://schemas.openxmlformats.org/package/2006/content-types";
                w.WriteStartElement("Types", ns);
                Empty(w, "Default", ns, "Extension", "rels", "ContentType", "application/vnd.openxmlformats-package.relationships+xml");
                Empty(w, "Default", ns, "Extension", "xml", "ContentType", "application/xml");
                Empty(w, "Override", ns, "PartName", "/xl/workbook.xml", "ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml");
                Empty(w, "Override", ns, "PartName", "/xl/styles.xml", "ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml");
                for (int i = 1; i <= 3; i++)
                    Empty(w, "Override", ns, "PartName", "/xl/worksheets/sheet" + i + ".xml", "ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml");
                w.WriteEndElement();
            });
        }

        internal static void WriteRelationships(ZipArchive archive)
        {
            AddXml(archive, "_rels/.rels", w =>
            {
                w.WriteStartElement("Relationships", PackageRelNs);
                Empty(w, "Relationship", PackageRelNs, "Id", "rId1", "Type", DocumentRelNs + "/officeDocument", "Target", "xl/workbook.xml");
                w.WriteEndElement();
            });
            AddXml(archive, "xl/_rels/workbook.xml.rels", w =>
            {
                w.WriteStartElement("Relationships", PackageRelNs);
                for (int i = 1; i <= 3; i++)
                    Empty(w, "Relationship", PackageRelNs, "Id", "rId" + i, "Type", DocumentRelNs + "/worksheet", "Target", "worksheets/sheet" + i + ".xml");
                Empty(w, "Relationship", PackageRelNs, "Id", "rId4", "Type", DocumentRelNs + "/styles", "Target", "styles.xml");
                w.WriteEndElement();
            });
        }

        internal static void WriteWorkbook(ZipArchive archive, int[] sheetColumns = null, int[] sheetRows = null)
        {
            AddXml(archive, "xl/workbook.xml", w =>
            {
                w.WriteStartElement("workbook", SpreadsheetNs);
                w.WriteAttributeString("xmlns", "r", null, DocumentRelNs);
                w.WriteStartElement("bookViews", SpreadsheetNs);
                Empty(w, "workbookView", SpreadsheetNs, "activeTab", "1");
                w.WriteEndElement();
                w.WriteStartElement("sheets", SpreadsheetNs);
                string[] names = { "Detail", "Summary", "Info" };
                for (int i = 0; i < names.Length; i++)
                {
                    w.WriteStartElement("sheet", SpreadsheetNs);
                    w.WriteAttributeString("name", names[i]);
                    w.WriteAttributeString("sheetId", (i + 1).ToString(CultureInfo.InvariantCulture));
                    w.WriteAttributeString("r", "id", DocumentRelNs, "rId" + (i + 1));
                    w.WriteEndElement();
                }
                w.WriteEndElement();
                w.WriteStartElement("definedNames", SpreadsheetNs);
                for (int i = 0; i < names.Length; i++)
                {
                    Start(w, "definedName", "name", "_xlnm.Print_Titles", "localSheetId", i.ToString(CultureInfo.InvariantCulture));
                    w.WriteString("'" + names[i] + "'!$1:$1");
                    w.WriteEndElement();
                    if (sheetColumns != null && sheetRows != null && sheetColumns.Length > i && sheetRows.Length > i)
                    {
                        Start(w, "definedName", "name", "_xlnm.Print_Area", "localSheetId", i.ToString(CultureInfo.InvariantCulture));
                        w.WriteString("'" + names[i] + "'!$A$1:$" + ColumnName(sheetColumns[i]) + "$" + sheetRows[i].ToString(CultureInfo.InvariantCulture));
                        w.WriteEndElement();
                    }
                }
                w.WriteEndElement();
                w.WriteEndElement();
            });
        }

        internal static void WriteStyles(ZipArchive archive)
        {
            AddXml(archive, "xl/styles.xml", w =>
            {
                w.WriteStartElement("styleSheet", SpreadsheetNs);
                Start(w, "numFmts", "count", "2");
                Empty(w, "numFmt", SpreadsheetNs, "numFmtId", "164", "formatCode", "#,##0.000");
                Empty(w, "numFmt", SpreadsheetNs, "numFmtId", "165", "formatCode", "0.######");
                w.WriteEndElement();
                Start(w, "fonts", "count", "3");
                WriteFont(w, false, "FF243C4B"); WriteFont(w, true, "FFFFFFFF"); WriteFont(w, true, "FF142D42");
                w.WriteEndElement();
                Start(w, "fills", "count", "5");
                WriteFill(w, "none", null); WriteFill(w, "gray125", null); WriteFill(w, "solid", "FF142D42");
                WriteFill(w, "solid", "FF007F78"); WriteFill(w, "solid", "FFF0F6F8");
                w.WriteEndElement();
                Start(w, "borders", "count", "2");
                w.WriteStartElement("border", SpreadsheetNs);
                foreach (string side in new[] { "left", "right", "top", "bottom", "diagonal" }) Empty(w, side, SpreadsheetNs);
                w.WriteEndElement();
                w.WriteStartElement("border", SpreadsheetNs);
                foreach (string side in new[] { "left", "right", "top" }) Empty(w, side, SpreadsheetNs);
                Start(w, "bottom", "style", "hair");
                Empty(w, "color", SpreadsheetNs, "rgb", "FFD7E3E8");
                w.WriteEndElement();
                Empty(w, "diagonal", SpreadsheetNs);
                w.WriteEndElement(); w.WriteEndElement();
                Start(w, "cellStyleXfs", "count", "1");
                Empty(w, "xf", SpreadsheetNs, "numFmtId", "0", "fontId", "0", "fillId", "0", "borderId", "0");
                w.WriteEndElement();
                Start(w, "cellXfs", "count", "14");
                WriteXf(w, 0, 0, 0); WriteXf(w, 0, 1, 2); WriteXf(w, 164, 0, 0); WriteXf(w, 1, 0, 0);
                WriteXf(w, 0, 1, 3); WriteXf(w, 164, 1, 3); WriteXf(w, 1, 1, 3); WriteXf(w, 165, 0, 0);
                // Styles 0..7 retain their meanings for every takeoff exporter.
                WriteXf(w, 0, 0, 4); WriteXf(w, 164, 0, 4); WriteXf(w, 1, 0, 4); WriteXf(w, 165, 0, 4);
                WriteXf(w, 0, 2, 0); WriteXf(w, 0, 2, 4);
                w.WriteEndElement();
                Start(w, "cellStyles", "count", "1");
                Empty(w, "cellStyle", SpreadsheetNs, "name", "Normal", "xfId", "0", "builtinId", "0");
                w.WriteEndElement(); w.WriteEndElement();
            });
        }

        private static void WriteFont(XmlWriter w, bool bold, string color)
        {
            w.WriteStartElement("font", SpreadsheetNs);
            if (bold) Empty(w, "b", SpreadsheetNs);
            Empty(w, "sz", SpreadsheetNs, "val", "11");
            Empty(w, "color", SpreadsheetNs, "rgb", color);
            Empty(w, "name", SpreadsheetNs, "val", "Calibri");
            w.WriteEndElement();
        }
        private static void WriteFill(XmlWriter w, string pattern, string color)
        {
            w.WriteStartElement("fill", SpreadsheetNs);
            Start(w, "patternFill", "patternType", pattern);
            if (color != null)
            {
                Empty(w, "fgColor", SpreadsheetNs, "rgb", color);
                Empty(w, "bgColor", SpreadsheetNs, "indexed", "64");
            }
            w.WriteEndElement(); w.WriteEndElement();
        }
        private static void WriteXf(XmlWriter w, int format, int font, int fill)
        {
            Start(w, "xf", "numFmtId", format.ToString(CultureInfo.InvariantCulture),
                "fontId", font.ToString(CultureInfo.InvariantCulture), "fillId", fill.ToString(CultureInfo.InvariantCulture),
                "borderId", "1", "xfId", "0", "applyNumberFormat", "1", "applyFont", "1", "applyFill", "1", "applyBorder", "1", "applyAlignment", "1");
            Empty(w, "alignment", SpreadsheetNs, "vertical", "center", "horizontal", format == 0 ? "left" : "right", "wrapText", "1", "indent", "1");
            w.WriteEndElement();
        }

        private static void WriteDetails(ZipArchive archive, IList<PipeRecord> records, IList<FieldDefinition> columns)
        {
            AddXml(archive, "xl/worksheets/sheet1.xml", w =>
            {
                BeginSheet(w, columns.Count, records.Count + 2, columns.Select(c => c.Header).ToList());
                Header(w, columns.Select(c => c.Header).ToList());
                double totalLength = 0;
                for (int i = 0; i < records.Count; i++)
                {
                    int row = i + 2;
                    Start(w, "row", "r", row.ToString(CultureInfo.InvariantCulture));
                    for (int c = 0; c < columns.Count; c++)
                    {
                        FieldDefinition field = columns[c];
                        WriteCell(w, row, c + 1, records[i].Get(field.Key), field.IsNumeric, field.IsNumeric ? (field.Key == "Length" ? 2 : 7) : 0);
                    }
                    totalLength += TakeoffEngine.Measurement(records[i], "Length");
                    w.WriteEndElement();
                }
                int totalRow = records.Count + 2;
                Start(w, "row", "r", totalRow.ToString(CultureInfo.InvariantCulture), "ht", "34", "customHeight", "1");
                bool labelWritten = false;
                for (int c = 0; c < columns.Count; c++)
                {
                    if (columns[c].Key == "Length") WriteCell(w, totalRow, c + 1, totalLength, true, 5);
                    else if (!labelWritten) { WriteCell(w, totalRow, c + 1, "TOTAL", false, 4); labelWritten = true; }
                    else WriteCell(w, totalRow, c + 1, null, false, 4);
                }
                w.WriteEndElement();
                EndSheet(w, columns.Count, records.Count + 1);
            });
        }

        private static void WriteSummary(ZipArchive archive, IList<SummaryRow> rows, TakeoffOptions options)
        {
            var headers = new List<string> { "Diameter (mm)" };
            if (options.GroupBySystem) headers.Add("Piping System");
            if (options.GroupByFamily) headers.Add("Family");
            if (options.GroupByType) headers.Add("Type");
            headers.Add("Pipe Count"); headers.Add("Total Length (m)");
            AddXml(archive, "xl/worksheets/sheet2.xml", w =>
            {
                BeginSheet(w, headers.Count, rows.Count + 2, headers, "Summary");
                Header(w, headers);
                int count = 0; double length = 0;
                for (int i = 0; i < rows.Count; i++)
                {
                    SummaryRow record = rows[i]; int row = i + 2; int column = 1;
                    Start(w, "row", "r", row.ToString(CultureInfo.InvariantCulture));
                    WriteCell(w, row, column++, record.DiameterMillimeters, true, 7);
                    if (options.GroupBySystem) WriteCell(w, row, column++, record.SystemName, false, 0);
                    if (options.GroupByFamily) WriteCell(w, row, column++, record.Family, false, 0);
                    if (options.GroupByType) WriteCell(w, row, column++, record.Type, false, 0);
                    WriteCell(w, row, column++, record.Count, true, 3);
                    WriteCell(w, row, column, record.TotalLengthMeters, true, 2);
                    checked { count += record.Count; }
                    length += record.TotalLengthMeters;
                    w.WriteEndElement();
                }
                int totalRow = rows.Count + 2;
                Start(w, "row", "r", totalRow.ToString(CultureInfo.InvariantCulture), "ht", "34", "customHeight", "1");
                WriteCell(w, totalRow, 1, "TOTAL", false, 4);
                for (int c = 2; c <= headers.Count - 2; c++) WriteCell(w, totalRow, c, null, false, 4);
                WriteCell(w, totalRow, headers.Count - 1, count, true, 6);
                WriteCell(w, totalRow, headers.Count, length, true, 5);
                w.WriteEndElement();
                EndSheet(w, headers.Count, rows.Count + 1);
            });
        }

        private static List<KeyValuePair<string, object>> CreateInfo(IList<PipeRecord> records, IList<SummaryRow> summary, TakeoffOptions options, ExportMetadata metadata)
        {
            var info = new List<KeyValuePair<string, object>>();
            Action<string, object> add = (key, value) => info.Add(new KeyValuePair<string, object>(key, value));
            add("Project", metadata.Project); add("Application", ReportBranding.VersionLabel + " — Pipe Takeoff");
            add("Revit version", metadata.RevitVersion); add("Scope", metadata.Scope);
            add("Exported at (workstation local time)", metadata.ExportedAt.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
            add("Exported pipe count", records.Count); add("Total length (m)", summary.Sum(r => r.TotalLengthMeters));
            add("Summary group count", summary.Count);
            var keys = new List<string> { "Nominal diameter (mm), rounded to 6 decimal places" };
            if (options.GroupBySystem) keys.Add("Piping System");
            if (options.GroupByFamily) keys.Add("Family");
            if (options.GroupByType) keys.Add("Type");
            add("Summary grouping", string.Join(" + ", keys));
            add("Length unit", "Meters (m); stored as numbers without display rounding.");
            add("Diameter unit", "Millimeters (mm); nominal diameter from the pipe parameter.");
            add("Additional numeric parameters", "Values use Revit project units; column headers identify the unit where available.");
            add("Filter matching", options.Match == FilterMatch.All ? "All rules (AND)" : "Any rule (OR)");
            add("Filter comparison", "Text comparisons ignore case. Missing values match IsEmpty and fail value comparisons, including NotEquals.");
            add("Numeric filter tolerance", "Numbers are equal within max(1e-9, max(abs(left), abs(right)) * 1e-12), in each column's units, to accommodate unit conversion roundoff.");
            add("Totals", "Totals reflect all exported records. Excel AutoFilter does not recalculate the static totals.");
            add("Text handling", "Cell text is limited to 32767 characters. Invalid XML characters are replaced with U+FFFD. All user text is stored as text, never formulas.");
            add("Addin creator", "Karim Ayman"); add("Tel", "01032638143");
            add("LinkedIn", "karimayman27"); add("Email", "mech.karim.ayman@gmail.com");
            if (options.Filters.Count == 0) add("Filters", "None");
            else for (int i = 0; i < options.Filters.Count; i++)
            {
                FilterRule rule = options.Filters[i];
                add("Filter " + (i + 1), rule.Field.Header + " " + rule.Operator + " " + (rule.Value ?? ""));
            }
            return info;
        }

        internal static void WriteInfo(ZipArchive archive, IList<KeyValuePair<string, object>> rows)
        {
            AddXml(archive, "xl/worksheets/sheet3.xml", w =>
            {
                var headers = new List<string> { "Property", "Value" };
                BeginSheet(w, 2, rows.Count + 1, headers, "Info");
                Header(w, headers);
                for (int i = 0; i < rows.Count; i++)
                {
                    int row = i + 2;
                    int lines = Math.Max(WrappedLineCount(rows[i].Key, 37), WrappedLineCount(TakeoffEngine.Text(rows[i].Value), 95));
                    int height = Math.Min(300, Math.Max(30, 16 * lines + 12));
                    Start(w, "row", "r", row.ToString(CultureInfo.InvariantCulture), "ht", height.ToString(CultureInfo.InvariantCulture), "customHeight", "1");
                    WriteCell(w, row, 1, rows[i].Key, false, 12);
                    bool number = rows[i].Value is int || rows[i].Value is double;
                    WriteCell(w, row, 2, rows[i].Value, number, number ? 7 : 0);
                    w.WriteEndElement();
                }
                EndSheet(w, 2, rows.Count + 1);
            });
        }

        private static int WrappedLineCount(string value, int width)
        {
            return (value ?? "").Split('\n').Sum(line => Math.Max(1, (line.Length + width - 1) / width));
        }

        internal static void BeginSheet(XmlWriter w, int columns, int rows, IList<string> headers, string sheetName = "Detail")
        {
            w.WriteStartElement("worksheet", SpreadsheetNs);
            w.WriteStartElement("sheetPr", SpreadsheetNs);
            Empty(w, "tabColor", SpreadsheetNs, "rgb", sheetName == "Summary" ? "FF007F78" : sheetName == "Info" ? "FF8395A1" : "FF142D42");
            Empty(w, "pageSetUpPr", SpreadsheetNs, "fitToPage", "1");
            w.WriteEndElement();
            Empty(w, "dimension", SpreadsheetNs, "ref", "A1:" + ColumnName(columns) + rows);
            w.WriteStartElement("sheetViews", SpreadsheetNs);
            Start(w, "sheetView", "workbookViewId", "0", "showGridLines", "0", "tabSelected", sheetName == "Summary" ? "1" : "0");
            Empty(w, "pane", SpreadsheetNs, "xSplit", "1", "ySplit", "1", "topLeftCell", "B2", "activePane", "bottomRight", "state", "frozen");
            Empty(w, "selection", SpreadsheetNs, "pane", "topRight", "activeCell", "B1", "sqref", "B1");
            Empty(w, "selection", SpreadsheetNs, "pane", "bottomLeft", "activeCell", "A2", "sqref", "A2");
            Empty(w, "selection", SpreadsheetNs, "pane", "bottomRight", "activeCell", "B2", "sqref", "B2");
            w.WriteEndElement(); w.WriteEndElement();
            Empty(w, "sheetFormatPr", SpreadsheetNs, "defaultRowHeight", "22");
            w.WriteStartElement("cols", SpreadsheetNs);
            for (int i = 0; i < columns; i++)
            {
                string index = (i + 1).ToString(CultureInfo.InvariantCulture);
                string header = headers[i] ?? "";
                int width = Math.Min(48, Math.Max(20, header.Length + 6));
                if (header == "Family" || header == "Type" || header.IndexOf("System", StringComparison.OrdinalIgnoreCase) >= 0 || header.IndexOf("Service", StringComparison.OrdinalIgnoreCase) >= 0) width = Math.Max(30, width);
                if (header.IndexOf("connector", StringComparison.OrdinalIgnoreCase) >= 0) width = Math.Max(38, width);
                if (header.IndexOf("Comments", StringComparison.OrdinalIgnoreCase) >= 0) width = 48;
                if (sheetName == "Info") width = i == 0 ? 42 : 105;
                Empty(w, "col", SpreadsheetNs, "min", index, "max", index, "width", width.ToString(CultureInfo.InvariantCulture), "customWidth", "1");
            }
            w.WriteEndElement();
            w.WriteStartElement("sheetData", SpreadsheetNs);
        }
        internal static void Header(XmlWriter w, IList<string> headers)
        {
            Start(w, "row", "r", "1", "ht", "36", "customHeight", "1");
            for (int i = 0; i < headers.Count; i++) WriteCell(w, 1, i + 1, headers[i], false, 1);
            w.WriteEndElement();
        }
        internal static void EndSheet(XmlWriter w, int columns, int filterEndRow)
        {
            w.WriteEndElement();
            Empty(w, "autoFilter", SpreadsheetNs, "ref", "A1:" + ColumnName(columns) + filterEndRow);
            Empty(w, "printOptions", SpreadsheetNs, "horizontalCentered", "1", "gridLines", "0");
            Empty(w, "pageMargins", SpreadsheetNs, "left", "0.25", "right", "0.25", "top", "0.6", "bottom", "0.55", "header", "0.25", "footer", "0.25");
            Empty(w, "pageSetup", SpreadsheetNs, "paperSize", "9", "orientation", "landscape", "fitToWidth", "1", "fitToHeight", "0");
            w.WriteStartElement("headerFooter", SpreadsheetNs);
            w.WriteElementString("oddHeader", SpreadsheetNs, "&L&\"Calibri,Bold\"&12&K142D42" + ReportBranding.VersionLabel + "&C&\"Calibri,Regular\"&10Quantity Takeoff&R&A");
            w.WriteElementString("oddFooter", SpreadsheetNs, "&L&\"Calibri,Regular\"&9&K687F8CKarim Ayman&CPage &P of &N&R&D");
            w.WriteEndElement();
            w.WriteEndElement();
        }
        internal static void WriteCell(XmlWriter w, int row, int column, object value, bool numeric, int style)
        {
            if (row > 1 && row % 2 == 0)
            {
                if (style == 0) style = 8;
                else if (style == 2) style = 9;
                else if (style == 3) style = 10;
                else if (style == 7) style = 11;
                else if (style == 12) style = 13;
            }
            Start(w, "c", "r", ColumnName(column) + row.ToString(CultureInfo.InvariantCulture), "s", style.ToString(CultureInfo.InvariantCulture));
            if (value == null || (numeric && string.IsNullOrWhiteSpace(TakeoffEngine.Text(value)))) { w.WriteEndElement(); return; }
            if (numeric)
            {
                double number;
                if (!TakeoffEngine.TryNumber(value, out number))
                    throw new ArgumentException("A numeric export value is invalid at " + ColumnName(column) + row + ".");
                w.WriteElementString("v", SpreadsheetNs, number.ToString("R", CultureInfo.InvariantCulture));
            }
            else
            {
                // Inline strings prevent =, +, -, @ and hyperlinks in model data becoming executable formulas.
                w.WriteAttributeString("t", "inlineStr");
                w.WriteStartElement("is", SpreadsheetNs);
                w.WriteStartElement("t", SpreadsheetNs);
                w.WriteAttributeString("xml", "space", "http://www.w3.org/XML/1998/namespace", "preserve");
                w.WriteString(SafeText(TakeoffEngine.Text(value)));
                w.WriteEndElement(); w.WriteEndElement();
            }
            w.WriteEndElement();
        }

        private static string SafeText(string value)
        {
            int length = Math.Min(value.Length, MaxTextLength);
            if (length < value.Length && length > 0 && char.IsHighSurrogate(value[length - 1])) length--;
            var result = new StringBuilder(length);
            for (int i = 0; i < length; i++)
            {
                char c = value[i];
                // Escape SpreadsheetML's literal _xHHHH_ convention before writing text.
                if (c == '_' && i + 6 < length && value[i + 1] == 'x' && value[i + 6] == '_' &&
                    IsHex(value[i + 2]) && IsHex(value[i + 3]) && IsHex(value[i + 4]) && IsHex(value[i + 5]))
                    result.Append("_x005F_");
                else if (char.IsHighSurrogate(c) && i + 1 < length && char.IsLowSurrogate(value[i + 1]))
                { result.Append(c); result.Append(value[++i]); }
                else if (char.IsSurrogate(c) || !XmlConvert.IsXmlChar(c)) result.Append('\uFFFD');
                else result.Append(c);
            }
            return result.ToString();
        }
        private static bool IsHex(char c) { return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F'); }
        private static string ColumnName(int column)
        {
            string name = "";
            while (column > 0) { column--; name = (char)('A' + column % 26) + name; column /= 26; }
            return name;
        }
        internal static void AddXml(ZipArchive archive, string path, Action<XmlWriter> write)
        {
            ZipArchiveEntry entry = archive.CreateEntry(path, CompressionLevel.Optimal);
            using (Stream stream = entry.Open())
            using (XmlWriter writer = XmlWriter.Create(stream, new XmlWriterSettings { Encoding = new UTF8Encoding(false), Indent = false, CloseOutput = false, CheckCharacters = true }))
            {
                writer.WriteStartDocument(true); write(writer); writer.WriteEndDocument();
            }
        }
        internal static void Start(XmlWriter w, string name, params string[] attributes)
        {
            w.WriteStartElement(name, SpreadsheetNs);
            for (int i = 0; i < attributes.Length; i += 2) w.WriteAttributeString(attributes[i], attributes[i + 1]);
        }
        private static void Empty(XmlWriter w, string name, string ns, params string[] attributes)
        {
            w.WriteStartElement(name, ns);
            for (int i = 0; i < attributes.Length; i += 2) w.WriteAttributeString(attributes[i], attributes[i + 1]);
            w.WriteEndElement();
        }
    }
}
