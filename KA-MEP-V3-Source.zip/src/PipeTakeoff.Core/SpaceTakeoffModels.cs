using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace PipeTakeoff.Core
{
    public enum SpaceTakeoffScope { Model, ActiveView, Selection }
    public enum SpaceSurfaceKind { FloorTop, SlabBottom, CeilingBottom }
    public enum SpaceHeightBasis { None, Ceiling, Slab, Mixed }
    public enum SpaceMeasurementStatus
    {
        Unmeasured, Measured, VariableHeight, PartialCoverage, MixedOverhead,
        MissingFloor, MissingOverhead, Unplaced, NotEnclosed, GeometryUnavailable, NeedsReview
    }

    /// <summary>All dimensions in these detached models use metres and square metres.</summary>
    public sealed class SpaceTakeoffOptions
    {
        public SpaceTakeoffScope Scope { get; set; } = SpaceTakeoffScope.Model;
        public long PhaseId { get; set; } = -1;
        public bool IncludeHostGeometry { get; set; } = false;
        public bool IncludeLinkedGeometry { get; set; } = true;
        public long SelectedLinkInstanceId { get; set; } = -1;
        public double FloorSearchToleranceMeters { get; set; } = 1.0;
        public double MaximumHeightMeters { get; set; } = 12.0;
        public int SampleGridSize { get; set; } = 5;
        public double HeightVariationToleranceMeters { get; set; } = 0.02;

        public SpaceTakeoffOptions Copy() { return (SpaceTakeoffOptions)MemberwiseClone(); }
        public void Validate()
        {
            if (!Enum.IsDefined(typeof(SpaceTakeoffScope), Scope)) throw new ArgumentOutOfRangeException(nameof(Scope));
            if (SelectedLinkInstanceId < -1) throw new ArgumentOutOfRangeException(nameof(SelectedLinkInstanceId));
            if (!IncludeHostGeometry && !IncludeLinkedGeometry) throw new ArgumentException("Select at least one geometry source.");
            if (!Finite(FloorSearchToleranceMeters) || FloorSearchToleranceMeters <= 0 || FloorSearchToleranceMeters > 5)
                throw new ArgumentOutOfRangeException(nameof(FloorSearchToleranceMeters), "Floor search tolerance must be above zero and at most 5 m.");
            if (!Finite(MaximumHeightMeters) || MaximumHeightMeters < 0.1 || MaximumHeightMeters > 100)
                throw new ArgumentOutOfRangeException(nameof(MaximumHeightMeters), "Maximum height must be between 0.1 and 100 m.");
            if (SampleGridSize < 3 || SampleGridSize > 11) throw new ArgumentOutOfRangeException(nameof(SampleGridSize), "Use a grid between 3 and 11 samples per axis.");
            if (!Finite(HeightVariationToleranceMeters) || HeightVariationToleranceMeters < 0.001 || HeightVariationToleranceMeters > 0.2)
                throw new ArgumentOutOfRangeException(nameof(HeightVariationToleranceMeters), "Height variation tolerance must be between 0.001 and 0.2 m.");
        }
        internal static bool Finite(double value) { return !double.IsNaN(value) && !double.IsInfinity(value); }
    }

    public sealed class SpacePhaseOption
    {
        public long Id { get; set; }
        public string Name { get; set; } = "";
        public override string ToString() { return Name; }
    }

    public sealed class SpaceLinkOption
    {
        public long Id { get; set; }
        public string Name { get; set; } = "";
        public bool IsLoaded { get; set; } = true;
        public override string ToString() { return Name; }
    }

    public sealed class SpaceTakeoffSnapshot
    {
        public string ProjectTitle { get; set; } = "";
        public string RevitVersion { get; set; } = "";
        public string Release { get; set; } = "";
        public string ScopeLabel { get; set; } = "";
        public DateTime ScannedAt { get; set; }
        public SpaceTakeoffOptions Options { get; set; } = new SpaceTakeoffOptions();
        public bool IsComplete { get; set; } = true;
        public List<SpaceTakeoffRow> Rows { get; set; } = new List<SpaceTakeoffRow>();
        public List<string> Notes { get; set; } = new List<string>();
        public SpaceOpeningScanResult OpeningScan { get; set; } = new SpaceOpeningScanResult();
    }

    public sealed class SpaceTakeoffRow
    {
        public long SpaceId { get; set; }
        public string SpaceUniqueId { get; set; } = "";
        public string SpaceNumber { get; set; } = "";
        public string SpaceName { get; set; } = "";
        public string RoomNumber { get; set; } = "";
        public string RoomName { get; set; } = "";
        public string RoomIdentitySource { get; set; } = "";
        public SpaceSurfaceSource RoomSource { get; set; }
        public string RoomUniqueId { get; set; } = "";
        public bool RoomIdentityVerified { get { return RoomSource != null && !string.IsNullOrWhiteSpace(RoomUniqueId); } }
        public string LevelName { get; set; } = "";
        public string PhaseName { get; set; } = "";
        public double? AreaSquareMeters { get; set; }
        public double? BaseElevationMeters { get; set; }
        public double? ClearHeightMeters { get; set; }
        public double? MinHeightMeters { get; set; }
        public double? MaxHeightMeters { get; set; }
        public SpaceHeightBasis HeightBasis { get; set; }
        public SpaceMeasurementStatus Status { get; set; } = SpaceMeasurementStatus.Unmeasured;
        public bool NeedsReview { get { return Status != SpaceMeasurementStatus.Measured || !RoomIdentityVerified || !OpeningTotals.Complete ||
            OpeningTotals.DoorMissingDimensionCount > 0 || OpeningTotals.WindowMissingDimensionCount > 0; } }
        public string StatusLabel { get { return SpaceTakeoffLabels.Status(Status); } }
        public List<SpaceHeightSample> Samples { get; set; } = new List<SpaceHeightSample>();
        public List<string> Notes { get; set; } = new List<string>();
        public List<SpaceOpeningRecord> Openings { get; set; } = new List<SpaceOpeningRecord>();
        public bool OpeningsComplete { get; set; }
        public List<string> OpeningNotes { get; set; } = new List<string>();
        public SpaceOpeningTotals OpeningTotals { get { return SpaceOpeningSummary.ForSpace(Openings, OpeningsComplete && RoomIdentityVerified); } }
        public int SamplesAttempted { get { return Samples.Count; } }
        public int SamplesMeasured { get { return Samples.Count(s => s.HeightMeters.HasValue && s.Status == SpaceMeasurementStatus.Measured); } }
        public string FloorSources { get { return Sources(Samples.Select(s => s.FloorSource)); } }
        public string OverheadSources { get { return Sources(Samples.Select(s => s.OverheadSource)); } }
        private static string Sources(IEnumerable<SpaceSurfaceSource> sources)
        {
            return string.Join("; ", sources.Where(s => s != null).Select(s => s.Label).Distinct(StringComparer.Ordinal).OrderBy(s => s, StringComparer.Ordinal));
        }
    }

    public sealed class SpaceHeightSample
    {
        public int SampleNumber { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public double BaseElevationMeters { get; set; }
        public double? FloorElevationMeters { get; set; }
        public double? OverheadElevationMeters { get; set; }
        public double? HeightMeters { get; set; }
        public SpaceHeightBasis HeightBasis { get; set; }
        public SpaceMeasurementStatus Status { get; set; } = SpaceMeasurementStatus.Unmeasured;
        public string StatusLabel { get { return SpaceTakeoffLabels.Status(Status); } }
        public SpaceSurfaceSource FloorSource { get; set; }
        public SpaceSurfaceSource OverheadSource { get; set; }
        public string Notes { get; set; } = "";
    }

    public sealed class SpaceSurfaceSource
    {
        public string DocumentTitle { get; set; } = "";
        public long LinkInstanceId { get; set; } = -1;
        public long ElementId { get; set; }
        public string ElementName { get; set; } = "";
        public string Key { get { return DocumentTitle + "|" + LinkInstanceId.ToString(CultureInfo.InvariantCulture) + "|" + ElementId.ToString(CultureInfo.InvariantCulture); } }
        public string Label
        {
            get
            {
                return DocumentTitle + (LinkInstanceId < 0 ? " / host" : " / link " + LinkInstanceId.ToString(CultureInfo.InvariantCulture)) +
                    " / " + ElementName + " [" + ElementId.ToString(CultureInfo.InvariantCulture) + "]";
            }
        }
    }

    public struct SpacePoint3
    {
        public SpacePoint3(double x, double y, double z) { X = x; Y = y; Z = z; }
        public double X { get; private set; }
        public double Y { get; private set; }
        public double Z { get; private set; }
    }

    public sealed class SpaceSurfaceTriangle
    {
        public SpaceSurfaceTriangle(SpacePoint3 a, SpacePoint3 b, SpacePoint3 c, SpaceSurfaceKind kind, SpaceSurfaceSource source)
        { A = a; B = b; C = c; Kind = kind; Source = source; }
        public SpacePoint3 A { get; private set; }
        public SpacePoint3 B { get; private set; }
        public SpacePoint3 C { get; private set; }
        public SpaceSurfaceKind Kind { get; private set; }
        public SpaceSurfaceSource Source { get; private set; }
    }

    public static class SpaceTakeoffLabels
    {
        public static string Status(SpaceMeasurementStatus status)
        {
            switch (status)
            {
                case SpaceMeasurementStatus.Measured: return "Measured (sampled)";
                case SpaceMeasurementStatus.VariableHeight: return "Variable height — review range";
                case SpaceMeasurementStatus.PartialCoverage: return "Partial measurement — review";
                case SpaceMeasurementStatus.MixedOverhead: return "Mixed ceiling/slab — review";
                case SpaceMeasurementStatus.MissingFloor: return "Floor not found";
                case SpaceMeasurementStatus.MissingOverhead: return "Ceiling/slab not found";
                case SpaceMeasurementStatus.Unplaced: return "Unplaced space";
                case SpaceMeasurementStatus.NotEnclosed: return "Not enclosed / no area";
                case SpaceMeasurementStatus.GeometryUnavailable: return "Geometry unavailable";
                case SpaceMeasurementStatus.NeedsReview: return "Needs review";
                default: return "Not measured";
            }
        }
    }
}
