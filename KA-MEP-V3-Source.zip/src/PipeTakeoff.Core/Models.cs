using System;
using System.Collections.Generic;

namespace PipeTakeoff.Core
{
    public sealed class FieldDefinition
    {
        public string Key { get; set; } = "";
        public string Header { get; set; } = "";
        public bool IsNumeric { get; set; }
        public override string ToString() { return Header; }
    }

    public sealed class PipeRecord
    {
        public Dictionary<string, object> Values { get; } = new Dictionary<string, object>(StringComparer.Ordinal);
        public object Get(string key) { object value; return Values.TryGetValue(key, out value) ? value : null; }
        public double LengthMeters { get { return Convert.ToDouble(Get("Length") ?? 0); } }
        public double DiameterMillimeters { get { return Convert.ToDouble(Get("Diameter") ?? 0); } }
    }

    public enum FilterOperator { Equals, NotEquals, Contains, DoesNotContain, GreaterThan, GreaterOrEqual, LessThan, LessOrEqual, IsEmpty, IsNotEmpty }

    public sealed class FilterRule
    {
        public FieldDefinition Field { get; set; }
        public FilterOperator Operator { get; set; }
        public string Value { get; set; } = "";
    }

    public enum FilterMatch { All, Any }

    public sealed class TakeoffOptions
    {
        public List<FieldDefinition> Columns { get; set; } = new List<FieldDefinition>();
        public List<FilterRule> Filters { get; set; } = new List<FilterRule>();
        public FilterMatch Match { get; set; } = FilterMatch.All;
        public bool GroupBySystem { get; set; } = true;
        public bool GroupByFamily { get; set; }
        public bool GroupByType { get; set; }
    }

    public sealed class SummaryRow
    {
        public double DiameterMillimeters { get; set; }
        public string SystemName { get; set; } = "";
        public string Family { get; set; } = "";
        public string Type { get; set; } = "";
        public int Count { get; set; }
        public double TotalLengthMeters { get; set; }
    }

    public sealed class ExportMetadata
    {
        public string Project { get; set; } = "";
        public string RevitVersion { get; set; } = "";
        public string Scope { get; set; } = "";
        public DateTime ExportedAt { get; set; } = DateTime.Now;
    }

    public static class StandardFields
    {
        public static List<FieldDefinition> Create()
        {
            return new List<FieldDefinition>
            {
                Field("ElementId", "Element ID", false), Field("Family", "Family", false),
                Field("Type", "Type", false), Field("Length", "Length (m)", true),
                Field("SystemName", "Piping System", false), Field("SystemType", "System Type", false),
                Field("Size", "Size (project format)", false), Field("Diameter", "Diameter (mm)", true),
                Field("Level", "Reference Level", false), Field("Mark", "Mark", false),
                Field("Comments", "Comments", false)
            };
        }
        private static FieldDefinition Field(string key, string header, bool numeric)
        { return new FieldDefinition { Key = key, Header = header, IsNumeric = numeric }; }
    }
}
