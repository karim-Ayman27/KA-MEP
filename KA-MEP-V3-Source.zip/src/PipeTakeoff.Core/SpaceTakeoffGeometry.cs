using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace PipeTakeoff.Core
{
    public sealed class SpaceSurfaceHit
    {
        public double ElevationMeters { get; internal set; }
        public SpaceSurfaceKind Kind { get; internal set; }
        public SpaceSurfaceSource Source { get; internal set; }
    }

    /// <summary>Detached vertical intersections against actual face triangles. Triangles,
    /// including their holes and transformed link coordinates, are supplied by the reader.</summary>
    public sealed class SpaceSurfaceIndex
    {
        public const int MaximumTriangles = 500000;
        private const int MaximumIndexEntries = 2000000;
        private const int MaximumLargeTriangles = 4096;
        private const double CellSize = 8.0;
        private const double PositionTolerance = 1e-7;
        private readonly Dictionary<Cell, List<Entry>> _cells = new Dictionary<Cell, List<Entry>>();
        private readonly List<Entry> _large = new List<Entry>();
        public int TriangleCount { get; private set; }

        public SpaceSurfaceIndex(IEnumerable<SpaceSurfaceTriangle> triangles)
        {
            if (triangles == null) throw new ArgumentNullException(nameof(triangles));
            int references = 0;
            foreach (var triangle in triangles)
            {
                if (++TriangleCount > MaximumTriangles) throw new InvalidOperationException("Surface geometry exceeds the 500,000 triangle limit. Reduce the sources or scope.");
                Validate(triangle);
                var entry = new Entry(triangle);
                // A vertical or degenerate face cannot bound a clear vertical height.
                if (Math.Abs(entry.Denominator) < 1e-12) continue;
                long minX = Bin(entry.MinX - PositionTolerance), maxX = Bin(entry.MaxX + PositionTolerance);
                long minY = Bin(entry.MinY - PositionTolerance), maxY = Bin(entry.MaxY + PositionTolerance);
                double count = ((double)maxX - minX + 1) * ((double)maxY - minY + 1);
                if (count > 256)
                {
                    if (_large.Count >= MaximumLargeTriangles) throw new InvalidOperationException("Too many large surface triangles. Reduce the geometry scope.");
                    _large.Add(entry);
                    continue;
                }
                if (references + count > MaximumIndexEntries) throw new InvalidOperationException("Surface search index exceeds its bounded size. Reduce the geometry scope.");
                references += (int)count;
                for (long x = minX; x <= maxX; x++)
                    for (long y = minY; y <= maxY; y++)
                    {
                        var key = new Cell(x, y);
                        List<Entry> bucket;
                        if (!_cells.TryGetValue(key, out bucket)) _cells.Add(key, bucket = new List<Entry>());
                        bucket.Add(entry);
                    }
            }
        }

        public IList<SpaceSurfaceHit> Query(double x, double y, double minimumElevation, double maximumElevation, SpaceSurfaceKind kind)
        {
            if (!SpaceTakeoffOptions.Finite(x) || !SpaceTakeoffOptions.Finite(y) ||
                !SpaceTakeoffOptions.Finite(minimumElevation) || !SpaceTakeoffOptions.Finite(maximumElevation) || minimumElevation > maximumElevation)
                throw new ArgumentException("A finite ordered vertical search interval is required.");
            if (!Enum.IsDefined(typeof(SpaceSurfaceKind), kind)) throw new ArgumentOutOfRangeException(nameof(kind));
            List<Entry> bucket;
            _cells.TryGetValue(new Cell(Bin(x), Bin(y)), out bucket);
            var results = new List<SpaceSurfaceHit>();
            foreach (var entry in (bucket ?? Enumerable.Empty<Entry>()).Concat(_large))
            {
                if (entry.Triangle.Kind != kind || entry.MaxZ < minimumElevation - PositionTolerance || entry.MinZ > maximumElevation + PositionTolerance ||
                    x < entry.MinX - PositionTolerance || x > entry.MaxX + PositionTolerance || y < entry.MinY - PositionTolerance || y > entry.MaxY + PositionTolerance) continue;
                double z;
                if (!entry.Intersect(x, y, out z) || z < minimumElevation - PositionTolerance || z > maximumElevation + PositionTolerance) continue;
                results.Add(new SpaceSurfaceHit { ElevationMeters = z, Kind = kind, Source = entry.Triangle.Source });
            }
            // Adjacent triangles share edges. Keep each distinct element identity and
            // elevation once, while preserving coincident elements from different links.
            var unique = new List<SpaceSurfaceHit>();
            var lastElevations = new Dictionary<string, double>(StringComparer.Ordinal);
            foreach (var hit in results.OrderBy(h => h.ElevationMeters).ThenBy(h => h.Source.Key, StringComparer.Ordinal))
            {
                double previous;
                if (lastElevations.TryGetValue(hit.Source.Key, out previous) && Math.Abs(previous - hit.ElevationMeters) <= PositionTolerance) continue;
                lastElevations[hit.Source.Key] = hit.ElevationMeters;
                unique.Add(hit);
            }
            return unique;
        }

        private static long Bin(double value)
        {
            if (!SpaceTakeoffOptions.Finite(value) || Math.Abs(value) > 1e9) throw new ArgumentOutOfRangeException(nameof(value), "Surface coordinates exceed the supported metric range.");
            return (long)Math.Floor(value / CellSize);
        }

        private static void Validate(SpaceSurfaceTriangle triangle)
        {
            if (triangle == null || triangle.Source == null) throw new ArgumentException("Every surface triangle needs a source element.");
            if (!Enum.IsDefined(typeof(SpaceSurfaceKind), triangle.Kind)) throw new ArgumentException("Unknown surface kind.");
            foreach (var point in new[] { triangle.A, triangle.B, triangle.C })
                if (!SpaceTakeoffOptions.Finite(point.X) || !SpaceTakeoffOptions.Finite(point.Y) || !SpaceTakeoffOptions.Finite(point.Z) ||
                    Math.Abs(point.X) > 1e9 || Math.Abs(point.Y) > 1e9 || Math.Abs(point.Z) > 1e9)
                    throw new ArgumentException("Surface coordinates must be finite and within the supported metric range.");
        }

        private struct Cell : IEquatable<Cell>
        {
            private readonly long _x, _y;
            public Cell(long x, long y) { _x = x; _y = y; }
            public bool Equals(Cell other) { return _x == other._x && _y == other._y; }
            public override bool Equals(object obj) { return obj is Cell && Equals((Cell)obj); }
            public override int GetHashCode() { unchecked { return _x.GetHashCode() * 397 ^ _y.GetHashCode(); } }
        }

        private sealed class Entry
        {
            internal readonly SpaceSurfaceTriangle Triangle;
            internal readonly double MinX, MaxX, MinY, MaxY, MinZ, MaxZ, Denominator;
            internal Entry(SpaceSurfaceTriangle triangle)
            {
                Triangle = triangle;
                MinX = Math.Min(triangle.A.X, Math.Min(triangle.B.X, triangle.C.X));
                MaxX = Math.Max(triangle.A.X, Math.Max(triangle.B.X, triangle.C.X));
                MinY = Math.Min(triangle.A.Y, Math.Min(triangle.B.Y, triangle.C.Y));
                MaxY = Math.Max(triangle.A.Y, Math.Max(triangle.B.Y, triangle.C.Y));
                MinZ = Math.Min(triangle.A.Z, Math.Min(triangle.B.Z, triangle.C.Z));
                MaxZ = Math.Max(triangle.A.Z, Math.Max(triangle.B.Z, triangle.C.Z));
                Denominator = (triangle.B.Y - triangle.C.Y) * (triangle.A.X - triangle.C.X) +
                    (triangle.C.X - triangle.B.X) * (triangle.A.Y - triangle.C.Y);
            }
            internal bool Intersect(double x, double y, out double z)
            {
                double a = ((Triangle.B.Y - Triangle.C.Y) * (x - Triangle.C.X) + (Triangle.C.X - Triangle.B.X) * (y - Triangle.C.Y)) / Denominator;
                double b = ((Triangle.C.Y - Triangle.A.Y) * (x - Triangle.C.X) + (Triangle.A.X - Triangle.C.X) * (y - Triangle.C.Y)) / Denominator;
                double c = 1 - a - b;
                z = a * Triangle.A.Z + b * Triangle.B.Z + c * Triangle.C.Z;
                return a >= -1e-9 && b >= -1e-9 && c >= -1e-9 && a <= 1 + 1e-9 && b <= 1 + 1e-9 && c <= 1 + 1e-9;
            }
        }
    }

    public static class SpaceHeightEngine
    {
        private const double SurfaceTolerance = 0.0001;
        private const double MinimumClearance = 0.001;

        public static SpaceHeightSample MeasureSample(SpaceSurfaceIndex index, double x, double y, double baseElevationMeters, SpaceTakeoffOptions options)
        {
            if (index == null) throw new ArgumentNullException(nameof(index));
            if (options == null) throw new ArgumentNullException(nameof(options));
            options.Validate();
            if (!SpaceTakeoffOptions.Finite(baseElevationMeters)) throw new ArgumentOutOfRangeException(nameof(baseElevationMeters));
            var sample = new SpaceHeightSample { X = x, Y = y, BaseElevationMeters = baseElevationMeters };
            var floors = index.Query(x, y, baseElevationMeters - options.FloorSearchToleranceMeters,
                baseElevationMeters + options.FloorSearchToleranceMeters, SpaceSurfaceKind.FloorTop);
            if (floors.Count == 0)
            {
                sample.Status = SpaceMeasurementStatus.MissingFloor;
                sample.Notes = "No physical floor top was found within the configured band around the Space base. Level elevation is not substituted for a floor.";
                return sample;
            }
            // Start at the support closest to the declared base, then follow physical
            // layers upward. A separate finish floor must not leave the structural
            // slab's lower top as the walking surface. Paired undersides prove the
            // additional layer touches/overlaps its support; a floating mezzanine is
            // not accepted merely because it falls in the search band.
            var floor = floors.OrderBy(h => Math.Abs(h.ElevationMeters - baseElevationMeters))
                .ThenBy(h => h.ElevationMeters).ThenBy(h => h.Source.Key, StringComparer.Ordinal).First();
            var supportBottoms = index.Query(x, y, baseElevationMeters - options.FloorSearchToleranceMeters - options.MaximumHeightMeters,
                floors.Last().ElevationMeters, SpaceSurfaceKind.SlabBottom);
            int supportLayers = 1;
            foreach (var level in floors.Where(h => h.ElevationMeters > floor.ElevationMeters + SurfaceTolerance)
                .GroupBy(h => Math.Round(h.ElevationMeters / SurfaceTolerance)).OrderBy(g => g.Key))
            {
                var connected = level.Where(candidate => supportBottoms.Any(bottom =>
                    string.Equals(bottom.Source.Key, candidate.Source.Key, StringComparison.Ordinal) &&
                    bottom.ElevationMeters <= floor.ElevationMeters + SurfaceTolerance &&
                    bottom.ElevationMeters < candidate.ElevationMeters - SurfaceTolerance))
                    .OrderByDescending(candidate => candidate.ElevationMeters).ThenBy(candidate => candidate.Source.Key, StringComparer.Ordinal).FirstOrDefault();
                if (connected == null)
                {
                    sample.Status = SpaceMeasurementStatus.NeedsReview;
                    sample.Notes = "Multiple floor-top elevations are not a proven continuous support/finish stack; no floor was chosen automatically: " +
                        string.Join("; ", floors.Select(h => h.ElevationMeters.ToString("0.####", CultureInfo.InvariantCulture) + " m — " + h.Source.Label));
                    return sample;
                }
                floor = connected;
                supportLayers++;
            }
            sample.FloorElevationMeters = floor.ElevationMeters;
            sample.FloorSource = floor.Source;
            double minZ = floor.ElevationMeters + MinimumClearance;
            double maxZ = floor.ElevationMeters + options.MaximumHeightMeters;
            var slabs = index.Query(x, y, minZ, maxZ, SpaceSurfaceKind.SlabBottom)
                .Where(h => !string.Equals(h.Source.Key, floor.Source.Key, StringComparison.Ordinal)).ToList();
            var ceilings = index.Query(x, y, minZ, maxZ, SpaceSurfaceKind.CeilingBottom);
            var slab = slabs.FirstOrDefault();
            // A ceiling from the storey above cannot override an intervening slab.
            var ceiling = ceilings.FirstOrDefault(h => slab == null || h.ElevationMeters <= slab.ElevationMeters + SurfaceTolerance);
            var overhead = ceiling ?? slab;
            if (overhead == null)
            {
                sample.Status = SpaceMeasurementStatus.MissingOverhead;
                sample.Notes = "No physical ceiling underside or overhead slab underside was found within the maximum height. Space upper limits are not substituted.";
                return sample;
            }
            sample.OverheadElevationMeters = overhead.ElevationMeters;
            sample.OverheadSource = overhead.Source;
            sample.HeightMeters = overhead.ElevationMeters - floor.ElevationMeters;
            sample.HeightBasis = ceiling == null ? SpaceHeightBasis.Slab : SpaceHeightBasis.Ceiling;
            sample.Status = SpaceMeasurementStatus.Measured;
            var notes = new List<string>();
            if (supportLayers > 1) notes.Add("The highest top of a continuous " + supportLayers + "-layer floor support/finish stack was used. Sources: " + string.Join("; ", floors.Select(h => h.Source.Label)));
            else if (floors.Count > 1) notes.Add("Additional floor tops were found; the support closest to the Space base and its coincident tops were used. Sources: " + string.Join("; ", floors.Select(h => h.Source.Label)));
            if (ceiling == null && ceilings.Count > 0) notes.Add("A ceiling above an intervening slab was ignored.");
            sample.Notes = string.Join(" ", notes);
            return sample;
        }

        /// <summary>Only a complete, consistent sampled result gets one clear-height
        /// value. That value is the minimum observed clearance, never an average.</summary>
        public static void Aggregate(SpaceTakeoffRow row, SpaceTakeoffOptions options, bool coverageComplete = true)
        {
            if (row == null) throw new ArgumentNullException(nameof(row));
            if (options == null) throw new ArgumentNullException(nameof(options));
            options.Validate();
            if (row.Samples == null || row.Notes == null || row.Samples.Any(s => s == null)) throw new ArgumentException("Sample and note collections must be present.", nameof(row));
            row.ClearHeightMeters = null;
            row.MinHeightMeters = null;
            row.MaxHeightMeters = null;
            row.HeightBasis = SpaceHeightBasis.None;
            foreach (var sample in row.Samples)
                if (sample.HeightMeters.HasValue && (!SpaceTakeoffOptions.Finite(sample.HeightMeters.Value) || sample.HeightMeters.Value <= 0))
                    throw new ArgumentException("A measured height must be finite and positive.", nameof(row));
            var measured = row.Samples.Where(s => s.Status == SpaceMeasurementStatus.Measured && s.HeightMeters.HasValue).ToList();
            if (measured.Count > 0)
            {
                row.MinHeightMeters = measured.Min(s => s.HeightMeters.Value);
                row.MaxHeightMeters = measured.Max(s => s.HeightMeters.Value);
                var bases = measured.Select(s => s.HeightBasis).Distinct().ToList();
                row.HeightBasis = bases.Count == 1 ? bases[0] : SpaceHeightBasis.Mixed;
            }
            if (row.Samples.Count == 0)
            {
                if (row.Status != SpaceMeasurementStatus.Unplaced && row.Status != SpaceMeasurementStatus.NotEnclosed)
                    row.Status = SpaceMeasurementStatus.GeometryUnavailable;
                AddNote(row, "No valid interior sampling points were available; no clear height has been assigned.");
            }
            else if (measured.Count == 0)
            {
                var statuses = row.Samples.Select(s => s.Status).Distinct().ToList();
                row.Status = statuses.Count == 1 && statuses[0] != SpaceMeasurementStatus.Measured ? statuses[0] : SpaceMeasurementStatus.NeedsReview;
                AddNote(row, "No complete floor-to-overhead sample was measured. Review the per-point results and source geometry.");
            }
            else if (!coverageComplete || measured.Count != row.Samples.Count)
            {
                row.Status = SpaceMeasurementStatus.PartialCoverage;
                AddNote(row, "Some samples or required geometry are unavailable. The range describes only successfully measured points; clear height is intentionally blank.");
            }
            else if (row.HeightBasis == SpaceHeightBasis.Mixed || row.HeightBasis == SpaceHeightBasis.None)
            {
                row.Status = SpaceMeasurementStatus.MixedOverhead;
                AddNote(row, "The sampled room includes both ceiling and slab undersides. Review their extents; no single height is assigned.");
            }
            else if (row.MaxHeightMeters.Value - row.MinHeightMeters.Value > options.HeightVariationToleranceMeters + 1e-9)
            {
                row.Status = SpaceMeasurementStatus.VariableHeight;
                AddNote(row, "Clearance varies beyond the configured tolerance. Use the sampled minimum/maximum range and review the model.");
            }
            else
            {
                row.Status = SpaceMeasurementStatus.Measured;
                row.ClearHeightMeters = row.MinHeightMeters;
                AddNote(row, "Clear height is the minimum sampled physical clearance. Sampling does not certify unsampled areas or calculate HVAC loads.");
            }
        }

        private static void AddNote(SpaceTakeoffRow row, string note)
        {
            if (!row.Notes.Contains(note)) row.Notes.Add(note);
        }
    }
}
