using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;

namespace PipeTakeoff.Revit
{
    /// <summary>Version boundaries are kept here so all releases preserve element identity.</summary>
    internal static class RevitCompat
    {
        public static long Id(ElementId id)
        {
            if (id == null) throw new ArgumentNullException(nameof(id));
#if REVIT2022 || REVIT2023
            return id.IntegerValue;
#else
            return id.Value;
#endif
        }

        public static ElementId ElementId(long value)
        {
#if REVIT2022 || REVIT2023
            return new Autodesk.Revit.DB.ElementId(checked((int)value));
#else
            return new Autodesk.Revit.DB.ElementId(value);
#endif
        }

        // GetAllRevisionCloudIds was introduced in 2023.1. Reflection lets a base
        // 2023 build use the exact API when an updated host provides it.
        internal static bool HasExactSheetCloudApi
        {
            get { return typeof(ViewSheet).GetMethod("GetAllRevisionCloudIds", Type.EmptyTypes) != null; }
        }

        internal static IEnumerable<ElementId> RevisionCloudIds(ViewSheet sheet)
        {
#if REVIT2022 || REVIT2023
            var exactMethod = typeof(ViewSheet).GetMethod("GetAllRevisionCloudIds", Type.EmptyTypes);
            if (exactMethod != null) return (ICollection<ElementId>)exactMethod.Invoke(sheet, null);
            // GetSheetIds includes primary/dependent views but can include hidden
            // and cropped clouds. Conservatively protect these revisions instead
            // of allowing an Additional revision edit to remove a cloud revision.
            return new FilteredElementCollector(sheet.Document).OfClass(typeof(RevisionCloud))
                .Cast<RevisionCloud>().Where(c => c.GetSheetIds().Contains(sheet.Id)).Select(c => c.Id).ToList();
#else
            return sheet.GetAllRevisionCloudIds();
#endif
        }
    }
}
