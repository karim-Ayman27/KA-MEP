using System;
using System.Linq;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using TaskDialog = Autodesk.Revit.UI.TaskDialog;

namespace PipeTakeoff.Revit
{
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    public sealed class SheetExportCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            try
            {
                var uiDocument = commandData.Application.ActiveUIDocument;
                if (uiDocument == null || uiDocument.Document.IsFamilyDocument)
                {
                    TaskDialog.Show("KA MEP | Sheet Studio", "Open a Revit project containing printable sheets first.");
                    return Result.Cancelled;
                }
                var document = uiDocument.Document;
                if (document.IsModifiable)
                {
                    TaskDialog.Show("KA MEP | Sheet Studio", "Finish the current Revit transaction before exporting sheets.");
                    return Result.Cancelled;
                }
                var snapshot = SheetParameterReader.Read(document);
                if (snapshot.Sheets.Count == 0)
                {
                    TaskDialog.Show("KA MEP | Sheet Studio", "No printable sheets were found. Placeholder sheets cannot be exported.");
                    return Result.Cancelled;
                }
                var owner = new WindowOwner(commandData.Application.MainWindowHandle);
                SheetExportRequest request;
                using (var form = new SheetExportForm(snapshot.Sheets, snapshot.Parameters,
                    BaseExportOptions.GetPredefinedSetupNames(document).OrderBy(x => x, StringComparer.CurrentCultureIgnoreCase).ToList(), document.Title))
                {
                    if (form.ShowDialog(owner) != DialogResult.OK) return Result.Cancelled;
                    request = form.Request;
                }
                SheetExportResult result;
                using (var progress = new SheetExportProgressForm(update => SheetExportService.Export(document, request, update)))
                {
                    progress.ShowDialog(owner);
                    if (progress.Error != null) throw new InvalidOperationException("The export could not be completed: " + progress.Error.Message, progress.Error);
                    result = progress.Result;
                }
                if (result == null) return Result.Cancelled;
                string title = result.Cancelled ? "Export cancelled" : result.Failed > 0 || result.StopReason != null ? "Export finished with issues" : "Export complete";
                var summary = title + "\n\nSuccessful export operations: " + result.Succeeded
                    + "\nFailed/incomplete operations: " + result.Failed
                    + "\nOperations not started: " + result.NotStarted
                    + "\nA combined PDF counts as one operation.\n\n" + result.Folder;
                if (!string.IsNullOrWhiteSpace(result.StopReason)) summary += "\n\n" + result.StopReason;
                summary += "\n\n" + (result.ReportError ?? "Details: " + result.ReportPath);
                TaskDialog.Show("KA MEP | Sheet Studio", summary);
                if (result.Cancelled) return Result.Cancelled;
                if (result.Failed > 0 || result.StopReason != null)
                {
                    message = "Some sheet exports were not completed. Review the KA MEP export report in " + result.Folder;
                    return Result.Failed;
                }
                return Result.Succeeded;
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException) { return Result.Cancelled; }
            catch (System.OperationCanceledException) { return Result.Cancelled; }
            catch (Exception ex)
            {
                message = ex.Message;
                TaskDialog.Show("KA MEP | Sheet Studio", "The sheet export could not be completed.\n\n" + ex.Message);
                return Result.Failed;
            }
        }

        private sealed class WindowOwner : IWin32Window
        {
            public WindowOwner(IntPtr handle) { Handle = handle; }
            public IntPtr Handle { get; private set; }
        }
    }
}
