using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace PipeTakeoff.Revit
{
    /// <summary>Detached MCP presentation. Connection lifecycle and all Revit access belong to the controller.</summary>
    public sealed class McpConnectionForm : Form
    {
        private readonly Button _enable = KaTheme.Button("Enable", true);
        private readonly Button _stop = KaTheme.Button("Stop");
        private readonly Button _save = KaTheme.Button("Save Claude config…");
        private readonly Button _close = KaTheme.Button("Close");
        private readonly Label _project = Line("McpProject");
        private readonly Label _state = Line("McpState");
        private readonly Label _mode = Line("McpMode");
        private readonly Label _activity = Line("McpActivity");
        private readonly Label _helper = Line("McpHelperStatus");
        private readonly TextBox _connectionFile = PathField("McpConnectionFile");
        private readonly TextBox _helperPath = PathField("McpHelperPath");
        private readonly TextBox _status = new TextBox
        {
            Name = "McpStatus", ReadOnly = true, Multiline = true, ScrollBars = ScrollBars.Vertical,
            WordWrap = true, BorderStyle = BorderStyle.None, BackColor = KaTheme.Surface,
            ForeColor = KaTheme.Ink, Dock = DockStyle.Fill, Margin = Padding.Empty,
            AccessibleName = "Connection status", TabStop = true
        };
        private readonly Panel _viewport = new Panel { Name = "McpHelpViewport", Dock = DockStyle.Fill, AutoScroll = true, BackColor = Color.White, Margin = Padding.Empty };
        private readonly ToolTip _tips = new ToolTip { AutoPopDelay = 30000 };
        private TableLayoutPanel _layout, _header, _body, _footer;
        private Label _title, _subtitle, _disclosure;
        private Font _titleFont;
        private bool _enabled, _hasProject, _helperAvailable, _built, _arranging, _closing;

        public event Action EnableRequested;
        public event Action StopRequested;
        public event Action SaveConfigRequested;
        public bool EnabledConnection { get { return _enabled; } }

        public McpConnectionForm()
        {
            KaTheme.ApplyForm(this, "Claude Desktop connection", 1060, 760);
            Name = "McpConnectionForm";
            MinimumSize = new Size(760, 540);
            BuildInterface();
            _enable.Click += delegate { if (_enable.Enabled) EnableRequested?.Invoke(); };
            _stop.Click += delegate { if (_stop.Enabled) StopRequested?.Invoke(); };
            _save.Click += delegate { if (_save.Enabled) SaveConfigRequested?.Invoke(); };
            _close.Click += delegate { Close(); };
            SetContext(null, null, null, false);
            SetState(false, "Open a Revit project, then choose Enable to allow this read-only connection.");
            SetActivity(null, null, 0);
        }

        public void SetContext(string projectTitle, string connectionFile, string helperPath, bool helperAvailable)
        {
            _hasProject = !string.IsNullOrWhiteSpace(projectTitle);
            _helperAvailable = helperAvailable;
            _project.Text = "Project: " + (_hasProject ? projectTitle : "No active project");
            _project.AccessibleDescription = _project.Text;
            _tips.SetToolTip(_project, _project.Text);
            _connectionFile.Text = connectionFile ?? "";
            _helperPath.Text = helperPath ?? "";
            _helper.Text = helperAvailable ? "Desktop helper: Available" : "Desktop helper: Missing — repair the KA MEP installation";
            _helper.ForeColor = helperAvailable ? KaTheme.Muted : KaTheme.Warning;
            _helper.AccessibleDescription = _helper.Text;
            _tips.SetToolTip(_helper, _helper.Text);
            UpdateActions();
        }

        public void SetState(bool enabled, string message)
        {
            _enabled = enabled;
            _state.Text = enabled ? "Enabled" : "Disabled";
            _state.ForeColor = enabled ? Color.FromArgb(0, 118, 108) : KaTheme.Muted;
            _state.AccessibleName = "Connection " + _state.Text;
            _status.Text = message ?? "";
            _status.AccessibleDescription = _status.Text;
            _tips.SetToolTip(_status, _status.Text);
            UpdateActions();
        }

        /// <summary>Records metadata only. Arbitrary result text is never displayed as an activity payload.</summary>
        public void SetActivity(string tool, string result, int completed)
        {
            string name = SafeToolName(tool);
            _activity.Text = name == null
                ? "Last request: None  •  Completed: " + Math.Max(0, completed).ToString(CultureInfo.CurrentCulture)
                : "Last: " + name + "  •  " + DateTime.Now.ToString("HH:mm:ss", CultureInfo.CurrentCulture)
                    + "  •  " + SafeOutcome(result) + "  •  Completed: " + Math.Max(0, completed).ToString(CultureInfo.CurrentCulture);
            _activity.AccessibleName = "Request activity";
            _activity.AccessibleDescription = _activity.Text;
            _tips.SetToolTip(_activity, _activity.Text);
        }

        private void BuildInterface()
        {
            _layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 6, Padding = new Padding(12) };
            _layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            for (int i = 0; i < 6; i++) _layout.RowStyles.Add(new RowStyle(i == 3 ? SizeType.Percent : SizeType.AutoSize, i == 3 ? 100 : 0));
            _header = new TableLayoutPanel { AutoSize = true, Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, BackColor = KaTheme.Navy, Padding = new Padding(16, 10, 16, 10), Margin = new Padding(0, 0, 0, 8) };
            _header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            _title = new Label { Name = "McpTitle", Text = "KA MEP  /  Claude Desktop", AutoSize = true, ForeColor = Color.White, Margin = Padding.Empty, Dock = DockStyle.Fill };
            _subtitle = new Label { Text = "Read your active Revit project through a local MCP connection.", AutoSize = true, ForeColor = Color.FromArgb(194, 211, 223), Margin = new Padding(0, 5, 0, 0), Dock = DockStyle.Fill };
            _header.Controls.Add(_title, 0, 0); _header.Controls.Add(_subtitle, 0, 1); _layout.Controls.Add(_header, 0, 0);

            var session = new TableLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, ColumnCount = 2, RowCount = 2, Margin = new Padding(0, 0, 0, 4) };
            session.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42)); session.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 58));
            session.Controls.Add(_project, 0, 0); session.SetColumnSpan(_project, 2);
            _mode.Text = "Read-only session"; _mode.TextAlign = ContentAlignment.MiddleRight;
            session.Controls.Add(_state, 0, 1); session.Controls.Add(_mode, 1, 1); _layout.Controls.Add(session, 0, 1);
            _disclosure = Paragraph("McpDisclosure", "Requested model data is sent to your Claude conversation.");
            _disclosure.ForeColor = KaTheme.Navy; _disclosure.Margin = new Padding(0, 2, 0, 8);
            _layout.Controls.Add(_disclosure, 0, 2);

            _body = new TableLayoutPanel { Name = "McpHelpContent", AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, ColumnCount = 1, Padding = new Padding(12), Margin = Padding.Empty };
            _body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            AddBody(Paragraph("McpDetailsHeading", "LOCAL CONNECTION", true));
            AddBody(_helper);
            AddBody(Paragraph("McpConnectionFileCaption", "Connection file")); AddBody(_connectionFile);
            AddBody(Paragraph("McpHelperPathCaption", "Claude Desktop helper")); AddBody(_helperPath);
            AddBody(Paragraph("McpSetupHeading", "CONNECT CLAUDE DESKTOP", true));
            AddBody(Paragraph("McpStepEnable", "1. Keep the intended Revit model active and choose Enable. Keep this window open while using Claude."));
            AddBody(Paragraph("McpStepSave", "2. Choose Save Claude config… to export a configuration snippet. This does not change your existing Claude configuration."));
            AddBody(Paragraph("McpStepMerge", "3. In Claude Desktop, open Settings → Developer → Edit Config. Merge the snippet’s mcpServers entry into your existing claude_desktop_config.json, preserving other servers. Save, then fully quit and restart Claude Desktop."));
            AddBody(Paragraph("McpStepAsk", "4. In Claude, ask to run ka_revit_project_info first to confirm the active project, then use the other read-only tools below."));
            AddBody(Paragraph("McpToolsHeading", "READ-ONLY TOOLS", true));
            AddBody(Paragraph("McpToolProject", "ka_revit_project_info — current project"));
            AddBody(Paragraph("McpToolSelection", "ka_revit_selection — selected elements"));
            AddBody(Paragraph("McpToolFind", "ka_revit_find_elements — search elements"));
            AddBody(Paragraph("McpToolParameters", "ka_revit_element_parameters — element values"));
            AddBody(Paragraph("McpToolSheets", "ka_revit_sheets — sheet list"));
            AddBody(Paragraph("McpToolWarnings", "ka_revit_warnings — model warnings"));
            AddBody(Paragraph("McpSessionHelp", "The model must remain active in Revit. Stop or close this window to end the connection. Only the last tool, time, outcome and request count appear here; request contents are not shown."));
            _viewport.Controls.Add(_body); _viewport.SizeChanged += delegate { FitBody(); }; _layout.Controls.Add(_viewport, 0, 3);

            var actions = new FlowLayoutPanel { Name = "McpActions", Dock = DockStyle.Fill, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, WrapContents = false, Margin = new Padding(0, 7, 0, 3) };
            _enable.Name = "McpEnable"; _stop.Name = "McpStop"; _save.Name = "McpSaveConfig"; _close.Name = "McpClose";
            foreach (var button in new[] { _enable, _stop, _save, _close }) { button.AutoSizeMode = AutoSizeMode.GrowAndShrink; actions.Controls.Add(button); }
            _layout.Controls.Add(actions, 0, 4);
            _footer = new TableLayoutPanel { Name = "McpFooter", ColumnCount = 1, RowCount = 2, AutoSize = true, Dock = DockStyle.Fill, Margin = Padding.Empty };
            _footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            _footer.Controls.Add(_status, 0, 0); _footer.Controls.Add(_activity, 0, 1); _layout.Controls.Add(_footer, 0, 5);
            Controls.Add(_layout); _built = true;
        }

        private void AddBody(Control control)
        {
            int row = _body.RowCount++;
            _body.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            control.Dock = DockStyle.Fill; _body.Controls.Add(control, 0, row);
        }

        private void UpdateActions()
        {
            _enable.Enabled = !_enabled && _hasProject && _helperAvailable && !_closing;
            _stop.Enabled = _enabled && !_closing;
            _save.Enabled = _helperAvailable && !string.IsNullOrWhiteSpace(_connectionFile.Text) && !_closing;
        }

        private void FitBody()
        {
            if (_body == null || _body.IsDisposed) return;
            int width = Math.Max(100, _viewport.ClientSize.Width - SystemInformation.VerticalScrollBarWidth - 2);
            _body.MaximumSize = new Size(width, 0);
            _body.Width = width;
            foreach (Control control in _body.Controls)
            {
                var label = control as Label;
                if (label != null && label.AutoSize) label.MaximumSize = new Size(Math.Max(80, width - _body.Padding.Horizontal - label.Margin.Horizontal), 0);
            }
        }

        protected override void OnShown(EventArgs e) { base.OnShown(e); KaTheme.ClampToScreen(this); }
        protected override void OnLayout(LayoutEventArgs e)
        {
            if (_built && !_arranging)
            {
                _arranging = true;
                try
                {
                    bool compact = ClientSize.Height < Font.Height * 31;
                    _layout.Padding = compact ? new Padding(6) : new Padding(12);
                    _subtitle.Visible = !compact;
                    _header.Padding = compact ? new Padding(10, 5, 10, 5) : new Padding(16, 10, 16, 10);
                    float points = Font.SizeInPoints * (compact ? 1.1F : 1.6F);
                    if (_titleFont == null || Math.Abs(_titleFont.SizeInPoints - points) > .01F)
                    {
                        var previous = _titleFont; _titleFont = new Font(Font.FontFamily, points, FontStyle.Bold);
                        _title.Font = _titleFont; previous?.Dispose();
                    }
                    else if (!ReferenceEquals(_title.Font, _titleFont)) _title.Font = _titleFont;
                    foreach (var label in new[] { _project, _state, _mode, _activity, _helper }) label.Height = Font.Height + 7;
                    _status.Height = Font.Height * 2 + 6;
                    _footer.RowStyles.Clear(); _footer.RowStyles.Add(new RowStyle(SizeType.Absolute, _status.Height)); _footer.RowStyles.Add(new RowStyle(SizeType.Absolute, _activity.Height));
                    _disclosure.MaximumSize = new Size(Math.Max(100, ClientSize.Width - _layout.Padding.Horizontal), 0);
                    foreach (var button in new[] { _enable, _stop, _save, _close })
                    { button.MinimumSize = new Size(0, 32); button.Padding = new Padding(8, 4, 8, 4); }
                    FitBody();
                }
                finally { _arranging = false; }
            }
            base.OnLayout(e);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            if (!e.Cancel && !_closing)
            {
                _closing = true;
                StopRequested?.Invoke();
                _enabled = false;
            }
        }

        private static string SafeToolName(string tool)
        {
            if (string.IsNullOrWhiteSpace(tool)) return null;
            switch (tool)
            {
                case "ka_revit_project_info": return "project_info";
                case "ka_revit_selection": return "selection";
                case "ka_revit_find_elements": return "find_elements";
                case "ka_revit_element_parameters": return "element_parameters";
                case "ka_revit_sheets": return "sheets";
                case "ka_revit_warnings": return "warnings";
                default: return "Request";
            }
        }

        private static string SafeOutcome(string result)
        {
            switch ((result ?? "").Trim().ToLowerInvariant())
            {
                case "ok": case "success": case "succeeded": return "Succeeded";
                case "error": case "failed": case "failure": return "Failed";
                case "cancelled": case "canceled": return "Cancelled";
                case "rejected": case "denied": return "Rejected";
                default: return "Completed";
            }
        }

        private static Label Line(string name) { return new Label { Name = name, Dock = DockStyle.Fill, AutoEllipsis = true, UseMnemonic = false, TextAlign = ContentAlignment.MiddleLeft, Margin = Padding.Empty }; }
        private static Label Paragraph(string name, string text, bool heading = false)
        {
            return new Label { Name = name, Text = text, AutoSize = true, Dock = DockStyle.Fill, ForeColor = heading ? KaTheme.Navy : KaTheme.Ink, Margin = new Padding(0, heading ? 12 : 4, 0, heading ? 6 : 4) };
        }
        private static TextBox PathField(string name)
        {
            return new TextBox { Name = name, ReadOnly = true, BorderStyle = BorderStyle.FixedSingle, BackColor = Color.White, ForeColor = KaTheme.Muted, Dock = DockStyle.Fill, Margin = new Padding(0, 0, 0, 6), AccessibleName = name == "McpConnectionFile" ? "Connection file path" : "Desktop helper path" };
        }
        protected override void Dispose(bool disposing) { if (disposing) { _tips.Dispose(); _titleFont?.Dispose(); } base.Dispose(disposing); }
    }
}
