using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace PipeTakeoff.Revit
{
    [Transaction(TransactionMode.Manual)]
    public sealed class InfoCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            var dialog = new TaskDialog("KA MEP - Info")
            {
                TitleAutoPrefix = false,
                MainInstruction = "KA MEP | " + KAMEP.Branding.ReleaseIdentity.VersionLabel,
                MainContent = "Addin creator: Karim Ayman\n" +
                    "Tel: 01032638143\n" +
                    "LinkedIn: karimayman27\n" +
                    "Email: mech.karim.ayman@gmail.com\n\n" +
                    KAMEP.Branding.ReleaseIdentity.Display + "\n" +
                    "Autodesk Revit 2022.1+ / 2023 / 2024 / 2025 / 2026 / 2027\n" +
                    "HVAC Spaces: room names and numbers, areas, sampled physical clear heights and Excel reports\n" +
                    "Clash Manager: HTML reports, linked element mapping, focused 3D views, hard-clash checks and Excel\n" +
                    "Claude Desktop / MCP: explicit local connection and read-only project queries\n" +
                    "Pipes, ducts, cable trays, conduits and fittings\n" +
                    "Excel quantities / PDF and DWG sheet export\n" +
                    "Tag Assistant: nearby placement, element review, distance/count limits and six patterns\n" +
                    "Sheet Parameters: batch edits and additional revision assignments\n" +
                    "Model Review & Cleanup: CAD, views, duplicates, warnings and a refreshable review score",
                ExpandedContent = "Loaded add-in: " + typeof(InfoCommand).Assembly.Location,
                CommonButtons = TaskDialogCommonButtons.Close
            };
            dialog.Show();
            return Result.Succeeded;
        }
    }

    public sealed class InfoCommandAvailability : IExternalCommandAvailability
    {
        public bool IsCommandAvailable(UIApplication applicationData, CategorySet selectedCategories)
        {
            return true;
        }
    }
}
