using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace PipeTakeoff.Revit
{
    /// <summary>Modeless, detached presentation. All Revit operations are requested through the controller.</summary>
    internal sealed class ModelReviewForm : Form
    {
        private readonly DataGridView _findings = new DataGridView();
        private readonly TextBox _search = new TextBox();
        private readonly ComboBox _kind = new ComboBox();
        private readonly TextBox _details = new TextBox();
        private readonly TextBox _coverage = new TextBox();
        private readonly Label _score = new Label();
        private readonly Label _counts = new Label();
        private readonly Label _scan = new Label();
        private readonly Label _status = new Label();
        private readonly Button _refresh = KaTheme.Button("Refresh", true);
        private readonly Button _inspect = KaTheme.Button("Show in Revit");
        private readonly Button _cleanup = KaTheme.Button("Preview cleanup…");
        private readonly Button _export = KaTheme.Button("Export review to Excel");
        private readonly Button _check = KaTheme.Button("Check cleanup candidates");
        private readonly Button _clear = KaTheme.Button("Clear checks");
        private readonly Button _viewDetails = KaTheme.Button("Review issue details");
        private readonly Button _allDetails = KaTheme.Button("All individual findings");
        private readonly Label _selectionHint = KaTheme.Hint("Open an issue to review individual findings before cleanup.");
        private readonly ToolTip _tips = new ToolTip { AutoPopDelay = 20000, InitialDelay = 300 };
        private readonly HashSet<string> _checked = new HashSet<string>(StringComparer.Ordinal);
        private ReviewSnapshot _snapshot;
        private IList<ReviewIssueGroup> _groups = new List<ReviewIssueGroup>();
        private bool _summaryMode = true;
        private string _detailGroupKey;
        private bool _loading, _busy;
        private double? _previousScore;
        private string _operationStatus = "Press Refresh to scan the active model.";

        public event Action RefreshRequested;
        public event Action<IList<string>> InspectRequested;
        public event Action<IList<string>> CleanupRequested;
        public event Action ExportRequested;

        public ReviewSnapshot Snapshot { get { return _snapshot; } }

        public ModelReviewForm()
        {
            KaTheme.ApplyForm(this, "Model Review & Cleanup", 1210, 810);
            Name = "ModelReviewForm";
            MinimumSize = new Size(900, 620);
            MinimizeBox = true;
            BuildInterface();
            WireEvents();
            SetBusy(false, _operationStatus);
            UpdateSummary();
        }

        public ModelReviewForm(ReviewSnapshot snapshot) : this() { SetSnapshot(snapshot); }

        public void SetSnapshot(ReviewSnapshot snapshot)
        {
            if (snapshot == null) throw new ArgumentNullException("snapshot");
            _previousScore = _snapshot != null && _snapshot.IsComplete ? (double?)_snapshot.HealthScore : null;
            _snapshot = snapshot;
            _groups = ReviewIssueGrouping.Group(snapshot.Findings);
            _summaryMode = true;
            _detailGroupKey = null;
            _checked.Clear();
            _operationStatus = snapshot.IsComplete ? "Scan complete. Repeated findings are grouped; open an issue to review its details." : "Scan incomplete. Read Coverage & scoring; health score is unavailable.";
            UpdateSummary();
            RefreshRows();
            UpdateActions();
        }

        public void SetBusy(bool busy, string message)
        {
            _busy = busy;
            if (!string.IsNullOrWhiteSpace(message)) _operationStatus = message;
            UseWaitCursor = busy;
            UpdateActions();
        }

        public void ShowFailure(string message)
        {
            _busy = false;
            UseWaitCursor = false;
            _operationStatus = string.IsNullOrWhiteSpace(message) ? "Operation failed. Press Refresh to review the current model." : message;
            UpdateActions();
            _status.ForeColor = KaTheme.Warning;
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            KaTheme.ClampToScreen(this);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _tips.Dispose();
            base.Dispose(disposing);
        }

        private void BuildInterface()
        {
            var workspace = CreateLayout("ReviewWorkspace", 1, 5);
            workspace.Padding = new Padding(14, 12, 14, 10);
            workspace.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            workspace.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            workspace.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            workspace.RowStyles.Add(new RowStyle(SizeType.Percent, 63));
            workspace.RowStyles.Add(new RowStyle(SizeType.Percent, 37));
            var header = KaTheme.Header("Model Review & Cleanup", "Inspect CAD, unplaced views and duplicate candidates  /  Fix items in Revit, then Refresh");
            foreach (Control control in header.Controls)
                if (control is Label) ((Label)control).UseMnemonic = false;
            workspace.Controls.Add(header, 0, 0);
            workspace.Controls.Add(Summary(), 0, 1);
            workspace.Controls.Add(Toolbar(), 0, 2);
            ConfigureGrid();
            workspace.Controls.Add(_findings, 0, 3);
            workspace.Controls.Add(DetailTabs(), 0, 4);
            var viewport = new Panel { Name = "ReviewViewport", Dock = DockStyle.Fill, AutoScroll = true };
            workspace.Dock = DockStyle.Top;
            viewport.Controls.Add(workspace);
            bool sizing = false;
            viewport.Layout += delegate
            {
                if (sizing) return;
                sizing = true;
                try { workspace.Height = Math.Max(viewport.ClientSize.Height, Font.Height * 32); }
                finally { sizing = false; }
            };
            Controls.Add(viewport);
            Controls.Add(Footer());
        }

        private Control Summary()
        {
            var panel = CreateLayout("ReviewSummary", 2, 3);
            panel.AutoSize = true;
            panel.BackColor = Color.White;
            panel.Padding = new Padding(12, 9, 12, 9);
            panel.Margin = new Padding(0, 0, 0, 8);
            panel.ColumnStyles.Clear();
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            for (int i = 0; i < 3; i++) panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            _score.Name = "ReviewHealthScore";
            ConfigureLabel(_score);
            _score.Font = new Font("Segoe UI", 21F, FontStyle.Bold);
            _score.ForeColor = KaTheme.Navy;
            _score.Margin = new Padding(0, 0, 22, 2);
            panel.Controls.Add(_score, 0, 0);
            panel.SetRowSpan(_score, 2);
            _counts.Name = "ReviewCounts";
            ConfigureLabel(_counts);
            _counts.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            panel.Controls.Add(_counts, 1, 0);
            var note = KaTheme.Hint("MODEL HEALTH · Grouped presentation. The score still uses every underlying occurrence.");
            note.Name = "ReviewHealthNote";
            panel.Controls.Add(note, 1, 1);
            _scan.Name = "ReviewScannedAt";
            ConfigureLabel(_scan);
            _scan.ForeColor = KaTheme.Muted;
            panel.Controls.Add(_scan, 0, 2);
            panel.SetColumnSpan(_scan, 2);
            return panel;
        }

        private Control Toolbar()
        {
            var panel = CreateLayout("ReviewToolbar", 2, 2);
            panel.AutoSize = true;
            panel.Padding = new Padding(0, 2, 0, 6);
            panel.ColumnStyles.Clear();
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            _kind.Name = "ReviewKindFilter";
            _kind.DropDownStyle = ComboBoxStyle.DropDownList;
            _kind.Width = 220;
            _kind.Items.AddRange(new object[] { "All findings", "CAD imports", "CAD links (review only)", "Unplaced views", "Potential duplicates", "Revit warnings" });
            _kind.SelectedIndex = 0;
            _kind.Margin = new Padding(0, 4, 10, 4);
            _search.Name = "ReviewSearch";
            _search.Dock = DockStyle.Fill;
            _search.Margin = new Padding(0, 4, 0, 4);
            _tips.SetToolTip(_search, "Search issues, finding details or element IDs. In summary mode a match shows the whole issue and its full counts.");
            panel.Controls.Add(_kind, 0, 0);
            panel.Controls.Add(_search, 1, 0);
            var buttons = KaTheme.Flow(); buttons.Dock = DockStyle.Fill;
            _check.Name = "ReviewCheckCandidates"; _clear.Name = "ReviewClearChecks";
            _viewDetails.Name = "ReviewOpenDetails"; _allDetails.Name = "ReviewAllDetails";
            buttons.Controls.Add(_viewDetails); buttons.Controls.Add(_allDetails);
            buttons.Controls.Add(_check); buttons.Controls.Add(_clear);
            _selectionHint.Anchor = AnchorStyles.Left;
            buttons.Controls.Add(_selectionHint);
            panel.Controls.Add(buttons, 0, 1);
            panel.SetColumnSpan(buttons, 2);
            return panel;
        }

        private void ConfigureGrid()
        {
            _findings.Name = "ReviewFindingGrid";
            KaTheme.StyleGrid(_findings, false);
            _findings.MultiSelect = false;
            _findings.EditMode = DataGridViewEditMode.EditOnEnter;
            _findings.Margin = new Padding(0, 0, 0, 8);
            _findings.Columns.Add(new DataGridViewCheckBoxColumn { Name = "Checked", HeaderText = "Use", Width = 44, MinimumWidth = 40, AutoSizeMode = DataGridViewAutoSizeColumnMode.None });
            _findings.Columns.Add(Column("Kind", "Review area", 22, 120));
            _findings.Columns.Add(Column("Finding", "Finding", 48, 180));
            _findings.Columns.Add(Column("Occurrences", "Occurrences", 12, 90));
            _findings.Columns.Add(Column("Elements", "Affected elements", 14, 100));
            _findings.Columns.Add(Column("Action", "Cleanup", 20, 100));
        }

        private Control DetailTabs()
        {
            var tabs = new TabControl { Name = "ReviewDetailTabs", Dock = DockStyle.Fill, Padding = new Point(12, 6), Margin = new Padding(0) };
            var details = new TabPage("Finding details") { BackColor = Color.White, Padding = new Padding(8) };
            var coverage = new TabPage("Coverage & scoring") { BackColor = Color.White, Padding = new Padding(8) };
            ConfigureText(_details, "ReviewFindingDetails");
            ConfigureText(_coverage, "ReviewCoverage");
            details.Controls.Add(_details); coverage.Controls.Add(_coverage);
            tabs.TabPages.Add(details); tabs.TabPages.Add(coverage);
            return tabs;
        }

        private Control Footer()
        {
            var footer = CreateLayout("ReviewFooter", 1, 2);
            footer.AutoSize = true;
            footer.Dock = DockStyle.Bottom;
            footer.Padding = new Padding(14, 7, 14, 9);
            footer.BackColor = Color.White;
            footer.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            footer.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            _status.Name = "ReviewStatus";
            ConfigureLabel(_status);
            // Keep long API errors and report paths from consuming the fixed action area.
            _status.AutoSize = false;
            _status.AutoEllipsis = true;
            _status.Height = Font.Height * 3;
            _status.FontChanged += delegate { _status.Height = _status.Font.Height * 3; };
            _status.Margin = new Padding(0, 0, 0, 5);
            footer.Controls.Add(_status, 0, 0);
            var buttons = new TableLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, ColumnCount = 5, RowCount = 1, Margin = new Padding(0) };
            foreach (float width in new[] { 15F, 20F, 25F, 28F, 12F }) buttons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, width));
            buttons.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            _refresh.Name = "ReviewRefreshButton"; _inspect.Name = "ReviewInspectButton";
            _cleanup.Name = "ReviewCleanupButton"; _export.Name = "ReviewExportButton";
            var close = KaTheme.Button("Close"); close.Name = "ReviewCloseButton";
            close.Click += delegate { Close(); };
            var actions = new[] { _refresh, _inspect, _cleanup, _export, close };
            for (int i = 0; i < actions.Length; i++)
            {
                actions[i].AutoSize = false;
                actions[i].Dock = DockStyle.Fill;
                actions[i].Height = 44;
                actions[i].Padding = new Padding(3);
                buttons.Controls.Add(actions[i], i, 0);
            }
            footer.Controls.Add(buttons, 0, 1);
            CancelButton = close;
            _tips.SetToolTip(_cleanup, "Preview the full deletion impact first. CAD links, duplicate candidates and warnings are review-only.");
            _tips.SetToolTip(_inspect, "Summary: show the selected issue's affected elements. Details: show checked findings, or the current finding when none are checked.");
            return footer;
        }

        private void WireEvents()
        {
            _search.TextChanged += delegate { if (!_loading) ApplyFilter(); };
            _kind.SelectedIndexChanged += delegate { if (!_loading) ApplyFilter(); };
            _viewDetails.Click += delegate
            {
                if (_busy || _snapshot == null) return;
                if (_summaryMode) { var group = CurrentGroup(); if (group != null) OpenDetails(group); }
                else ShowSummary();
            };
            _allDetails.Click += delegate { if (!_busy && _snapshot != null) OpenDetails(null); };
            _refresh.Click += delegate { if (!_busy && RefreshRequested != null) RefreshRequested(); };
            _export.Click += delegate { if (!_busy && _snapshot != null && ExportRequested != null) ExportRequested(); };
            _inspect.Click += delegate
            {
                if (_busy || _snapshot == null || InspectRequested == null) return;
                var group = CurrentGroup();
                var keys = _summaryMode ? (group == null ? new List<string>() : group.Findings.Select(x => x.Key).ToList())
                    : _snapshot.Findings.Where(x => _checked.Contains(x.Key)).Select(x => x.Key).ToList();
                var current = CurrentFinding();
                if (!_summaryMode && keys.Count == 0 && current != null) keys.Add(current.Key);
                if (keys.Count > 0) InspectRequested(keys);
            };
            _cleanup.Click += delegate
            {
                if (_busy || _summaryMode || _snapshot == null || CleanupRequested == null) return;
                var keys = _snapshot.Findings.Where(x => x.CanClean && _checked.Contains(x.Key)).Select(x => x.Key).ToList();
                if (keys.Count > 0) CleanupRequested(keys);
            };
            _check.Click += delegate
            {
                if (_busy || _summaryMode || _snapshot == null || !_snapshot.IsComplete) return;
                foreach (DataGridViewRow row in _findings.Rows)
                {
                    var finding = row.Tag as ReviewFinding;
                    if (finding != null && finding.CanClean) _checked.Add(finding.Key);
                }
                UpdateChecks();
            };
            _clear.Click += delegate { _checked.Clear(); UpdateChecks(); };
            _findings.CurrentCellDirtyStateChanged += delegate
            {
                if (_findings.IsCurrentCellDirty && _findings.CurrentCell is DataGridViewCheckBoxCell)
                    _findings.CommitEdit(DataGridViewDataErrorContexts.Commit);
            };
            _findings.CellValueChanged += delegate(object sender, DataGridViewCellEventArgs e)
            {
                if (_loading || _summaryMode || e.RowIndex < 0 || e.ColumnIndex != 0) return;
                var row = _findings.Rows[e.RowIndex]; var finding = row.Tag as ReviewFinding;
                if (finding == null) return;
                if (Convert.ToBoolean(row.Cells[0].Value, CultureInfo.InvariantCulture)) _checked.Add(finding.Key);
                else _checked.Remove(finding.Key);
                UpdateActions();
            };
            _findings.SelectionChanged += delegate { if (!_loading) { UpdateDetails(); UpdateActions(); } };
            _findings.CellDoubleClick += delegate(object sender, DataGridViewCellEventArgs e)
            {
                if (e.RowIndex < 0 || _busy) return;
                if (_summaryMode) { var group = CurrentGroup(); if (group != null) OpenDetails(group); }
                else if (e.ColumnIndex != 0 && _inspect.Enabled) _inspect.PerformClick();
            };
        }

        private void OpenDetails(ReviewIssueGroup group)
        {
            _summaryMode = false;
            _detailGroupKey = group == null ? null : group.Key;
            _checked.Clear();
            _loading = true;
            try { _search.Clear(); _kind.SelectedIndex = 0; }
            finally { _loading = false; }
            RefreshRows();
        }

        private void ShowSummary()
        {
            _summaryMode = true;
            _detailGroupKey = null;
            // Returning to a collapsed list never keeps hidden cleanup approvals.
            _checked.Clear();
            RefreshRows();
        }

        private void ApplyFilter()
        {
            // A filter can hide a previously checked finding. Do not carry cleanup
            // selections across a change of review scope.
            _checked.Clear();
            RefreshRows();
        }

        private IEnumerable<ReviewFinding> DetailFindings()
        {
            if (_snapshot == null) return Enumerable.Empty<ReviewFinding>();
            if (_detailGroupKey == null) return _snapshot.Findings;
            var group = _groups.FirstOrDefault(x => x.Key == _detailGroupKey);
            return group == null ? Enumerable.Empty<ReviewFinding>() : group.Findings;
        }

        private void RefreshRows()
        {
            string current = _summaryMode ? (CurrentGroup() == null ? null : CurrentGroup().Key)
                : (CurrentFinding() == null ? null : CurrentFinding().Key);
            _loading = true;
            try
            {
                _findings.Rows.Clear();
                _findings.Columns["Checked"].Visible = !_summaryMode;
                _findings.Columns["Occurrences"].Visible = _summaryMode;
                _findings.Columns["Finding"].HeaderText = _summaryMode ? "Issue" : "Individual finding";
                _findings.Columns["Action"].HeaderText = _summaryMode ? "Review" : "Cleanup";
                if (_snapshot != null)
                {
                    var search = _search.Text.Trim();
                    if (_summaryMode)
                    {
                        foreach (var group in _groups.Where(x => MatchesKind(x.Kind) &&
                            (search.Length == 0 || (x.Title ?? "").IndexOf(search, StringComparison.CurrentCultureIgnoreCase) >= 0 || x.Findings.Any(f => MatchesSearch(f, search)))))
                        {
                            int index = _findings.Rows.Add(false, KindName(group.Kind), group.Title, group.OccurrenceCount,
                                group.AffectedElementCount, "Open details");
                            var row = _findings.Rows[index]; row.Tag = group;
                            row.Cells[2].ToolTipText = "Repeated occurrences are grouped once. Open details to review individual findings.";
                            row.Cells[3].ToolTipText = "Underlying finding count; used by the unchanged health calculation.";
                            row.Cells[4].ToolTipText = "Distinct affected element IDs across this complete issue group.";
                            if (group.Key == current) _findings.CurrentCell = row.Cells[2];
                        }
                    }
                    else
                    {
                        foreach (var finding in DetailFindings().Where(x => MatchesKind(x.Kind) && MatchesSearch(x, search)))
                        {
                            int index = _findings.Rows.Add(_checked.Contains(finding.Key), KindName(finding.Kind), finding.Title, 1,
                                finding.ElementIds.Distinct().Count(), finding.CanClean ? "Eligible" : "Review only");
                            var row = _findings.Rows[index]; row.Tag = finding;
                            row.Cells[2].ToolTipText = finding.Title + Environment.NewLine + finding.Detail;
                            row.Cells[5].ToolTipText = finding.CanClean ? "Deletion impact must be reviewed before cleanup." : finding.CleanupBlockReason;
                            if (finding.Key == current) _findings.CurrentCell = row.Cells[2];
                        }
                    }
                }
            }
            finally { _loading = false; }
            UpdateDetails(); UpdateActions();
        }

        private void UpdateChecks()
        {
            _loading = true;
            try
            {
                foreach (DataGridViewRow row in _findings.Rows)
                {
                    var finding = row.Tag as ReviewFinding;
                    row.Cells[0].Value = finding != null && _checked.Contains(finding.Key);
                }
            }
            finally { _loading = false; }
            UpdateActions();
        }

        private void UpdateSummary()
        {
            if (_snapshot == null)
            {
                _score.Text = "— / 100";
                _counts.Text = "No scan yet";
                _scan.Text = "This window stays open while you work in Revit. Refresh reads the model again.";
                _coverage.Text = ScoringExplanation();
                return;
            }
            _score.Text = _snapshot.IsComplete ? _snapshot.HealthScore.ToString("0.#", CultureInfo.InvariantCulture) + " / 100" : "Unavailable";
            _score.ForeColor = !_snapshot.IsComplete ? KaTheme.Muted : _snapshot.HealthScore >= 80 ? Color.FromArgb(0, 131, 122) : KaTheme.Warning;
            int scoredIssues = _groups.Count(x => x.Kind != ReviewKind.CadLink);
            int linkedIssues = _groups.Count(x => x.Kind == ReviewKind.CadLink);
            int affected = _snapshot.Findings.SelectMany(x => x.ElementIds).Distinct().Count();
            _counts.Text = scoredIssues + " issue types" + (linkedIssues > 0 ? "  ·  " + linkedIssues + " informational groups" : "") + Environment.NewLine +
                _snapshot.Findings.Count + " occurrences  ·  " + affected + " distinct affected elements";
            string delta = "";
            if (_snapshot.IsComplete && _previousScore.HasValue)
            {
                double difference = _snapshot.HealthScore - _previousScore.Value;
                delta = "  |  Change since previous scan: " + (difference > 0 ? "+" : "") + difference.ToString("0.#", CultureInfo.InvariantCulture);
            }
            _scan.Text = _snapshot.ProjectTitle + "  |  Scanned " + _snapshot.ScannedAt.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.CurrentCulture) + delta;
            _coverage.Text = ScoringExplanation() + Environment.NewLine + Environment.NewLine +
                _snapshot.HealthBreakdown + Environment.NewLine + "Underlying counts: CAD imports " + Count(ReviewKind.CadImport) +
                "; unplaced views " + Count(ReviewKind.UnplacedView) + "; duplicate groups " + Count(ReviewKind.PotentialDuplicate) +
                "; other warnings " + Count(ReviewKind.RevitWarning) + ". Grouping only changes presentation, not the score." + Environment.NewLine + "Model elements counted: " + _snapshot.ModelElementCount + Environment.NewLine +
                "Scan coverage: " + (_snapshot.IsComplete ? "Completed for the stated checks." : "INCOMPLETE — no health score is shown.") + Environment.NewLine + Environment.NewLine +
                string.Join(Environment.NewLine, _snapshot.Notes);
        }

        private void UpdateDetails()
        {
            if (_summaryMode)
            {
                var group = CurrentGroup();
                if (group == null) { _details.Text = _snapshot == null ? "Refresh to load issue groups." : "No issues match this filter."; return; }
                _details.Text = KindName(group.Kind) + " / " + group.Title + Environment.NewLine + Environment.NewLine +
                    group.OccurrenceCount + " occurrences · " + group.AffectedElementCount + " distinct affected elements." + Environment.NewLine +
                    "This row represents the complete issue group, including all matching repeated findings." + Environment.NewLine +
                    "Choose Review issue details to inspect individual findings or select cleanup candidates. Group rows never select items for deletion.";
                return;
            }
            var finding = CurrentFinding();
            if (finding == null) { _details.Text = _snapshot == null ? "Refresh to load findings." : "No findings match this filter."; return; }
            _details.Text = KindName(finding.Kind) + "  /  " + finding.Title + Environment.NewLine + Environment.NewLine +
                finding.Detail + Environment.NewLine + Environment.NewLine +
                "Element IDs: " + string.Join(", ", finding.ElementIds.Select(x => x.ToString(CultureInfo.InvariantCulture))) + Environment.NewLine +
                "Cleanup: " + (finding.CanClean ? "Eligible for preview. Dependent deletions and current model conditions are checked again before applying." : "Review only. " + finding.CleanupBlockReason);
        }

        private void UpdateActions()
        {
            int cleanable = _snapshot == null ? 0 : _snapshot.Findings.Count(x => x.CanClean && _checked.Contains(x.Key));
            _refresh.Enabled = !_busy;
            _inspect.Enabled = !_busy && _snapshot != null && (_summaryMode ? CurrentGroup() != null : _checked.Count > 0 || CurrentFinding() != null);
            _cleanup.Enabled = !_busy && !_summaryMode && cleanable > 0 && _snapshot != null && _snapshot.IsComplete;
            _cleanup.Text = cleanable > 0 ? "Preview cleanup (" + cleanable + ")…" : "Preview cleanup…";
            _export.Enabled = !_busy && _snapshot != null;
            _check.Visible = !_summaryMode; _clear.Visible = !_summaryMode;
            _check.Enabled = !_busy && !_summaryMode && _snapshot != null && _snapshot.IsComplete;
            _clear.Enabled = !_busy && !_summaryMode && _checked.Count > 0;
            _viewDetails.Text = _summaryMode ? "Review issue details" : "Issue summary";
            _viewDetails.Enabled = !_busy && _snapshot != null && (!_summaryMode || CurrentGroup() != null);
            _allDetails.Visible = _summaryMode;
            _allDetails.Enabled = !_busy && _snapshot != null && _snapshot.Findings.Count > 0;
            _selectionHint.Text = _summaryMode ? "Open an issue to review individual findings before cleanup." :
                (_detailGroupKey == null ? "All individual findings. " : "Individual findings for the opened issue. ") + "Changing filters clears checks.";
            _search.Enabled = !_busy; _kind.Enabled = !_busy; _findings.Enabled = !_busy;
            _status.ForeColor = _busy ? KaTheme.Navy : KaTheme.Muted;
            var scope = _snapshot == null ? "" : _summaryMode
                ? "  |  " + _findings.Rows.Count + " shown / " + _groups.Count + " issue groups. Counts include every occurrence in each shown group."
                : "  |  " + _findings.Rows.Count + " shown / " + DetailFindings().Count() + " individual findings; " + _checked.Count + " checked (" + cleanable + " cleanup candidates).";
            _status.Text = _operationStatus + scope;
            _tips.SetToolTip(_status, _status.Text);
        }

        private int Count(ReviewKind kind) { return _snapshot.Findings.Count(x => x.Kind == kind); }
        private ReviewFinding CurrentFinding() { return _findings.CurrentRow == null ? null : _findings.CurrentRow.Tag as ReviewFinding; }
        private ReviewIssueGroup CurrentGroup() { return _findings.CurrentRow == null ? null : _findings.CurrentRow.Tag as ReviewIssueGroup; }
        private bool MatchesKind(ReviewKind kind) { return _kind.SelectedIndex <= 0 || (int)kind == _kind.SelectedIndex - 1; }
        private static bool MatchesSearch(ReviewFinding finding, string search)
        {
            return search.Length == 0 || (finding.Title ?? "").IndexOf(search, StringComparison.CurrentCultureIgnoreCase) >= 0 ||
                (finding.Detail ?? "").IndexOf(search, StringComparison.CurrentCultureIgnoreCase) >= 0 ||
                finding.ElementIds.Any(x => x.ToString(CultureInfo.InvariantCulture).IndexOf(search, StringComparison.Ordinal) >= 0);
        }
        private static string KindName(ReviewKind kind)
        {
            switch (kind)
            {
                case ReviewKind.CadImport: return "CAD import";
                case ReviewKind.CadLink: return "CAD link";
                case ReviewKind.UnplacedView: return "Unplaced view";
                case ReviewKind.PotentialDuplicate: return "Potential duplicates";
                default: return "Revit warning";
            }
        }
        private static string ScoringExplanation()
        {
            return ReviewHealth.Explanation + Environment.NewLine + Environment.NewLine +
                "The summary shows repeated issues once; occurrence counts still drive the health score. Expand an issue to review individual findings. A score of 100 only means these checks have no scored findings; other model problems may exist." + Environment.NewLine +
                "Use Show in Revit to inspect findings. After fixing items or using Undo, press Refresh to rescan. Cleanup handles only explicitly checked, eligible CAD imports and unplaced views, after a deletion-impact preview.";
        }
        private static TableLayoutPanel CreateLayout(string name, int columns, int rows)
        {
            var panel = new TableLayoutPanel { Name = name, Dock = DockStyle.Fill, ColumnCount = columns, RowCount = rows, Margin = new Padding(0) };
            for (int i = 0; i < columns; i++) panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F / columns));
            return panel;
        }
        private static void ConfigureLabel(Label label)
        {
            label.AutoSize = true; label.Dock = DockStyle.Fill; label.Margin = new Padding(0, 2, 0, 3);
        }
        private static void ConfigureText(TextBox text, string name)
        {
            text.Name = name; text.Dock = DockStyle.Fill; text.Multiline = true; text.ReadOnly = true;
            text.ScrollBars = ScrollBars.Vertical; text.BackColor = Color.White; text.BorderStyle = BorderStyle.None;
        }
        private static DataGridViewTextBoxColumn Column(string name, string title, float weight, int minimum)
        {
            return new DataGridViewTextBoxColumn { Name = name, HeaderText = title, FillWeight = weight, MinimumWidth = minimum, ReadOnly = true, SortMode = DataGridViewColumnSortMode.NotSortable };
        }
    }
}
