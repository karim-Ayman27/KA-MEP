using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using PipeTakeoff.Core;
using Form = System.Windows.Forms.Form;
using View = Autodesk.Revit.DB.View;
using TaskDialog = Autodesk.Revit.UI.TaskDialog;

namespace PipeTakeoff.Revit
{
    [Transaction(TransactionMode.Manual)]
    public sealed class ModelReviewCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            try
            {
                var ui = commandData.Application;
                if (ui.ActiveUIDocument == null || ui.ActiveUIDocument.Document.IsFamilyDocument)
                {
                    TaskDialog.Show("KA MEP - Model Review", "Open a Revit project to review its model.");
                    return Result.Cancelled;
                }
                ModelReviewController.Open(ui);
                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                TaskDialog.Show("KA MEP - Model Review", ex.Message);
                return Result.Failed;
            }
        }
    }

    /// <summary>All modeless Revit access goes through an ExternalEvent bound to one document.</summary>
    internal sealed class ModelReviewController : IExternalEventHandler
    {
        private enum Operation { None, Refresh, Inspect, Cleanup }
        private static ModelReviewController _current;
        private readonly Document _document;
        private readonly ModelReviewForm _form;
        private ExternalEvent _event;
        private ReviewSnapshot _snapshot;
        private Operation _pending;
        private IList<string> _keys = new List<string>();
        private bool _executing;
        private bool _closed;

        private ModelReviewController(UIApplication ui)
        {
            _document = ui.ActiveUIDocument.Document;
            _form = new ModelReviewForm();
            _event = ExternalEvent.Create(this);
            _form.RefreshRequested += delegate { Request(Operation.Refresh, null); };
            _form.InspectRequested += keys => Request(Operation.Inspect, keys);
            _form.CleanupRequested += keys => Request(Operation.Cleanup, keys);
            _form.ExportRequested += Export;
            _form.FormClosed += delegate
            {
                _closed = true;
                _pending = Operation.None;
                if (!_executing) DisposeEvent();
                if (ReferenceEquals(_current, this)) _current = null;
            };
            try
            {
                Refresh();
                _form.Show(new RevitOwner(ui.MainWindowHandle));
            }
            catch
            {
                _form.Dispose();
                DisposeEvent();
                throw;
            }
        }

        public static void Open(UIApplication ui)
        {
            if (_current != null && !_current._closed)
            {
                if (_current._document.Equals(ui.ActiveUIDocument.Document))
                {
                    _current._form.WindowState = FormWindowState.Normal;
                    _current._form.Show();
                    _current._form.Activate();
                    return;
                }
                _current._form.Close();
            }
            _current = new ModelReviewController(ui);
        }

        public static void Shutdown()
        {
            if (_current != null) _current._form.Close();
            _current = null;
        }

        public string GetName() { return "KA MEP Model Review & Cleanup"; }

        private void Request(Operation operation, IList<string> keys)
        {
            if (_closed || _executing || _pending != Operation.None) return;
            _pending = operation;
            _keys = keys == null ? new List<string>() : keys.ToList();
            _form.SetBusy(true, "Waiting for Revit. Finish the current command if necessary...");
            try
            {
                var result = _event.Raise();
                if (result != ExternalEventRequest.Accepted && result != ExternalEventRequest.Pending)
                    throw new InvalidOperationException("Revit did not accept the request. Finish the current command and try again.");
            }
            catch (Exception ex)
            {
                _pending = Operation.None;
                _form.SetBusy(false, "");
                _form.ShowFailure(ex.Message);
            }
        }

        public void Execute(UIApplication app)
        {
            if (_closed) { DisposeEvent(); return; }
            var operation = _pending;
            var keys = _keys;
            _pending = Operation.None;
            _executing = true;
            string status = "";
            try
            {
                if (operation == Operation.None) return;
                if (!_document.IsValidObject || app.ActiveUIDocument == null ||
                    !app.ActiveUIDocument.Document.Equals(_document))
                    throw new InvalidOperationException("This review belongs to \"" + _snapshot.ProjectTitle +
                        "\". Activate that project and try again, or close this window and open Model Review for the current project.");
                if (operation == Operation.Refresh) Refresh();
                else if (operation == Operation.Inspect) Inspect(app.ActiveUIDocument, keys);
                else if (operation == Operation.Cleanup) status = Cleanup();
            }
            catch (Exception ex) { _form.ShowFailure(ex.Message); }
            finally
            {
                _executing = false;
                if (_closed) DisposeEvent();
                else _form.SetBusy(false, status);
            }
        }

        private void Refresh()
        {
            var fresh = ModelReviewService.Scan(_document);
            _snapshot = fresh;
            _form.SetSnapshot(fresh);
        }

        private void Inspect(UIDocument ui, IList<string> keys)
        {
            var selected = new HashSet<string>(keys);
            var ids = _snapshot.Findings.Where(f => selected.Contains(f.Key))
                .SelectMany(f => f.ElementIds).Distinct().ToList();
            if (ids.Count == 0) throw new InvalidOperationException("Choose a finding with model elements first.");
            var live = new List<Element>();
            foreach (long id in ids)
            {
                var element = _document.GetElement(RevitCompat.ElementId(id));
                string identity;
                if (element == null || (_snapshot.UniqueIds.TryGetValue(id, out identity) && element.UniqueId != identity))
                    throw new InvalidOperationException("The finding has changed or an element was removed. Press Refresh.");
                live.Add(element);
            }
            if (live.Count == 1 && live[0] is View)
            {
                ui.ActiveView = (View)live[0];
                return;
            }
            var ownerIds = live.Where(e => e.ViewSpecific).Select(e => e.OwnerViewId).Distinct().ToList();
            if (ownerIds.Count == 1 && live.All(e => e.ViewSpecific))
            {
                var view = _document.GetElement(ownerIds[0]) as View;
                if (view != null && !view.IsTemplate) ui.ActiveView = view;
            }
            var elementIds = live.Select(e => e.Id).ToList();
            ui.Selection.SetElementIds(elementIds);
            try { ui.ShowElements(elementIds); }
            catch (Autodesk.Revit.Exceptions.ArgumentException)
            {
                _form.ShowFailure("The elements are selected, but Revit could not display them in a view. Use the element IDs in the details.");
            }
        }

        private string Cleanup()
        {
            var plan = ModelReviewService.PreviewCleanup(_document, _snapshot, _keys);
            using (var confirm = new ModelReviewCleanupForm(plan))
                if (confirm.ShowDialog(_form) != DialogResult.OK)
                {
                    Refresh();
                    return "Cleanup cancelled. No changes saved. Review refreshed; select items again if needed.";
                }

            // ApplyCleanup returns only after commit; post-commit report/refresh errors are handled separately.
            string result = ModelReviewService.ApplyCleanup(_document, plan);
            string report = WriteCleanupLog(plan, result);
            try { Refresh(); }
            catch (Exception ex)
            {
                _form.ShowFailure("Cleanup was saved. Undo once restores the operation. Refresh could not complete: " + ex.Message);
            }
            return result + " Undo once restores this operation." + report;
        }

        private static string WriteCleanupLog(ReviewCleanupPlan plan, string result)
        {
            try
            {
                string folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KAMEP", "Logs");
                Directory.CreateDirectory(folder);
                string file = Path.Combine(folder, "ModelCleanup-" + DateTime.Now.ToString("yyyyMMdd-HHmmss-fff", CultureInfo.InvariantCulture) +
                    "-" + Guid.NewGuid().ToString("N").Substring(0, 6) + ".txt");
                File.WriteAllText(file, "KA MEP " + KAMEP.Branding.ReleaseIdentity.Display + Environment.NewLine +
                    DateTime.Now.ToString("O") + Environment.NewLine + result + Environment.NewLine +
                    string.Join(Environment.NewLine, plan.Lines), new UTF8Encoding(true));
                return " Log: " + file;
            }
            catch (Exception ex) { return " Cleanup log could not be saved: " + ex.Message; }
        }

        private void Export()
        {
            if (_snapshot == null || _closed || _executing || _pending != Operation.None) return;
            using (var dialog = new SaveFileDialog
            {
                Title = "Export Model Review report", Filter = "Excel workbook (*.xlsx)|*.xlsx",
                DefaultExt = "xlsx", AddExtension = true, OverwritePrompt = true,
                FileName = "KA-MEP-Model-Review-" + DateTime.Now.ToString("yyyyMMdd-HHmm", CultureInfo.InvariantCulture) + ".xlsx"
            })
            {
                if (dialog.ShowDialog(_form) != DialogResult.OK) return;
                try
                {
                    var report = new ModelReviewReport
                    {
                        ProjectTitle = _snapshot.ProjectTitle, Release = KAMEP.Branding.ReleaseIdentity.Display,
                        ScannedAt = _snapshot.ScannedAt, IsComplete = _snapshot.IsComplete, HealthScore = _snapshot.HealthScore,
                        HealthExplanation = _snapshot.HealthExplanation + "\n" + _snapshot.HealthBreakdown,
                        Notes = _snapshot.Notes.Concat(new[] { "Export is the last scanned snapshot. Press Refresh after model changes before exporting.",
                            "Model elements: " + _snapshot.ModelElementCount.ToString(CultureInfo.InvariantCulture) }).ToList(),
                        Rows = _snapshot.IssueGroups.SelectMany(group => group.Findings.Select(f => new ModelReviewReportRow
                        {
                            Kind = f.Kind.ToString(), IssueKey = group.Key, IssueTitle = group.Title, Title = f.Title, Detail = f.Detail,
                            ElementIds = new List<long>(f.ElementIds),
                            CleanupAvailability = f.CanClean ? "Eligible for preview; current model is rechecked before cleanup." : f.CleanupBlockReason
                        })).ToList()
                    };
                    ModelReviewXlsxExporter.Export(dialog.FileName, report);
                    _form.SetBusy(false, "Excel report saved: " + dialog.FileName);
                }
                catch (Exception ex) { _form.ShowFailure("The Excel report was not saved. " + ex.Message); }
            }
        }

        private void DisposeEvent()
        {
            if (_event != null) { _event.Dispose(); _event = null; }
        }

        private sealed class RevitOwner : IWin32Window
        {
            public RevitOwner(IntPtr handle) { Handle = handle; }
            public IntPtr Handle { get; private set; }
        }
    }

}
