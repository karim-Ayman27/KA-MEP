using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using DB = Autodesk.Revit.DB;
using PipeTakeoff.Core;

namespace PipeTakeoff.Revit
{
    internal sealed class SheetExportForm : Form
    {
        private readonly List<SheetExportItem> _sheets;
        private readonly DataGridView _grid = new DataGridView();
        private readonly TextBox _search = new TextBox();
        private readonly Label _count = new Label();
        private readonly Label _validation = new Label();
        private readonly CheckBox _pdf = Check("PDF document", true);
        private readonly CheckBox _dwg = Check("AutoCAD DWG", false);
        private readonly CheckBox _combined = Check("Combine into one PDF (list order)", false);
        private readonly TextBox _combinedName = new TextBox();
        private readonly TextBox _prefix = new TextBox();
        private readonly TextBox _suffix = new TextBox();
        private readonly ComboBox _separator = new ComboBox { DropDownStyle = ComboBoxStyle.DropDown, Dock = DockStyle.Fill };
        private readonly TextBox _parameterSearch = new TextBox();
        private readonly ComboBox _availableParameter = Combo();
        private readonly ListBox _namingParts = new ListBox { Height = 126, Dock = DockStyle.Fill, HorizontalScrollbar = true, IntegralHeight = false };
        private readonly List<SheetNamingParameter> _parameters;
        private readonly Label _combinedPreview = new Label { AutoSize = true, Dock = DockStyle.Fill, ForeColor = KaTheme.Muted };
        private readonly TextBox _folder = new TextBox();
        private readonly ComboBox _paper = Combo();
        private readonly ComboBox _orientation = Combo();
        private readonly ComboBox _scale = Combo();
        private readonly NumericUpDown _zoom = new NumericUpDown { Minimum = 1, Maximum = 1000, Value = 100, Width = 100 };
        private readonly ComboBox _pdfColor = Combo();
        private readonly ComboBox _pdfQuality = Combo();
        private readonly ComboBox _processing = Combo();
        private readonly ComboBox _rasterQuality = Combo();
        private readonly CheckBox _hideCrop = Check("Hide crop boundaries", true);
        private readonly CheckBox _hideReference = Check("Hide reference / work planes", true);
        private readonly CheckBox _hideScope = Check("Hide scope boxes", true);
        private readonly CheckBox _hideTags = Check("Hide unreferenced view tags", true);
        private readonly CheckBox _thinHalftone = Check("Replace halftone with thin lines", false);
        private readonly ComboBox _dwgPreset = Combo();
        private readonly CheckBox _override = Check("Override the four options below", false);
        private readonly ComboBox _dwgVersion = Combo();
        private readonly ComboBox _dwgUnit = Combo();
        private readonly ComboBox _dwgColor = Combo();
        private readonly CheckBox _mergeViews = Check("Combine sheet views using Xrefs", false);
        private Control _pdfSettings;
        private Control _dwgSettings;
        private readonly Button _export = KaTheme.Button("Export sheets", true);
        private bool _refreshing;
        public SheetExportRequest Request { get; private set; }

        public SheetExportForm(List<SheetExportItem> sheets, List<SheetNamingParameter> parameters, IList<string> dwgPresets, string projectTitle)
        {
            _sheets = sheets;
            _parameters = parameters;
            _separator.Items.AddRange(new object[] { "_", " - ", " ", "." });
            _separator.Text = "_";
            foreach (var key in new[] { SheetParameterReader.SheetNumberKey, SheetParameterReader.SheetNameKey })
            {
                var field = _parameters.FirstOrDefault(x => x.Key == key);
                if (field != null) _namingParts.Items.Add(field);
            }
            KaTheme.ApplyForm(this, "Sheet Studio", 1220, 820);
            MinimumSize = new Size(1000, 700);
            _combinedName.Text = SheetExportService.SafeStem(projectTitle + "_Sheets", "KA_MEP_Sheets");
            _folder.Text = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, Padding = new Padding(14) };
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.Controls.Add(KaTheme.Header("SHEET STUDIO", "Select your sheets. Set the output. Deliver a coordinated PDF + DWG package."), 0, 0);
            var body = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Margin = new Padding(0) };
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 51));
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 49));
            var left = KaTheme.Section("01", "SHEETS & ORDER", BuildSheetPanel());
            left.Margin = new Padding(0, 0, 12, 0);
            body.Controls.Add(left, 0, 0);
            body.Controls.Add(KaTheme.Section("02", "EXPORT OPTIONS", BuildOptions(dwgPresets)), 1, 0);
            root.Controls.Add(body, 0, 1);
            root.Controls.Add(BuildFooter(), 0, 2);
            Controls.Add(root);
            AcceptButton = _export;
            _export.Click += (s, e) => Confirm();
            _pdf.CheckedChanged += (s, e) => UpdateEnabled();
            _dwg.CheckedChanged += (s, e) => UpdateEnabled();
            _combined.CheckedChanged += (s, e) => UpdateEnabled();
            _paper.SelectedIndexChanged += (s, e) => UpdateEnabled();
            _scale.SelectedIndexChanged += (s, e) => UpdateEnabled();
            _dwgPreset.SelectedIndexChanged += (s, e) => UpdateEnabled();
            _override.CheckedChanged += (s, e) => UpdateEnabled();
            _prefix.TextChanged += (s, e) => UpdatePreviews();
            _suffix.TextChanged += (s, e) => UpdatePreviews();
            _separator.TextChanged += (s, e) => UpdatePreviews();
            _combinedName.TextChanged += (s, e) => UpdateCombinedPreview();
            UpdateCombinedPreview();
            Shown += (s, e) => KaTheme.ClampToScreen(this);
            RefreshSheets();
            UpdateEnabled();
        }

        private Control BuildSheetPanel()
        {
            var panel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 6 };
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.Controls.Add(KaTheme.Hint("SEARCH BY SHEET NUMBER OR NAME"), 0, 0);
            _search.Dock = DockStyle.Fill;
            _search.Margin = new Padding(0, 0, 0, 8);
            _search.TextChanged += (s, e) => RefreshSheets();
            panel.Controls.Add(_search, 0, 1);
            var select = KaTheme.Flow();
            AddAction(select, "Check visible", () => SetVisible(true));
            AddAction(select, "Uncheck visible", () => SetVisible(false));
            AddAction(select, "Clear all", () => { foreach (var item in _sheets) item.Selected = false; RefreshSheets(); });
            panel.Controls.Add(select, 0, 2);
            KaTheme.StyleGrid(_grid, false);
            _grid.MultiSelect = false;
            _grid.EditMode = DataGridViewEditMode.EditOnEnter;
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { Name = "Include", HeaderText = "", Width = 40, AutoSizeMode = DataGridViewAutoSizeColumnMode.None });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Number", HeaderText = "NUMBER", Width = 85, AutoSizeMode = DataGridViewAutoSizeColumnMode.None, ReadOnly = true });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Name", HeaderText = "SHEET NAME", ReadOnly = true });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Preview", HeaderText = "FILE NAME PREVIEW", ReadOnly = true, FillWeight = 145 });
            foreach (DataGridViewColumn column in _grid.Columns) column.SortMode = DataGridViewColumnSortMode.NotSortable;
            _grid.CurrentCellDirtyStateChanged += (s, e) => { if (_grid.IsCurrentCellDirty) _grid.CommitEdit(DataGridViewDataErrorContexts.Commit); };
            _grid.CellValueChanged += (s, e) =>
            {
                if (_refreshing || e.RowIndex < 0 || e.ColumnIndex != 0) return;
                var row = _grid.Rows[e.RowIndex];
                ((SheetExportItem)row.Tag).Selected = Convert.ToBoolean(row.Cells[0].Value);
                UpdateCount();
                UpdatePreviews();
            };
            panel.Controls.Add(_grid, 0, 3);
            var order = KaTheme.Flow();
            AddAction(order, "Move up", () => MoveSelectedSheet(-1));
            AddAction(order, "Move down", () => MoveSelectedSheet(1));
            AddAction(order, "Sort by number", () => { _sheets.Sort((a, b) => StringComparer.CurrentCultureIgnoreCase.Compare(a.Number, b.Number)); RefreshSheets(); });
            panel.Controls.Add(order, 0, 4);
            _count.Dock = DockStyle.Fill;
            _count.AutoSize = true;
            _count.ForeColor = KaTheme.Muted;
            _count.Margin = new Padding(0, 8, 0, 0);
            panel.Controls.Add(_count, 0, 5);
            return panel;
        }

        private Control BuildOptions(IList<string> presets)
        {
            var panel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3 };
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var formats = KaTheme.Flow();
            _pdf.Margin = new Padding(0, 4, 26, 10);
            _dwg.Margin = new Padding(0, 4, 0, 10);
            formats.Controls.Add(_pdf);
            formats.Controls.Add(_dwg);
            panel.Controls.Add(formats, 0, 0);
            var tabs = new TabControl { Dock = DockStyle.Fill };
            var namingTab = new TabPage("File naming") { BackColor = Color.White, Padding = new Padding(10), AutoScroll = true };
            namingTab.Controls.Add(BuildNaming());
            tabs.TabPages.Add(namingTab);
            _pdfSettings = BuildPdf();
            _dwgSettings = BuildDwg(presets);
            var pdfTab = new TabPage("PDF / Print to file") { BackColor = Color.White, Padding = new Padding(10), AutoScroll = true };
            var dwgTab = new TabPage("DWG / AutoCAD") { BackColor = Color.White, Padding = new Padding(10), AutoScroll = true };
            pdfTab.Controls.Add(_pdfSettings);
            dwgTab.Controls.Add(_dwgSettings);
            tabs.TabPages.Add(pdfTab);
            tabs.TabPages.Add(dwgTab);
            panel.Controls.Add(tabs, 0, 1);
            var output = Fields();
            output.Margin = new Padding(0, 10, 0, 0);

            var folder = new TableLayoutPanel { AutoSize = true, Dock = DockStyle.Fill, ColumnCount = 2, Margin = new Padding(0) };
            folder.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            folder.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            _folder.Dock = DockStyle.Fill;
            _folder.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            folder.Controls.Add(_folder, 0, 0);
            var browse = KaTheme.Button("Browse…");
            browse.Margin = new Padding(5, 0, 0, 0);
            browse.Click += (s, e) =>
            {
                using (var dialog = new FolderBrowserDialog { Description = "Choose the parent folder for this export package", SelectedPath = _folder.Text })
                    if (dialog.ShowDialog(this) == DialogResult.OK) _folder.Text = dialog.SelectedPath;
            };
            folder.Controls.Add(browse, 1, 0);
            AddField(output, "Output folder", folder);
            AddWide(output, KaTheme.Hint("A new package folder is created for each run. PDF and DWG use the naming preview; DWG supporting views may add Revit suffixes in each sheet folder."));
            panel.Controls.Add(output, 0, 2);
            return panel;
        }

        private Control BuildNaming()
        {
            var p = Fields();
            AddWide(p, KaTheme.Hint("Compose names from all available Sheet parameters and Project Information. Values use the current model display units."));
            _parameterSearch.Dock = DockStyle.Fill;
            _parameterSearch.TextChanged += (s, e) => RefreshParameterChoices();
            AddField(p, "Find a parameter", _parameterSearch);
            AddField(p, "Available parameter", _availableParameter);
            var add = KaTheme.Flow();
            AddAction(add, "Add parameter", () =>
            {
                if (_availableParameter.SelectedItem == null) return;
                _namingParts.Items.Add(_availableParameter.SelectedItem);
                _namingParts.SelectedIndex = _namingParts.Items.Count - 1;
                UpdatePreviews();
            });
            AddWide(p, add);
            AddField(p, "Name parts in order", _namingParts);
            var actions = KaTheme.Flow();
            AddAction(actions, "Up", () => MoveNamePart(-1));
            AddAction(actions, "Down", () => MoveNamePart(1));
            AddAction(actions, "Remove", () =>
            {
                int index = _namingParts.SelectedIndex;
                if (index < 0) return;
                _namingParts.Items.RemoveAt(index);
                if (_namingParts.Items.Count > 0) _namingParts.SelectedIndex = Math.Min(index, _namingParts.Items.Count - 1);
                UpdatePreviews();
            });
            AddAction(actions, "Reset", () =>
            {
                _namingParts.Items.Clear();
                foreach (var key in new[] { SheetParameterReader.SheetNumberKey, SheetParameterReader.SheetNameKey })
                {
                    var item = _parameters.FirstOrDefault(x => x.Key == key);
                    if (item != null) _namingParts.Items.Add(item);
                }
                UpdatePreviews();
            });
            AddWide(p, actions);
            AddField(p, "Separator / custom", _separator);
            AddField(p, "Prefix", _prefix);
            AddField(p, "Suffix", _suffix);
            AddWide(p, KaTheme.Hint("Missing or unreadable values become NA. Invalid Windows filename characters become _. Duplicate names gain _2, _3… in selected sheet order. Names are limited to 100 characters; PDF/DWG extensions are automatic."));
            AddWide(p, KaTheme.Hint("The preview includes collision suffixes for checked sheets. A combined PDF uses its own name in the PDF tab. Sheet Name and Sheet Number are always available."));
            RefreshParameterChoices();
            return p;
        }

        private void RefreshParameterChoices()
        {
            var previous = _availableParameter.SelectedItem as SheetNamingParameter;
            string search = _parameterSearch.Text.Trim();
            _availableParameter.BeginUpdate();
            _availableParameter.Items.Clear();
            foreach (var parameter in _parameters.Where(x => search.Length == 0 || x.Label.IndexOf(search, StringComparison.CurrentCultureIgnoreCase) >= 0))
                _availableParameter.Items.Add(parameter);
            if (previous != null && _availableParameter.Items.Contains(previous)) _availableParameter.SelectedItem = previous;
            else if (_availableParameter.Items.Count > 0) _availableParameter.SelectedIndex = 0;
            _availableParameter.EndUpdate();
        }

        private void MoveNamePart(int direction)
        {
            int index = _namingParts.SelectedIndex, target = index + direction;
            if (index < 0 || target < 0 || target >= _namingParts.Items.Count) return;
            var item = _namingParts.Items[index];
            _namingParts.Items.RemoveAt(index);
            _namingParts.Items.Insert(target, item);
            _namingParts.SelectedIndex = target;
            UpdatePreviews();
        }

        private SheetNameOptions NamingOptions()
        {
            return new SheetNameOptions { ParameterKeys = _namingParts.Items.Cast<SheetNamingParameter>().Select(x => x.Key).ToList(),
                Prefix = _prefix.Text, Suffix = _suffix.Text, Separator = _separator.Text };
        }

        private void UpdatePreviews()
        {
            if (_refreshing || _grid.Columns.Count < 4) return;
            var selected = _sheets.Where(x => x.Selected).ToList();
            var request = new SheetExportRequest { Sheets = selected, Naming = NamingOptions() };
            var names = SheetExportService.BuildNames(request);
            var selectedNames = new Dictionary<SheetExportItem, string>();
            for (int i = 0; i < selected.Count; i++) selectedNames[selected[i]] = names[i];
            foreach (DataGridViewRow row in _grid.Rows)
            {
                var item = (SheetExportItem)row.Tag;
                string name;
                if (!selectedNames.TryGetValue(item, out name))
                {
                    request.Sheets = new List<SheetExportItem> { item };
                    name = SheetExportService.BuildNames(request)[0];
                }
                row.Cells[3].Value = name;
                row.Cells[3].ToolTipText = name + (item.Selected ? " (selected export name)" : " (check this sheet to resolve collisions)");
            }
        }

        private void UpdateCombinedPreview()
        {
            string name = _combinedName.Text.Trim();
            if (name.EndsWith(".pdf", StringComparison.OrdinalIgnoreCase)) name = name.Substring(0, name.Length - 4);
            _combinedPreview.Text = "Combined PDF: " + SheetExportService.SafeStem(name, "KA_MEP_Sheets") + ".pdf";
        }

        private Control BuildPdf()
        {
            var p = Fields();
            AddWide(p, _combined);
            AddField(p, "Combined file name", _combinedName);
            AddWide(p, _combinedPreview);
            Add(_paper, "Use Sheet Size", DB.ExportPaperFormat.Default);
            Add(_paper, "A4", DB.ExportPaperFormat.ISO_A4); Add(_paper, "A3", DB.ExportPaperFormat.ISO_A3);
            Add(_paper, "A2", DB.ExportPaperFormat.ISO_A2); Add(_paper, "A1", DB.ExportPaperFormat.ISO_A1); Add(_paper, "A0", DB.ExportPaperFormat.ISO_A0);
            AddField(p, "Paper size", _paper);
            Add(_orientation, "Automatic", DB.PageOrientationType.Auto); Add(_orientation, "Landscape", DB.PageOrientationType.Landscape); Add(_orientation, "Portrait", DB.PageOrientationType.Portrait);
            AddField(p, "Orientation", _orientation);
            Add(_scale, "Actual size / 100%", 1); Add(_scale, "Fit to page", 0); Add(_scale, "Custom percentage", 2);
            AddField(p, "Scale", _scale);
            AddField(p, "Custom scale (%)", _zoom);
            AddWide(p, KaTheme.Hint("Use Sheet Size preserves each sheet's original size. Choose A0–A4 to enable orientation and scale. Fit to page changes the drawing's printed scale."));
            Add(_pdfColor, "Color", DB.ColorDepthType.Color); Add(_pdfColor, "Grayscale", DB.ColorDepthType.GrayScale); Add(_pdfColor, "Black lines", DB.ColorDepthType.BlackLine);
            AddField(p, "Colors", _pdfColor);
            Add(_processing, "Vector where possible", false); Add(_processing, "Always raster", true);
            AddField(p, "Graphics", _processing);
            foreach (DB.PDFExportQualityType quality in Enum.GetValues(typeof(DB.PDFExportQualityType)))
                Add(_pdfQuality, quality.ToString().Replace("DPI", "") + " DPI", quality);
            SelectValue(_pdfQuality, "DPI300");
            AddField(p, "Export resolution", _pdfQuality);
            Add(_rasterQuality, "High", DB.RasterQualityType.High); Add(_rasterQuality, "Presentation", DB.RasterQualityType.Presentation);
            Add(_rasterQuality, "Medium", DB.RasterQualityType.Medium); Add(_rasterQuality, "Low", DB.RasterQualityType.Low);
            AddField(p, "Raster quality", _rasterQuality);
            AddWide(p, _hideCrop); AddWide(p, _hideReference); AddWide(p, _hideScope); AddWide(p, _hideTags); AddWide(p, _thinHalftone);
            AddWide(p, KaTheme.Hint("Native Revit PDF export creates print-ready files. Some views require raster processing. Separate PDFs use the naming rule; a combined PDF uses its own file name."));
            return p;
        }

        private Control BuildDwg(IList<string> presets)
        {
            var p = Fields();
            Add(_dwgPreset, "Revit defaults + options below", "");
            foreach (var name in presets) Add(_dwgPreset, name, name);
            if (presets.Count > 0) _dwgPreset.SelectedIndex = 1;
            AddField(p, "Project export setup", _dwgPreset);
            AddWide(p, KaTheme.Hint("Project setups preserve layer mapping and all other Revit DWG settings. The selected setup is never modified."));
            AddWide(p, _override);
            Add(_dwgVersion, "AutoCAD 2018", DB.ACADVersion.R2018); Add(_dwgVersion, "AutoCAD 2013", DB.ACADVersion.R2013);
            Add(_dwgVersion, "AutoCAD 2010", DB.ACADVersion.R2010); Add(_dwgVersion, "AutoCAD 2007", DB.ACADVersion.R2007);
            AddField(p, "DWG version", _dwgVersion);
            Add(_dwgUnit, "Millimeters", DB.ExportUnit.Millimeter); Add(_dwgUnit, "Centimeters", DB.ExportUnit.Centimeter); Add(_dwgUnit, "Meters", DB.ExportUnit.Meter);
            Add(_dwgUnit, "Feet", DB.ExportUnit.Foot); Add(_dwgUnit, "Inches", DB.ExportUnit.Inch); Add(_dwgUnit, "Project default", DB.ExportUnit.Default);
            AddField(p, "Drawing units", _dwgUnit);
            Add(_dwgColor, "Indexed colors", DB.ExportColorMode.IndexColors); Add(_dwgColor, "True color", DB.ExportColorMode.TrueColor); Add(_dwgColor, "True color by view", DB.ExportColorMode.TrueColorPerView);
            AddField(p, "DWG colors", _dwgColor);
            AddWide(p, _mergeViews);
            AddWide(p, KaTheme.Hint("Sheet export may create additional view files and Xrefs. Each sheet is placed in its own folder. Keep that folder's files together when sharing or moving the drawing."));
            AddWide(p, KaTheme.Hint("For shared coordinates, layer standards, solids, fonts and line styles, configure a DWG export setup in Revit, then select it here."));
            return p;
        }

        private Control BuildFooter()
        {
            var footer = new TableLayoutPanel { AutoSize = true, Dock = DockStyle.Fill, ColumnCount = 2, Margin = new Padding(0, 12, 0, 0) };
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            _validation.AutoSize = true;
            _validation.Dock = DockStyle.Fill;
            _validation.ForeColor = Color.FromArgb(166, 52, 43);
            _validation.Text = "Review selection and settings before starting.";
            _validation.ForeColor = KaTheme.Muted;
            footer.Controls.Add(_validation, 0, 0);
            var buttons = KaTheme.Flow();
            buttons.Controls.Add(_export);
            var cancel = KaTheme.Button("Cancel");
            cancel.DialogResult = DialogResult.Cancel;
            CancelButton = cancel;
            buttons.Controls.Add(cancel);
            footer.Controls.Add(buttons, 1, 0);
            return footer;
        }

        private void RefreshSheets(SheetExportItem focus = null)
        {
            _refreshing = true;
            _grid.Rows.Clear();
            var search = _search.Text.Trim();
            foreach (var sheet in _sheets.Where(x => search.Length == 0 || x.Label.IndexOf(search, StringComparison.CurrentCultureIgnoreCase) >= 0))
            {
                var index = _grid.Rows.Add(sheet.Selected, sheet.Number, sheet.Name, "");
                _grid.Rows[index].Tag = sheet;
                if (sheet == focus) _grid.CurrentCell = _grid.Rows[index].Cells[1];
            }
            _refreshing = false;
            UpdateCount();
            UpdatePreviews();
        }

        private void SetVisible(bool selected)
        {
            foreach (DataGridViewRow row in _grid.Rows) ((SheetExportItem)row.Tag).Selected = selected;
            RefreshSheets();
        }

        private void MoveSelectedSheet(int direction)
        {
            if (_grid.CurrentRow == null) return;
            if (_search.Text.Trim().Length > 0) { ShowValidation("Clear the search before changing sheet order."); return; }
            var item = (SheetExportItem)_grid.CurrentRow.Tag;
            var index = _sheets.IndexOf(item);
            var next = index + direction;
            if (next < 0 || next >= _sheets.Count) return;
            _sheets.RemoveAt(index); _sheets.Insert(next, item);
            RefreshSheets(item);
        }

        private void UpdateCount()
        {
            var selected = _sheets.Count(x => x.Selected);
            var hidden = selected - _grid.Rows.Cast<DataGridViewRow>().Count(x => ((SheetExportItem)x.Tag).Selected);
            _count.Text = selected + " selected / " + _sheets.Count + " printable sheets · " + _grid.RowCount + " visible"
                + (hidden > 0 ? "\n" + hidden + " selected sheets are hidden by the search." : "")
                + "\nChecked sheets export in the list order. Placeholder sheets are excluded.";
            _export.Text = "Export " + selected + " sheets";
        }

        private void UpdateEnabled()
        {
            if (_pdfSettings == null || _dwgSettings == null) return;
            _pdfSettings.Enabled = _pdf.Checked;
            _dwgSettings.Enabled = _dwg.Checked;
            _combinedName.Enabled = _combined.Checked;
            bool customPaper = Get<DB.ExportPaperFormat>(_paper) != DB.ExportPaperFormat.Default;
            _orientation.Enabled = customPaper;
            _scale.Enabled = customPaper;
            _zoom.Enabled = customPaper && Get<int>(_scale) == 2;
            bool hasPreset = !string.IsNullOrEmpty(Get<string>(_dwgPreset));
            _override.Enabled = hasPreset;
            bool overrides = !hasPreset || _override.Checked;
            _dwgVersion.Enabled = overrides;
            _dwgUnit.Enabled = overrides;
            _dwgColor.Enabled = overrides;
            _mergeViews.Enabled = overrides;
        }

        private void Confirm()
        {
            _grid.EndEdit();
            var selected = _sheets.Where(x => x.Selected).ToList();
            if (selected.Count == 0) { ShowValidation("Check at least one sheet to export."); return; }
            if (!_pdf.Checked && !_dwg.Checked) { ShowValidation("Select PDF, DWG, or both output formats."); return; }
            if (string.IsNullOrWhiteSpace(_folder.Text)) { ShowValidation("Choose an output folder."); return; }
            string folder;
            try
            {
                folder = Path.GetFullPath(_folder.Text.Trim());
                if (!Directory.Exists(folder)) { ShowValidation("The output folder does not exist. Browse to an existing folder."); return; }
            }
            catch (Exception ex) { ShowValidation("Invalid output folder: " + ex.Message); return; }
            if (_pdf.Checked && _combined.Checked && string.IsNullOrWhiteSpace(_combinedName.Text)) { ShowValidation("Enter a name for the combined PDF."); return; }
            var combinedName = _combinedName.Text.Trim();
            if (combinedName.EndsWith(".pdf", StringComparison.OrdinalIgnoreCase)) combinedName = combinedName.Substring(0, combinedName.Length - 4);
            if (_pdf.Checked && _combined.Checked && string.IsNullOrWhiteSpace(combinedName)) { ShowValidation("Enter a file name before .pdf."); return; }
            if (_namingParts.Items.Count == 0) { ShowValidation("Add at least one parameter to the file naming rule."); return; }
            Request = new SheetExportRequest
            {
                Sheets = selected, Folder = folder, Naming = NamingOptions(), NamingParameters = _namingParts.Items.Cast<SheetNamingParameter>().ToList(), ExportPdf = _pdf.Checked, ExportDwg = _dwg.Checked,
                CombinedPdf = _combined.Checked, CombinedName = combinedName, Paper = Get<DB.ExportPaperFormat>(_paper),
                Orientation = Get<DB.PageOrientationType>(_orientation), FitToPage = Get<int>(_scale) == 0,
                ZoomPercent = Get<int>(_scale) == 2 ? (int)_zoom.Value : 100, PdfColor = Get<DB.ColorDepthType>(_pdfColor),
                PdfQuality = Get<DB.PDFExportQualityType>(_pdfQuality), Raster = Get<bool>(_processing), RasterQuality = Get<DB.RasterQualityType>(_rasterQuality),
                HideCrop = _hideCrop.Checked, HideReference = _hideReference.Checked, HideScope = _hideScope.Checked,
                HideUnreferenced = _hideTags.Checked, ThinHalftone = _thinHalftone.Checked, DwgPreset = Get<string>(_dwgPreset),
                OverrideDwg = _override.Checked, DwgVersion = Get<DB.ACADVersion>(_dwgVersion), DwgUnit = Get<DB.ExportUnit>(_dwgUnit),
                DwgColor = Get<DB.ExportColorMode>(_dwgColor), MergeViews = _mergeViews.Checked
            };
            DialogResult = DialogResult.OK;
            Close();
        }

        private void ShowValidation(string text) { _validation.ForeColor = Color.FromArgb(166, 52, 43); _validation.Text = text; }
        private static ComboBox Combo() { return new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Dock = DockStyle.Fill, IntegralHeight = false, MaxDropDownItems = 12 }; }
        private static CheckBox Check(string text, bool selected) { return new CheckBox { Text = text, Checked = selected, AutoSize = true, Margin = new Padding(0, 4, 0, 5) }; }
        private static void AddAction(FlowLayoutPanel panel, string text, Action action) { var b = KaTheme.Button(text); b.Click += (s, e) => action(); panel.Controls.Add(b); }
        private sealed class Choice { public string Label; public object Value; public override string ToString() { return Label; } }
        private static void Add(ComboBox combo, string label, object value) { combo.Items.Add(new Choice { Label = label, Value = value }); if (combo.SelectedIndex < 0) combo.SelectedIndex = 0; }
        private static T Get<T>(ComboBox combo) { return (T)((Choice)combo.SelectedItem).Value; }
        private static void SelectValue(ComboBox combo, string value) { for (int i = 0; i < combo.Items.Count; i++) if (((Choice)combo.Items[i]).Value.ToString() == value) combo.SelectedIndex = i; }
        private static TableLayoutPanel Fields()
        {
            var p = new TableLayoutPanel { AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, Dock = DockStyle.Top, ColumnCount = 2, Margin = new Padding(0), Padding = new Padding(0, 0, 4, 0) };
            p.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 142)); p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            return p;
        }
        private static void AddField(TableLayoutPanel panel, string label, Control control)
        {
            var row = panel.RowCount++;
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.Controls.Add(new Label { Text = label, AutoSize = true, Anchor = AnchorStyles.Left, Margin = new Padding(0, 7, 8, 7) }, 0, row);
            control.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            control.Margin = new Padding(0, 4, 0, 4);
            panel.Controls.Add(control, 1, row);
        }
        private static void AddWide(TableLayoutPanel panel, Control control)
        {
            var row = panel.RowCount++;
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.Controls.Add(control, 0, row); panel.SetColumnSpan(control, 2);
        }
    }
}
