using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using PipeTakeoff.Core;

namespace PipeTakeoff.Revit
{
    /// <summary>All Revit access stays on the external-command thread; the dialog receives detached values.</summary>
    internal sealed class TagAssistantRevitService
    {
        private sealed class CategoryPair
        {
            public BuiltInCategory Host;
            public BuiltInCategory Tag;
            public string Name;
            public string Key { get { return Host.ToString(); } }
            public CategoryPair(BuiltInCategory host, BuiltInCategory tag, string name) { Host = host; Tag = tag; Name = name; }
        }

        private static readonly CategoryPair[] CategoryPairs =
        {
            new CategoryPair(BuiltInCategory.OST_PipeCurves, BuiltInCategory.OST_PipeTags, "Pipes"),
            new CategoryPair(BuiltInCategory.OST_FlexPipeCurves, BuiltInCategory.OST_FlexPipeTags, "Flex pipes"),
            new CategoryPair(BuiltInCategory.OST_PipeFitting, BuiltInCategory.OST_PipeFittingTags, "Pipe fittings"),
            new CategoryPair(BuiltInCategory.OST_PipeAccessory, BuiltInCategory.OST_PipeAccessoryTags, "Pipe accessories"),
            new CategoryPair(BuiltInCategory.OST_DuctCurves, BuiltInCategory.OST_DuctTags, "Ducts"),
            new CategoryPair(BuiltInCategory.OST_FlexDuctCurves, BuiltInCategory.OST_FlexDuctTags, "Flex ducts"),
            new CategoryPair(BuiltInCategory.OST_DuctFitting, BuiltInCategory.OST_DuctFittingTags, "Duct fittings"),
            new CategoryPair(BuiltInCategory.OST_DuctAccessory, BuiltInCategory.OST_DuctAccessoryTags, "Duct accessories"),
            new CategoryPair(BuiltInCategory.OST_CableTray, BuiltInCategory.OST_CableTrayTags, "Cable trays"),
            new CategoryPair(BuiltInCategory.OST_CableTrayFitting, BuiltInCategory.OST_CableTrayFittingTags, "Cable tray fittings"),
            new CategoryPair(BuiltInCategory.OST_Conduit, BuiltInCategory.OST_ConduitTags, "Conduits"),
            new CategoryPair(BuiltInCategory.OST_ConduitFitting, BuiltInCategory.OST_ConduitFittingTags, "Conduit fittings"),
            new CategoryPair(BuiltInCategory.OST_MechanicalEquipment, BuiltInCategory.OST_MechanicalEquipmentTags, "Mechanical equipment"),
            new CategoryPair(BuiltInCategory.OST_DuctTerminal, BuiltInCategory.OST_DuctTerminalTags, "Air terminals"),
            new CategoryPair(BuiltInCategory.OST_PlumbingFixtures, BuiltInCategory.OST_PlumbingFixtureTags, "Plumbing fixtures"),
#if !REVIT2022
            new CategoryPair(BuiltInCategory.OST_PlumbingEquipment, BuiltInCategory.OST_PlumbingEquipmentTags, "Plumbing equipment"),
#endif
            new CategoryPair(BuiltInCategory.OST_Sprinklers, BuiltInCategory.OST_SprinklerTags, "Sprinklers"),
            new CategoryPair(BuiltInCategory.OST_ElectricalEquipment, BuiltInCategory.OST_ElectricalEquipmentTags, "Electrical equipment"),
            new CategoryPair(BuiltInCategory.OST_ElectricalFixtures, BuiltInCategory.OST_ElectricalFixtureTags, "Electrical fixtures"),
            new CategoryPair(BuiltInCategory.OST_LightingFixtures, BuiltInCategory.OST_LightingFixtureTags, "Lighting fixtures"),
            new CategoryPair(BuiltInCategory.OST_LightingDevices, BuiltInCategory.OST_LightingDeviceTags, "Lighting devices"),
            new CategoryPair(BuiltInCategory.OST_DataDevices, BuiltInCategory.OST_DataDeviceTags, "Data devices"),
            new CategoryPair(BuiltInCategory.OST_CommunicationDevices, BuiltInCategory.OST_CommunicationDeviceTags, "Communication devices"),
            new CategoryPair(BuiltInCategory.OST_FireAlarmDevices, BuiltInCategory.OST_FireAlarmDeviceTags, "Fire alarm devices"),
            new CategoryPair(BuiltInCategory.OST_SecurityDevices, BuiltInCategory.OST_SecurityDeviceTags, "Security devices"),
            new CategoryPair(BuiltInCategory.OST_NurseCallDevices, BuiltInCategory.OST_NurseCallDeviceTags, "Nurse call devices")
        };

        private readonly UIDocument uiDocument;
        private readonly Document document;
        private readonly View view;
        private readonly XYZ origin;
        private readonly XYZ right;
        private readonly XYZ up;
        private readonly XYZ normal;
        private readonly Dictionary<string, XYZ> hostPoints = new Dictionary<string, XYZ>(StringComparer.Ordinal);
        private readonly List<IndependentTag> viewTags = new List<IndependentTag>();
        private TagRectangle? modelCrop;
        private readonly List<TextNote> visibleNotes = new List<TextNote>();
        private readonly Dictionary<long, TagRectangle> visiblePointHostBounds = new Dictionary<long, TagRectangle>();

        public TagAssistantRevitService(UIDocument uiDocument)
        {
            this.uiDocument = uiDocument;
            document = uiDocument.Document;
            view = document.ActiveView;
            origin = view.Origin ?? XYZ.Zero;
            right = view.RightDirection.Normalize();
            up = view.UpDirection.Normalize();
            normal = view.ViewDirection.Normalize();
        }

        public static string UnsupportedReason(UIDocument uiDocument)
        {
            if (uiDocument == null || uiDocument.Document.IsFamilyDocument)
                return "Open a Revit project and a plan, section or elevation view first.";
            var doc = uiDocument.Document;
            var active = doc.ActiveView;
            if (doc.IsReadOnly) return "The current document is read-only.";
            if (active == null || active.IsTemplate) return "Tag Assistant cannot run in a view template.";
            var type = active.ViewType;
            if (type != ViewType.FloorPlan && type != ViewType.CeilingPlan && type != ViewType.EngineeringPlan &&
                type != ViewType.Section && type != ViewType.Elevation && type != ViewType.Detail)
                return "Open a plan, section or elevation view. Sheets, schedules, drafting views and 3D views are not supported by this version.";
            if (!FilteredElementCollector.IsViewValidForElementIteration(doc, active.Id))
                return "Elements cannot be collected from this view.";
            if (active.Scale < 1) return "The active view needs a valid drawing scale.";
            return null;
        }

        public TagAssistantSnapshot Read()
        {
            var snapshot = new TagAssistantSnapshot { ViewName = view.Name, ViewScale = view.Scale };
            hostPoints.Clear();
            viewTags.Clear();
            visibleNotes.Clear();
            visiblePointHostBounds.Clear();
            modelCrop = view.CropBoxActive ? ProjectBounds(view.CropBox) : null;
            snapshot.AllowedBounds = modelCrop; // Near-host labels remain with the drawing, even when annotation crop is off.
            if (view.CropBoxActive)
            {
                using (var cropManager = view.GetCropRegionShapeManager())
                {
                    if (cropManager.ShapeSet || cropManager.NumberOfSplitRegions > 1)
                    {
                        snapshot.NearHostAvailable = false;
                        snapshot.NearHostUnavailableReason = "Near host placement currently requires an unsplit rectangular crop without a custom crop shape. Review this view manually, use an uncropped view, or choose an explicit group pattern.";
                    }
                }
            }
            var selected = new HashSet<long>(uiDocument.Selection.GetElementIds().Select(id => RevitCompat.Id(id)));
            snapshot.HasSelection = selected.Count != 0;
            var pairs = CategoryPairs.ToDictionary(pair => (long)pair.Host);
            var byKey = CategoryPairs.ToDictionary(pair => pair.Key, StringComparer.Ordinal);
            List<FamilySymbol> symbols;
            using (var collector = new FilteredElementCollector(document))
                symbols = collector.OfClass(typeof(FamilySymbol)).Cast<FamilySymbol>().ToList();
            List<IndependentTag> visibleTags;
            using (var collector = new FilteredElementCollector(document, view.Id))
                visibleTags = collector.OfClass(typeof(IndependentTag)).Cast<IndependentTag>().ToList();
            viewTags.AddRange(visibleTags.Where(t => !t.IsHidden(view)));
            foreach (var tag in viewTags)
            {
                try
                {
                    var head = Project(tag.TagHeadPosition);
                    // A leader can make the API box enormous. The detached schematic uses an estimate;
                    // Apply measures the real text with the leader temporarily removed and rolls it back.
                    var bounds = tag.HasLeader ? null : ProjectBounds(tag.get_BoundingBox(view));
                    double width = PaperFeet(tag.TagOrientation == Autodesk.Revit.DB.TagOrientation.Vertical ? 4 : 25);
                    double height = PaperFeet(tag.TagOrientation == Autodesk.Revit.DB.TagOrientation.Vertical ? 25 : 4);
                    snapshot.ExistingTagBounds[RevitCompat.Id(tag.Id)] = bounds ?? new TagRectangle(head.X - width / 2, head.Y - height / 2, head.X + width / 2, head.Y + height / 2);
                }
                catch { snapshot.Notes.Add("An existing tag cannot be shown accurately in the schematic; measured placement is checked before applying."); }
            }
            using (var collector = new FilteredElementCollector(document, view.Id))
                visibleNotes.AddRange(collector.OfClass(typeof(TextNote)).Cast<TextNote>().Where(t => !t.IsHidden(view)));
            foreach (var note in visibleNotes)
            {
                var bounds = ProjectBounds(note.get_BoundingBox(view));
                if (bounds.HasValue) snapshot.ExistingTagObstacles.Add(bounds.Value);
            }

            // Hidden view-owned tags still count as already tagged; arranging is limited to visible tags.
            List<IndependentTag> ownedTags;
            using (var collector = new FilteredElementCollector(document))
                ownedTags = collector.OfClass(typeof(IndependentTag)).OwnedByView(view.Id).Cast<IndependentTag>().ToList();
            var primaryViewId = view.GetPrimaryViewId();
            if (primaryViewId != ElementId.InvalidElementId)
            {
                using (var collector = new FilteredElementCollector(document))
                    ownedTags.AddRange(collector.OfClass(typeof(IndependentTag)).OwnedByView(primaryViewId).Cast<IndependentTag>());
                snapshot.Notes.Add("Tags owned by the primary view are counted as already tagged. Arrange existing only moves tags owned by this active view.");
            }
            var taggedHosts = new HashSet<long>();
            foreach (var tag in ownedTags.Concat(visibleTags).GroupBy(t => RevitCompat.Id(t.Id)).Select(g => g.First()))
            {
                try
                {
#if !REVIT2022 && !REVIT2023
                    if (!tag.HasTagBehavior()) continue;
#endif
                    foreach (var id in tag.GetTaggedLocalElementIds()) taggedHosts.Add(RevitCompat.Id(id));
                }
                catch (Exception ex)
                {
                    snapshot.CanCreateMissing = false;
                    snapshot.Notes.Add("Create missing is unavailable because tag " + Id(tag) + " references could not be read safely: " + ex.Message);
                }
            }

            List<Element> hosts;
            using (var collector = new FilteredElementCollector(document, view.Id))
                hosts = collector.WherePasses(new ElementMulticategoryFilter(CategoryPairs.Select(pair => pair.Host).ToList()))
                    .WhereElementIsNotElementType().ToList();
            // Keep unchecked and already-tagged point-family symbols as obstacles too.
            // Otherwise selecting one pipe could place its label over neighbouring equipment.
            foreach (var host in hosts.Where(h => !(h is MEPCurve) && !h.IsHidden(view)))
            {
                var bounds = HostObstacle(host);
                if (bounds.HasValue)
                {
                    visiblePointHostBounds[RevitCompat.Id(host.Id)] = bounds.Value;
                    snapshot.ExistingTagObstacles.Add(bounds.Value);
                }
            }
            int unreadable = 0;
            foreach (var host in hosts.OrderBy(h => RevitCompat.Id(h.Id)))
            {
                if (host.IsHidden(view) || taggedHosts.Contains(RevitCompat.Id(host.Id))) continue;
                var pipe = host as Autodesk.Revit.DB.Plumbing.Pipe;
                var duct = host as Autodesk.Revit.DB.Mechanical.Duct;
                if ((pipe != null && pipe.IsPlaceholder) || (duct != null && duct.IsPlaceholder)) continue;
                CategoryPair pair;
                if (host.Category == null || !pairs.TryGetValue(RevitCompat.Id(host.Category.Id), out pair)) continue;
                XYZ point;
                if (!TryHostPoint(host, out point)) { unreadable++; continue; }
                string key = "host:" + Id(host);
                hostPoints[key] = point;
                snapshot.Candidates.Add(new TagAssistantCandidate
                {
                    Key = key, HostId = RevitCompat.Id(host.Id), ExistingTagId = 0, CategoryKey = pair.Key,
                    Label = HostLabel(host), IsSelected = selected.Contains(RevitCompat.Id(host.Id)),
                    Anchor = Project(point), ExistingHead = Project(point),
                    Width = PaperFeet(25), Height = PaperFeet(4), Orientation = TagTextOrientation.Horizontal,
                    IsCurve = host is MEPCurve, CurveLengthInternal = VisibleCurveLength(host), HostBounds = HostObstacle(host)
                });
            }
            int skippedTags = 0;
            foreach (var tag in viewTags.OrderBy(t => RevitCompat.Id(t.Id)))
            {
                try
                {
                    Element host;
                    Reference reference;
                    string reason = ExistingTagReason(tag, out host, out reference);
                    if (reason != null)
                    {
                        skippedTags++;
                        if (selected.Contains(RevitCompat.Id(tag.Id))) snapshot.Notes.Add("Selected tag " + Id(tag) + " skipped: " + reason);
                        continue;
                    }
                    CategoryPair pair;
                    if (host.Category == null || !pairs.TryGetValue(RevitCompat.Id(host.Category.Id), out pair)) { skippedTags++; continue; }
                    if (tag.Category == null || RevitCompat.Id(tag.Category.Id) != (long)pair.Tag) { skippedTags++; continue; }
                    XYZ point;
                    if (!TryHostPoint(host, out point)) { unreadable++; continue; }
                    var orientation = tag.TagOrientation == Autodesk.Revit.DB.TagOrientation.Vertical ? TagTextOrientation.Vertical : TagTextOrientation.Horizontal;
                    double width = PaperFeet(orientation == TagTextOrientation.Vertical ? 4 : 25);
                    double height = PaperFeet(orientation == TagTextOrientation.Vertical ? 25 : 4);
                    string key = "tag:" + Id(tag);
                    hostPoints[key] = point;
                    snapshot.Candidates.Add(new TagAssistantCandidate
                    {
                        Key = key, HostId = RevitCompat.Id(host.Id), ExistingTagId = RevitCompat.Id(tag.Id), CategoryKey = pair.Key,
                        Label = HostLabel(host), IsSelected = selected.Contains(RevitCompat.Id(tag.Id)) || selected.Contains(RevitCompat.Id(host.Id)),
                        Anchor = Project(point), ExistingHead = Project(tag.TagHeadPosition), Width = width, Height = height, Orientation = orientation,
                        IsCurve = host is MEPCurve, CurveLengthInternal = VisibleCurveLength(host), HostBounds = HostObstacle(host)
                    });
                }
                catch (Exception ex)
                {
                    skippedTags++;
                    if (selected.Contains(RevitCompat.Id(tag.Id))) snapshot.Notes.Add("Selected tag " + Id(tag) + " skipped: " + ex.Message);
                }
            }

            foreach (var key in snapshot.Candidates.Select(candidate => candidate.CategoryKey).Distinct(StringComparer.Ordinal))
            {
                var pair = byKey[key];
                var category = new TagCategoryOption { Key = key, Name = pair.Name };
                foreach (var symbol in symbols.Where(s => s.Category != null && RevitCompat.Id(s.Category.Id) == (long)pair.Tag)
                    .OrderBy(s => s.FamilyName, StringComparer.CurrentCultureIgnoreCase).ThenBy(s => s.Name, StringComparer.CurrentCultureIgnoreCase))
                    category.Types.Add(new TagTypeOption { Id = RevitCompat.Id(symbol.Id), Name = symbol.FamilyName + " : " + symbol.Name,
                        FamilyName = symbol.FamilyName, TypeName = symbol.Name,
                        RotatesWithComponent = RotatesWithComponent(symbol) });
                snapshot.Categories.Add(category);
            }
            snapshot.Categories = snapshot.Categories.OrderBy(c => c.Name, StringComparer.CurrentCultureIgnoreCase).ToList();
            if (taggedHosts.Count != 0) snapshot.Notes.Add(taggedHosts.Count.ToString(CultureInfo.InvariantCulture) + " tagged hosts are excluded from Create missing, including hosts tagged by unsupported tag types.");
            if (skippedTags != 0) snapshot.Notes.Add(skippedTags.ToString(CultureInfo.InvariantCulture) + " existing tags cannot be arranged (unsupported category/reference, pinned, grouped or orphaned).");
            if (unreadable != 0) snapshot.Notes.Add(unreadable.ToString(CultureInfo.InvariantCulture) + " elements have no readable position in this view.");
            snapshot.Notes.Add("Current document only. Select the intended elements first; no whole-view creation is selected automatically. Family types must already be loaded.");
            snapshot.Notes.Add("Near host uses measured text sizes, a maximum label-center distance and the rectangular drawing crop. Crowded or unreadable placements are skipped, not pushed far away. The schematic uses estimated text sizes.");
            snapshot.Notes.Add("Collision checks cover tag heads, text notes and visible point-family bounds, not every model edge, dimension or leader crossing.");
            snapshot.Notes.Add("The short-run filter uses projected visible paper length. End-on risers have unknown projected length and remain eligible.");
            return snapshot;
        }

        public TagPoint PickOrigin()
        {
            var point = uiDocument.Selection.PickPoint(Autodesk.Revit.UI.Selection.ObjectSnapTypes.None,
                "KA MEP: pick the reference point for the tag pattern. Press Esc to cancel without changes.");
            return Project(point);
        }

        public TagAssistantApplyResult Apply(TagAssistantSnapshot snapshot, TagAssistantOptions options, Func<IReadOnlyList<string>, bool> confirmLayoutWarnings)
        {
            var errors = TagAssistantModel.Validate(snapshot, options);
            if (errors.Count != 0) throw new InvalidOperationException(string.Join("\n", errors));
            bool nearHost = options.Pattern == TagLayoutPattern.NearHost;
            var result = new TagAssistantApplyResult();
            var candidates = TagAssistantModel.Candidates(snapshot, options);
            result.Requested = candidates.Count;
            var measurements = new Dictionary<string, Measurement>(StringComparer.Ordinal);
            var measuredExisting = new Dictionary<long, TagRectangle>();
            var noteObstacles = new List<TagRectangle>();
            using (var trial = new Transaction(document, "KA MEP - measure tag heads (rolled back)"))
            {
                if (trial.Start() != TransactionStatus.Started) throw new InvalidOperationException("Could not start the tag measurement transaction.");
                try
                {
                    foreach (var candidate in candidates)
                    {
                        using (var sub = new SubTransaction(document))
                        {
                            sub.Start();
                            try
                            {
                                var originalEndpoint = CaptureExistingLeader(candidate);
                                var tag = PrepareTag(candidate, options, false);
                                if (tag.HasLeader) tag.HasLeader = false;
                                document.Regenerate();
                                if (candidate.ExistingTagId == 0 && MissingTagText(tag))
                                    throw new InvalidOperationException("The selected family produces an empty label or question marks. Choose a family with useful populated parameters.");
                                var measurement = Measure(tag);
                                if (measurement == null)
                                {
                                    if (nearHost) throw new InvalidOperationException("The real label bounds are unavailable; near-host placement skips this tag instead of guessing its size.");
                                    measurement = new Measurement
                                    {
                                        Width = PaperFeet(options.Orientation == TagTextOrientation.Vertical ? options.EstimatedHeightMm : options.EstimatedWidthMm),
                                        Height = PaperFeet(options.Orientation == TagTextOrientation.Vertical ? options.EstimatedWidthMm : options.EstimatedHeightMm),
                                        HeadOffset = new TagPoint(0, 0)
                                    };
                                    result.Warnings.Add("Host " + candidate.HostId + ": tag head bounds unavailable; estimated dimensions are used. Check the result in Revit.");
                                }
                                var symbol = document.GetElement(tag.GetTypeId()) as FamilySymbol;
                                if (symbol != null && RotatesWithComponent(symbol))
                                    result.Warnings.Add("Host " + candidate.HostId + ": " + symbol.FamilyName + " rotates with its component; the family may override the requested text orientation.");
                                if (nearHost && candidate.ExistingTagId != 0)
                                {
                                    var leader = originalEndpoint;
                                    if (leader != null && leader.FreeEnd != null && Distance(Project(leader.FreeEnd), candidate.Anchor) > PaperFeet(options.MaximumDistanceMm))
                                        result.Warnings.Add("Tag " + candidate.ExistingTagId + ": its existing free leader endpoint is far from the host. The endpoint is preserved; inspect the leader manually.");
                                }
                                if (options.LeaderStyle == TagLeaderStyle.Orthogonal)
                                {
                                    var references = tag.GetTaggedReferences();
                                    if (references.Count != 1) throw new InvalidOperationException("Right-angle leaders require exactly one reference.");
                                    // Test API/family support inside the rolled-back trial before confirming the batch.
                                    PrepareOrthogonalLeader(tag, references[0], originalEndpoint == null || originalEndpoint.FreeEnd == null
                                        ? hostPoints[candidate.Key] : originalEndpoint.FreeEnd);
                                }
                                measurements.Add(candidate.Key, measurement);
                            }
                            catch (Autodesk.Revit.Exceptions.RegenerationFailedException) { throw; }
                            catch (Exception ex)
                            {
                                result.Skipped++;
                                result.Details.Add("SKIPPED host " + candidate.HostId + TagSuffix(candidate) + ": " + ex.Message);
                            }
                            finally { if (sub.GetStatus() == TransactionStatus.Started) sub.RollBack(); }
                        }
                    }

                    var movableIds = new HashSet<long>(candidates.Where(c => c.ExistingTagId != 0 && measurements.ContainsKey(c.Key)).Select(c => c.ExistingTagId));
                    // Near host also measures current positions of moving tags: skipped tags stay there and become obstacles.
                    var obstacleTags = viewTags.Where(t => nearHost || !movableIds.Contains(RevitCompat.Id(t.Id))).ToList();
                    int limit = nearHost ? TagLayoutEngine.MaximumObstacles : 500;
                    if (nearHost && obstacleTags.Count + visibleNotes.Count > limit)
                        throw new InvalidOperationException("This view has more than " + limit + " tag/text obstacles. Near-host placement cannot verify all of them. Use a smaller cropped view.");
                    foreach (var fixedTag in obstacleTags.Take(limit))
                    {
                        using (var sub = new SubTransaction(document))
                        {
                            sub.Start();
                            try
                            {
                                if (fixedTag.OwnerViewId == view.Id && fixedTag.HasLeader) fixedTag.HasLeader = false;
                                document.Regenerate();
                                var bounds = ProjectBounds(fixedTag.get_BoundingBox(view));
                                if (!bounds.HasValue) throw new InvalidOperationException("Existing tag bounds are unavailable.");
                                measuredExisting[RevitCompat.Id(fixedTag.Id)] = bounds.Value;
                            }
                            catch (Autodesk.Revit.Exceptions.RegenerationFailedException) { throw; }
                            catch
                            {
                                // Protected primary-view/pinned tags may reject edits; their full bounds are conservative.
                                var bounds = ProjectBounds(fixedTag.get_BoundingBox(view));
                                if (bounds.HasValue) measuredExisting[RevitCompat.Id(fixedTag.Id)] = bounds.Value;
                                else if (nearHost) throw new InvalidOperationException("Existing tag " + Id(fixedTag) + " cannot be measured. Near-host placement stopped before changing the model.");
                                else result.Warnings.Add("A fixed tag has no readable obstacle bounds; review annotations manually.");
                            }
                            finally { if (sub.GetStatus() == TransactionStatus.Started) sub.RollBack(); }
                        }
                    }
                    if (!nearHost && obstacleTags.Count > limit) result.Warnings.Add("Only the first 500 existing tags were considered as fixed obstacles. Review other annotations manually.");
                    if (nearHost)
                    {
                        foreach (var note in visibleNotes)
                        {
                            var bounds = ProjectBounds(note.get_BoundingBox(view));
                            if (!bounds.HasValue) throw new InvalidOperationException("A text note cannot be measured. Near-host placement stopped before changing the model.");
                            noteObstacles.Add(bounds.Value);
                        }
                        noteObstacles.AddRange(visiblePointHostBounds.Values);
                    }
                }
                finally { if (trial.GetStatus() == TransactionStatus.Started) trial.RollBack(); }
            }

            if (measurements.Count == 0)
            {
                result.Warnings.Add("No useful compatible labels could be prepared. No changes were made.");
                return result;
            }
            var successfulCandidates = candidates.Where(c => measurements.ContainsKey(c.Key)).ToList();
            var activeCandidates = successfulCandidates.ToList();
            var obstacles = new List<TagRectangle>();
            TagLayoutResult layout;
            while (true)
            {
                var movingIds = new HashSet<long>(activeCandidates.Where(c => c.ExistingTagId != 0).Select(c => c.ExistingTagId));
                obstacles = measuredExisting.Where(pair => !movingIds.Contains(pair.Key)).Select(pair => pair.Value).Concat(noteObstacles).ToList();
                if (nearHost)
                {
                    // Distant objects cannot intersect any candidate's bounded search area.
                    obstacles = obstacles.Where(o => activeCandidates.Any(c => ObstacleCanAffect(o, c.Anchor,
                        PaperFeet(options.MaximumDistanceMm + options.SpacingMm), measurements[c.Key].Width, measurements[c.Key].Height))).ToList();
                    if (obstacles.Count > TagLayoutEngine.MaximumObstacles)
                        throw new InvalidOperationException("More than " + TagLayoutEngine.MaximumObstacles + " nearby tag, text or point-family obstacles need checking. Use a smaller selection or cropped view.");
                }
                layout = TagLayoutEngine.Arrange(activeCandidates.Select(c =>
                    new TagLayoutItem(c.Key, c.Anchor, measurements[c.Key].Width, measurements[c.Key].Height) { HostBounds = nearHost ? c.HostBounds : null }),
                    TagAssistantModel.BuildLayoutOptions(snapshot, options), obstacles);
                if (!nearHost || layout.SkippedKeys.Count == 0) break;
                var skipped = new HashSet<string>(layout.SkippedKeys, StringComparer.Ordinal);
                bool fixedTagAdded = activeCandidates.Any(c => c.ExistingTagId != 0 && skipped.Contains(c.Key));
                result.Warnings.AddRange(layout.Warnings);
                foreach (var candidate in activeCandidates.Where(c => skipped.Contains(c.Key)))
                {
                    result.Skipped++;
                    result.Details.Add("SKIPPED host " + candidate.HostId + TagSuffix(candidate) + ": no clear measured position inside the distance/crop limits. Existing tag kept in place.");
                }
                activeCandidates.RemoveAll(c => skipped.Contains(c.Key));
                // Newly fixed existing tags can block earlier placements, so rerun with their measured original bounds.
                if (!fixedTagAdded) break;
            }
            result.Warnings.AddRange(layout.Warnings);
            result.Planned = layout.Placements.Count;
            result.MaximumDistanceMm = layout.Placements.Count == 0 ? 0 : layout.Placements.Max(p => Distance(p.Head, p.Anchor)) * 304.8 / view.Scale;
            if (layout.Placements.Count == 0)
            {
                result.Warnings.Add("No clear nearby positions were found within the chosen limits. No tags were created or moved. Reduce the selection or choose a smaller readable tag family.");
                return result;
            }
            var reviewWarnings = new List<string>
            {
                "Requested: " + result.Requested + " | Measured placements: " + result.Planned + " | Skipped: " + result.Skipped,
                "Maximum label-center distance from its element: " + result.MaximumDistanceMm.ToString("0.#", CultureInfo.InvariantCulture) + " paper mm.",
                nearHost ? "Only nearby clear placements are included. Crowded labels are skipped; existing skipped tags remain in place." : "This is a group pattern. Check its distance and scope before applying. Near host keeps individual labels close to their elements."
            };
            reviewWarnings.AddRange(result.Warnings.Distinct());
            if (options.LeaderStyle == TagLeaderStyle.Orthogonal)
                reviewWarnings.Add("Right-angle leaders preserve tag alignment and existing free endpoints. Attached/new endpoints become free at the host; leader starts are attached to the label. Already axis-aligned endpoints use a straight axis-aligned line.");
            var crop = AnnotationCropBounds();
            if (crop.HasValue)
            {
                int outside = layout.Placements.Count(p => !Contains(crop.Value, p.Bounds));
                if (outside != 0)
                {
                    var warning = outside.ToString(CultureInfo.InvariantCulture) + " measured tag heads extend outside the active annotation crop and may not be visible.";
                    reviewWarnings.Add(warning); result.Warnings.Add(warning);
                }
            }
            // Every batch receives a concrete measured count/distance review, even with no conflict warnings.
            if (confirmLayoutWarnings == null || !confirmLayoutWarnings(reviewWarnings))
            {
                result.Cancelled = true;
                result.Details.Add("CANCELLED after measured-layout review. No changes were made.");
                return result;
            }
            var placementByKey = layout.Placements.ToDictionary(p => p.Key, StringComparer.Ordinal);
            var failureHandler = new TagFailureHandler(result);
            using (var transaction = new Transaction(document, "KA MEP - Tag Assistant"))
            {
                if (transaction.Start() != TransactionStatus.Started) throw new InvalidOperationException("Could not start the Tag Assistant transaction.");
                transaction.SetFailureHandlingOptions(transaction.GetFailureHandlingOptions()
                    .SetFailuresPreprocessor(failureHandler).SetClearAfterRollback(true).SetForcedModalHandling(true));
                try
                {
                    foreach (var candidate in successfulCandidates.Where(c => placementByKey.ContainsKey(c.Key)))
                    {
                        using (var sub = new SubTransaction(document))
                        {
                            sub.Start();
                            try
                            {
                                var placement = placementByKey[candidate.Key];
                                var originalLeader = CaptureExistingLeader(candidate);
                                var tag = PrepareTag(candidate, options, false);
                                if (tag.HasLeader) tag.HasLeader = false;
                                var refs = tag.GetTaggedReferences();
                                if (refs.Count != 1) throw new InvalidOperationException("The tag no longer has exactly one reference.");
                                var reference = refs[0];
                                var measured = measurements[candidate.Key];
                                var head = new TagPoint(placement.Head.X + measured.HeadOffset.X, placement.Head.Y + measured.HeadOffset.Y);
                                double depth = Depth(tag.TagHeadPosition);
                                tag.TagHeadPosition = Unproject(head, depth);
                                document.Regenerate();
                                if (nearHost)
                                {
                                    var actual = ProjectBounds(tag.get_BoundingBox(view));
                                    if (!actual.HasValue) throw new InvalidOperationException("The placed tag's actual text bounds cannot be verified.");
                                    var bounds = actual.Value;
                                    var center = new TagPoint((bounds.Left + bounds.Right) / 2, (bounds.Bottom + bounds.Top) / 2);
                                    if (Distance(center, candidate.Anchor) > PaperFeet(options.MaximumDistanceMm) + 1e-8 ||
                                        (snapshot.AllowedBounds.HasValue && !Contains(snapshot.AllowedBounds.Value, bounds)))
                                        throw new InvalidOperationException("The family moved its label beyond the measured distance/crop limit.");
                                    if (obstacles.Any(o => o.Intersects(bounds)) || layout.Placements.Any(p => p.Key != candidate.Key && p.Bounds.Intersects(bounds)) ||
                                        activeCandidates.Any(c => c.HostBounds.HasValue && c.HostBounds.Value.Intersects(bounds)))
                                        throw new InvalidOperationException("The final family geometry overlaps a checked obstacle or another planned tag.");
                                    double tolerance = PaperFeet(0.01);
                                    if (Math.Abs(bounds.Left - placement.Bounds.Left) > tolerance || Math.Abs(bounds.Right - placement.Bounds.Right) > tolerance ||
                                        Math.Abs(bounds.Bottom - placement.Bounds.Bottom) > tolerance || Math.Abs(bounds.Top - placement.Bounds.Top) > tolerance)
                                        throw new InvalidOperationException("The family changed its text size or offset after measurement. The nearby layout could not be verified.");
                                }
                                bool requestedLeader = options.LeaderStyle != TagLeaderStyle.None;
                                if (tag.HasLeader != requestedLeader) tag.HasLeader = requestedLeader;
                                if (tag.HasLeader)
                                {
                                    if (options.LeaderStyle == TagLeaderStyle.Orthogonal)
                                    {
                                        ApplyOrthogonalLeader(tag, reference, originalLeader == null || originalLeader.FreeEnd == null
                                            ? hostPoints[candidate.Key] : originalLeader.FreeEnd, head, options.Pattern,
                                            nearHost ? snapshot.AllowedBounds : null);
                                    }
                                    else
                                    {
                                        if (originalLeader != null)
                                        {
                                            if (tag.LeaderEndCondition != originalLeader.EndCondition)
                                            {
                                                if (!tag.CanLeaderEndConditionBeAssigned(originalLeader.EndCondition))
                                                    throw new InvalidOperationException("The chosen type cannot preserve this tag's existing leader end condition.");
                                                tag.LeaderEndCondition = originalLeader.EndCondition;
                                            }
                                            if (originalLeader.FreeEnd != null) tag.SetLeaderEnd(reference, originalLeader.FreeEnd);
                                        }
                                        var elbow = options.LeaderStyle == TagLeaderStyle.Straight ? head :
                                            new TagPoint(head.X + placement.Elbow.X - placement.Head.X, head.Y + placement.Elbow.Y - placement.Head.Y);
                                        if (options.LeaderStyle == TagLeaderStyle.Elbow || tag.HasLeaderElbow(reference))
                                            tag.SetLeaderElbow(reference, Unproject(elbow, depth));
                                    }
                                }
                                document.Regenerate();
                                if (sub.Commit() != TransactionStatus.Committed) throw new InvalidOperationException("Revit did not commit this tag change.");
                                if (candidate.ExistingTagId == 0) result.Created++; else result.Moved++;
                                result.Details.Add((candidate.ExistingTagId == 0 ? "CREATED" : "ARRANGED") + " tag " + Id(tag) + " for host " + candidate.HostId);
                            }
                            catch (Autodesk.Revit.Exceptions.RegenerationFailedException) { throw; }
                            catch (Exception ex)
                            {
                                if (sub.GetStatus() == TransactionStatus.Started) sub.RollBack();
                                if (nearHost) throw new InvalidOperationException("Nearby placement could not be verified for host " + candidate.HostId + ". The entire tag operation was rolled back. " + ex.Message, ex);
                                result.Skipped++;
                                result.Details.Add("SKIPPED host " + candidate.HostId + TagSuffix(candidate) + ": " + ex.Message);
                            }
                        }
                    }
                    if (result.Created + result.Moved == 0) { transaction.RollBack(); return result; }
                    if (transaction.Commit() != TransactionStatus.Committed)
                    {
                        result.Details.Add("ROLLED BACK: Revit rejected the final transaction. No tag changes were kept.");
                        result.Created = result.Moved = 0;
                        result.Skipped = result.Requested;
                        result.RolledBack = true;
                    }
                }
                catch
                {
                    if (transaction.GetStatus() == TransactionStatus.Started) transaction.RollBack();
                    throw;
                }
            }
            result.Warnings.Add("Review the final layout in Revit. Checks cover tag heads, text notes and visible point-family bounds, not every model edge, dimension or leader crossing.");
            return result;
        }

        private static bool MissingTagText(IndependentTag tag)
        {
            var text = tag.TagText;
            return string.IsNullOrWhiteSpace(text) || text.All(c => char.IsWhiteSpace(c) || c == '?');
        }

        private void PrepareOrthogonalLeader(IndependentTag tag, Reference reference, XYZ endpoint)
        {
            if (!tag.HasLeader) tag.HasLeader = true;
            if (tag.LeaderEndCondition != LeaderEndCondition.Free)
            {
                if (!tag.CanLeaderEndConditionBeAssigned(LeaderEndCondition.Free))
                    throw new InvalidOperationException("This tag family cannot use the free endpoint needed for a verified right-angle leader.");
                tag.LeaderEndCondition = LeaderEndCondition.Free;
            }
#if REVIT2027
            // A free start is independent of TagHeadPosition; attaching it is necessary
            // for a head-based elbow to stay axis aligned in Revit 2027.
            if (tag.LeaderStartCondition != LeaderStartCondition.Attached)
            {
                if (!tag.CanLeaderStartConditionBeAssigned(LeaderStartCondition.Attached))
                    throw new InvalidOperationException("This tag family cannot attach the leader start to the label for a right-angle leader.");
                tag.LeaderStartCondition = LeaderStartCondition.Attached;
            }
#endif
            tag.SetLeaderEnd(reference, endpoint);
            document.Regenerate();
            if (tag.GetLeaderEnd(reference).DistanceTo(endpoint) > 1e-7)
                throw new InvalidOperationException("Revit changed the leader endpoint; the right-angle leader cannot be verified.");
        }

        private void ApplyOrthogonalLeader(IndependentTag tag, Reference reference, XYZ endpoint, TagPoint plannedHead,
            TagLayoutPattern pattern, TagRectangle? allowedBounds)
        {
            PrepareOrthogonalLeader(tag, reference, endpoint);
            const double tolerance = 1e-7;
            var actualHead = Project(tag.TagHeadPosition);
            if (Distance(actualHead, plannedHead) > tolerance)
                throw new InvalidOperationException("The family moved the tag head when enabling its leader; the requested alignment cannot be preserved.");
            var end = Project(tag.GetLeaderEnd(reference));
            var elbow = TagLayoutEngine.OrthogonalElbow(end, actualHead, pattern);
            if (allowedBounds.HasValue && !Contains(allowedBounds.Value, elbow))
                throw new InvalidOperationException("The right-angle elbow falls outside the permitted annotation area.");
            bool needsBend = Math.Abs(end.X - actualHead.X) > tolerance && Math.Abs(end.Y - actualHead.Y) > tolerance;
            // Revit represents collinear endpoints as a straight leader without an elbow.
            if (needsBend || tag.HasLeaderElbow(reference))
                tag.SetLeaderElbow(reference, Unproject(needsBend ? elbow : actualHead, Depth(tag.TagHeadPosition)));
            document.Regenerate();
            var verifiedHead = Project(tag.TagHeadPosition);
            if (Distance(verifiedHead, plannedHead) > tolerance || tag.GetLeaderEnd(reference).DistanceTo(endpoint) > tolerance)
                throw new InvalidOperationException("Revit changed the tag head or leader endpoint; this right-angle placement was rejected.");
            var hasElbow = tag.HasLeaderElbow(reference);
            if (needsBend && !hasElbow)
                throw new InvalidOperationException("This family did not retain the requested right-angle elbow.");
            var verifiedElbow = hasElbow ? Project(tag.GetLeaderElbow(reference)) : verifiedHead;
            if ((needsBend && Distance(verifiedElbow, elbow) > tolerance) ||
                !AxisAligned(end, verifiedElbow, tolerance) || !AxisAligned(verifiedElbow, verifiedHead, tolerance))
                throw new InvalidOperationException("The resulting leader is not axis aligned; the tag was left unchanged.");
        }

        private static bool AxisAligned(TagPoint a, TagPoint b, double tolerance)
        { return Math.Abs(a.X - b.X) <= tolerance || Math.Abs(a.Y - b.Y) <= tolerance; }

        private IndependentTag PrepareTag(TagAssistantCandidate candidate, TagAssistantOptions options, bool addLeader)
        {
            var host = document.GetElement(RevitCompat.ElementId(candidate.HostId));
            if (host == null) throw new InvalidOperationException("The host no longer exists.");
            CategoryPair pair = CategoryPairs.FirstOrDefault(p => p.Key == candidate.CategoryKey);
            if (pair == null || host.Category == null || RevitCompat.Id(host.Category.Id) != (long)pair.Host)
                throw new InvalidOperationException("The host category changed or is not supported.");
            IndependentTag tag;
            if (candidate.ExistingTagId != 0)
            {
                tag = document.GetElement(RevitCompat.ElementId(candidate.ExistingTagId)) as IndependentTag;
                if (tag == null) throw new InvalidOperationException("The existing tag no longer exists.");
                Element currentHost;
                Reference reference;
                var reason = ExistingTagReason(tag, out currentHost, out reference);
                if (reason != null) throw new InvalidOperationException(reason);
                if (currentHost.Id != host.Id) throw new InvalidOperationException("The tag now refers to a different host.");
                if (!options.PreserveExistingTypes)
                {
                    var symbol = SelectedSymbol(candidate, options, pair);
                    if (!symbol.IsActive) symbol.Activate();
                    if (tag.GetTypeId() != symbol.Id)
                    {
                        var replacement = tag.ChangeTypeId(symbol.Id);
                        if (replacement != ElementId.InvalidElementId) tag = document.GetElement(replacement) as IndependentTag;
                        if (tag == null) throw new InvalidOperationException("Revit could not change the tag type.");
                    }
                }
            }
            else
            {
                var symbol = SelectedSymbol(candidate, options, pair);
                if (!symbol.IsActive) symbol.Activate();
                tag = IndependentTag.Create(document, symbol.Id, view.Id, new Reference(host), addLeader,
                    ApiOrientation(options.Orientation), hostPoints[candidate.Key]);
                if (tag == null) throw new InvalidOperationException("Revit did not create a tag for this host and family.");
            }
            tag.TagOrientation = ApiOrientation(options.Orientation);
            return tag;
        }

        private OriginalLeader CaptureExistingLeader(TagAssistantCandidate candidate)
        {
            if (candidate.ExistingTagId == 0) return null;
            var tag = document.GetElement(RevitCompat.ElementId(candidate.ExistingTagId)) as IndependentTag;
            if (tag == null || !tag.HasLeader) return null;
            var state = new OriginalLeader { EndCondition = tag.LeaderEndCondition };
            if (state.EndCondition == LeaderEndCondition.Free)
            {
                var references = tag.GetTaggedReferences();
                if (references.Count != 1) throw new InvalidOperationException("Cannot preserve a multi-reference leader endpoint.");
                state.FreeEnd = tag.GetLeaderEnd(references[0]);
            }
            return state;
        }

        private sealed class OriginalLeader
        {
            public LeaderEndCondition EndCondition;
            public XYZ FreeEnd;
        }

        private FamilySymbol SelectedSymbol(TagAssistantCandidate candidate, TagAssistantOptions options, CategoryPair pair)
        {
            long symbolId;
            if (!options.SelectedTypeIds.TryGetValue(candidate.CategoryKey, out symbolId))
                throw new InvalidOperationException("Choose a loaded tag family/type for this category.");
            var symbol = document.GetElement(RevitCompat.ElementId(symbolId)) as FamilySymbol;
            if (symbol == null || symbol.Category == null || RevitCompat.Id(symbol.Category.Id) != (long)pair.Tag)
                throw new InvalidOperationException("The selected tag family/type is not compatible with this category.");
            return symbol;
        }

        private string ExistingTagReason(IndependentTag tag, out Element host, out Reference reference)
        {
            host = null;
            reference = null;
            if (tag.OwnerViewId != view.Id) return "The tag belongs to another view.";
#if !REVIT2022 && !REVIT2023
            if (!tag.HasTagBehavior()) return "This annotation does not support tag operations.";
#endif
            if (tag.Pinned) return "Pinned tags are not moved.";
            if (tag.GroupId != ElementId.InvalidElementId) return "Grouped tags are not moved.";
            if (tag.IsOrphaned) return "The tag is orphaned.";
            if (tag.IsMaterialTag || tag.IsMulticategoryTag) return "Material and multi-category tags are not supported.";
            if (tag.MultiReferenceAnnotationId != ElementId.InvalidElementId || tag.MultiLeader) return "Multi-reference tags are not supported.";
            var refs = tag.GetTaggedReferences();
            if (refs.Count != 1) return "Exactly one local element reference is required.";
            reference = refs[0];
            if (reference.LinkedElementId != ElementId.InvalidElementId) return "Tags of linked elements are not supported.";
            if (tag.IsTaggedOnSubelement()) return "Subelement tags are not supported.";
            host = document.GetElement(reference.ElementId);
            if (host == null) return "The tagged element cannot be found.";
            return null;
        }

        private bool TryHostPoint(Element host, out XYZ point)
        {
            point = null;
            try
            {
                if (host.IsHidden(view)) return false;
                var curve = host.Location as LocationCurve;
                if (curve != null && curve.Curve != null && curve.Curve.IsBound)
                {
                    var line = curve.Curve as Line;
                    if (line != null)
                    {
                        double first, last;
                        if (!VisibleLineRange(line, out first, out last)) return false;
                        point = line.Evaluate((first + last) * 0.5, true);
                    }
                    else point = curve.Curve.Evaluate(0.5, true);
                }
                var location = host.Location as LocationPoint;
                if (point == null && location != null) point = location.Point;
                if (point == null)
                {
                    var box = host.get_BoundingBox(view);
                    if (box != null) point = box.Transform.OfPoint((box.Min + box.Max) * 0.5);
                }
                return point != null && (!modelCrop.HasValue || Contains(modelCrop.Value, Project(point)));
            }
            catch { return false; }
        }

        private double? VisibleCurveLength(Element host)
        {
            if (!(host is MEPCurve)) return null;
            var location = host.Location as LocationCurve;
            if (location == null || location.Curve == null || !location.Curve.IsBound) return null;
            var line = location.Curve as Line;
            if (line != null)
            {
                double first, last;
                if (!VisibleLineRange(line, out first, out last)) return 0;
                var a = Project(line.GetEndPoint(0));
                var b = Project(line.GetEndPoint(1));
                double projectedLength = Distance(a, b) * (last - first);
                // Vertical risers viewed end-on are legitimate point-like annotations, not short expendable runs.
                return projectedLength <= 1e-8 ? (double?)null : projectedLength;
            }
            // Use projected tessellation, only for an uncropped curve; a cropped arc has no reliable visible length here.
            if (modelCrop.HasValue) return null;
            var points = location.Curve.Tessellate().Select(Project).ToList();
            double length = 0;
            for (int i = 1; i < points.Count; i++) length += Distance(points[i - 1], points[i]);
            return length <= 1e-8 ? (double?)null : length;
        }

        private TagRectangle? HostObstacle(Element host)
        {
            if (host is MEPCurve) return null; // A long run's rectangular envelope would hide unrelated adjacent runs.
            var bounds = ProjectBounds(host.get_BoundingBox(view));
            return bounds.HasValue && bounds.Value.Width > 1e-9 && bounds.Value.Height > 1e-9 ? bounds : null;
        }

        private bool VisibleLineRange(Line line, out double first, out double last)
        {
            first = 0; last = 1;
            if (!modelCrop.HasValue) return true;
            var a = Project(line.GetEndPoint(0)); var b = Project(line.GetEndPoint(1));
            var crop = modelCrop.Value;
            double dx = b.X - a.X, dy = b.Y - a.Y;
            return Clip(-dx, a.X - crop.Left, ref first, ref last) && Clip(dx, crop.Right - a.X, ref first, ref last) &&
                Clip(-dy, a.Y - crop.Bottom, ref first, ref last) && Clip(dy, crop.Top - a.Y, ref first, ref last) && last >= first;
        }
        private static bool Clip(double p, double q, ref double first, ref double last)
        {
            if (Math.Abs(p) < 1e-12) return q >= -1e-9;
            double t = q / p;
            if (p < 0) { if (t > last) return false; first = Math.Max(first, t); }
            else { if (t < first) return false; last = Math.Min(last, t); }
            return true;
        }
        private static bool Contains(TagRectangle bounds, TagPoint point)
        { return point.X >= bounds.Left - 1e-9 && point.X <= bounds.Right + 1e-9 && point.Y >= bounds.Bottom - 1e-9 && point.Y <= bounds.Top + 1e-9; }
        private static bool Contains(TagRectangle outer, TagRectangle inner)
        { return Contains(outer, new TagPoint(inner.Left, inner.Bottom)) && Contains(outer, new TagPoint(inner.Right, inner.Top)); }
        private static double Distance(TagPoint a, TagPoint b)
        { double x = a.X - b.X, y = a.Y - b.Y; return Math.Sqrt(x * x + y * y); }
        private static bool ObstacleCanAffect(TagRectangle obstacle, TagPoint anchor, double radius, double width, double height)
        {
            var search = new TagRectangle(anchor.X - radius - width / 2, anchor.Y - radius - height / 2,
                anchor.X + radius + width / 2, anchor.Y + radius + height / 2);
            return obstacle.Intersects(search);
        }

        private Measurement Measure(IndependentTag tag)
        {
            var optionalBounds = ProjectBounds(tag.get_BoundingBox(view));
            if (!optionalBounds.HasValue) return null;
            var bounds = optionalBounds.Value;
            if (bounds.Right - bounds.Left <= 1e-9 || bounds.Top - bounds.Bottom <= 1e-9) return null;
            var head = Project(tag.TagHeadPosition);
            return new Measurement
            {
                Width = bounds.Right - bounds.Left, Height = bounds.Top - bounds.Bottom,
                HeadOffset = new TagPoint(head.X - (bounds.Left + bounds.Right) * 0.5, head.Y - (bounds.Bottom + bounds.Top) * 0.5)
            };
        }

        private TagRectangle? ProjectBounds(BoundingBoxXYZ box)
        {
            if (box == null) return null;
            var points = new List<TagPoint>();
            foreach (var x in new[] { box.Min.X, box.Max.X })
                foreach (var y in new[] { box.Min.Y, box.Max.Y })
                    foreach (var z in new[] { box.Min.Z, box.Max.Z }) points.Add(Project(box.Transform.OfPoint(new XYZ(x, y, z))));
            return new TagRectangle(points.Min(p => p.X), points.Min(p => p.Y), points.Max(p => p.X), points.Max(p => p.Y));
        }

        private TagRectangle? AnnotationCropBounds()
        {
            var active = view.get_Parameter(BuiltInParameter.VIEWER_ANNOTATION_CROP_ACTIVE);
            if (!view.CropBoxActive || active == null || active.AsInteger() == 0) return null;
            using (var manager = view.GetCropRegionShapeManager())
            {
                if (!manager.CanHaveAnnotationCrop) return null;
                var bounds = ProjectBounds(view.CropBox);
                if (!bounds.HasValue) return null;
                // API annotation offsets are paper feet, unlike CropBox model coordinates.
                return new TagRectangle(bounds.Value.Left - manager.LeftAnnotationCropOffset * view.Scale,
                    bounds.Value.Bottom - manager.BottomAnnotationCropOffset * view.Scale,
                    bounds.Value.Right + manager.RightAnnotationCropOffset * view.Scale,
                    bounds.Value.Top + manager.TopAnnotationCropOffset * view.Scale);
            }
        }

        private TagPoint Project(XYZ point)
        {
            var vector = point - origin;
            return new TagPoint(vector.DotProduct(right), vector.DotProduct(up));
        }

        private XYZ Unproject(TagPoint point, double depth) { return origin + right * point.X + up * point.Y + normal * depth; }
        private double Depth(XYZ point) { return (point - origin).DotProduct(normal); }
        private double PaperFeet(double millimeters) { return millimeters * view.Scale / 304.8; }
        private static string Id(Element element) { return RevitCompat.Id(element.Id).ToString(CultureInfo.InvariantCulture); }
        private static string TagSuffix(TagAssistantCandidate candidate) { return candidate.ExistingTagId == 0 ? "" : " / tag " + candidate.ExistingTagId; }
        private static Autodesk.Revit.DB.TagOrientation ApiOrientation(TagTextOrientation orientation)
        { return orientation == TagTextOrientation.Vertical ? Autodesk.Revit.DB.TagOrientation.Vertical : Autodesk.Revit.DB.TagOrientation.Horizontal; }

        private string HostLabel(Element host)
        {
            var type = document.GetElement(host.GetTypeId()) as ElementType;
            var mark = host.get_Parameter(BuiltInParameter.ALL_MODEL_MARK);
            return (type == null ? host.Name : type.FamilyName + " : " + type.Name) +
                (mark != null && mark.HasValue && !string.IsNullOrWhiteSpace(mark.AsString()) ? " | " + mark.AsString() : "") + " [" + Id(host) + "]";
        }

        private static bool RotatesWithComponent(FamilySymbol symbol)
        {
            foreach (var element in new Element[] { symbol, symbol.Family })
            {
                if (element == null) continue;
                var parameter = element.get_Parameter(BuiltInParameter.FAMILY_ROTATE_WITH_COMPONENT);
                if (parameter != null && parameter.StorageType == StorageType.Integer && parameter.AsInteger() != 0) return true;
            }
            return false;
        }

        private sealed class Measurement
        {
            public double Width;
            public double Height;
            public TagPoint HeadOffset;
        }

        private sealed class TagFailureHandler : IFailuresPreprocessor
        {
            private readonly TagAssistantApplyResult result;
            public TagFailureHandler(TagAssistantApplyResult result) { this.result = result; }
            public FailureProcessingResult PreprocessFailures(FailuresAccessor failuresAccessor)
            {
                bool error = false;
                foreach (var failure in failuresAccessor.GetFailureMessages())
                {
                    if (failure.GetSeverity() == FailureSeverity.Warning)
                    {
                        result.Warnings.Add("Revit: " + failure.GetDescriptionText());
                        failuresAccessor.DeleteWarning(failure);
                    }
                    else
                    {
                        result.Details.Add("Revit error: " + failure.GetDescriptionText());
                        error = true;
                    }
                }
                return error ? FailureProcessingResult.ProceedWithRollBack : FailureProcessingResult.Continue;
            }
        }
    }

    internal sealed class TagAssistantApplyResult
    {
        public int Requested;
        public int Planned;
        public double MaximumDistanceMm;
        public int Created;
        public int Moved;
        public int Skipped;
        public bool RolledBack;
        public bool Cancelled;
        public readonly List<string> Warnings = new List<string>();
        public readonly List<string> Details = new List<string>();
    }
}
