using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using PipeTakeoff.Core;

namespace PipeTakeoff.Revit
{
    internal sealed class SpaceOpeningSourceContext
    {
        public Document Document;
        public Phase Phase;
        public Transform Placement;
        public long LinkId;
    }

    /// <summary>Read-only, phase-specific opening extraction. There is no nearest-Room or bounding-box fallback.</summary>
    internal static class SpaceOpeningReader
    {
        private const int MaximumOpeningsPerSource = 250000;

        public static SpaceOpeningScanResult Read(IEnumerable<SpaceOpeningSourceContext> sources, IList<SpaceTakeoffRow> rows,
            bool sourceScopeComplete = true)
        {
            if (sources == null) throw new ArgumentNullException(nameof(sources));
            if (rows == null) throw new ArgumentNullException(nameof(rows));
            var result = new SpaceOpeningScanResult();
            var sourceComplete = new Dictionary<string, bool>(StringComparer.Ordinal);
            foreach (var row in rows) { row.Openings.Clear(); row.OpeningsComplete = false; row.OpeningNotes.Clear(); }
            foreach (var context in sources)
            {
                if (context == null || context.Document == null || context.Phase == null)
                {
                    sourceScopeComplete = false;
                    result.Notes.Add("An opening source or its mapped phase was unavailable; quantities cannot be considered complete.");
                    continue;
                }
                string key = SourceKey(context.Document.Title, context.LinkId);
                if (sourceComplete.ContainsKey(key)) continue;
                string label = context.Document.Title + (context.LinkId < 0 ? " / host" : " / link " + context.LinkId.ToString(CultureInfo.InvariantCulture));
                sourceComplete[key] = true;
                int nested = 0, failures = 0, unassociated = 0, scanned = 0;
                try
                {
                    using (var collector = new FilteredElementCollector(context.Document))
                    using (var categories = new ElementMulticategoryFilter(new[] { BuiltInCategory.OST_Doors, BuiltInCategory.OST_Windows }))
                    {
                        foreach (var opening in collector.WherePasses(categories).OfClass(typeof(FamilyInstance)).WhereElementIsNotElementType().Cast<FamilyInstance>())
                        {
                            try
                            {
                                if (!IsPrimary(opening) || !ExistsInPhase(opening, context.Phase.Id)) continue;
                                if (opening.SuperComponent != null) { nested++; continue; }
                                if (++scanned > MaximumOpeningsPerSource)
                                {
                                    sourceComplete[key] = false;
                                    result.Notes.Add(label + ": opening scan exceeded the " + MaximumOpeningsPerSource.ToString(CultureInfo.InvariantCulture) + " instance limit; available associations are partial.");
                                    break;
                                }
                                var record = new SpaceOpeningRecord
                                {
                                    Kind = RevitCompat.Id(opening.Category.Id) == (long)BuiltInCategory.OST_Doors ? SpaceOpeningKind.Door : SpaceOpeningKind.Window,
                                    Source = new SpaceSurfaceSource { DocumentTitle = context.Document.Title, LinkInstanceId = context.LinkId,
                                        ElementId = RevitCompat.Id(opening.Id), ElementName = opening.Name ?? "" },
                                    UniqueId = opening.UniqueId ?? ""
                                };
                                result.Openings.Add(record);
                                ReadDimensions(opening, record);
                                ReadRooms(opening, context, record);
                                if (record.AssociationStatus == SpaceOpeningAssociationStatus.LookupFailed)
                                {
                                    sourceComplete[key] = false; failures++;
                                }
                                else if (record.Rooms.Count == 0)
                                {
                                    sourceComplete[key] = false; unassociated++;
                                }
                            }
                            catch (Autodesk.Revit.Exceptions.OperationCanceledException) { throw; }
                            catch (Exception ex)
                            {
                                sourceComplete[key] = false; failures++;
                                if (failures <= 12) result.Notes.Add(label + ": opening could not be fully read — " + ex.Message);
                            }
                        }
                    }
                }
                catch (Autodesk.Revit.Exceptions.OperationCanceledException) { throw; }
                catch (Exception ex)
                {
                    sourceComplete[key] = false;
                    result.Notes.Add(label + ": door/window collection failed — " + ex.Message);
                }
                if (nested > 0) result.Notes.Add(label + ": excluded " + nested.ToString(CultureInfo.InvariantCulture) + " nested door/window family instances to avoid counting both parent and child components.");
                if (failures > 0) result.Notes.Add(label + ": " + failures.ToString(CultureInfo.InvariantCulture) + " opening association/read failures; affected Space counts remain unknown even when some associations were found.");
                if (unassociated > 0) result.Notes.Add(label + ": " + unassociated.ToString(CultureInfo.InvariantCulture) + " openings have no phase-specific Room association. They remain in the source-scope unassociated list; affected Space counts are unknown.");
            }

            // Populate the exact identity joins once. Per-source completeness below keeps
            // an unreadable placement from invalidating an unrelated verified placement.
            SpaceOpeningAssociation.Assign(rows, result.Openings, false);
            foreach (var row in rows)
            {
                bool complete;
                row.OpeningsComplete = sourceScopeComplete && row.RoomIdentityVerified &&
                    sourceComplete.TryGetValue(SourceKey(row.RoomSource.DocumentTitle, row.RoomSource.LinkInstanceId), out complete) && complete;
                if (!row.RoomIdentityVerified)
                    row.OpeningNotes.Add("Door/window counts are unknown because a unique phase-correct architectural Room identity was not verified.");
                else if (!row.OpeningsComplete)
                    row.OpeningNotes.Add("Door/window attribution or the selected source scan is incomplete. Known opening details/subtotals are retained; complete counts and areas remain blank.");
                int missing = row.Openings.Count(opening => !opening.AreaSquareMeters.HasValue);
                if (missing > 0) row.OpeningNotes.Add(missing.ToString(CultureInfo.InvariantCulture) + " associated openings lack valid nominal width/height; their areas are blank and known areas are subtotaled separately.");
            }
            result.Complete = sourceScopeComplete && sourceComplete.Count > 0 && sourceComplete.Values.All(value => value) && rows.All(row => row.OpeningsComplete);
            if (sourceComplete.Count == 0) result.Notes.Add("No available door/window source was scanned; zero quantities are not assumed.");
            result.Notes.Add("Door/window scope: top-level OST_Doors / OST_Windows FamilyInstances in the selected source phase, existing or new, main/primary design options. Nested families are excluded. Direct link placements retain separate identities.");
            result.Notes.Add("Associations use phase-specific FromRoom / ToRoom, with phase-specific Room fallback, and exact document/link/Room identity. Shared openings count once per associated Space; unique totals deduplicate the physical source instance.");
            result.Notes.Add("Area is nominal width × height in m² from positive finite length parameters, instance before type. It is not net glazing, rough opening, or clear opening area. No bounding-box dimension fallback is used.");
            return result;
        }

        private static void ReadDimensions(FamilyInstance opening, SpaceOpeningRecord record)
        {
            try
            {
                var symbol = opening.Symbol;
                record.FamilyName = symbol != null && symbol.Family != null ? symbol.Family.Name ?? "" : "";
                record.TypeName = symbol == null ? "" : symbol.Name ?? "";
                var widthParameter = record.Kind == SpaceOpeningKind.Door ? BuiltInParameter.DOOR_WIDTH : BuiltInParameter.WINDOW_WIDTH;
                var heightParameter = record.Kind == SpaceOpeningKind.Door ? BuiltInParameter.DOOR_HEIGHT : BuiltInParameter.WINDOW_HEIGHT;
                string widthSource, heightSource;
                record.WidthMeters = ReadLength(opening, symbol, widthParameter, out widthSource);
                record.HeightMeters = ReadLength(opening, symbol, heightParameter, out heightSource);
                record.DimensionSource = "Width: " + widthSource + "; height: " + heightSource;
                if (!record.AreaSquareMeters.HasValue)
                    record.DimensionNotes = "Nominal area unavailable: width and height must both be positive finite length parameters. Missing values are not zero.";
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                record.DimensionNotes = "Nominal dimension read failed: " + ex.Message + ". Area is unavailable; the opening can still be counted if association is complete.";
                // A failure must not leave a deceptively complete area assembled from a partially read family.
                record.WidthMeters = null; record.HeightMeters = null;
            }
        }

        private static double? ReadLength(FamilyInstance opening, FamilySymbol symbol, BuiltInParameter parameterId, out string source)
        {
            double? instance = SpaceOpeningDimensions.PositiveLengthMeters(LengthFeet(opening.get_Parameter(parameterId)), null);
            if (instance.HasValue)
            {
                source = "instance " + parameterId;
                return instance;
            }
            double? type = symbol == null ? null : SpaceOpeningDimensions.PositiveLengthMeters(null, LengthFeet(symbol.get_Parameter(parameterId)));
            source = type.HasValue ? "type " + parameterId : "missing " + parameterId;
            return type;
        }

        private static double? LengthFeet(Parameter parameter)
        {
            if (parameter == null || !parameter.HasValue || parameter.StorageType != StorageType.Double || parameter.Definition == null ||
                !SpecTypeId.Length.Equals(parameter.Definition.GetDataType())) return null;
            double value = parameter.AsDouble();
            return !double.IsNaN(value) && !double.IsInfinity(value) && value > 0 ? value : (double?)null;
        }

        private static void ReadRooms(FamilyInstance opening, SpaceOpeningSourceContext context, SpaceOpeningRecord record)
        {
            var errors = new List<string>();
            Action<Func<Room>, string> read = (lookup, label) =>
            {
                try
                {
                    var room = lookup();
                    if (room == null) return;
                    if (!room.Document.Equals(context.Document) || !IsPrimary(room) || SpatialPhaseId(room) != RevitCompat.Id(context.Phase.Id))
                        throw new InvalidOperationException("returned a Room outside the selected document, phase or main/primary option");
                    var identity = new SpaceOpeningRoomIdentity
                    {
                        Source = new SpaceSurfaceSource { DocumentTitle = context.Document.Title, LinkInstanceId = context.LinkId,
                            ElementId = RevitCompat.Id(room.Id), ElementName = room.Name ?? "" },
                        UniqueId = room.UniqueId ?? "", Number = room.Number ?? "", Name = RoomName(room)
                    };
                    if (identity.Key.Length == 0) throw new InvalidOperationException("returned no stable Room identity");
                    if (!record.Rooms.Any(existing => existing.Key == identity.Key)) record.Rooms.Add(identity);
                }
                catch (Autodesk.Revit.Exceptions.OperationCanceledException) { throw; }
                catch (Exception ex) { errors.Add(label + ": " + ex.Message); }
            };
            read(() => opening.get_FromRoom(context.Phase), "FromRoom");
            read(() => opening.get_ToRoom(context.Phase), "ToRoom");
            if (record.Rooms.Count == 0) read(() => opening.get_Room(context.Phase), "Room");
            if (errors.Count > 0)
            {
                record.AssociationStatus = SpaceOpeningAssociationStatus.LookupFailed;
                record.AssociationNotes = "Phase-specific Room lookup incomplete: " + string.Join("; ", errors);
            }
            else if (record.Rooms.Count == 0)
            {
                record.AssociationStatus = SpaceOpeningAssociationStatus.Unassociated;
                record.AssociationNotes = "No FromRoom, ToRoom or Room in mapped phase '" + context.Phase.Name + "'; attribution to exported Spaces is unknown.";
            }
            else record.AssociationNotes = "Exact Room identity in mapped phase '" + context.Phase.Name + "'.";
        }

        private static string SourceKey(string title, long linkId) { return title + "|" + linkId.ToString(CultureInfo.InvariantCulture); }
        private static bool IsPrimary(Element element) { return element.DesignOption == null || element.DesignOption.IsPrimary; }
        private static bool ExistsInPhase(Element element, ElementId phaseId)
        {
            var status = element.GetPhaseStatus(phaseId);
            return status == ElementOnPhaseStatus.Existing || status == ElementOnPhaseStatus.New;
        }
        private static long SpatialPhaseId(SpatialElement element)
        {
            var parameter = element.get_Parameter(BuiltInParameter.ROOM_PHASE_ID);
            var id = parameter != null && parameter.StorageType == StorageType.ElementId ? parameter.AsElementId() : element.CreatedPhaseId;
            return id == null ? -1 : RevitCompat.Id(id);
        }
        private static string RoomName(Room room)
        {
            var parameter = room.get_Parameter(BuiltInParameter.ROOM_NAME);
            return parameter == null ? "" : (parameter.AsString() ?? "").Trim();
        }
    }
}
