using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PipeTakeoff.Core;

namespace PipeTakeoff.Revit
{
    /// <summary>Detached modal presentation. Scan/export delegates run synchronously in the external command.</summary>
    public sealed class SpaceTakeoffForm : Form
    {
        private readonly ComboBox _scope = Choice("All spaces in this model", "Spaces in the active view", "Selected spaces only");
        private readonly ComboBox _phase = Choice();
        private readonly ComboBox _linkChoice = Choice();
        private readonly CheckBox _host = new CheckBox { Text = "Current model floors / ceilings", AutoSize = true };
        private readonly CheckBox _links = new CheckBox { Text = "Loaded Revit Links: architectural floors / ceilings", AutoSize = true };
        private readonly NumericUpDown _floorSearch = Number(1, .01M, 5, 2, .1M);
        private readonly NumericUpDown _maxHeight = Number(12, .1M, 100, 1, .5M);
        private readonly NumericUpDown _gridSize = Number(5, 3, 11, 0, 1);
        private readonly NumericUpDown _variation = Number(20, 1, 200, 0, 1);
        private readonly ComboBox _level = Choice();
        private readonly ComboBox _resultFilter = Choice("All results", "Needs review", "Height measured (sampled)", "Ceiling", "Slab fallback", "Mixed ceiling / slab", "Openings need review", "Openings complete");
        private readonly ComboBox _units = Choice("Metres (m)", "Millimetres (mm)");
        private readonly TextBox _search = new TextBox();
        private readonly DataGridView _spaces = new DataGridView();
        private readonly DataGridView _samples = new DataGridView();
        private readonly DataGridView _openings = new DataGridView();
        private readonly TextBox _rowDetails = NotesBox();
        private readonly TextBox _openingDetails = NotesBox();
        private readonly TextBox _scanNotes = NotesBox();
        private readonly Label _summary = new Label();
        private readonly Label _status = new Label();
        private readonly TabControl _tabs = new TabControl();
        private readonly Button _scan = KaTheme.Button("Scan / Refresh");
        private readonly Button _export = KaTheme.Button("Export Excel (.xlsx)", true);
        private readonly Button _close = KaTheme.Button("Close");
        private readonly ToolTip _tips = new ToolTip { InitialDelay = 350, AutoPopDelay = 25000 };
        private TableLayoutPanel _workspace, _header, _footer;
        private Control _headerCaption, _headerBrand, _headerTitle;
        private Font _brandFont, _titleFont;
        private string _summaryFullText = "", _summaryCompactText = "";
        private bool _interfaceBuilt, _arranging, _compact;
        private SpaceTakeoffSnapshot _snapshot;
        private List<SpaceTakeoffRow> _filtered = new List<SpaceTakeoffRow>();
        private bool _loading, _busy, _stale;
        private string _message = "Choose scope and phase, then Scan / Refresh. Architectural Revit Links are selected by default.";

        public event Action<SpaceTakeoffOptions> ScanRequested;
        public event Action<SpaceTakeoffSnapshot, bool, string> ExportRequested;
        public SpaceTakeoffSnapshot Snapshot { get { return _snapshot; } }
        public IList<SpaceTakeoffRow> FilteredRows { get { return _filtered.AsReadOnly(); } }
        public bool HeightsInMillimeters { get { return _units.SelectedIndex == 1; } }
        public string FilterDescription
        {
            get
            {
                return "Visible result subset: " + _filtered.Count.ToString(CultureInfo.InvariantCulture) + " / " +
                    (_snapshot == null ? 0 : _snapshot.Rows.Count).ToString(CultureInfo.InvariantCulture) +
                    " spaces; level=" + Convert.ToString(_level.SelectedItem) + "; result=" + Convert.ToString(_resultFilter.SelectedItem) +
                    "; search=" + _search.Text.Trim() + ". Row selection does not limit export.";
            }
        }

        public SpaceTakeoffForm(IList<SpacePhaseOption> phases, SpaceTakeoffOptions defaults, IList<SpaceLinkOption> links = null)
        {
            if (phases == null) throw new ArgumentNullException(nameof(phases));
            if (defaults == null) throw new ArgumentNullException(nameof(defaults));
            KaTheme.ApplyForm(this, "HVAC Spaces", 1230, 800);
            Name = "SpaceTakeoffForm";
            MinimumSize = new Size(850, 580);
            KeyPreview = true;
            _loading = true;
            BuildInterface();
            foreach (var phase in phases) _phase.Items.Add(phase);
            _linkChoice.Items.Add(new SpaceLinkOption { Id = -1, Name = "All loaded direct Revit Links", IsLoaded = true });
            foreach (var link in (links ?? new List<SpaceLinkOption>()).Where(link => link.IsLoaded)) _linkChoice.Items.Add(link);
            _linkChoice.SelectedItem = _linkChoice.Items.Cast<SpaceLinkOption>().FirstOrDefault(link => link.Id == defaults.SelectedLinkInstanceId);
            if (_linkChoice.SelectedIndex < 0) _linkChoice.SelectedIndex = 0;
            _phase.SelectedItem = phases.FirstOrDefault(p => p.Id == defaults.PhaseId);
            if (_phase.SelectedIndex < 0 && _phase.Items.Count > 0) _phase.SelectedIndex = _phase.Items.Count - 1;
            _scope.SelectedIndex = (int)defaults.Scope;
            _host.Checked = defaults.IncludeHostGeometry;
            _links.Checked = defaults.IncludeLinkedGeometry;
            _floorSearch.Value = (decimal)defaults.FloorSearchToleranceMeters;
            _maxHeight.Value = (decimal)defaults.MaximumHeightMeters;
            _gridSize.Value = defaults.SampleGridSize;
            _variation.Value = (decimal)(defaults.HeightVariationToleranceMeters * 1000);
            _level.Items.Add("All levels"); _level.SelectedIndex = 0;
            _resultFilter.SelectedIndex = 0; _units.SelectedIndex = 0;
            _loading = false;
            WireEvents();
            UpdateRows(); UpdateActions();
        }

        public SpaceTakeoffOptions ReadOptions()
        {
            var phase = _phase.SelectedItem as SpacePhaseOption;
            if (phase == null) throw new InvalidOperationException("Select a project phase before scanning.");
            var options = new SpaceTakeoffOptions
            {
                Scope = (SpaceTakeoffScope)_scope.SelectedIndex, PhaseId = phase.Id,
                IncludeHostGeometry = _host.Checked, IncludeLinkedGeometry = _links.Checked,
                SelectedLinkInstanceId = ((SpaceLinkOption)_linkChoice.SelectedItem).Id,
                FloorSearchToleranceMeters = (double)_floorSearch.Value, MaximumHeightMeters = (double)_maxHeight.Value,
                SampleGridSize = (int)_gridSize.Value, HeightVariationToleranceMeters = (double)_variation.Value / 1000
            };
            options.Validate(); return options;
        }

        public void SetSnapshot(SpaceTakeoffSnapshot snapshot)
        {
            if (snapshot == null || snapshot.Rows == null || snapshot.Notes == null) throw new ArgumentException("A complete snapshot container is required.");
            _snapshot = snapshot; _stale = false; _loading = true;
            try
            {
                _level.Items.Clear(); _level.Items.Add("All levels");
                foreach (string level in snapshot.Rows.Select(r => r.LevelName ?? "").Distinct(StringComparer.Ordinal).OrderBy(x => x, StringComparer.CurrentCultureIgnoreCase))
                    _level.Items.Add(level);
                _level.SelectedIndex = 0; _resultFilter.SelectedIndex = 0; _search.Clear();
            }
            finally { _loading = false; }
            _scanNotes.Text = "Project: " + snapshot.ProjectTitle + Environment.NewLine +
                "Scope: " + snapshot.ScopeLabel + Environment.NewLine + "Scanned: " + snapshot.ScannedAt.ToString("g", CultureInfo.CurrentCulture) +
                Environment.NewLine + Environment.NewLine + string.Join(Environment.NewLine + Environment.NewLine, snapshot.Notes);
            if (snapshot.OpeningScan != null)
                _scanNotes.AppendText(Environment.NewLine + Environment.NewLine + "Opening source scan: " + (snapshot.OpeningScan.Complete ? "complete" : "incomplete / review") +
                    "; unassociated openings in scanned sources: " + snapshot.OpeningScan.UnassociatedOpenings.Count().ToString(CultureInfo.CurrentCulture) +
                    ". Source coverage counts do not change with result filters." + Environment.NewLine + string.Join(Environment.NewLine, snapshot.OpeningScan.Notes));
            _message = snapshot.IsComplete ? "Scan complete. Export includes all rows visible after filters; selected rows do not limit export."
                : "Scan incomplete. Results require review; coverage notes are included in the Excel report.";
            UpdateRows(); UpdateActions(); _tabs.SelectedIndex = 1;
        }

        public void ShowFailure(string message)
        {
            _snapshot = null; _filtered.Clear(); _stale = true;
            _message = "Scan failed: " + message;
            _scanNotes.Text = _message;
            UpdateRows(); UpdateActions();
        }

        public void ShowStatus(string message)
        {
            _message = message ?? ""; UpdateActions();
        }

        protected override void OnShown(EventArgs e) { base.OnShown(e); KaTheme.ClampToScreen(this); }
        protected override void OnLayout(LayoutEventArgs e)
        {
            if (_interfaceBuilt && !_arranging)
            {
                _arranging = true;
                try { FitAvailableHeight(); }
                finally { _arranging = false; }
            }
            base.OnLayout(e);
        }

        private void FitAvailableHeight()
        {
            // Keep the full-size text, but spend less height on chrome on short or high-DPI screens.
            _compact = ClientSize.Height < Font.Height * 28;
            _workspace.Padding = _compact ? new Padding(6, 4, 6, 4) : new Padding(14, 12, 14, 8);
            _headerCaption.Visible = !_compact;
            FitHeaderFont(_headerBrand, ref _brandFont, Font.SizeInPoints * (_compact ? 1.1F : 2F));
            FitHeaderFont(_headerTitle, ref _titleFont, Font.SizeInPoints * (_compact ? 1.1F : 15F / 9F));
            _header.Padding = _compact ? new Padding(12, 4, 12, 4) : new Padding(18, 12, 18, 12);
            _header.Margin = new Padding(0, 0, 0, _compact ? 4 : 10);
            _tabs.Padding = _compact ? new Point(8, 4) : new Point(13, 7);
            _footer.Padding = _compact ? new Padding(10, 4, 10, 5) : new Padding(14, 7, 14, 9);
            _status.Height = _status.Font.Height * (_compact ? 1 : 2) + 6;
            _summary.Height = _summary.Font.Height * (_compact ? 1 : 2) + 6;
            _summary.Text = _compact ? _summaryCompactText : _summaryFullText;
            foreach (var button in new[] { _export, _scan, _close })
            {
                button.Padding = new Padding(6, 4, 6, 4);
                button.AutoSize = true;
                button.AutoSizeMode = AutoSizeMode.GrowAndShrink;
                button.MinimumSize = new Size(0, 36);
            }
        }

        private void FitHeaderFont(Control control, ref Font ownedFont, float points)
        {
            if (ownedFont == null || Math.Abs(ownedFont.SizeInPoints - points) > .01F)
            {
                var previous = ownedFont;
                ownedFont = new Font(Font.FontFamily, points, FontStyle.Bold);
                control.Font = ownedFont;
                if (previous != null) previous.Dispose();
            }
            else if (!ReferenceEquals(control.Font, ownedFont)) control.Font = ownedFont;
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (_busy) { e.Cancel = true; return; }
            base.OnFormClosing(e);
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Control | Keys.E)) { if (_export.Enabled) ExportVisible(); return true; }
            return base.ProcessCmdKey(ref msg, keyData);
        }
        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            if (disposing)
            {
                _tips.Dispose();
                if (_brandFont != null) _brandFont.Dispose();
                if (_titleFont != null) _titleFont.Dispose();
            }
        }

        private void BuildInterface()
        {
            _scope.Name = "SpaceScope"; _phase.Name = "SpacePhase";
            _linkChoice.Name = "SpaceLinkChoice";
            _host.Name = "SpaceIncludeHost"; _links.Name = "SpaceIncludeLinks";
            _floorSearch.Name = "SpaceFloorSearch"; _maxHeight.Name = "SpaceMaximumHeight";
            _gridSize.Name = "SpaceSampleGrid"; _variation.Name = "SpaceVariationTolerance";
            _search.Name = "SpaceSearch"; _level.Name = "SpaceLevelFilter";
            _resultFilter.Name = "SpaceResultFilter"; _units.Name = "SpaceHeightUnits";
            _workspace = new TableLayoutPanel { Name = "SpaceWorkspace", Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, Padding = new Padding(14, 12, 14, 8) };
            _workspace.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            _workspace.RowStyles.Add(new RowStyle(SizeType.AutoSize)); _workspace.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            _header = (TableLayoutPanel)KaTheme.Header("HVAC Spaces", "Rooms / physical clear heights / doors & windows / Excel");
            _headerCaption = _header.GetControlFromPosition(0, 1);
            _headerBrand = _header.GetControlFromPosition(0, 0);
            _headerTitle = _header.GetControlFromPosition(1, 0);
            _workspace.Controls.Add(_header, 0, 0);
            _tabs.Name = "SpaceTakeoffTabs"; _tabs.Dock = DockStyle.Fill; _tabs.Padding = new Point(13, 7);
            _tabs.TabPages.Add(OptionsTab()); _tabs.TabPages.Add(ResultsTab()); _tabs.TabPages.Add(MeasurementsTab());
            _workspace.Controls.Add(_tabs, 0, 1);
            Controls.Add(_workspace); Controls.Add(Footer());
            _interfaceBuilt = true;
            PerformLayout();
        }

        private TabPage OptionsTab()
        {
            var page = Page("1  Scan options");
            var layout = new TableLayoutPanel { Name = "SpaceOptionsContent", Dock = DockStyle.Top, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, ColumnCount = 1, Padding = new Padding(12) };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            layout.Controls.Add(Hint("Spaces are read from this MEP document. Room identities, physical floors / ceilings, and doors / windows can come from the selected architectural links."));
            layout.Controls.Add(Field("Spaces to include", _scope)); layout.Controls.Add(Field("Project phase", _phase));
            layout.Controls.Add(Hint("Geometry sources")); layout.Controls.Add(_links); layout.Controls.Add(_host);
            layout.Controls.Add(Field("Architectural Revit Link", _linkChoice));
            layout.Controls.Add(Hint("The scope limits Spaces, not the geometry visible in the active view. Unloaded or unsupported links are reported in scan notes."));
            layout.Controls.Add(Field("Floor search ± from Space base (m)", _floorSearch));
            layout.Controls.Add(Field("Maximum clear-height search (m)", _maxHeight));
            layout.Controls.Add(Field("Interior sample grid per axis", _gridSize));
            layout.Controls.Add(Field("Height variation tolerance (mm)", _variation));
            layout.Controls.Add(Hint("Measured height uses floor top to ceiling underside; where no ceiling is found below the next slab, that slab underside is used. Space height parameters are not substituted for physical measurements."));
            layout.Controls.Add(Hint("Measurements are sampled. Slopes, partial ceilings or incomplete coverage need review; missing values stay blank. Open Measurements & notes for element sources and individual sample results."));
            layout.Controls.Add(Hint("Door / window quantities use the associated architectural Room in the selected phase. Area is nominal width × height, not glazing or free opening area. Shared doors count once per associated Room; report totals count each source opening once. Unverified quantities remain blank."));
            var viewport = new Panel { Name = "SpaceOptionsViewport", Dock = DockStyle.Fill, AutoScroll = true };
            viewport.Controls.Add(layout); page.Controls.Add(viewport);
            return page;
        }

        private TabPage ResultsTab()
        {
            var page = Page("2  Spaces");
            var body = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, Padding = new Padding(6) };
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            body.RowStyles.Add(new RowStyle(SizeType.AutoSize)); body.RowStyles.Add(new RowStyle(SizeType.AutoSize)); body.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            var filters = new TableLayoutPanel { Name = "SpaceFilters", Dock = DockStyle.Top, AutoSize = true, ColumnCount = 4, RowCount = 2 };
            filters.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize)); filters.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            filters.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize)); filters.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            AddFilter(filters, "Level", _level, 0, 0); AddFilter(filters, "Result", _resultFilter, 2, 0);
            AddFilter(filters, "Search", _search, 0, 1); AddFilter(filters, "Units", _units, 2, 1);
            _tips.SetToolTip(_units, "Height display units; areas remain in square metres.");
            body.Controls.Add(filters, 0, 0);
            _summary.Name = "SpaceResultSummary"; _summary.Dock = DockStyle.Fill; _summary.AutoSize = false; _summary.AutoEllipsis = true;
            _summary.Height = Font.Height * 2 + 8; _summary.ForeColor = KaTheme.Muted;
            _summary.FontChanged += delegate { PerformLayout(); };
            body.Controls.Add(_summary, 0, 1);
            StyleSpaceGrid(_spaces); _spaces.Name = "SpaceResultsGrid";
            _spaces.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
            _spaces.MultiSelect = false;
            AddColumn(_spaces, "RoomNumber", "Room number", 100); AddColumn(_spaces, "RoomName", "Room name", 180);
            AddColumn(_spaces, "SpaceNumber", "Space number", 100); AddColumn(_spaces, "SpaceName", "Space name", 180);
            AddColumn(_spaces, "Level", "Level", 110); AddColumn(_spaces, "Area", "Area (m²)", 100);
            AddColumn(_spaces, "Height", "Clear height (m)", 125); AddColumn(_spaces, "Minimum", "Min sampled (m)", 125);
            AddColumn(_spaces, "Maximum", "Max sampled (m)", 125); AddColumn(_spaces, "Source", "Overhead", 120);
            AddColumn(_spaces, "Status", "Height status", 215); AddColumn(_spaces, "Samples", "Measured / attempted", 155);
            AddColumn(_spaces, "DoorCount", "Doors", 85); AddColumn(_spaces, "DoorArea", "Door area (m²)", 125);
            AddColumn(_spaces, "DoorKnownArea", "Known door area (m²)", 160);
            AddColumn(_spaces, "WindowCount", "Windows", 90); AddColumn(_spaces, "WindowArea", "Window area (m²)", 135);
            AddColumn(_spaces, "WindowKnownArea", "Known window area (m²)", 170);
            AddColumn(_spaces, "OpeningStatus", "Opening status", 235);
            foreach (string name in new[] { "DoorArea", "DoorKnownArea", "WindowArea", "WindowKnownArea" })
            {
                _spaces.Columns[name].DefaultCellStyle.Format = "N2";
                _spaces.Columns[name].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            }
            foreach (string name in new[] { "DoorCount", "WindowCount" }) _spaces.Columns[name].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            _spaces.Columns["Area"].DefaultCellStyle.Format = "N2";
            _spaces.Columns["Area"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            body.Controls.Add(_spaces, 0, 2); page.Controls.Add(body); return page;
        }

        private TabPage MeasurementsTab()
        {
            var page = Page("3  Measurements & notes");
            var nested = new TabControl { Name = "SpaceDetailTabs", Dock = DockStyle.Fill };
            var detail = Page("Selected Space");
            var content = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, Padding = new Padding(6) };
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            content.RowStyles.Add(new RowStyle(SizeType.Percent, 40)); content.RowStyles.Add(new RowStyle(SizeType.Percent, 60));
            _rowDetails.Name = "SpaceRowDetails"; content.Controls.Add(_rowDetails, 0, 0);
            StyleSpaceGrid(_samples); _samples.Name = "SpaceSampleGridResults"; _samples.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
            AddColumn(_samples, "Sample", "Sample", 70); AddColumn(_samples, "Floor", "Floor Z (m)", 110);
            AddColumn(_samples, "Top", "Overhead Z (m)", 120); AddColumn(_samples, "Height", "Clear height (m)", 125);
            AddColumn(_samples, "Basis", "Overhead", 110); AddColumn(_samples, "Status", "Result", 210);
            AddColumn(_samples, "FloorSource", "Floor source", 310); AddColumn(_samples, "TopSource", "Overhead source", 310);
            AddColumn(_samples, "Notes", "Notes", 350); content.Controls.Add(_samples, 0, 1); detail.Controls.Add(content);
            var scan = Page("Scan coverage"); _scanNotes.Name = "SpaceScanNotes"; scan.Controls.Add(_scanNotes);
            nested.TabPages.Add(detail); nested.TabPages.Add(OpeningsTab()); nested.TabPages.Add(scan); page.Controls.Add(nested); return page;
        }

        private TabPage OpeningsTab()
        {
            var page = Page("Openings");
            var content = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, Padding = new Padding(6) };
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            content.RowStyles.Add(new RowStyle(SizeType.Percent, 40)); content.RowStyles.Add(new RowStyle(SizeType.Percent, 60));
            _openingDetails.Name = "SpaceOpeningDetails"; content.Controls.Add(_openingDetails, 0, 0);
            StyleSpaceGrid(_openings); _openings.Name = "SpaceOpeningsGrid";
            _openings.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
            AddColumn(_openings, "Kind", "Category", 95); AddColumn(_openings, "ElementId", "Element ID", 125);
            AddColumn(_openings, "Family", "Family", 180); AddColumn(_openings, "Type", "Type", 180);
            AddColumn(_openings, "Size", "Size (W × H)", 200);
            AddColumn(_openings, "Width", "Width (m)", 105); AddColumn(_openings, "Height", "Height (m)", 105);
            AddColumn(_openings, "Area", "Nominal area (m²)", 145); AddColumn(_openings, "Status", "Dimension status", 210);
            AddColumn(_openings, "Shared", "Shared by Rooms", 145);
            AddColumn(_openings, "Source", "Opening source", 320); AddColumn(_openings, "Rooms", "Associated Rooms", 320);
            AddColumn(_openings, "Notes", "Notes", 350);
            _openings.Columns["Area"].DefaultCellStyle.Format = "N2";
            foreach (string name in new[] { "Width", "Height", "Area" }) _openings.Columns[name].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            content.Controls.Add(_openings, 0, 1); page.Controls.Add(content); return page;
        }

        private Control Footer()
        {
            var footer = new TableLayoutPanel { Name = "SpaceFixedFooter", Dock = DockStyle.Bottom, AutoSize = true, ColumnCount = 3, RowCount = 2, BackColor = Color.White, Padding = new Padding(14, 7, 14, 9) };
            _footer = footer;
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 46)); footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34)); footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
            footer.RowStyles.Add(new RowStyle(SizeType.AutoSize)); footer.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            _status.Name = "SpaceStatus"; _status.Dock = DockStyle.Fill; _status.AutoSize = false; _status.AutoEllipsis = true;
            _status.Height = Font.Height * 2 + 8; _status.ForeColor = KaTheme.Muted;
            _status.FontChanged += delegate { PerformLayout(); };
            footer.Controls.Add(_status, 0, 0); footer.SetColumnSpan(_status, 3);
            _export.Name = "SpaceExportExcel"; _scan.Name = "SpaceScanRefresh"; _close.Name = "SpaceClose";
            foreach (var button in new[] { _export, _scan, _close }) { button.Dock = DockStyle.Fill; button.AutoSize = false; button.MinimumSize = new Size(0, 40); }
            footer.Controls.Add(_export, 0, 1); footer.Controls.Add(_scan, 1, 1); footer.Controls.Add(_close, 2, 1);
            _close.DialogResult = DialogResult.Cancel; CancelButton = _close;
            _tips.SetToolTip(_export, "Ctrl+E. Export every visible filtered Space, including review rows and blank measurements. Selected rows do not limit export.");
            return footer;
        }

        private void WireEvents()
        {
            _scan.Click += delegate { RunScan(); }; _export.Click += delegate { ExportVisible(); };
            _scope.SelectedIndexChanged += OptionsChanged; _phase.SelectedIndexChanged += OptionsChanged;
            _linkChoice.SelectedIndexChanged += OptionsChanged;
            _host.CheckedChanged += OptionsChanged; _links.CheckedChanged += OptionsChanged;
            _floorSearch.ValueChanged += OptionsChanged; _maxHeight.ValueChanged += OptionsChanged;
            _gridSize.ValueChanged += OptionsChanged; _variation.ValueChanged += OptionsChanged;
            _level.SelectedIndexChanged += delegate { if (!_loading) UpdateRows(); };
            _resultFilter.SelectedIndexChanged += delegate { if (!_loading) UpdateRows(); };
            _search.TextChanged += delegate { if (!_loading) UpdateRows(); };
            _units.SelectedIndexChanged += delegate { if (!_loading) UpdateRows(); };
            _spaces.SelectionChanged += delegate { if (!_loading) UpdateDetails(); };
            _spaces.CellDoubleClick += delegate(object sender, DataGridViewCellEventArgs e) { if (e.RowIndex >= 0) _tabs.SelectedIndex = 2; };
        }

        private void OptionsChanged(object sender, EventArgs e)
        {
            if (_loading || _busy) return;
            if (_snapshot != null) { _stale = true; _message = "Scan settings changed. Scan / Refresh before exporting; displayed rows are from the previous settings."; }
            UpdateActions();
        }

        private void RunScan()
        {
            if (_busy) return;
            SpaceTakeoffOptions options;
            try { options = ReadOptions(); }
            catch (Exception ex) { ShowFailure(ex.Message); return; }
            if (ScanRequested == null) { ShowFailure("The scan service is unavailable."); return; }
            _snapshot = null; _filtered.Clear(); _stale = true; _busy = true;
            _message = "Reading Spaces, architectural surfaces, doors and windows. Revit remains read-only during this scan…";
            UpdateRows(); UpdateActions(); Refresh();
            try
            {
                ScanRequested(options.Copy());
                if (_snapshot == null) ShowFailure("The scan did not return a result. Review the geometry sources and try again.");
            }
            catch (Exception ex) { ShowFailure(ex.Message); }
            finally { _busy = false; UpdateActions(); }
        }

        private void ExportVisible()
        {
            if (!_export.Enabled || _snapshot == null || _stale || _busy || ExportRequested == null) return;
            var report = new SpaceTakeoffSnapshot
            {
                ProjectTitle = _snapshot.ProjectTitle, RevitVersion = _snapshot.RevitVersion, Release = _snapshot.Release,
                ScopeLabel = _snapshot.ScopeLabel, ScannedAt = _snapshot.ScannedAt, IsComplete = _snapshot.IsComplete,
                Options = _snapshot.Options.Copy(), Rows = _filtered.ToList(), Notes = _snapshot.Notes.ToList(), OpeningScan = _snapshot.OpeningScan
            };
            report.Notes.Add(FilterDescription);
            _busy = true; UpdateActions();
            try { ExportRequested(report, HeightsInMillimeters, FilterDescription); }
            catch (Exception ex) { _message = "Excel export failed: " + ex.Message; }
            finally { _busy = false; UpdateActions(); }
        }

        private void UpdateRows()
        {
            long? selected = _spaces.CurrentRow == null ? (long?)null : ((SpaceTakeoffRow)_spaces.CurrentRow.Tag).SpaceId;
            _filtered = _snapshot == null ? new List<SpaceTakeoffRow>() : _snapshot.Rows.Where(Matches).ToList();
            _loading = true;
            try
            {
                _spaces.Rows.Clear(); string unit = HeightsInMillimeters ? "mm" : "m";
                foreach (string name in new[] { "Height", "Minimum", "Maximum" })
                {
                    _spaces.Columns[name].HeaderText = (name == "Height" ? "Clear height" : name == "Minimum" ? "Min sampled" : "Max sampled") + " (" + unit + ")";
                    _spaces.Columns[name].DefaultCellStyle.Format = HeightsInMillimeters ? "N0" : "N3";
                    _spaces.Columns[name].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
                foreach (var row in _filtered)
                {
                    var totals = row.OpeningTotals;
                    int index = _spaces.Rows.Add(row.RoomNumber, row.RoomName, row.SpaceNumber, row.SpaceName, row.LevelName,
                        row.AreaSquareMeters, DisplayLength(row.ClearHeightMeters), DisplayLength(row.MinHeightMeters), DisplayLength(row.MaxHeightMeters),
                        Basis(row.HeightBasis), row.StatusLabel, row.SamplesMeasured + " / " + row.SamplesAttempted,
                        totals.DoorCount, totals.DoorAreaSquareMeters, KnownArea(totals.DoorKnownAreaSquareMeters, row),
                        totals.WindowCount, totals.WindowAreaSquareMeters, KnownArea(totals.WindowKnownAreaSquareMeters, row), OpeningStatus(row));
                    var visual = _spaces.Rows[index]; visual.Tag = row;
                    if (row.Status != SpaceMeasurementStatus.Measured) visual.Cells["Status"].Style.ForeColor = KaTheme.Warning;
                    if (OpeningsNeedReview(row)) visual.Cells["OpeningStatus"].Style.ForeColor = KaTheme.Warning;
                    visual.Cells["RoomName"].ToolTipText = row.RoomIdentitySource;
                    visual.Cells["Height"].ToolTipText = "Sampled physical clear height. Blank values require review; use the min/max columns and Measurements tab.";
                    foreach (string name in new[] { "DoorCount", "WindowCount", "DoorArea", "WindowArea", "DoorKnownArea", "WindowKnownArea", "OpeningStatus" })
                        visual.Cells[name].ToolTipText = "Nominal width × height. Blank totals are unknown or incomplete; known area is only a subtotal. Shared doors count per associated Room and once in unique report totals. " + string.Join("; ", row.OpeningNotes);
                    if (selected.HasValue && row.SpaceId == selected.Value) _spaces.CurrentCell = visual.Cells[0];
                }
            }
            finally { _loading = false; }
            var openingTotals = SpaceOpeningSummary.ForUniqueOpenings(_filtered.SelectMany(row => row.Openings),
                _filtered.Count > 0 && _filtered.All(row => row.OpeningTotals.Complete));
            _summaryFullText = string.Format(CultureInfo.CurrentCulture, "{0:N0} / {1:N0} Spaces shown · known area {2:N2} m² · {3:N0} need review\r\nUnique openings in shown Spaces: doors {4} / windows {5}. Double-click for details; export uses every shown row.",
                _filtered.Count, _snapshot == null ? 0 : _snapshot.Rows.Count, _filtered.Sum(r => r.AreaSquareMeters ?? 0), _filtered.Count(r => r.NeedsReview),
                Quantity(openingTotals.DoorCount), Quantity(openingTotals.WindowCount));
            _summaryCompactText = string.Format(CultureInfo.CurrentCulture, "{0:N0} / {1:N0} Spaces · {2:N0} review · doors {3} / windows {4}",
                _filtered.Count, _snapshot == null ? 0 : _snapshot.Rows.Count, _filtered.Count(r => r.NeedsReview),
                Quantity(openingTotals.DoorCount), Quantity(openingTotals.WindowCount));
            _summary.Text = _compact ? _summaryCompactText : _summaryFullText;
            _tips.SetToolTip(_summary, _summaryFullText);
            UpdateDetails(); UpdateActions();
        }

        private bool Matches(SpaceTakeoffRow row)
        {
            if (_level.SelectedIndex > 0 && !string.Equals(row.LevelName ?? "", Convert.ToString(_level.SelectedItem), StringComparison.Ordinal)) return false;
            switch (_resultFilter.SelectedIndex)
            {
                case 1: if (!row.NeedsReview) return false; break;
                case 2: if (row.Status != SpaceMeasurementStatus.Measured) return false; break;
                case 3: if (row.HeightBasis != SpaceHeightBasis.Ceiling) return false; break;
                case 4: if (row.HeightBasis != SpaceHeightBasis.Slab) return false; break;
                case 5: if (row.HeightBasis != SpaceHeightBasis.Mixed) return false; break;
                case 6: if (!OpeningsNeedReview(row)) return false; break;
                case 7: if (OpeningsNeedReview(row)) return false; break;
            }
            string search = _search.Text.Trim();
            if (search.Length == 0) return true;
            return new[] { row.RoomName, row.RoomNumber, row.SpaceName, row.SpaceNumber, row.LevelName, row.PhaseName,
                row.SpaceId.ToString(CultureInfo.InvariantCulture), row.StatusLabel, row.RoomIdentitySource, row.FloorSources, row.OverheadSources,
                OpeningStatus(row), string.Join("; ", row.OpeningNotes), string.Join("; ", row.Openings.Select(o => o.FamilyName + " " + o.TypeName)) }
                .Any(value => (value ?? "").IndexOf(search, StringComparison.CurrentCultureIgnoreCase) >= 0);
        }

        private void UpdateDetails()
        {
            var row = _spaces.CurrentRow == null ? null : _spaces.CurrentRow.Tag as SpaceTakeoffRow;
            _samples.Rows.Clear(); _openings.Rows.Clear();
            if (row == null)
            {
                _rowDetails.Text = "Select a Space on the Spaces tab to review its measurement sources.";
                _openingDetails.Text = "Select a Space on the Spaces tab to review its associated Room's doors and windows."; return;
            }
            var text = new StringBuilder();
            text.AppendLine("Space: " + row.SpaceNumber + " / " + row.SpaceName + " [" + row.SpaceId.ToString(CultureInfo.InvariantCulture) + "]");
            text.AppendLine("Room: " + row.RoomNumber + " / " + row.RoomName);
            text.AppendLine("Room identity: " + row.RoomIdentitySource);
            text.AppendLine("Level: " + row.LevelName + " / Phase: " + row.PhaseName);
            text.AppendLine("Height status: " + row.StatusLabel + " / Overhead: " + Basis(row.HeightBasis));
            text.AppendLine("Opening status: " + OpeningStatus(row));
            text.AppendLine("Floor sources: " + row.FloorSources); text.AppendLine("Overhead sources: " + row.OverheadSources);
            foreach (string note in row.Notes) text.AppendLine(note);
            _rowDetails.Text = text.ToString();
            string unit = HeightsInMillimeters ? "mm" : "m";
            _samples.Columns["Height"].HeaderText = "Clear height (" + unit + ")";
            foreach (string column in new[] { "Floor", "Top", "Height" }) _samples.Columns[column].DefaultCellStyle.Format = column == "Height" && HeightsInMillimeters ? "N0" : "N3";
            foreach (var sample in row.Samples)
                _samples.Rows.Add(sample.SampleNumber, sample.FloorElevationMeters, sample.OverheadElevationMeters, DisplayLength(sample.HeightMeters),
                    Basis(sample.HeightBasis), sample.StatusLabel, sample.FloorSource == null ? "" : sample.FloorSource.Label,
                    sample.OverheadSource == null ? "" : sample.OverheadSource.Label, sample.Notes);
            UpdateOpeningDetails(row, unit);
        }

        private void UpdateOpeningDetails(SpaceTakeoffRow row, string unit)
        {
            var totals = row.OpeningTotals;
            var text = new StringBuilder();
            text.AppendLine("Space " + row.SpaceNumber + " / Room " + row.RoomNumber + " — " + OpeningStatus(row));
            text.AppendLine("Doors: " + Quantity(totals.DoorCount) + "; nominal area: " + Area(totals.DoorAreaSquareMeters) +
                "; known subtotal: " + KnownAreaText(totals.DoorKnownAreaSquareMeters, row) + "; missing dimensions: " + totals.DoorMissingDimensionCount);
            text.AppendLine("Windows: " + Quantity(totals.WindowCount) + "; nominal area: " + Area(totals.WindowAreaSquareMeters) +
                "; known subtotal: " + KnownAreaText(totals.WindowKnownAreaSquareMeters, row) + "; missing dimensions: " + totals.WindowMissingDimensionCount);
            if (!totals.Complete && row.RoomIdentityVerified)
                text.AppendLine("Known associated openings found: doors " + KnownOpeningCount(row, SpaceOpeningKind.Door) +
                    " / windows " + KnownOpeningCount(row, SpaceOpeningKind.Window) + ". Inventory is incomplete; these are not total counts.");
            text.AppendLine("Size = nominal width × height (" + unit + ") for each opening; Unknown marks a missing dimension. Nominal area = width × height. Shared doors count once for each associated Room; report totals count each source opening once. Blank totals are unknown or incomplete.");
            foreach (string note in row.OpeningNotes) text.AppendLine(note);
            _openingDetails.Text = text.ToString();
            _openings.Columns["Width"].HeaderText = "Width (" + unit + ")"; _openings.Columns["Height"].HeaderText = "Height (" + unit + ")";
            _openings.Columns["Width"].DefaultCellStyle.Format = _openings.Columns["Height"].DefaultCellStyle.Format = HeightsInMillimeters ? "N0" : "N3";
            foreach (var opening in row.Openings)
            {
                int index = _openings.Rows.Add(opening.Kind.ToString(), opening.Source == null ? (object)null : opening.Source.ElementId,
                    opening.FamilyName, opening.TypeName, SpaceOpeningDimensions.FormatSize(opening.WidthMeters, opening.HeightMeters, HeightsInMillimeters, CultureInfo.CurrentCulture),
                    DisplayLength(opening.WidthMeters), DisplayLength(opening.HeightMeters), opening.AreaSquareMeters,
                    opening.AreaSquareMeters.HasValue ? "Known nominal dimensions" : "Missing dimensions — review",
                    opening.IsShared ? "Yes" : "No",
                    opening.Source == null ? "" : opening.Source.Label,
                    string.Join("; ", opening.Rooms.Select(room => room.Number + " / " + room.Name + (room.Source == null ? "" : " [" + room.Source.ElementId + "]"))),
                    string.Join("; ", new[] { opening.DimensionSource, opening.DimensionNotes, opening.AssociationNotes }.Where(note => !string.IsNullOrWhiteSpace(note))));
                _openings.Rows[index].Tag = opening;
                if (!opening.AreaSquareMeters.HasValue) _openings.Rows[index].Cells["Status"].Style.ForeColor = KaTheme.Warning;
            }
        }

        private void UpdateActions()
        {
            _scan.Enabled = !_busy && _phase.SelectedItem != null;
            _export.Enabled = !_busy && !_stale && _snapshot != null && _filtered.Count > 0;
            _close.Enabled = !_busy; _tabs.Enabled = !_busy;
            _linkChoice.Enabled = !_busy && _links.Checked;
            UseWaitCursor = _busy; _status.Text = _message;
            _status.ForeColor = _stale && _snapshot != null ? KaTheme.Warning : KaTheme.Muted;
            _tips.SetToolTip(_status, _message);
        }

        private object DisplayLength(double? value) { return value.HasValue ? (object)(value.Value * (HeightsInMillimeters ? 1000 : 1)) : null; }
        private static bool OpeningsNeedReview(SpaceTakeoffRow row)
        {
            var totals = row.OpeningTotals;
            return !totals.Complete || totals.DoorMissingDimensionCount > 0 || totals.WindowMissingDimensionCount > 0;
        }
        private static string OpeningStatus(SpaceTakeoffRow row)
        {
            if (!row.RoomIdentityVerified) return "Unknown — Room association unverified";
            var totals = row.OpeningTotals;
            if (!totals.Complete) return "Incomplete opening coverage — review";
            int missing = totals.DoorMissingDimensionCount + totals.WindowMissingDimensionCount;
            return missing == 0 ? "Complete nominal quantities" : "Missing dimensions: " + missing.ToString(CultureInfo.CurrentCulture) + " — review known subtotal";
        }
        private static int KnownOpeningCount(SpaceTakeoffRow row, SpaceOpeningKind kind)
        {
            return row.Openings.Where(opening => opening != null && opening.Source != null && opening.Kind == kind)
                .Select(opening => opening.Source.Key).Distinct(StringComparer.Ordinal).Count();
        }
        private static object KnownArea(double value, SpaceTakeoffRow row)
        {
            return row.OpeningTotals.Complete || row.Openings.Any(opening => opening != null && opening.Source != null) ? (object)value : null;
        }
        private static string KnownAreaText(double value, SpaceTakeoffRow row) { return KnownArea(value, row) == null ? "Unknown" : Area(value); }
        private static string Quantity(int? value) { return value.HasValue ? value.Value.ToString(CultureInfo.CurrentCulture) : "Unknown"; }
        private static string Area(double? value) { return value.HasValue ? value.Value.ToString("N2", CultureInfo.CurrentCulture) + " m²" : "Unknown / incomplete"; }
        private static string Basis(SpaceHeightBasis basis) { return basis == SpaceHeightBasis.Ceiling ? "Ceiling" : basis == SpaceHeightBasis.Slab ? "Slab fallback" : basis == SpaceHeightBasis.Mixed ? "Mixed" : "Not found"; }
        private static TextBox NotesBox() { return new TextBox { Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Both, WordWrap = true, Dock = DockStyle.Fill, BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle }; }
        private static ComboBox Choice(params string[] items)
        {
            var control = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, IntegralHeight = false, DropDownHeight = 220, DropDownWidth = 420, Dock = DockStyle.Fill };
            control.Items.AddRange(items); return control;
        }
        private static NumericUpDown Number(decimal value, decimal min, decimal max, int decimals, decimal step) { return new NumericUpDown { Value = value, Minimum = min, Maximum = max, DecimalPlaces = decimals, Increment = step, Dock = DockStyle.Fill }; }
        private static TabPage Page(string text) { return new TabPage(text) { BackColor = KaTheme.Surface, Padding = new Padding(6) }; }
        private static Label Hint(string text) { var label = KaTheme.Hint(text); label.Margin = new Padding(0, 5, 0, 8); return label; }
        private static void StyleSpaceGrid(DataGridView grid)
        {
            KaTheme.StyleGrid(grid, true);
            Action fit = delegate
            {
                // DataGridView caches cell-style fonts separately from its Control.Font.
                grid.DefaultCellStyle.Font = grid.Font;
                grid.ColumnHeadersDefaultCellStyle.Font = grid.Font;
                int textHeight = TextRenderer.MeasureText("Mg", grid.Font, Size.Empty, TextFormatFlags.SingleLine).Height;
                grid.RowTemplate.Height = Math.Max(29, textHeight + grid.DefaultCellStyle.Padding.Vertical + 8);
                grid.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.False;
                grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
                grid.ColumnHeadersHeight = Math.Max(34, textHeight + grid.ColumnHeadersDefaultCellStyle.Padding.Vertical + 8);
                foreach (DataGridViewRow row in grid.Rows) row.Height = grid.RowTemplate.Height;
                foreach (DataGridViewColumn column in grid.Columns)
                    if (column.Tag is int) column.Width = Math.Max(column.MinimumWidth, (int)Math.Ceiling((int)column.Tag * grid.Font.SizeInPoints / 9F));
            };
            grid.FontChanged += delegate { fit(); };
            fit();
        }
        private static void AddColumn(DataGridView grid, string name, string title, int width)
        {
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = name, HeaderText = title,
                Width = (int)Math.Ceiling(width * grid.Font.SizeInPoints / 9F), Tag = width,
                MinimumWidth = 55, SortMode = DataGridViewColumnSortMode.NotSortable });
        }
        private static Control Field(string title, Control input)
        {
            var panel = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, ColumnCount = 2, RowCount = 1, Margin = new Padding(0, 4, 0, 6) };
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 46)); panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 54));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var label = new Label { Text = title, AutoSize = true, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Margin = new Padding(0, 4, 10, 4) };
            panel.Controls.Add(label, 0, 0);
            input.Margin = new Padding(0, 2, 0, 2); input.Dock = DockStyle.Top; panel.Controls.Add(input, 1, 0);
            // Native combo boxes retain their preferred height even when a table tries to shrink them.
            // Reserve that height in the row itself, including margins, after font/DPI changes.
            EventHandler fit = delegate
            {
                var combo = input as ComboBox;
                int nativeHeight = combo == null ? input.PreferredSize.Height : combo.PreferredHeight;
                if (combo != null && input.Height != nativeHeight) input.Height = nativeHeight;
                int height = Math.Max(nativeHeight + input.Margin.Vertical,
                    label.GetPreferredSize(new Size(Math.Max(1, label.Width), 0)).Height + label.Margin.Vertical);
                panel.MinimumSize = new Size(0, height);
            };
            input.FontChanged += fit; input.SizeChanged += fit; label.FontChanged += fit;
            panel.Layout += delegate { fit(panel, EventArgs.Empty); };
            return panel;
        }
        private static void AddFilter(TableLayoutPanel panel, string title, Control input, int x, int y)
        {
            panel.Controls.Add(new Label { Text = title, Dock = DockStyle.Fill, AutoSize = true, TextAlign = ContentAlignment.MiddleLeft, Margin = new Padding(0, 4, 6, 4) }, x, y);
            input.Margin = new Padding(0, 3, 10, 3); input.Dock = DockStyle.Fill; panel.Controls.Add(input, x + 1, y);
        }
    }
}
