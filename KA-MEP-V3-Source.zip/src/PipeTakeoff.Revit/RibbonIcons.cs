using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Media.Imaging;

namespace PipeTakeoff.Revit
{
    internal static class RibbonIcons
    {
        internal static BitmapImage Create(string kind, int size)
        {
            if (kind == "home" || kind == "info")
            {
                using (var stream = new MemoryStream(KAMEP.Branding.BrandImages.RibbonLogoBytes(size)))
                {
                    var image = new BitmapImage();
                    image.BeginInit();
                    image.CacheOption = BitmapCacheOption.OnLoad;
                    image.StreamSource = stream;
                    image.EndInit();
                    image.Freeze();
                    return image;
                }
            }
            using (var bitmap = new Bitmap(size, size, PixelFormat.Format32bppArgb))
            using (var graphics = Graphics.FromImage(bitmap))
            {
                graphics.SmoothingMode = SmoothingMode.AntiAlias;
                graphics.ScaleTransform(size / 32f, size / 32f);
                graphics.Clear(Color.Transparent);
                using (var background = new SolidBrush(Color.FromArgb(20, 45, 66)))
                using (var accent = new SolidBrush(Color.FromArgb(0, 181, 165)))
                using (var white = new Pen(Color.White, 2f))
                using (var teal = new Pen(Color.FromArgb(0, 181, 165), 2f))
                {
                    graphics.FillEllipse(background, 1, 1, 30, 30);
                    white.StartCap = LineCap.Round; white.EndCap = LineCap.Round;
                    if (kind == "mcp")
                    {
                        graphics.DrawRectangle(white, 5, 7, 9, 17);
                        graphics.DrawRectangle(teal, 20, 10, 7, 12);
                        graphics.DrawLine(white, 14, 16, 20, 16);
                        graphics.FillEllipse(accent, 8, 19, 3, 3);
                    }
                    else if (kind == "clashes")
                    {
                        graphics.DrawRectangle(white, 6, 7, 12, 12);
                        graphics.DrawRectangle(teal, 14, 14, 12, 12);
                        graphics.DrawLine(white, 16, 9, 16, 16);
                        graphics.FillEllipse(accent, 14, 19, 4, 4);
                    }
                    else if (kind == "spaces")
                    {
                        graphics.DrawRectangle(white, 5, 7, 15, 18);
                        graphics.DrawLine(teal, 25, 7, 25, 25);
                        graphics.DrawLines(teal, new[] { new Point(22, 10), new Point(25, 7), new Point(28, 10) });
                        graphics.DrawLines(teal, new[] { new Point(22, 22), new Point(25, 25), new Point(28, 22) });
                        graphics.DrawLine(white, 9, 12, 16, 12);
                        graphics.DrawLine(white, 9, 17, 14, 17);
                    }
                    else if (kind == "pipes")
                    {
                        using (var pipe = new Pen(Color.White, 5f))
                            graphics.DrawLines(pipe, new[] { new Point(8, 23), new Point(8, 11), new Point(24, 11) });
                        graphics.FillRectangle(accent, 5, 19, 6, 3);
                        graphics.FillRectangle(accent, 19, 8, 3, 6);
                    }
                    else if (kind == "ducts")
                    {
                        graphics.DrawPolygon(white, new[] { new Point(6, 12), new Point(15, 7), new Point(26, 13), new Point(17, 18) });
                        graphics.DrawLines(white, new[] { new Point(6, 12), new Point(6, 21), new Point(17, 26), new Point(26, 21), new Point(26, 13) });
                        graphics.DrawLine(teal, 17, 18, 17, 26);
                    }
                    else if (kind == "trays")
                    {
                        graphics.DrawLine(white, 9, 7, 9, 25);
                        graphics.DrawLine(white, 23, 7, 23, 25);
                        for (int y = 9; y <= 24; y += 5) graphics.DrawLine(teal, 10, y, 22, y);
                    }
                    else if (kind == "conduits")
                    {
                        graphics.DrawLines(white, new[] { new Point(8, 24), new Point(8, 12), new Point(12, 8), new Point(24, 8) });
                        graphics.DrawLines(teal, new[] { new Point(14, 24), new Point(14, 16), new Point(16, 14), new Point(24, 14) });
                    }
                    else if (kind == "tags")
                    {
                        graphics.DrawRectangle(white, 15, 6, 11, 6);
                        graphics.DrawRectangle(white, 15, 19, 11, 6);
                        graphics.DrawLines(teal, new[] { new Point(6, 18), new Point(10, 9), new Point(15, 9) });
                        graphics.DrawLines(teal, new[] { new Point(6, 26), new Point(10, 22), new Point(15, 22) });
                        graphics.FillEllipse(accent, 4, 16, 4, 4);
                        graphics.FillEllipse(accent, 4, 24, 4, 4);
                    }
                    else if (kind == "sheetparams")
                    {
                        graphics.DrawRectangle(white, 7, 5, 16, 22);
                        graphics.DrawLine(white, 11, 11, 19, 11);
                        graphics.DrawLine(white, 11, 16, 16, 16);
                        using (var pencil = new Pen(Color.FromArgb(0, 181, 165), 4f))
                        {
                            pencil.StartCap = LineCap.Square;
                            pencil.EndCap = LineCap.Square;
                            graphics.DrawLine(pencil, 17, 23, 25, 15);
                        }
                        graphics.FillPolygon(Brushes.White, new[] { new Point(14, 26), new Point(15, 21), new Point(19, 25) });
                    }
                    else if (kind == "review")
                    {
                        graphics.DrawEllipse(white, 7, 6, 14, 14);
                        graphics.DrawLine(white, 19, 19, 26, 26);
                        graphics.DrawLines(teal, new[] { new Point(10, 13), new Point(13, 16), new Point(18, 10) });
                    }
                    else if (kind == "sheets")
                    {
                        graphics.DrawRectangle(white, 8, 6, 15, 20);
                        graphics.DrawLine(teal, 12, 12, 19, 12);
                        graphics.DrawLine(white, 12, 17, 19, 17);
                        graphics.DrawLine(white, 12, 21, 17, 21);
                    }
                    else if (kind == "info")
                    {
                        graphics.FillEllipse(accent, 14, 7, 4, 4);
                        graphics.DrawLine(white, 16, 15, 16, 24);
                    }
                    else
                    {
                        foreach (var point in new[] { new Point(7, 7), new Point(18, 7), new Point(7, 18) })
                            graphics.FillRectangle(accent, point.X, point.Y, 7, 7);
                        graphics.FillRectangle(Brushes.White, 18, 18, 7, 7);
                    }
                }
                using (var stream = new MemoryStream())
                {
                    bitmap.Save(stream, ImageFormat.Png);
                    stream.Position = 0;
                    var image = new BitmapImage();
                    image.BeginInit();
                    image.CacheOption = BitmapCacheOption.OnLoad;
                    image.StreamSource = stream;
                    image.EndInit();
                    image.Freeze();
                    return image;
                }
            }
        }
    }
}
