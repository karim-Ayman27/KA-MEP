using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Windows.Forms;

namespace PipeTakeoff.Revit
{
    [Transaction(TransactionMode.Manual)]
    public sealed class HubCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            using (var form = new HubForm())
            {
                if (form.ShowDialog(new WindowOwner(commandData.Application.MainWindowHandle)) != DialogResult.OK)
                    return Result.Cancelled;
                switch (form.SelectedAction)
                {
                    case HubAction.Claude: return new McpConnectionCommand().Execute(commandData, ref message, elements);
                    case HubAction.Spaces: return new SpaceTakeoffCommand().Execute(commandData, ref message, elements);
                    case HubAction.Clashes: return new ClashManagerCommand().Execute(commandData, ref message, elements);
                    case HubAction.Pipes: return new TakeoffCommand().Execute(commandData, ref message, elements);
                    case HubAction.Ducts: return new DuctTakeoffCommand().Execute(commandData, ref message, elements);
                    case HubAction.CableTrays: return new CableTrayTakeoffCommand().Execute(commandData, ref message, elements);
                    case HubAction.Conduits: return new ConduitTakeoffCommand().Execute(commandData, ref message, elements);
                    case HubAction.Sheets: return new SheetExportCommand().Execute(commandData, ref message, elements);
                    case HubAction.SheetParameters: return new SheetEditorCommand().Execute(commandData, ref message, elements);
                    case HubAction.ModelReview: return new ModelReviewCommand().Execute(commandData, ref message, elements);
                    case HubAction.Tags: return new TagAssistantCommand().Execute(commandData, ref message, elements);
                    case HubAction.Info: return new InfoCommand().Execute(commandData, ref message, elements);
                    default: return Result.Cancelled;
                }
            }
        }

        private sealed class WindowOwner : IWin32Window
        {
            public WindowOwner(IntPtr handle) { Handle = handle; }
            public IntPtr Handle { get; private set; }
        }
    }
}
