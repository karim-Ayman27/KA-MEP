using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Electrical;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.UI;
using PipeTakeoff.Core;

namespace PipeTakeoff.Revit
{
    internal sealed class ElectricalSnapshot
    {
        public List<PipeRecord> Records { get; set; }
        public List<FieldDefinition> Fields { get; set; }
        public string ScopeLabel { get; set; }
    }

    /// <summary>Reads current-model electrical containment on Revit's API thread into detached records.</summary>
    internal static class ElectricalReader
    {
        private sealed class ParameterField
        {
            public string Key;
            public FieldDefinition Field;
        }

        private sealed class Section
        {
            public string Key;
            public string Label;
            public double? Diameter;
            public double? Width;
            public double? Height;
        }

        private static readonly HashSet<long> MappedParameters = new HashSet<long>
        {
            (long)BuiltInParameter.CURVE_ELEM_LENGTH,
            (long)BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM,
            (long)BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM,
            (long)BuiltInParameter.RBS_CONDUIT_DIAMETER_PARAM,
            (long)BuiltInParameter.RBS_CTC_SERVICE_TYPE,
            (long)BuiltInParameter.RBS_CALCULATED_SIZE,
            (long)BuiltInParameter.ALL_MODEL_MARK,
            (long)BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS
        };

        public static ElectricalSnapshot Read(UIDocument uiDocument, PipeScope scope, bool cableTray)
        {
            var document = uiDocument.Document;
            var description = cableTray ? "cable trays and cable tray fittings" : "conduits and conduit fittings";
            List<Element> elements;
            string scopeLabel;
            if (scope == PipeScope.Selection)
            {
                elements = uiDocument.Selection.GetElementIds().Select(document.GetElement)
                    .Where(e => IsIncluded(e, cableTray)).ToList();
                scopeLabel = "Selected " + description + " (current model)";
            }
            else
            {
                if (scope == PipeScope.ActiveView && !FilteredElementCollector.IsViewValidForElementIteration(document, document.ActiveView.Id))
                    throw new InvalidOperationException("This view cannot be used for electrical containment collection. Choose a model view or use the whole model.");
                using (var collector = scope == PipeScope.ActiveView
                    ? new FilteredElementCollector(document, document.ActiveView.Id)
                    : new FilteredElementCollector(document))
                using (var categories = new ElementMulticategoryFilter(cableTray
                    ? new[] { BuiltInCategory.OST_CableTray, BuiltInCategory.OST_CableTrayFitting }
                    : new[] { BuiltInCategory.OST_Conduit, BuiltInCategory.OST_ConduitFitting }))
                {
                    elements = collector.WherePasses(categories).WhereElementIsNotElementType()
                        .Where(e => IsIncluded(e, cableTray)).ToList();
                }
                scopeLabel = scope == PipeScope.ActiveView
                    ? "Active view: " + document.ActiveView.Name + " (" + description + ")"
                    : "All " + description + " (current model)";
            }

            var fields = ElectricalStandardFields.Create();
            var custom = new Dictionary<string, ParameterField>(StringComparer.Ordinal);
            var typeValues = new Dictionary<long, Dictionary<string, object>>();
            var rows = new List<PipeRecord>(elements.Count);
            foreach (var element in elements.OrderBy(e => RevitCompat.Id(e.Id)))
            {
                var row = new PipeRecord();
                var type = document.GetElement(element.GetTypeId()) as ElementType;
                var curve = element as CableTrayConduitBase;
                row.Values["ElementId"] = RevitCompat.Id(element.Id).ToString(CultureInfo.InvariantCulture);
                row.Values["Category"] = cableTray
                    ? (curve == null ? "Cable Tray Fitting" : "Cable Tray")
                    : (curve == null ? "Conduit Fitting" : "Conduit");
                row.Values["Family"] = type == null ? "" : type.FamilyName;
                row.Values["Type"] = type == null ? "" : type.Name;
                // Cable tray/conduit do not have a piping system. Preserve their actual service-type value.
                row.Values["SystemName"] = Text(element.get_Parameter(BuiltInParameter.RBS_CTC_SERVICE_TYPE), document);
                row.Values["Size"] = Text(element.get_Parameter(BuiltInParameter.RBS_CALCULATED_SIZE), document);
                row.Values["Level"] = LevelName(element, curve, document);
                row.Values["Mark"] = Text(element.get_Parameter(BuiltInParameter.ALL_MODEL_MARK), document);
                row.Values["Comments"] = Text(element.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS), document);

                if (curve != null) ReadCurve(curve, row, cableTray);
                else ReadFitting((FamilyInstance)element, type, row);
                if (string.IsNullOrWhiteSpace(row.Get("Size") as string)) row.Values["Size"] = row.Get("SectionLabel");
                ReadParameters(element, "Instance", document, row.Values, custom);
                if (type != null)
                {
                    Dictionary<string, object> values;
                    if (!typeValues.TryGetValue(RevitCompat.Id(type.Id), out values))
                    {
                        values = new Dictionary<string, object>(StringComparer.Ordinal);
                        ReadParameters(type, "Type", document, values, custom);
                        typeValues.Add(RevitCompat.Id(type.Id), values);
                    }
                    foreach (var item in values) row.Values[item.Key] = item.Value;
                }
                rows.Add(row);
            }
            foreach (var duplicates in custom.Values.GroupBy(f => f.Field.Header).Where(g => g.Count() > 1))
                foreach (var field in duplicates) field.Field.Header += " {" + field.Key + "}";
            fields.AddRange(custom.Values.Select(f => f.Field).OrderBy(f => f.Header, StringComparer.CurrentCultureIgnoreCase));
            return new ElectricalSnapshot { Records = rows, Fields = fields, ScopeLabel = scopeLabel };
        }

        private static bool IsIncluded(Element element, bool cableTray)
        {
            if (cableTray ? element is CableTray : element is Conduit) return true;
            return element is FamilyInstance && element.Category != null && RevitCompat.Id(element.Category.Id) ==
                (long)(cableTray ? BuiltInCategory.OST_CableTrayFitting : BuiltInCategory.OST_ConduitFitting);
        }

        private static void ReadCurve(CableTrayConduitBase curve, PipeRecord row, bool cableTray)
        {
            var length = Number(curve.get_Parameter(BuiltInParameter.CURVE_ELEM_LENGTH), UnitTypeId.Meters);
            if (!length.HasValue)
                throw new InvalidOperationException("A " + (cableTray ? "cable tray" : "conduit") + " has no valid length parameter: "
                    + RevitCompat.Id(curve.Id).ToString(CultureInfo.InvariantCulture) + ". Its length has not been assumed to be zero.");
            row.Values["Length"] = length.Value;
            row.Values["FittingKind"] = "";
            row.Values["Angle"] = null;
            // Conduit quantity dimensions use nominal diameter, not outside or inside diameter.
            var section = cableTray
                ? MakeSection(ConnectorProfileType.Rectangular, null,
                    Number(curve.get_Parameter(BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM), UnitTypeId.Millimeters),
                    Number(curve.get_Parameter(BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM), UnitTypeId.Millimeters))
                : MakeSection(ConnectorProfileType.Round,
                    Number(curve.get_Parameter(BuiltInParameter.RBS_CONDUIT_DIAMETER_PARAM), UnitTypeId.Millimeters), null, null);
            AssignSection(row, section, curve.Id);
        }

        private static void ReadFitting(FamilyInstance fitting, ElementType type, PipeRecord row)
        {
            // Fittings are item counts. Family length parameters never enter straight-run length totals.
            row.Values["Length"] = null;
            var partType = ReadPartType(fitting, type);
            row.Values["FittingKind"] = partType.HasValue ? partType.Value.ToString() : "Unknown";
            var ports = new List<Connector>();
            var sections = new List<Section>();
            var incomplete = false;
            var manager = fitting.MEPModel == null ? null : fitting.MEPModel.ConnectorManager;
            if (manager != null)
            {
                foreach (Connector connector in manager.Connectors)
                {
                    if (connector.Domain != Domain.DomainCableTrayConduit || !IsPhysicalPort(connector.ConnectorType)) continue;
                    ports.Add(connector);
                    Section section;
                    try
                    {
                        var shape = connector.Shape;
                        section = MakeSection(shape,
                            shape == ConnectorProfileType.Round ? (double?)ToMillimeters(connector.Radius * 2) : null,
                            shape == ConnectorProfileType.Rectangular ? (double?)ToMillimeters(connector.Width) : null,
                            shape == ConnectorProfileType.Rectangular ? (double?)ToMillimeters(connector.Height) : null);
                    }
                    catch (Autodesk.Revit.Exceptions.InvalidOperationException) { section = null; }
                    if (section == null) incomplete = true;
                    else sections.Add(section);
                }
            }

            // Only known elbows have a single deflection angle. Offset fittings must not acquire a fictitious zero angle.
            var elbow = partType.HasValue && IsElbow(partType.Value);
            var angle = elbow ? ElbowDeflection(ports) : null;
            if (elbow && !angle.HasValue) angle = ReadBuiltInAngle(fitting, type);
            row.Values["Angle"] = angle.HasValue ? (object)angle.Value : null;
            row.Values["Diameter"] = null;
            row.Values["Width"] = null;
            row.Values["Height"] = null;
            if (sections.Count == 0) AssignSection(row, null, fitting.Id);
            else
            {
                sections = sections.OrderBy(s => s.Key, StringComparer.Ordinal).ToList();
                // Preserve port multiplicity and every reducer size; sorting removes connector enumeration order.
                row.Values["SectionKey"] = string.Join("|", sections.Select(s => s.Key));
                row.Values["SectionLabel"] = string.Join(" + ", sections.GroupBy(s => s.Key).Select(g =>
                    g.Count().ToString(CultureInfo.InvariantCulture) + " × [" + g.First().Label + "]"));
                if (!incomplete && sections.All(s => s.Key == sections[0].Key))
                {
                    row.Values["Diameter"] = sections[0].Diameter;
                    row.Values["Width"] = sections[0].Width;
                    row.Values["Height"] = sections[0].Height;
                }
                if (incomplete)
                {
                    row.Values["SectionKey"] += "|Incomplete:" + RevitCompat.Id(fitting.Id).ToString(CultureInfo.InvariantCulture);
                    row.Values["SectionLabel"] += " + [unavailable port dimensions]";
                }
            }
            if (elbow && !angle.HasValue)
                row.Values["SectionKey"] += "|UnresolvedAngle:" + RevitCompat.Id(fitting.Id).ToString(CultureInfo.InvariantCulture);
            if (!partType.HasValue)
                row.Values["SectionKey"] += "|UnknownFittingKind:" + RevitCompat.Id(fitting.Id).ToString(CultureInfo.InvariantCulture);
        }

        private static PartType? ReadPartType(FamilyInstance fitting, ElementType type)
        {
            var mechanical = fitting.MEPModel as MechanicalFitting;
            if (mechanical != null && mechanical.PartType != PartType.Undefined) return mechanical.PartType;
            var family = fitting.Symbol == null ? null : fitting.Symbol.Family;
            foreach (var element in new Element[] { fitting, type, family })
            {
                if (element == null) continue;
                foreach (var builtIn in new[] { BuiltInParameter.RBS_PART_TYPE, BuiltInParameter.FAMILY_CONTENT_PART_TYPE })
                {
                    var parameter = element.get_Parameter(builtIn);
                    if (parameter == null || !parameter.HasValue || parameter.StorageType != StorageType.Integer) continue;
                    var raw = parameter.AsInteger();
                    if (Enum.IsDefined(typeof(PartType), raw) && (PartType)raw != PartType.Undefined) return (PartType)raw;
                }
            }
            return null;
        }

        private static bool IsElbow(PartType type)
        {
            return type == PartType.Elbow || type == PartType.LadderCableTrayElbow || type == PartType.LadderCableTrayVerticalElbow
                || type == PartType.ChannelCableTrayElbow || type == PartType.ChannelCableTrayVerticalElbow || type == PartType.JunctionBoxElbow;
        }

        private static bool IsPhysicalPort(ConnectorType type)
        {
            return type == ConnectorType.End || type == ConnectorType.Curve || type == ConnectorType.Physical
                || type == ConnectorType.EndSurface || type == ConnectorType.BlankEnd;
        }

        private static double? ElbowDeflection(IList<Connector> ports)
        {
            if (ports.Count != 2) return null;
            try
            {
                var first = ports[0].CoordinateSystem.BasisZ;
                var second = ports[1].CoordinateSystem.BasisZ;
                if (first.GetLength() < 1e-9 || second.GetLength() < 1e-9) return null;
                var dot = first.Normalize().DotProduct(second.Normalize());
                var radians = Math.PI - Math.Acos(Math.Max(-1, Math.Min(1, dot)));
                var degrees = UnitUtils.ConvertFromInternalUnits(radians, UnitTypeId.Degrees);
                return double.IsNaN(degrees) || double.IsInfinity(degrees) ? null : (double?)Math.Round(degrees, 6);
            }
            catch (Autodesk.Revit.Exceptions.InvalidOperationException) { return null; }
        }

        private static double? ReadBuiltInAngle(Element fitting, ElementType type)
        {
            foreach (var element in new Element[] { fitting, type })
            {
                if (element == null) continue;
                foreach (var builtIn in new[] { BuiltInParameter.CONNECTOR_ANGLE_OF_DEFLECTION, BuiltInParameter.CONNECTOR_ANGLE })
                {
                    var parameter = element.get_Parameter(builtIn);
                    if (parameter == null || parameter.Definition == null || !SpecTypeId.Angle.Equals(parameter.Definition.GetDataType())) continue;
                    var value = Number(parameter, UnitTypeId.Degrees);
                    if (value.HasValue && value.Value <= 180.000001) return Math.Round(value.Value, 6);
                }
            }
            return null;
        }

        private static Section MakeSection(ConnectorProfileType shape, double? diameter, double? width, double? height)
        {
            if (shape == ConnectorProfileType.Round && IsPositive(diameter))
                return new Section { Diameter = diameter, Key = "Round:" + Canonical(diameter.Value), Label = "Ø " + Display(diameter.Value) + " mm" };
            if (shape == ConnectorProfileType.Rectangular && IsPositive(width) && IsPositive(height))
                return new Section { Width = width, Height = height,
                    Key = "Rectangular:" + Canonical(width.Value) + "x" + Canonical(height.Value),
                    Label = Display(width.Value) + " × " + Display(height.Value) + " mm" };
            return null;
        }

        private static void AssignSection(PipeRecord row, Section section, ElementId id)
        {
            row.Values["SectionKey"] = section == null ? "Unknown:" + RevitCompat.Id(id).ToString(CultureInfo.InvariantCulture) : section.Key;
            row.Values["SectionLabel"] = section == null ? "Not available" : section.Label;
            row.Values["Diameter"] = section == null ? null : (object)section.Diameter;
            row.Values["Width"] = section == null ? null : (object)section.Width;
            row.Values["Height"] = section == null ? null : (object)section.Height;
        }

        private static string LevelName(Element element, MEPCurve curve, Document document)
        {
            if (curve != null && curve.ReferenceLevel != null) return curve.ReferenceLevel.Name;
            var level = document.GetElement(element.LevelId) as Level;
            return level == null ? "" : level.Name;
        }

        private static bool IsPositive(double? value)
        { return value.HasValue && value.Value > 0 && !double.IsNaN(value.Value) && !double.IsInfinity(value.Value); }

        private static double? Number(Parameter parameter, ForgeTypeId units)
        {
            if (parameter == null || !parameter.HasValue || parameter.StorageType != StorageType.Double) return null;
            var value = UnitUtils.ConvertFromInternalUnits(parameter.AsDouble(), units);
            return double.IsNaN(value) || double.IsInfinity(value) || value < 0 ? null : (double?)value;
        }

        private static double ToMillimeters(double value)
        { return UnitUtils.ConvertFromInternalUnits(value, UnitTypeId.Millimeters); }
        private static string Canonical(double value)
        { return Math.Round(value, 6).ToString("0.######", CultureInfo.InvariantCulture); }
        private static string Display(double value)
        { return value.ToString("0.###", CultureInfo.CurrentCulture); }

        private static void ReadParameters(Element element, string source, Document document,
            Dictionary<string, object> values, Dictionary<string, ParameterField> fields)
        {
            foreach (Parameter parameter in element.Parameters)
            {
                if (parameter.Definition == null || parameter.StorageType == StorageType.None) continue;
                if (source == "Instance" && MappedParameters.Contains(RevitCompat.Id(parameter.Id))) continue;
                var key = source + ":" + (parameter.IsShared ? parameter.GUID.ToString("D") : RevitCompat.Id(parameter.Id).ToString(CultureInfo.InvariantCulture));
                var numeric = parameter.StorageType == StorageType.Double || parameter.StorageType == StorageType.Integer;
                var measured = parameter.StorageType == StorageType.Double && UnitUtils.IsMeasurableSpec(parameter.Definition.GetDataType());
                ForgeTypeId unit = measured ? parameter.GetUnitTypeId() : null;
                if (!fields.ContainsKey(key))
                {
                    var suffix = measured ? " (" + LabelUtils.GetLabelForUnit(unit) + ")" : "";
                    fields.Add(key, new ParameterField { Key = key,
                        Field = new FieldDefinition { Key = key, Header = parameter.Definition.Name + suffix + " [" + source + "]", IsNumeric = numeric } });
                }
                if (!parameter.HasValue) { values[key] = null; continue; }
                if (parameter.StorageType == StorageType.Double)
                    values[key] = measured ? UnitUtils.ConvertFromInternalUnits(parameter.AsDouble(), unit) : parameter.AsDouble();
                else if (parameter.StorageType == StorageType.Integer) values[key] = parameter.AsInteger();
                else values[key] = Text(parameter, document);
            }
        }

        private static string Text(Parameter parameter, Document document)
        {
            if (parameter == null || !parameter.HasValue) return "";
            if (parameter.StorageType == StorageType.String) return parameter.AsString() ?? "";
            if (parameter.StorageType == StorageType.ElementId)
            {
                var id = parameter.AsElementId();
                var element = id == ElementId.InvalidElementId ? null : document.GetElement(id);
                return element == null ? parameter.AsValueString() ?? "" : element.Name;
            }
            return parameter.AsValueString() ?? "";
        }
    }
}
