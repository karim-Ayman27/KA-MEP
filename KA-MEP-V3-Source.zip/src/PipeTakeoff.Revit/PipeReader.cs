using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.UI;
using PipeTakeoff.Core;

namespace PipeTakeoff.Revit
{
    internal enum PipeScope { Model, ActiveView, Selection }

    internal sealed class PipeSnapshot
    {
        public List<PipeRecord> Records { get; set; }
        public List<FieldDefinition> Fields { get; set; }
        public string ScopeLabel { get; set; }
    }

    internal static class PipeReader
    {
        private sealed class ParameterField
        {
            public string Key;
            public FieldDefinition Field;
        }

        // Never resolve a built-in field by translated display name.
        private static readonly HashSet<long> MappedParameters = new HashSet<long>
        {
            (long)BuiltInParameter.CURVE_ELEM_LENGTH,
            (long)BuiltInParameter.RBS_PIPE_DIAMETER_PARAM,
            (long)BuiltInParameter.RBS_SYSTEM_NAME_PARAM,
            (long)BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM,
            (long)BuiltInParameter.RBS_CALCULATED_SIZE,
            (long)BuiltInParameter.ALL_MODEL_MARK,
            (long)BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS
        };

        public static PipeSnapshot Read(UIDocument uiDocument, PipeScope scope)
        {
            var document = uiDocument.Document;
            List<Pipe> pipes;
            string scopeLabel;
            if (scope == PipeScope.Selection)
            {
                pipes = uiDocument.Selection.GetElementIds().Select(document.GetElement).OfType<Pipe>().Where(p => !p.IsPlaceholder).ToList();
                scopeLabel = "Selected pipes (current model)";
            }
            else
            {
                if (scope == PipeScope.ActiveView && !FilteredElementCollector.IsViewValidForElementIteration(document, document.ActiveView.Id))
                    throw new InvalidOperationException("This view cannot be used for pipe collection. Choose a model view or use all pipes.");
                using (var collector = scope == PipeScope.ActiveView
                    ? new FilteredElementCollector(document, document.ActiveView.Id)
                    : new FilteredElementCollector(document))
                {
                    pipes = collector.OfClass(typeof(Pipe)).WhereElementIsNotElementType().Cast<Pipe>().Where(p => !p.IsPlaceholder).ToList();
                }
                scopeLabel = scope == PipeScope.ActiveView ? "Active view: " + document.ActiveView.Name : "All pipes (current model)";
            }

            var fields = StandardFields.Create();
            var custom = new Dictionary<string, ParameterField>(StringComparer.Ordinal);
            var typeValues = new Dictionary<long, Dictionary<string, object>>();
            var rows = new List<PipeRecord>(pipes.Count);
            foreach (var pipe in pipes.OrderBy(p => RevitCompat.Id(p.Id)))
            {
                var row = new PipeRecord();
                var type = document.GetElement(pipe.GetTypeId()) as ElementType;
                row.Values["ElementId"] = RevitCompat.Id(pipe.Id).ToString(CultureInfo.InvariantCulture);
                row.Values["Family"] = type == null ? "" : type.FamilyName;
                row.Values["Type"] = type == null ? "" : type.Name;
                var length = pipe.get_Parameter(BuiltInParameter.CURVE_ELEM_LENGTH);
                if (length == null || !length.HasValue)
                    throw new InvalidOperationException("A pipe has no length parameter: " + RevitCompat.Id(pipe.Id).ToString(CultureInfo.InvariantCulture));
                row.Values["Length"] = UnitUtils.ConvertFromInternalUnits(length.AsDouble(), UnitTypeId.Meters);
                row.Values["Diameter"] = UnitUtils.ConvertFromInternalUnits(pipe.Diameter, UnitTypeId.Millimeters);
                row.Values["SystemName"] = Text(pipe.get_Parameter(BuiltInParameter.RBS_SYSTEM_NAME_PARAM), document);
                row.Values["SystemType"] = Text(pipe.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM), document);
                row.Values["Size"] = Text(pipe.get_Parameter(BuiltInParameter.RBS_CALCULATED_SIZE), document);
                row.Values["Level"] = pipe.ReferenceLevel == null ? "" : pipe.ReferenceLevel.Name;
                row.Values["Mark"] = Text(pipe.get_Parameter(BuiltInParameter.ALL_MODEL_MARK), document);
                row.Values["Comments"] = Text(pipe.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS), document);
                ReadParameters(pipe, "Instance", document, row.Values, custom);
                if (type != null)
                {
                    Dictionary<string, object> values;
                    if (!typeValues.TryGetValue(RevitCompat.Id(type.Id), out values))
                    {
                        values = new Dictionary<string, object>(StringComparer.Ordinal);
                        ReadParameters(type, "Type", document, values, custom);
                        typeValues.Add(RevitCompat.Id(type.Id), values);
                    }
                    foreach (var item in values) row.Values[item.Key] = item.Value;
                }
                rows.Add(row);
            }
            // Different project parameters can share the same display name.
            foreach (var duplicates in custom.Values.GroupBy(f => f.Field.Header).Where(g => g.Count() > 1))
                foreach (var field in duplicates) field.Field.Header += " {" + field.Key + "}";
            fields.AddRange(custom.Values.Select(f => f.Field).OrderBy(f => f.Header, StringComparer.CurrentCultureIgnoreCase));
            return new PipeSnapshot { Records = rows, Fields = fields, ScopeLabel = scopeLabel };
        }

        private static void ReadParameters(Element element, string source, Document document,
            Dictionary<string, object> values, Dictionary<string, ParameterField> fields)
        {
            foreach (Parameter parameter in element.Parameters)
            {
                if (parameter.Definition == null || parameter.StorageType == StorageType.None) continue;
                if (source == "Instance" && MappedParameters.Contains(RevitCompat.Id(parameter.Id))) continue;
                var key = source + ":" + (parameter.IsShared ? parameter.GUID.ToString("D") : RevitCompat.Id(parameter.Id).ToString(CultureInfo.InvariantCulture));
                var numeric = parameter.StorageType == StorageType.Double || parameter.StorageType == StorageType.Integer;
                var measured = parameter.StorageType == StorageType.Double && UnitUtils.IsMeasurableSpec(parameter.Definition.GetDataType());
                ForgeTypeId unit = measured ? parameter.GetUnitTypeId() : null;
                if (!fields.ContainsKey(key))
                {
                    var suffix = measured ? " (" + LabelUtils.GetLabelForUnit(unit) + ")" : "";
                    fields.Add(key, new ParameterField
                    {
                        Key = key,
                        Field = new FieldDefinition { Key = key, Header = parameter.Definition.Name + suffix + " [" + source + "]", IsNumeric = numeric }
                    });
                }
                if (!parameter.HasValue) { values[key] = null; continue; }
                if (parameter.StorageType == StorageType.Double)
                    values[key] = measured ? UnitUtils.ConvertFromInternalUnits(parameter.AsDouble(), unit) : parameter.AsDouble();
                else if (parameter.StorageType == StorageType.Integer) values[key] = parameter.AsInteger();
                else values[key] = Text(parameter, document);
            }
        }

        private static string Text(Parameter parameter, Document document)
        {
            if (parameter == null || !parameter.HasValue) return "";
            if (parameter.StorageType == StorageType.String) return parameter.AsString() ?? "";
            if (parameter.StorageType == StorageType.ElementId)
            {
                var id = parameter.AsElementId();
                var element = id == ElementId.InvalidElementId ? null : document.GetElement(id);
                return element == null ? parameter.AsValueString() ?? "" : element.Name;
            }
            return parameter.AsValueString() ?? "";
        }
    }
}
