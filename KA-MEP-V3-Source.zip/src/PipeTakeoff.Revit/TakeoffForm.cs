using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using PipeTakeoff.Core;

namespace PipeTakeoff.Revit
{
    /// <summary>Edits a takeoff from detached data; this form never accesses the Revit document.</summary>
    public class TakeoffForm : Form
    {
        private readonly bool isDuct;
        private readonly bool isElectrical;
        private readonly bool cableTray;
        private readonly IList<PipeRecord> records;
        private readonly IList<FieldDefinition> fields;
        private readonly CheckedListBox columns = new CheckedListBox();
        private readonly DataGridView filterGrid = new DataGridView();
        private readonly DataGridView summaryGrid = new DataGridView();
        private readonly ComboBox match = new ComboBox();
        private readonly CheckBox groupSystem = new CheckBox();
        private readonly CheckBox groupFamily = new CheckBox();
        private readonly CheckBox groupType = new CheckBox();
        private readonly Label previewStatus = new Label();
        private readonly Label selectionStatus = new Label();
        private readonly Button exportButton = new Button();
        private readonly CheckBox includeFittings = new CheckBox();
        private Label countMetric;
        private Label lengthMetric;
        private Label thirdMetric;
        private Label fourthMetric;
        private bool loading = true;

        public TakeoffOptions Options { get; private set; }
        public List<PipeRecord> FilteredRecords { get; private set; }
        public bool IncludesDuctFittings { get { return isDuct && includeFittings.Checked; } }
        public bool IncludesElectricalFittings { get { return isElectrical && includeFittings.Checked; } }

        private string TakeoffName { get { return isElectrical ? (cableTray ? "Cable Tray Takeoff" : "Conduit Takeoff") : (isDuct ? "Duct Takeoff" : "Pipe Takeoff"); } }
        private string SystemLabel { get { return isElectrical ? "Service type" : (isDuct ? "Duct system" : "Piping system"); } }

        public TakeoffForm(IList<PipeRecord> records, IList<FieldDefinition> fields, string scopeLabel)
            : this(records, fields, scopeLabel, false) { }

        protected TakeoffForm(IList<PipeRecord> records, IList<FieldDefinition> fields, string scopeLabel, bool isDuct)
            : this(records, fields, scopeLabel, isDuct, false, false) { }

        protected TakeoffForm(IList<PipeRecord> records, IList<FieldDefinition> fields, string scopeLabel,
            bool isDuct, bool isElectrical, bool cableTray)
        {
            if (records == null) throw new ArgumentNullException(nameof(records));
            if (fields == null) throw new ArgumentNullException(nameof(fields));
            this.isDuct = isDuct;
            this.isElectrical = isElectrical;
            this.cableTray = cableTray;
            this.records = records;
            this.fields = fields;
            Options = new TakeoffOptions();
            FilteredRecords = new List<PipeRecord>();

            KaTheme.ApplyForm(this, TakeoffName);
            BuildLayout(scopeLabel ?? "Current document");

            loading = false;
            RefreshPreview(false);
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            KaTheme.ClampToScreen(this);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Control | Keys.E))
            {
                if (exportButton.Enabled) exportButton.PerformClick();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void BuildLayout(string scopeLabel)
        {
            var root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill, Padding = new Padding(12, 12, 12, 0), ColumnCount = 1, RowCount = 3
            };
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            Controls.Add(root);
            root.Controls.Add(KaTheme.Header(TakeoffName,
                "Scope: " + scopeLabel + "   •   " + records.Count.ToString("N0") +
                (isElectrical ? (cableTray ? " cable tray / fitting elements available" : " conduit / fitting elements available")
                    : (isDuct ? " duct / fitting elements available" : " rigid pipes available")) +
                "   •   Length: m   /   Size: mm" + (isDuct ? "   /   Area: m²" : "")), 0, 0);

            var metrics = new TableLayoutPanel
            {
                Dock = DockStyle.Fill, AutoSize = true, ColumnCount = 4, RowCount = 1,
                Margin = new Padding(0, 0, 0, 10)
            };
            for (int i = 0; i < 4; i++) metrics.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            metrics.Controls.Add(KaTheme.Metric(isElectrical ? "Straight segments" : (isDuct ? "Ducts" : "Matching pipes"), out countMetric), 0, 0);
            metrics.Controls.Add(KaTheme.Metric("Length · m", out lengthMetric), 1, 0);
            metrics.Controls.Add(KaTheme.Metric(isDuct || isElectrical ? "Fittings" : "Summary groups", out thirdMetric), 2, 0);
            var lastMetric = KaTheme.Metric(isElectrical ? "Summary groups" : (isDuct ? "Known area · m²" : "Detail columns"), out fourthMetric);
            lastMetric.Margin = new Padding(0);
            metrics.Controls.Add(lastMetric, 3, 0);
            root.Controls.Add(metrics, 0, 1);

            // The workspace scrolls when Windows DPI scaling leaves less vertical space;
            // action buttons stay outside the scrolling region and remain reachable.
            var viewport = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Margin = new Padding(0) };
            var content = new TableLayoutPanel
            {
                Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1,
                Margin = new Padding(0), MinimumSize = new Size(820, 390)
            };
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 26F));
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 74F));
            viewport.Controls.Add(content);
            root.Controls.Add(viewport, 0, 2);
            var fieldPanel = BuildColumnsPanel();
            fieldPanel.Margin = new Padding(0, 0, 10, 0);
            content.Controls.Add(fieldPanel, 0, 0);

            var right = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, Margin = new Padding(0) };
            right.RowStyles.Add(new RowStyle(SizeType.Percent, 47F));
            right.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            right.RowStyles.Add(new RowStyle(SizeType.Percent, 53F));
            right.Controls.Add(BuildFiltersPanel(), 0, 0);
            var grouping = BuildGroupingPanel();
            grouping.Margin = new Padding(0, 8, 0, 8);
            right.Controls.Add(grouping, 0, 1);
            right.Controls.Add(BuildPreviewPanel(), 0, 2);
            content.Controls.Add(right, 1, 0);

            // Dock directly to the form: neither the workspace's minimum width nor a
            // long status message may push these actions beyond the visible client area.
            // Fixed table cells also prevent a wrapping FlowLayoutPanel from clipping
            // trailing actions when Windows/Revit scales the interface.
            var footer = new TableLayoutPanel
            {
                Name = "TakeoffActions", AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Dock = DockStyle.Bottom, ColumnCount = 3, RowCount = 2,
                Padding = new Padding(12, 8, 12, 12), Margin = new Padding(0), BackColor = Color.White
            };
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45F));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35F));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            footer.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            footer.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var refresh = NewButton("Refresh preview");
            refresh.Name = "RefreshPreview";
            refresh.Click += delegate { RefreshPreview(true); };
            exportButton.Name = "ExportExcel";
            exportButton.Text = "Export Excel (.xlsx)";
            KaTheme.StyleButton(exportButton, true);
            exportButton.Click += Export;
            var cancel = NewButton("Close");
            cancel.Name = "CloseTakeoff";
            cancel.DialogResult = DialogResult.Cancel;
            var actionButtons = new[] { exportButton, refresh, cancel };
            for (int index = 0; index < actionButtons.Length; index++)
            {
                var button = actionButtons[index];
                button.AutoSize = false;
                button.MinimumSize = Size.Empty;
                button.Size = new Size(120, Math.Max(40, Font.Height + 20));
                button.Padding = new Padding(4);
                button.Dock = DockStyle.Fill;
                button.Margin = new Padding(0, 0, index == actionButtons.Length - 1 ? 0 : 8, 0);
                button.TabIndex = index;
                footer.Controls.Add(button, index, 0);
            }
            selectionStatus.AutoSize = false;
            selectionStatus.AutoEllipsis = true;
            selectionStatus.Height = Math.Max(22, Font.Height + 6);
            selectionStatus.Dock = DockStyle.Fill;
            selectionStatus.ForeColor = KaTheme.Muted;
            selectionStatus.Margin = new Padding(0, 6, 0, 0);
            footer.Controls.Add(selectionStatus, 0, 1);
            footer.SetColumnSpan(selectionStatus, 3);
            Controls.Add(footer);
            root.BringToFront();
            AcceptButton = exportButton;
            CancelButton = cancel;
        }

        private Control BuildColumnsPanel()
        {
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3 };
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.Controls.Add(new Label
            {
                Text = "Select standard or additional parameters.",
                AutoSize = true,
                Dock = DockStyle.Fill,
                Margin = new Padding(0, 0, 0, 8)
            }, 0, 0);
            columns.Dock = DockStyle.Fill;
            columns.CheckOnClick = true;
            columns.IntegralHeight = false;
            columns.HorizontalScrollbar = true;
            columns.DisplayMember = "Header";
            columns.BorderStyle = BorderStyle.None;
            columns.BackColor = Color.White;
            columns.ForeColor = KaTheme.Ink;
            var defaults = new HashSet<string>(StringComparer.Ordinal)
            {
                "ElementId", "Family", "Type", "Length", "SystemName", "SystemType", "Size", "Diameter"
            };
            if (isDuct)
            {
                defaults = new HashSet<string>(StringComparer.Ordinal)
                {
                    "ElementId", "Category", "Shape", "Family", "Type", "SystemName", "Size",
                    "Length", "Area", "AreaSource", "FittingKind", "Angle"
                };
            }
            else if (isElectrical)
            {
                defaults = new HashSet<string>(StringComparer.Ordinal)
                {
                    "ElementId", "Category", "Family", "Type", "SystemName", "Level", "Size",
                    "SectionLabel", "Length", "FittingKind", "Angle"
                };
                if (cableTray) { defaults.Add("Width"); defaults.Add("Height"); }
                else defaults.Add("Diameter");
            }
            foreach (var field in fields) columns.Items.Add(field, defaults.Contains(field.Key));
            columns.ItemCheck += delegate(object sender, ItemCheckEventArgs e)
            {
                if (loading) return;
                int selected = columns.CheckedItems.Count;
                if (e.NewValue == CheckState.Checked && e.CurrentValue != CheckState.Checked) selected++;
                if (e.NewValue != CheckState.Checked && e.CurrentValue == CheckState.Checked) selected--;
                UpdateSelectionStatus(selected);
                MarkPreviewStale();
            };
            layout.Controls.Add(columns, 0, 1);
            var actions = NewFlowPanel();
            var all = NewButton("Select all");
            var none = NewButton("Clear");
            all.Click += delegate { SetAllColumns(true); };
            none.Click += delegate { SetAllColumns(false); };
            actions.Controls.Add(all);
            actions.Controls.Add(none);
            layout.Controls.Add(actions, 0, 2);
            return KaTheme.Section("01", "Excel columns", layout);
        }

        private Control BuildFiltersPanel()
        {
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3 };
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var toolbar = NewFlowPanel();
            toolbar.Controls.Add(new Label { Text = "Match", AutoSize = true, Margin = new Padding(0, 8, 5, 0) });
            match.DropDownStyle = ComboBoxStyle.DropDownList;
            match.FlatStyle = FlatStyle.Flat;
            match.Items.AddRange(new object[] { "All filters (AND)", "Any filter (OR)" });
            match.SelectedIndex = 0;
            match.Width = 155;
            match.Margin = new Padding(0, 3, 12, 3);
            match.SelectedIndexChanged += delegate { MarkPreviewStale(); };
            toolbar.Controls.Add(match);
            var add = NewButton("Add filter");
            var remove = NewButton("Remove selected");
            add.Enabled = fields.Count > 0;
            add.Click += delegate { AddFilter(); };
            remove.Click += delegate
            {
                foreach (var row in filterGrid.SelectedRows.Cast<DataGridViewRow>().OrderByDescending(r => r.Index).ToList())
                    filterGrid.Rows.Remove(row);
                MarkPreviewStale();
            };
            toolbar.Controls.Add(add);
            toolbar.Controls.Add(remove);
            layout.Controls.Add(toolbar, 0, 0);

            ConfigureGrid(filterGrid, false);
            filterGrid.EditMode = DataGridViewEditMode.EditOnEnter;
            filterGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            filterGrid.Columns.Add(new DataGridViewComboBoxColumn
            {
                Name = "Field",
                HeaderText = "Parameter",
                DataSource = fields.ToList(),
                DisplayMember = "Header",
                ValueMember = "Key",
                ValueType = typeof(string),
                DropDownWidth = 440,
                MaxDropDownItems = 16,
                FillWeight = 42,
                FlatStyle = FlatStyle.Flat,
                DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton
            });
            filterGrid.Columns.Add(new DataGridViewComboBoxColumn
            {
                Name = "Operator",
                HeaderText = "Condition",
                DataSource = OperatorChoice.All,
                DisplayMember = "Label",
                ValueMember = "Value",
                ValueType = typeof(FilterOperator),
                FillWeight = 29,
                FlatStyle = FlatStyle.Flat,
                DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton
            });
            filterGrid.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Value",
                HeaderText = "Value",
                FillWeight = 29,
                SortMode = DataGridViewColumnSortMode.NotSortable
            });
            filterGrid.CurrentCellDirtyStateChanged += delegate
            {
                if (filterGrid.IsCurrentCellDirty && filterGrid.CurrentCell is DataGridViewComboBoxCell)
                    filterGrid.CommitEdit(DataGridViewDataErrorContexts.Commit);
            };
            filterGrid.CellValueChanged += delegate(object sender, DataGridViewCellEventArgs e)
            {
                if (e.RowIndex >= 0) UpdateFilterRow(filterGrid.Rows[e.RowIndex]);
                MarkPreviewStale();
            };
            filterGrid.CellBeginEdit += delegate { MarkPreviewStale(); };
            filterGrid.RowsRemoved += delegate { MarkPreviewStale(); };
            filterGrid.DataError += delegate(object sender, DataGridViewDataErrorEventArgs e)
            {
                e.ThrowException = false;
                e.Cancel = true;
                if (e.RowIndex >= 0) filterGrid.Rows[e.RowIndex].ErrorText = "Select a valid parameter and condition.";
            };
            layout.Controls.Add(filterGrid, 0, 1);
            layout.Controls.Add(new Label
            {
                Text = "No filters = all scoped elements. Numeric filters use the units in the parameter name.",
                AutoSize = true,
                Dock = DockStyle.Fill,
                ForeColor = SystemColors.GrayText,
                Margin = new Padding(0, 5, 0, 0)
            }, 0, 2);
            return KaTheme.Section("02", "Parameter filters", layout);
        }

        private Control BuildGroupingPanel()
        {
            var layout = new TableLayoutPanel
            {
                AutoSize = true,
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 2,
                Margin = new Padding(0)
            };
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var choices = NewFlowPanel();
            choices.Dock = DockStyle.Fill;
            if (isDuct || isElectrical)
            {
                includeFittings.Text = "Include fittings";
                includeFittings.Checked = true;
                includeFittings.AutoSize = true;
                includeFittings.Margin = new Padding(0, 3, 18, 3);
                includeFittings.CheckedChanged += delegate { MarkPreviewStale(); };
                choices.Controls.Add(includeFittings);
            }
            if (isElectrical)
                choices.Controls.Add(new CheckBox { Text = cableTray ? "Size / connectors (mm)" : "Diameter / connectors (mm)", Checked = true, Enabled = false, AutoSize = true });
            else if (!isDuct)
                choices.Controls.Add(new CheckBox { Text = "Diameter (mm)", Checked = true, Enabled = false, AutoSize = true });
            groupSystem.Text = SystemLabel;
            groupSystem.Checked = true;
            groupFamily.Text = "Family";
            groupFamily.Checked = isElectrical;
            groupType.Text = "Type";
            groupType.Checked = isDuct || isElectrical;
            foreach (var check in new[] { groupSystem, groupFamily, groupType })
            {
                check.AutoSize = true;
                check.Margin = new Padding(3, 3, 14, 3);
                check.CheckedChanged += delegate { MarkPreviewStale(); };
                choices.Controls.Add(check);
            }
            layout.Controls.Add(choices, 0, 0);
            layout.Controls.Add(new Label
            {
                Text = isElectrical ? "Always separate category, size / connectors, fitting kind and angle. Fittings are counted; lengths include straight segments only."
                    : (isDuct ? "Always separate category, shape, size, fitting kind and angle. Optional groups above."
                    : "Same diameter combines automatically. Add system, family or type to separate groups."),
                AutoSize = true,
                Dock = DockStyle.Fill,
                Margin = new Padding(3, 5, 3, 0),
                ForeColor = SystemColors.GrayText
            }, 0, 1);
            return KaTheme.Section("03", "Summary grouping", layout, true);
        }

        private Control BuildPreviewPanel()
        {
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            previewStatus.AutoSize = true;
            previewStatus.Dock = DockStyle.Fill;
            previewStatus.Margin = new Padding(0, 0, 0, 8);
            layout.Controls.Add(previewStatus, 0, 0);
            ConfigureGrid(summaryGrid, true);
            if (isDuct || isElectrical)
            {
                AddSummaryColumn("Category", "Category", "Category", null);
                if (isDuct) AddSummaryColumn("Shape", "Shape", "Shape", null);
                AddSummaryColumn("Size", "Size (mm)", "Size", null);
                AddSummaryColumn("FittingKind", "Fitting", "FittingKind", null);
                AddSummaryColumn("Angle", "Angle (°)", "AngleDegrees", "0.##");
            }
            else AddSummaryColumn("Diameter", "Diameter (mm)", "DiameterMillimeters", "0.######");
            AddSummaryColumn("System", SystemLabel, "SystemName", null);
            AddSummaryColumn("Family", "Family", "Family", null);
            AddSummaryColumn("Type", "Type", "Type", null);
            AddSummaryColumn("Count", isDuct || isElectrical ? "Count" : "Pipe count", "Count", "N0");
            AddSummaryColumn("Length", "Total length (m)", "TotalLengthMeters", "N3");
            if (isDuct)
            {
                AddSummaryColumn("Area", "Known area (m²)", "TotalAreaSquareMeters", "N3");
                AddSummaryColumn("MissingArea", "Area missing", "MissingAreaCount", "N0");
            }
            if (isDuct || isElectrical)
            {
                summaryGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
                foreach (DataGridViewColumn column in summaryGrid.Columns)
                    column.Width = column.Name == "Size" || column.Name == "System" || column.Name == "Family" || column.Name == "Type" ? 140 : 96;
                summaryGrid.CellFormatting += delegate(object sender, DataGridViewCellFormattingEventArgs e)
                {
                    if (e.RowIndex < 0) return;
                    if (isElectrical)
                    {
                        var electricalRow = summaryGrid.Rows[e.RowIndex].DataBoundItem as ElectricalSummaryRow;
                        if (electricalRow != null && summaryGrid.Columns[e.ColumnIndex].Name == "Length" && IsElectricalFitting(electricalRow.Category))
                        {
                            e.Value = "—";
                            e.FormattingApplied = true;
                        }
                        return;
                    }
                    var row = summaryGrid.Rows[e.RowIndex].DataBoundItem as DuctSummaryRow;
                    if (row == null) return;
                    string column = summaryGrid.Columns[e.ColumnIndex].Name;
                    if ((column == "Length" && row.Category == "Duct Fitting") ||
                        (column == "Area" && row.MissingAreaCount == row.Count))
                    {
                        e.Value = "—";
                        e.FormattingApplied = true;
                    }
                };
            }
            layout.Controls.Add(summaryGrid, 0, 1);
            return KaTheme.Section("04", "Quantity preview", layout);
        }

        private static void ConfigureGrid(DataGridView grid, bool readOnly)
        {
            KaTheme.StyleGrid(grid, readOnly);
        }

        private void AddSummaryColumn(string name, string header, string property, string format)
        {
            var column = new DataGridViewTextBoxColumn
            {
                Name = name,
                HeaderText = header,
                DataPropertyName = property,
                SortMode = DataGridViewColumnSortMode.NotSortable
            };
            if (format != null)
            {
                column.DefaultCellStyle.Format = format;
                column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            }
            summaryGrid.Columns.Add(column);
        }

        private static FlowLayoutPanel NewFlowPanel()
        {
            return KaTheme.Flow();
        }

        private static Button NewButton(string text)
        {
            return KaTheme.Button(text);
        }

        private void SetAllColumns(bool value)
        {
            for (int index = 0; index < columns.Items.Count; index++) columns.SetItemChecked(index, value);
        }

        private void AddFilter()
        {
            var field = fields.FirstOrDefault(f => f.Key == "SystemName") ?? fields.FirstOrDefault();
            if (field == null) return;
            int index = filterGrid.Rows.Add(field.Key, field.IsNumeric ? FilterOperator.Equals : FilterOperator.Contains, "");
            filterGrid.ClearSelection();
            filterGrid.Rows[index].Selected = true;
            filterGrid.CurrentCell = filterGrid.Rows[index].Cells["Value"];
            filterGrid.BeginEdit(true);
            MarkPreviewStale();
        }

        private void UpdateFilterRow(DataGridViewRow row)
        {
            object selectedOperator = row.Cells["Operator"].Value;
            bool emptyCheck = selectedOperator is FilterOperator &&
                ((FilterOperator)selectedOperator == FilterOperator.IsEmpty || (FilterOperator)selectedOperator == FilterOperator.IsNotEmpty);
            row.Cells["Value"].ReadOnly = emptyCheck;
            row.Cells["Value"].Style.BackColor = emptyCheck ? SystemColors.Control : SystemColors.Window;
            var field = fields.FirstOrDefault(f => f.Key == Convert.ToString(row.Cells["Field"].Value));
            row.Cells["Value"].ToolTipText = emptyCheck ? "This condition does not use a value." :
                (field == null ? "" : "Enter a value for " + field.Header + ".");
            row.ErrorText = "";
        }

        private TakeoffOptions ReadOptions()
        {
            if (filterGrid.IsCurrentCellDirty) filterGrid.CommitEdit(DataGridViewDataErrorContexts.Commit);
            if (!filterGrid.EndEdit()) throw new ArgumentException("Finish editing the filter before continuing.");
            var options = new TakeoffOptions
            {
                Columns = columns.CheckedItems.Cast<FieldDefinition>().ToList(),
                Match = match.SelectedIndex == 1 ? FilterMatch.Any : FilterMatch.All,
                GroupBySystem = groupSystem.Checked,
                GroupByFamily = groupFamily.Checked,
                GroupByType = groupType.Checked
            };
            foreach (DataGridViewRow row in filterGrid.Rows)
            {
                var key = Convert.ToString(row.Cells["Field"].Value, CultureInfo.CurrentCulture);
                var field = fields.FirstOrDefault(f => f.Key == key);
                object op = row.Cells["Operator"].Value;
                if (field == null || !(op is FilterOperator))
                    throw new ArgumentException("Filter " + (row.Index + 1) + ": select a parameter and condition.");
                options.Filters.Add(new FilterRule
                {
                    Field = field,
                    Operator = (FilterOperator)op,
                    Value = Convert.ToString(row.Cells["Value"].Value, CultureInfo.CurrentCulture) ?? ""
                });
            }
            return options;
        }

        private bool RefreshPreview(bool showError)
        {
            try
            {
                var options = ReadOptions();
                TakeoffEngine.ValidateFilters(options);
                IEnumerable<PipeRecord> source = records;
                if (isDuct && !includeFittings.Checked)
                    source = source.Where(record => !string.Equals(Convert.ToString(record.Get("Category"), CultureInfo.InvariantCulture), "Duct Fitting", StringComparison.OrdinalIgnoreCase));
                if (isElectrical && !includeFittings.Checked)
                    source = source.Where(record => !IsElectricalFitting(Convert.ToString(record.Get("Category"), CultureInfo.InvariantCulture)));
                var filtered = TakeoffEngine.Filter(source, options);
                summaryGrid.Columns["System"].Visible = options.GroupBySystem;
                summaryGrid.Columns["Family"].Visible = options.GroupByFamily;
                summaryGrid.Columns["Type"].Visible = options.GroupByType;
                previewStatus.ForeColor = KaTheme.Muted;
                countMetric.ForeColor = lengthMetric.ForeColor = thirdMetric.ForeColor = fourthMetric.ForeColor = KaTheme.Navy;
                if (isElectrical)
                {
                    var summary = ElectricalTakeoffEngine.Summarize(filtered, options);
                    summaryGrid.DataSource = new BindingList<ElectricalSummaryRow>(summary);
                    int fittingCount = filtered.Count(record => IsElectricalFitting(Convert.ToString(record.Get("Category"), CultureInfo.InvariantCulture)));
                    countMetric.Text = (filtered.Count - fittingCount).ToString("N0");
                    lengthMetric.Text = summary.Sum(row => row.TotalLengthMeters).ToString("N3");
                    thirdMetric.Text = fittingCount.ToString("N0");
                    fourthMetric.Text = summary.Count.ToString("N0");
                    previewStatus.Text = summary.Count.ToString("N0") + " groups • " + filtered.Count.ToString("N0") +
                        " matching elements. Straight lengths in metres; fittings counted separately.";
                }
                else if (isDuct)
                {
                    var summary = DuctTakeoffEngine.Summarize(filtered, options);
                    summaryGrid.DataSource = new BindingList<DuctSummaryRow>(summary);
                    int fittingCount = filtered.Count(record => string.Equals(Convert.ToString(record.Get("Category"), CultureInfo.InvariantCulture), "Duct Fitting", StringComparison.OrdinalIgnoreCase));
                    int missingArea = summary.Sum(row => row.MissingAreaCount);
                    countMetric.Text = (filtered.Count - fittingCount).ToString("N0");
                    thirdMetric.Text = fittingCount.ToString("N0");
                    fourthMetric.Text = filtered.Count > 0 && missingArea == filtered.Count
                        ? "—" : summary.Sum(row => row.TotalAreaSquareMeters).ToString("N3");
                    lengthMetric.Text = summary.Sum(row => row.TotalLengthMeters).ToString("N3");
                    previewStatus.Text = summary.Count.ToString("N0") + " groups • " + filtered.Count.ToString("N0") + " matching elements. " +
                        (missingArea > 0 ? "AREA INCOMPLETE: " + missingArea.ToString("N0") + " elements have no reliable area. Review Area Source in Excel."
                        : "Area available for all matching elements. Review Area Source in Excel.");
                    if (missingArea > 0)
                    {
                        previewStatus.ForeColor = KaTheme.Warning;
                        fourthMetric.ForeColor = KaTheme.Warning;
                    }
                }
                else
                {
                    var summary = TakeoffEngine.Summarize(filtered, options);
                    summaryGrid.DataSource = new BindingList<SummaryRow>(summary);
                    countMetric.Text = filtered.Count.ToString("N0");
                    lengthMetric.Text = filtered.Sum(record => record.LengthMeters).ToString("N3");
                    thirdMetric.Text = summary.Count.ToString("N0");
                    fourthMetric.Text = columns.CheckedItems.Count.ToString("N0");
                    previewStatus.Text = "Rigid pipes only. Fittings, accessories, insulation, flex pipes and linked models are excluded.";
                }
                Options = options;
                FilteredRecords = filtered;
                UpdateSelectionStatus(columns.CheckedItems.Count);
                if (filtered.Count == 0) selectionStatus.Text = "No matching elements. Adjust the filters to export.";
                return true;
            }
            catch (ArgumentException ex)
            {
                previewStatus.ForeColor = Color.Firebrick;
                previewStatus.Text = "Preview needs correction: " + ex.Message;
                if (showError) MessageBox.Show(this, ex.Message, "KA MEP - Check filters", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

        private void UpdateSelectionStatus(int selected)
        {
            selectionStatus.Text = selected > 0
                ? selected.ToString(CultureInfo.CurrentCulture) + " detail columns • Excel includes details and a grouped summary."
                : "Select at least one detail column to export.";
            // A stale preview may contain zero matches, so only disable for missing columns or an empty source.
            // Export always refreshes the current filters before deciding whether there are rows to export.
            exportButton.Enabled = selected > 0 && records.Count > 0;
        }

        private static bool IsElectricalFitting(string category)
        {
            return string.Equals(category, "Cable Tray Fitting", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(category, "Conduit Fitting", StringComparison.OrdinalIgnoreCase);
        }

        private void MarkPreviewStale()
        {
            if (loading) return;
            previewStatus.ForeColor = KaTheme.Warning;
            previewStatus.Text = "Settings changed • Refresh preview to recalculate quantities. Export always recalculates.";
            countMetric.Text = lengthMetric.Text = thirdMetric.Text = fourthMetric.Text = "—";
            summaryGrid.DataSource = null;
        }

        private void Export(object sender, EventArgs e)
        {
            if (!RefreshPreview(true)) return;
            if (Options.Columns.Count == 0)
            {
                MessageBox.Show(this, "Select at least one detail column.", "KA MEP - Nothing to export", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (FilteredRecords.Count == 0)
            {
                MessageBox.Show(this, "No elements match the current filters. Adjust or remove filters before exporting.",
                    "KA MEP - Nothing to export", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            DialogResult = DialogResult.OK;
            Close();
        }

        private sealed class OperatorChoice
        {
            public FilterOperator Value { get; set; }
            public string Label { get; set; }

            public static List<OperatorChoice> All
            {
                get
                {
                    return new List<OperatorChoice>
                    {
                        Create(FilterOperator.Equals, "Equals"),
                        Create(FilterOperator.NotEquals, "Does not equal"),
                        Create(FilterOperator.Contains, "Contains"),
                        Create(FilterOperator.DoesNotContain, "Does not contain"),
                        Create(FilterOperator.GreaterThan, "Greater than (>)"),
                        Create(FilterOperator.GreaterOrEqual, "At least (>=)"),
                        Create(FilterOperator.LessThan, "Less than (<)"),
                        Create(FilterOperator.LessOrEqual, "At most (<=)"),
                        Create(FilterOperator.IsEmpty, "Is empty"),
                        Create(FilterOperator.IsNotEmpty, "Is not empty")
                    };
                }
            }

            private static OperatorChoice Create(FilterOperator value, string label)
            {
                return new OperatorChoice { Value = value, Label = label };
            }
        }
    }
}
