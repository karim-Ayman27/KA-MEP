using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using PipeTakeoff.Core;
using Room = Autodesk.Revit.DB.Architecture.Room;
using Space = Autodesk.Revit.DB.Mechanical.Space;

namespace PipeTakeoff.Revit
{
    /// <summary>Reads host MEP Spaces and actual Floor/Ceiling faces on Revit's API thread.
    /// No transaction, temporary view, parameter write or analytical-height fallback is used.</summary>
    public static class SpaceTakeoffReader
    {
        private const double MetresPerFoot = 0.3048;
        private const int MaximumSpaces = 5000;
        private const int MaximumTriangles = 250000;
        private const int MaximumSamples = 256;

        internal sealed class SourceDocument
        {
            internal Document Document;
            internal Transform Placement;
            internal Phase Phase;
            internal long LinkId;
            internal string Label;
        }

        private sealed class SpaceWork
        {
            internal Space Space;
            internal SpaceTakeoffRow Row;
            internal List<XYZ> Samples = new List<XYZ>();
            internal List<XYZ> RoomProbePoints = new List<XYZ>();
            internal bool SamplingComplete = true;
        }

        private sealed class Envelope
        {
            internal double MinX = double.PositiveInfinity, MinY = double.PositiveInfinity, MinZ = double.PositiveInfinity;
            internal double MaxX = double.NegativeInfinity, MaxY = double.NegativeInfinity, MaxZ = double.NegativeInfinity;
            internal bool HasPoints { get { return !double.IsInfinity(MinX); } }
            internal void Add(XYZ point)
            {
                MinX = Math.Min(MinX, point.X); MinY = Math.Min(MinY, point.Y); MinZ = Math.Min(MinZ, point.Z);
                MaxX = Math.Max(MaxX, point.X); MaxY = Math.Max(MaxY, point.Y); MaxZ = Math.Max(MaxZ, point.Z);
            }
            internal bool Overlaps(Envelope other)
            {
                const double epsilon = 0.01 / MetresPerFoot;
                return HasPoints && other.HasPoints && MinX <= other.MaxX + epsilon && MaxX >= other.MinX - epsilon &&
                    MinY <= other.MaxY + epsilon && MaxY >= other.MinY - epsilon && MinZ <= other.MaxZ + epsilon && MaxZ >= other.MinZ - epsilon;
            }
        }

        public static IList<SpacePhaseOption> GetPhases(Document document)
        {
            if (document == null) throw new ArgumentNullException(nameof(document));
            return document.Phases.Cast<Phase>().Select(phase => new SpacePhaseOption { Id = RevitCompat.Id(phase.Id), Name = phase.Name }).ToList();
        }

        public static IList<SpaceLinkOption> GetLinks(Document document)
        {
            if (document == null) throw new ArgumentNullException(nameof(document));
            using (var collector = new FilteredElementCollector(document))
                return collector.OfClass(typeof(RevitLinkInstance)).Cast<RevitLinkInstance>()
                    .Where(link => link.GetLinkDocument() != null && IsPrimary(link))
                    .Select(link => new SpaceLinkOption { Id = RevitCompat.Id(link.Id), IsLoaded = true,
                        Name = link.GetLinkDocument().Title + " [link " + RevitCompat.Id(link.Id).ToString(CultureInfo.InvariantCulture) + "]" })
                    .OrderBy(link => link.Name, StringComparer.CurrentCultureIgnoreCase).ToList();
        }

        public static long DefaultPhaseId(Document document)
        {
            if (document == null) throw new ArgumentNullException(nameof(document));
            var parameter = document.ActiveView == null ? null : document.ActiveView.get_Parameter(BuiltInParameter.VIEW_PHASE);
            var phase = parameter == null ? null : document.GetElement(parameter.AsElementId()) as Phase;
            if (phase == null) phase = document.Phases.Cast<Phase>().LastOrDefault();
            if (phase == null) throw new InvalidOperationException("This project has no phase to use for Space takeoff.");
            return RevitCompat.Id(phase.Id);
        }

        public static SpaceTakeoffSnapshot Read(UIDocument uiDocument, SpaceTakeoffOptions options)
        {
            if (uiDocument == null) throw new ArgumentNullException(nameof(uiDocument));
            if (options == null) throw new ArgumentNullException(nameof(options));
            options = options.Copy(); options.Validate();
            var document = uiDocument.Document;
            if (document.IsFamilyDocument) throw new InvalidOperationException("Open a project containing MEP Spaces.");
            if (options.PhaseId < 0) options.PhaseId = DefaultPhaseId(document);
            var phase = document.GetElement(RevitCompat.ElementId(options.PhaseId)) as Phase;
            if (phase == null) throw new InvalidOperationException("The selected phase is unavailable. Reopen the tool and choose a project phase.");
            var snapshot = new SpaceTakeoffSnapshot
            {
                ProjectTitle = document.Title, RevitVersion = document.Application.VersionName,
                Release = KAMEP.Branding.ReleaseIdentity.Display, ScannedAt = DateTime.Now, Options = options,
                ScopeLabel = ScopeLabel(document, options) + " | Phase: " + phase.Name
            };
            snapshot.Notes.Add("Spaces are read from the current document. Areas are Revit Space areas in m². Heights are sampled vertical distances between physical floor-top and ceiling/slab-bottom faces in metres.");
            snapshot.Notes.Add("A single clear height is available only for complete, consistent sampled results. Min/max are sampled values, not guaranteed extrema over every point of the room. Beams, roofs, ducts and imported/direct-shape geometry are not clearance surfaces.");
            snapshot.Notes.Add("Only main-model and primary design-option geometry is included. Hidden geometry can still provide a physical floor or ceiling; view scope filters Spaces, not the source surfaces.");
            var spaces = CollectSpaces(uiDocument, options, phase, snapshot);
            if (spaces.Count > MaximumSpaces) throw new InvalidOperationException("This scope contains more than " + MaximumSpaces + " Spaces. Use a smaller view or selection.");
            var work = spaces.Select(space => PrepareSpace(space, phase, options)).ToList();
            snapshot.Rows.AddRange(work.Select(item => item.Row));
            var measurable = work.Where(item => item.Samples.Count > 0).ToList();
            if (work.Count == 0) return snapshot;

            bool complete = true;
            var sources = ReadSources(document, phase, options, snapshot, ref complete);
            bool sourceScopeComplete = complete;
            var searchEnvelope = new Envelope();
            foreach (var item in measurable)
            {
                double baseZ = item.Row.BaseElevationMeters.Value / MetresPerFoot;
                foreach (var sample in item.Samples)
                {
                    searchEnvelope.Add(new XYZ(sample.X, sample.Y, baseZ - options.FloorSearchToleranceMeters / MetresPerFoot));
                    searchEnvelope.Add(new XYZ(sample.X, sample.Y, baseZ + (options.MaximumHeightMeters + options.FloorSearchToleranceMeters) / MetresPerFoot));
                }
            }
            var triangles = measurable.Count == 0 ? new List<SpaceSurfaceTriangle>() : ReadSurfaces(sources, searchEnvelope, snapshot, ref complete);
            snapshot.IsComplete = complete;
            if (triangles.Count == 0) snapshot.Notes.Add("No usable Floor/Ceiling faces intersect this Space scope in the chosen geometry sources and phase.");
            var index = new SpaceSurfaceIndex(triangles);
            foreach (var item in measurable)
            {
                try
                {
                    int number = 0;
                    foreach (var point in item.Samples)
                    {
                        var sample = SpaceHeightEngine.MeasureSample(index, point.X * MetresPerFoot, point.Y * MetresPerFoot,
                            item.Row.BaseElevationMeters.Value, options);
                        // A legitimate positive Space base offset must not replace the
                        // physical floor or prevent checking its enclosing Space.
                        double containmentZ = sample.FloorElevationMeters.HasValue
                            ? Math.Max(sample.FloorElevationMeters.Value + .01, item.Row.BaseElevationMeters.Value + .01) : 0;
                        if (sample.FloorElevationMeters.HasValue && sample.Status == SpaceMeasurementStatus.Measured &&
                            !item.Space.IsPointInSpace(new XYZ(point.X, point.Y, containmentZ / MetresPerFoot)))
                        {
                            sample.HeightMeters = null;
                            sample.Status = SpaceMeasurementStatus.NeedsReview;
                            sample.Notes = "The chosen floor surface does not lead into this Space at the sample point; check analytical base offsets and overlapping levels.";
                        }
                        sample.SampleNumber = ++number;
                        item.Row.Samples.Add(sample);
                    }
                    SpaceHeightEngine.Aggregate(item.Row, options, complete && item.SamplingComplete);
                }
                catch (Autodesk.Revit.Exceptions.OperationCanceledException) { throw; }
                catch (Exception ex)
                {
                    item.Row.ClearHeightMeters = null;
                    item.Row.Status = SpaceMeasurementStatus.GeometryUnavailable;
                    item.Row.Notes.Add("Measurement could not be completed: " + ex.Message);
                    snapshot.IsComplete = false;
                }
            }
            // Room identity is independent of a successful height result, so a room
            // can still support door/window takeoff when its ceiling is unavailable.
            foreach (var item in work)
            {
                try { MatchRoom(item, sources, phase); }
                catch (Autodesk.Revit.Exceptions.OperationCanceledException) { throw; }
                catch (Exception ex)
                {
                    item.Row.Notes.Add("Architectural Room association could not be completed: " + ex.Message);
                }
            }
            snapshot.OpeningScan = SpaceOpeningReader.Read(sources.Select(source => new SpaceOpeningSourceContext
            {
                Document = source.Document, Phase = source.Phase, Placement = source.Placement, LinkId = source.LinkId
            }), snapshot.Rows, sourceScopeComplete);
            snapshot.Notes.Add("Door/window areas are nominal width × height, not net glazing or measured frame/leaf geometry. Shared openings count once for each associated room; unique exported totals deduplicate source elements and link placements.");
            if (!snapshot.OpeningScan.Complete)
                snapshot.Notes.Add("Opening association or collection is incomplete. Known records are retained; unavailable counts/areas must not be interpreted as zero.");
            if (!complete) snapshot.Notes.Add("Some selected source geometry could not be read. Available sample values are retained for review, but no complete single-height claim is made from this partial scan.");
            return snapshot;
        }

        private static List<Space> CollectSpaces(UIDocument uiDocument, SpaceTakeoffOptions options, Phase phase, SpaceTakeoffSnapshot snapshot)
        {
            var document = uiDocument.Document;
            List<Space> candidates;
            if (options.Scope == SpaceTakeoffScope.Selection)
                candidates = uiDocument.Selection.GetElementIds().Select(document.GetElement).OfType<Space>().ToList();
            else
            {
                if (options.Scope == SpaceTakeoffScope.ActiveView && !FilteredElementCollector.IsViewValidForElementIteration(document, document.ActiveView.Id))
                    throw new InvalidOperationException("The active view cannot collect Spaces. Choose model scope or select Space elements.");
                using (var collector = options.Scope == SpaceTakeoffScope.ActiveView
                    ? new FilteredElementCollector(document, document.ActiveView.Id) : new FilteredElementCollector(document))
                    candidates = collector.OfCategory(BuiltInCategory.OST_MEPSpaces).WhereElementIsNotElementType().OfType<Space>().ToList();
            }
            int otherPhase = 0, otherOption = 0;
            var result = new List<Space>();
            foreach (var space in candidates)
            {
                if (!IsPrimary(space)) { otherOption++; continue; }
                if (SpatialPhaseId(space) != RevitCompat.Id(phase.Id)) { otherPhase++; continue; }
                result.Add(space);
            }
            if (otherPhase > 0) snapshot.Notes.Add(otherPhase + " Spaces outside the selected phase were excluded.");
            if (otherOption > 0) snapshot.Notes.Add(otherOption + " Spaces in non-primary design options were excluded.");
            return result.OrderBy(space => space.Number, StringComparer.CurrentCultureIgnoreCase).ThenBy(space => RevitCompat.Id(space.Id)).ToList();
        }

        private static SpaceWork PrepareSpace(Space space, Phase phase, SpaceTakeoffOptions options)
        {
            var item = new SpaceWork { Space = space, Row = new SpaceTakeoffRow
            {
                SpaceId = RevitCompat.Id(space.Id), SpaceUniqueId = space.UniqueId,
                SpaceNumber = space.Number ?? "", SpaceName = ParameterText(space, BuiltInParameter.ROOM_NAME),
                PhaseName = phase.Name, LevelName = space.Level == null ? "" : space.Level.Name
            } };
            var row = item.Row;
            try
            {
                var location = space.Location as LocationPoint;
                if (location == null) { row.Status = SpaceMeasurementStatus.Unplaced; row.Notes.Add("The Space has no placement point."); return item; }
                double area = space.Area;
                row.AreaSquareMeters = area * MetresPerFoot * MetresPerFoot;
                if (area <= 1e-9) { row.Status = SpaceMeasurementStatus.NotEnclosed; row.Notes.Add("The Space has no positive enclosed area."); return item; }
                if (space.Level == null) throw new InvalidOperationException("The Space level is unavailable.");
                double baseZ = space.Level.ProjectElevation + space.BaseOffset;
                row.BaseElevationMeters = baseZ * MetresPerFoot;
                var bounds = space.get_BoundingBox(null);
                if (bounds == null) throw new InvalidOperationException("The Space bounding geometry is unavailable.");
                var envelope = BoxEnvelope(bounds, Transform.Identity);
                double topZ = envelope.MaxZ;
                var probeLevels = new[] { baseZ + 0.15 / MetresPerFoot, baseZ + 0.9 / MetresPerFoot,
                    (Math.Max(baseZ, envelope.MinZ) + topZ) / 2, envelope.MinZ + Math.Max(1e-5, (topZ - envelope.MinZ) * .1),
                    topZ - 0.15 / MetresPerFoot };
                var keys = new HashSet<string>(StringComparer.Ordinal);
                Action<double, double> add = (x, y) =>
                {
                    if (item.Samples.Count >= MaximumSamples) return;
                    string key = Math.Round(x * MetresPerFoot, 5).ToString("R", CultureInfo.InvariantCulture) + ":" +
                        Math.Round(y * MetresPerFoot, 5).ToString("R", CultureInfo.InvariantCulture);
                    if (keys.Contains(key)) return;
                    foreach (double z in probeLevels)
                    {
                        var point = new XYZ(x, y, z);
                        if (!space.IsPointInSpace(point)) continue;
                        // Height measurements need one XY column. Room attribution must
                        // inspect the other interior elevations too: architectural Room
                        // bases may differ, and tall Spaces can cross stacked Rooms.
                        if (keys.Add(key)) item.Samples.Add(point);
                        item.RoomProbePoints.Add(point);
                    }
                };
                add(location.Point.X, location.Point.Y);
                int density = options.SampleGridSize;
                for (int y = 0; y < density; y++)
                    for (int x = 0; x < density; x++)
                        add(envelope.MinX + (envelope.MaxX - envelope.MinX) * (x + .5) / density,
                            envelope.MinY + (envelope.MaxY - envelope.MinY) * (y + .5) / density);
                // Boundary-near points make narrow/concave wings less likely to disappear
                // between grid cells. IsPointInSpace rejects holes and the outside side.
                using (var boundaryOptions = new SpatialElementBoundaryOptions { SpatialElementBoundaryLocation = SpatialElementBoundaryLocation.Finish })
                {
                    var loops = space.GetBoundarySegments(boundaryOptions);
                    if (loops == null || loops.Count == 0) throw new InvalidOperationException("Space boundary loops are unavailable.");
                    int edges = 0;
                    foreach (var loop in loops)
                        foreach (var segment in loop)
                        {
                            if (++edges > 128) { item.SamplingComplete = false; continue; }
                            using (var curve = segment.GetCurve())
                            {
                                var mid = curve.Evaluate(.5, true);
                                var tangent = curve.ComputeDerivatives(.5, true).BasisX;
                                double length = Math.Sqrt(tangent.X * tangent.X + tangent.Y * tangent.Y);
                                if (length < 1e-9) continue;
                                foreach (double distance in new[] { .05 / MetresPerFoot, .2 / MetresPerFoot })
                                {
                                    double dx = -tangent.Y / length * distance, dy = tangent.X / length * distance;
                                    add(mid.X + dx, mid.Y + dy); add(mid.X - dx, mid.Y - dy);
                                }
                            }
                        }
                }
                if (item.Samples.Count == 0) throw new InvalidOperationException("No interior sample point passed Space.IsPointInSpace. Check Space enclosure, level and offsets.");
                if (!item.SamplingComplete || item.Samples.Count >= MaximumSamples)
                {
                    item.SamplingComplete = false;
                    row.Notes.Add("Complex Space sampling reached a boundary/sample limit; review the available sample range.");
                }
                row.Notes.Add("Interior sampling: " + item.Samples.Count + " points; " + density + "×" + density + " grid plus placement/boundary-near points. Analytical Space limits identify interior points only; they are not reported as physical height.");
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                row.Status = SpaceMeasurementStatus.GeometryUnavailable;
                row.Notes.Add(ex.Message);
                item.Samples.Clear(); item.SamplingComplete = false;
            }
            return item;
        }

        private static List<SourceDocument> ReadSources(Document document, Phase phase, SpaceTakeoffOptions options,
            SpaceTakeoffSnapshot snapshot, ref bool complete)
        {
            var sources = new List<SourceDocument>();
            if (options.IncludeHostGeometry) sources.Add(new SourceDocument { Document = document, Phase = phase,
                Placement = Transform.Identity, LinkId = -1, Label = document.Title + " / host" });
            if (!options.IncludeLinkedGeometry) return sources;
            List<RevitLinkInstance> links;
            using (var collector = new FilteredElementCollector(document)) links = collector.OfClass(typeof(RevitLinkInstance)).Cast<RevitLinkInstance>().ToList();
            if (options.SelectedLinkInstanceId >= 0)
            {
                var selected = links.SingleOrDefault(link => RevitCompat.Id(link.Id) == options.SelectedLinkInstanceId);
                if (selected == null || selected.GetLinkDocument() == null)
                    throw new InvalidOperationException("The selected architectural link is missing or unloaded. Load it or choose another link before scanning.");
                if (!IsPrimary(selected) || !ExistsInPhase(selected, phase.Id))
                    throw new InvalidOperationException("The selected link is not in the main/primary design option or does not exist in this phase.");
                links = new List<RevitLinkInstance> { selected };
            }
            foreach (var link in links)
            {
                try
                {
                    if (!IsPrimary(link) || !ExistsInPhase(link, phase.Id)) continue;
                    var linkedDocument = link.GetLinkDocument();
                    if (linkedDocument == null)
                    {
                        snapshot.Notes.Add("Unloaded link " + RevitCompat.Id(link.Id) + " is excluded from the explicit 'all loaded direct links' source scope.");
                        continue;
                    }
                    var type = document.GetElement(link.GetTypeId()) as RevitLinkType;
                    ElementId linkedPhaseId;
                    if (type == null || !type.GetPhaseMap().TryGetValue(phase.Id, out linkedPhaseId))
                        throw new InvalidOperationException("No phase mapping exists for host phase '" + phase.Name + "'.");
                    var linkedPhase = linkedDocument.GetElement(linkedPhaseId) as Phase;
                    if (linkedPhase == null) throw new InvalidOperationException("The mapped linked phase is unavailable.");
                    var source = new SourceDocument { Document = linkedDocument, Phase = linkedPhase,
                        Placement = link.GetTotalTransform(), LinkId = RevitCompat.Id(link.Id), Label = linkedDocument.Title + " / link " + RevitCompat.Id(link.Id) };
                    sources.Add(source);
                    snapshot.Notes.Add(source.Label + ": mapped phase '" + phase.Name + "' → '" + linkedPhase.Name + "'.");
                    using (var nested = new FilteredElementCollector(linkedDocument))
                    {
                        if (nested.OfClass(typeof(RevitLinkInstance)).Cast<RevitLinkInstance>().Any(n => IsPrimary(n) && ExistsInPhase(n, linkedPhase.Id)))
                        {
                            snapshot.Notes.Add(source.Label + " contains nested links, which are excluded from the explicit direct-link source scope. Load any required nested architectural/structural models directly in the host and include them before relying on this report.");
                        }
                    }
                }
                catch (Autodesk.Revit.Exceptions.OperationCanceledException) { throw; }
                catch (Exception ex)
                {
                    complete = false;
                    snapshot.Notes.Add("Link " + RevitCompat.Id(link.Id) + " could not be fully read: " + ex.Message);
                }
            }
            if (sources.Count == 0)
            {
                complete = false;
                snapshot.Notes.Add("No available geometry source matches the selected phase. Load the architectural Revit link or enable current-model geometry.");
            }
            return sources;
        }

        private static List<SpaceSurfaceTriangle> ReadSurfaces(IEnumerable<SourceDocument> sources, Envelope scope,
            SpaceTakeoffSnapshot snapshot, ref bool complete)
        {
            var triangles = new List<SpaceSurfaceTriangle>();
            int failures = 0, nonPlanar = 0;
            foreach (var source in sources)
            {
                List<HostObject> elements;
                try
                {
                    using (var collector = new FilteredElementCollector(source.Document))
                    using (var categories = new ElementMulticategoryFilter(new[] { BuiltInCategory.OST_Floors, BuiltInCategory.OST_Ceilings }))
                        elements = collector.WherePasses(categories).WhereElementIsNotElementType().OfType<HostObject>().ToList();
                }
                catch (Exception ex) { complete = false; snapshot.Notes.Add(source.Label + " surface collection failed: " + ex.Message); continue; }
                foreach (var element in elements)
                {
                    try
                    {
                        if (!IsPrimary(element) || !ExistsInPhase(element, source.Phase.Id)) continue;
                        var box = element.get_BoundingBox(null);
                        if (box != null && !scope.Overlaps(BoxEnvelope(box, source.Placement))) continue;
                        var identity = new SpaceSurfaceSource { DocumentTitle = source.Document.Title, LinkInstanceId = source.LinkId,
                            ElementId = RevitCompat.Id(element.Id), ElementName = element.Name ?? "" };
                        var pending = new List<SpaceSurfaceTriangle>();
                        if (element is Floor)
                        {
                            AddFaces(element, HostObjectUtils.GetTopFaces(element), source.Placement, SpaceSurfaceKind.FloorTop, identity, pending, ref nonPlanar);
                            AddFaces(element, HostObjectUtils.GetBottomFaces(element), source.Placement, SpaceSurfaceKind.SlabBottom, identity, pending, ref nonPlanar);
                        }
                        else if (element is Ceiling)
                            AddFaces(element, HostObjectUtils.GetBottomFaces(element), source.Placement, SpaceSurfaceKind.CeilingBottom, identity, pending, ref nonPlanar);
                        if (pending.Count == 0) throw new InvalidOperationException("No usable physical top/bottom faces were available.");
                        if (triangles.Count + pending.Count > MaximumTriangles)
                        {
                            complete = false;
                            snapshot.Notes.Add("Surface triangulation exceeded " + MaximumTriangles + " triangles. Use a smaller Space selection or view; available sample values require review.");
                            return triangles;
                        }
                        triangles.AddRange(pending);
                    }
                    catch (Autodesk.Revit.Exceptions.OperationCanceledException) { throw; }
                    catch (Exception ex)
                    {
                        complete = false; failures++;
                        if (failures <= 12) snapshot.Notes.Add(source.Label + " / element " + RevitCompat.Id(element.Id) + ": geometry unavailable — " + ex.Message);
                    }
                }
            }
            if (failures > 12) snapshot.Notes.Add((failures - 12) + " further surface-read failures occurred. All results are marked partial rather than assuming a ceiling is absent.");
            if (nonPlanar > 0)
            {
                complete = false;
                snapshot.Notes.Add(nonPlanar + " curved/non-planar source faces were triangulated. Their elevations are mesh approximations; review min/max samples rather than treating them as an exact constant height.");
            }
            snapshot.Notes.Add("Physical surface triangles read: " + triangles.Count + ".");
            return triangles;
        }

        private static void AddFaces(HostObject element, IList<Reference> references, Transform placement, SpaceSurfaceKind kind,
            SpaceSurfaceSource source, List<SpaceSurfaceTriangle> triangles, ref int nonPlanar)
        {
            if (references == null || references.Count == 0) throw new InvalidOperationException("The required host face references are missing.");
            foreach (var reference in references)
            {
                var face = element.GetGeometryObjectFromReference(reference) as Face;
                if (face == null) throw new InvalidOperationException("A physical face reference could not be resolved.");
                if (!(face is PlanarFace)) nonPlanar++;
                using (var mesh = face.Triangulate())
                {
                    if (mesh.NumTriangles > 100000) throw new InvalidOperationException("A single face exceeds the triangulation safety limit.");
                    for (int i = 0; i < mesh.NumTriangles; i++)
                    {
                        var triangle = mesh.get_Triangle(i);
                        triangles.Add(new SpaceSurfaceTriangle(Metric(placement.OfPoint(triangle.get_Vertex(0))),
                            Metric(placement.OfPoint(triangle.get_Vertex(1))), Metric(placement.OfPoint(triangle.get_Vertex(2))), kind, source));
                    }
                }
            }
        }

        private static void MatchRoom(SpaceWork item, IList<SourceDocument> sources, Phase hostPhase)
        {
            var row = item.Row;
            var matches = new Dictionary<string, Tuple<Room, SourceDocument>>(StringComparer.Ordinal);
            var related = item.Space.Room;
            if (related != null && IsPrimary(related) && related.Document.Equals(item.Space.Document) && SpatialPhaseId(related) == RevitCompat.Id(hostPhase.Id)
                && sources.Any(source => source.LinkId < 0))
            {
                SetRoom(row, related, -1, item.Space.Document.Title + " / host / related Room " + RevitCompat.Id(related.Id));
                return;
            }
            bool lookupFailed = false;
            foreach (var source in sources)
            {
                foreach (var point in item.RoomProbePoints)
                {
                    try
                    {
                        var local = source.Placement.Inverse.OfPoint(point);
                        var room = source.Document.GetRoomAtPoint(local, source.Phase);
                        if (room == null || !IsPrimary(room)) continue;
                        string key = source.LinkId.ToString(CultureInfo.InvariantCulture) + ":" + room.UniqueId;
                        matches[key] = Tuple.Create(room, source);
                    }
                    catch (Autodesk.Revit.Exceptions.OperationCanceledException) { throw; }
                    catch (Exception) { lookupFailed = true; }
                }
            }
            if (matches.Count == 1 && !lookupFailed)
            {
                var match = matches.Values.Single();
                SetRoom(row, match.Item1, match.Item2.LinkId, match.Item2.Label + " / Room " + RevitCompat.Id(match.Item1.Id) + " / mapped phase '" + match.Item2.Phase.Name + "'");
                return;
            }
            if (matches.Count > 1)
            {
                row.Notes.Add("Interior samples correspond to more than one architectural Room/link placement. Room name/number are left blank for review.");
                row.RoomIdentitySource = "Ambiguous room association";
            }
            else
            {
                row.RoomName = ParameterText(item.Space, BuiltInParameter.SPACE_ASSOC_ROOM_NAME);
                row.RoomNumber = ParameterText(item.Space, BuiltInParameter.SPACE_ASSOC_ROOM_NUMBER);
                if (row.RoomName.Length > 0 || row.RoomNumber.Length > 0)
                {
                    row.RoomIdentitySource = "Space associated-room parameters (not geometrically verified)";
                    row.Notes.Add("Associated Room text was read from Space parameters; a unique Room could not be verified in the chosen geometry sources and mapped phase.");
                }
                else row.Notes.Add("No associated architectural Room was found. Space name/number remain separate; Room fields are not replaced by Space fields.");
            }
            if (lookupFailed) row.Notes.Add("Some phase-specific architectural Room lookups failed.");
        }

        private static void SetRoom(SpaceTakeoffRow row, Room room, long linkId, string source)
        {
            row.RoomName = ParameterText(room, BuiltInParameter.ROOM_NAME);
            row.RoomNumber = room.Number ?? ""; row.RoomIdentitySource = source;
            row.RoomUniqueId = room.UniqueId;
            row.RoomSource = new SpaceSurfaceSource
            {
                DocumentTitle = room.Document.Title, LinkInstanceId = linkId,
                ElementId = RevitCompat.Id(room.Id), ElementName = row.RoomName
            };
        }

        private static long SpatialPhaseId(SpatialElement element)
        {
            var parameter = element.get_Parameter(BuiltInParameter.ROOM_PHASE_ID);
            var id = parameter != null && parameter.StorageType == StorageType.ElementId ? parameter.AsElementId() : element.CreatedPhaseId;
            return id == null ? -1 : RevitCompat.Id(id);
        }

        private static bool ExistsInPhase(Element element, ElementId phaseId)
        {
            var status = element.GetPhaseStatus(phaseId);
            return status == ElementOnPhaseStatus.Existing || status == ElementOnPhaseStatus.New ||
                (status == ElementOnPhaseStatus.None && element.CreatedPhaseId == ElementId.InvalidElementId && element.DemolishedPhaseId == ElementId.InvalidElementId);
        }
        private static bool IsPrimary(Element element) { return element.DesignOption == null || element.DesignOption.IsPrimary; }
        private static string ParameterText(Element element, BuiltInParameter id)
        {
            var parameter = element.get_Parameter(id);
            return parameter == null ? "" : (parameter.AsString() ?? "").Trim();
        }
        private static SpacePoint3 Metric(XYZ point) { return new SpacePoint3(point.X * MetresPerFoot, point.Y * MetresPerFoot, point.Z * MetresPerFoot); }
        private static Envelope BoxEnvelope(BoundingBoxXYZ box, Transform placement)
        {
            var result = new Envelope();
            foreach (double x in new[] { box.Min.X, box.Max.X })
                foreach (double y in new[] { box.Min.Y, box.Max.Y })
                    foreach (double z in new[] { box.Min.Z, box.Max.Z }) result.Add(placement.OfPoint(box.Transform.OfPoint(new XYZ(x, y, z))));
            return result;
        }
        private static string ScopeLabel(Document document, SpaceTakeoffOptions options)
        {
            string spaces = options.Scope == SpaceTakeoffScope.Selection ? "Selected host Spaces" : options.Scope == SpaceTakeoffScope.ActiveView
                ? "Host Spaces in view: " + document.ActiveView.Name : "All host Spaces";
            return spaces + " | Surfaces: " + (options.IncludeHostGeometry && options.IncludeLinkedGeometry ? "host + direct links"
                : options.IncludeLinkedGeometry ? "direct Revit links" : "current model") +
                (options.IncludeLinkedGeometry ? (options.SelectedLinkInstanceId < 0 ? " (all loaded)" : " (selected link " + options.SelectedLinkInstanceId.ToString(CultureInfo.InvariantCulture) + ")") : "");
        }
    }
}
