using System;
using System.Collections.Generic;
using System.Linq;
using PipeTakeoff.Core;

namespace PipeTakeoff.Revit
{
    public enum TagAssistantMode { CreateMissing, ArrangeExisting }
    public enum TagAssistantScope { Selection, ActiveView }
    public enum TagLeaderStyle { None, Straight, Elbow, Orthogonal }
    public enum TagTextOrientation { Horizontal, Vertical }

    public sealed class TagTypeOption
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string FamilyName { get; set; }
        public string TypeName { get; set; }
        public bool RotatesWithComponent { get; set; }
        public string FamilyDisplayName
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(FamilyName)) return FamilyName;
                var name = Name ?? string.Empty;
                int separator = name.IndexOf(" : ", StringComparison.Ordinal);
                return separator < 0 ? name : name.Substring(0, separator);
            }
        }
        public string TypeDisplayName
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(TypeName)) return TypeName;
                var name = Name ?? string.Empty;
                int separator = name.IndexOf(" : ", StringComparison.Ordinal);
                return separator < 0 ? name : name.Substring(separator + 3);
            }
        }
        public override string ToString() { return Name ?? string.Empty; }
    }

    public sealed class TagCategoryOption
    {
        public string Key { get; set; }
        public string Name { get; set; }
        public List<TagTypeOption> Types { get; set; } = new List<TagTypeOption>();
    }

    public sealed class TagAssistantCandidate
    {
        public string Key { get; set; }
        public string CategoryKey { get; set; }
        public string Label { get; set; }
        public long HostId { get; set; }
        public long ExistingTagId { get; set; }
        public bool IsSelected { get; set; }
        public TagPoint Anchor { get; set; }
        public TagPoint ExistingHead { get; set; }
        public double Width { get; set; }
        public double Height { get; set; }
        public TagTextOrientation Orientation { get; set; }
        public bool IsCurve { get; set; }
        /// <summary>Visible projected curve length in internal feet, when available.</summary>
        public double? CurveLengthInternal { get; set; }
        public TagRectangle? HostBounds { get; set; }
    }

    public sealed class TagAssistantSnapshot
    {
        public string ViewName { get; set; }
        public int ViewScale { get; set; }
        public bool HasSelection { get; set; }
        public bool CanCreateMissing { get; set; } = true;
        public bool NearHostAvailable { get; set; } = true;
        public string NearHostUnavailableReason { get; set; } = "";
        public TagRectangle? AllowedBounds { get; set; }
        public List<TagRectangle> ExistingTagObstacles { get; set; } = new List<TagRectangle>();
        public Dictionary<long, TagRectangle> ExistingTagBounds { get; set; } = new Dictionary<long, TagRectangle>();
        public List<TagCategoryOption> Categories { get; set; } = new List<TagCategoryOption>();
        public List<TagAssistantCandidate> Candidates { get; set; } = new List<TagAssistantCandidate>();
        public List<string> Notes { get; set; } = new List<string>();
    }

    public sealed class TagAssistantOptions
    {
        public TagAssistantMode Mode { get; set; } = TagAssistantMode.CreateMissing;
        public TagAssistantScope Scope { get; set; } = TagAssistantScope.Selection;
        public HashSet<string> EnabledCategoryKeys { get; set; } = new HashSet<string>(StringComparer.Ordinal);
        public Dictionary<string, long> SelectedTypeIds { get; set; } = new Dictionary<string, long>(StringComparer.Ordinal);
        public HashSet<string> ExcludedCandidateKeys { get; set; } = new HashSet<string>(StringComparer.Ordinal);
        public TagLayoutPattern Pattern { get; set; } = TagLayoutPattern.NearHost;
        public TagLayoutSide Side { get; set; } = TagLayoutSide.Positive;
        public double SpacingMm { get; set; } = 1.5;
        public double OffsetMm { get; set; } = 3;
        public double ShoulderMm { get; set; } = 2;
        public double MaximumDistanceMm { get; set; } = 20;
        public int MaximumTags { get; set; } = 50;
        public bool SkipShortCurves { get; set; } = true;
        public double MinimumCurveLengthMm { get; set; } = 5;
        public double AngleDegrees { get; set; } = 30;
        public double EstimatedWidthMm { get; set; } = 25;
        public double EstimatedHeightMm { get; set; } = 4;
        public int Columns { get; set; } = 3;
        public TagLeaderStyle LeaderStyle { get; set; } = TagLeaderStyle.Straight;
        public TagTextOrientation Orientation { get; set; } = TagTextOrientation.Horizontal;
        public bool PreserveExistingTypes { get; set; } = true;
        public bool PickOrigin { get; set; }
        public TagPoint? Origin { get; set; }
    }

    /// <summary>Detached UI data and view-plane layout adapter. All lengths are internal feet;
    /// settings use printed millimeters, converted once with the active view scale.</summary>
    public static class TagAssistantModel
    {
        public const int MaximumBatchSize = 500;
        public const string DefaultSelectionGuidance = "Default scope is Selected elements only. In mixed creation selections, fitting and flex categories start unchecked; enable them deliberately if needed.";
        private static readonly HashSet<string> DetailCategoryKeys = new HashSet<string>(StringComparer.Ordinal)
        {
            "OST_PipeFitting", "OST_DuctFitting", "OST_CableTrayFitting", "OST_ConduitFitting", "OST_FlexPipeCurves", "OST_FlexDuctCurves"
        };

        public static TagAssistantOptions CreateDefaults(TagAssistantSnapshot snapshot)
        {
            if (snapshot == null) throw new ArgumentNullException(nameof(snapshot));
            var options = new TagAssistantOptions();
            // Never turn an empty or unsupported selection into a whole-view creation batch.
            options.Scope = TagAssistantScope.Selection;
            var scope = snapshot.Candidates.Where(c => c.IsSelected).ToList();
            if (!scope.Any(c => c.ExistingTagId == 0) && scope.Any(c => c.ExistingTagId != 0)) options.Mode = TagAssistantMode.ArrangeExisting;
            var selectedCategories = new HashSet<string>(scope.Where(c => options.Mode == TagAssistantMode.ArrangeExisting ? c.ExistingTagId != 0 : c.ExistingTagId == 0)
                .Select(c => c.CategoryKey), StringComparer.Ordinal);
            if (options.Mode == TagAssistantMode.CreateMissing && selectedCategories.Any(key => !DetailCategoryKeys.Contains(key)))
                selectedCategories.ExceptWith(DetailCategoryKeys);
            foreach (var category in snapshot.Categories)
            {
                if (selectedCategories.Contains(category.Key)) options.EnabledCategoryKeys.Add(category.Key);
                if (category.Types.Count > 0) options.SelectedTypeIds[category.Key] = category.Types[0].Id;
            }
            return options;
        }

        public static List<TagAssistantCandidate> Candidates(TagAssistantSnapshot snapshot, TagAssistantOptions options)
        {
            return CandidatesForReview(snapshot, options).Where(c => CandidateExclusionReason(snapshot, options, c) == null).ToList();
        }

        /// <summary>Scope/category/mode matches before per-element exclusions and short-curve filtering.</summary>
        public static List<TagAssistantCandidate> CandidatesForReview(TagAssistantSnapshot snapshot, TagAssistantOptions options)
        {
            if (snapshot == null) throw new ArgumentNullException(nameof(snapshot));
            if (options == null) throw new ArgumentNullException(nameof(options));
            return snapshot.Candidates.Where(c => options.EnabledCategoryKeys.Contains(c.CategoryKey)
                && (options.Scope == TagAssistantScope.ActiveView || c.IsSelected)
                && (options.Mode == TagAssistantMode.ArrangeExisting ? c.ExistingTagId != 0 : c.ExistingTagId == 0))
                .OrderBy(c => c.Key, StringComparer.Ordinal).ToList();
        }

        /// <summary>Null means included; a reason identifies a deliberate filter, never a silent batch truncation.</summary>
        public static string CandidateExclusionReason(TagAssistantSnapshot snapshot, TagAssistantOptions options, TagAssistantCandidate candidate)
        {
            if (snapshot == null) throw new ArgumentNullException(nameof(snapshot));
            if (options == null) throw new ArgumentNullException(nameof(options));
            if (candidate == null) throw new ArgumentNullException(nameof(candidate));
            if (options.ExcludedCandidateKeys.Contains(candidate.Key)) return "Excluded in the Elements review.";
            if (options.Mode == TagAssistantMode.CreateMissing && options.SkipShortCurves && candidate.IsCurve && candidate.CurveLengthInternal.HasValue &&
                snapshot.ViewScale > 0 && !double.IsNaN(options.MinimumCurveLengthMm) && !double.IsInfinity(options.MinimumCurveLengthMm) &&
                candidate.CurveLengthInternal.Value < PaperToInternal(options.MinimumCurveLengthMm, snapshot.ViewScale))
                return "Short visible curve: below " + options.MinimumCurveLengthMm.ToString("0.##", System.Globalization.CultureInfo.CurrentCulture) + " paper mm.";
            return null;
        }

        public static double PaperToInternal(double millimeters, int scale)
        {
            if (scale <= 0) throw new ArgumentOutOfRangeException(nameof(scale));
            if (double.IsNaN(millimeters) || double.IsInfinity(millimeters)) throw new ArgumentOutOfRangeException(nameof(millimeters));
            return millimeters * scale / 304.8;
        }

        public static TagLayoutOptions BuildLayoutOptions(TagAssistantSnapshot snapshot, TagAssistantOptions options)
        {
            return new TagLayoutOptions
            {
                Pattern = options.Pattern, Side = options.Side,
                Spacing = PaperToInternal(options.SpacingMm, snapshot.ViewScale),
                Offset = PaperToInternal(options.OffsetMm, snapshot.ViewScale),
                Shoulder = PaperToInternal(options.ShoulderMm, snapshot.ViewScale),
                OrthogonalLeaders = options.LeaderStyle == TagLeaderStyle.Orthogonal,
                MaximumDistance = options.Pattern == TagLayoutPattern.NearHost ? PaperToInternal(options.MaximumDistanceMm, snapshot.ViewScale) : 20,
                AllowedBounds = options.Pattern == TagLayoutPattern.NearHost ? snapshot.AllowedBounds : null,
                AngleDegrees = options.AngleDegrees, Columns = options.Columns, Origin = options.Origin
            };
        }

        public static TagLayoutResult Preview(TagAssistantSnapshot snapshot, TagAssistantOptions options)
        {
            var candidates = Candidates(snapshot, options);
            if (candidates.Count > MaximumBatchSize) throw new InvalidOperationException("Select up to 500 elements per batch. Narrow the selection or categories.");
            if (options.MaximumTags < 1 || options.MaximumTags > MaximumBatchSize) throw new InvalidOperationException("Maximum tags must be between 1 and 500.");
            if (candidates.Count > options.MaximumTags) throw new InvalidOperationException("This batch has " + candidates.Count + " candidates, above your limit of " + options.MaximumTags + ". Uncheck elements or raise Maximum tags explicitly.");
            var items = new List<TagLayoutItem>();
            foreach (var candidate in candidates)
            {
                bool useExisting = candidate.ExistingTagId != 0 && options.PreserveExistingTypes && candidate.Width > 0 && candidate.Height > 0;
                double width = useExisting ? candidate.Width : PaperToInternal(options.EstimatedWidthMm, snapshot.ViewScale);
                double height = useExisting ? candidate.Height : PaperToInternal(options.EstimatedHeightMm, snapshot.ViewScale);
                var orientation = useExisting ? candidate.Orientation : TagTextOrientation.Horizontal;
                if (orientation != options.Orientation) { var swap = width; width = height; height = swap; }
                items.Add(new TagLayoutItem(candidate.Key, candidate.Anchor, width, height) { HostBounds = candidate.HostBounds });
            }
            var movingTags = new HashSet<long>(candidates.Where(c => c.ExistingTagId != 0).Select(c => c.ExistingTagId));
            var obstacles = snapshot.ExistingTagObstacles.Concat(snapshot.ExistingTagBounds.Where(x => !movingTags.Contains(x.Key)).Select(x => x.Value));
            return TagLayoutEngine.Arrange(items, BuildLayoutOptions(snapshot, options), obstacles);
        }

        public static List<string> Validate(TagAssistantSnapshot snapshot, TagAssistantOptions options)
        {
            var errors = new List<string>();
            if (snapshot == null || options == null) { errors.Add("Tag settings are unavailable."); return errors; }
            if (snapshot.ViewScale <= 0) errors.Add("The active view needs a valid drawing scale.");
            if (!Enum.IsDefined(typeof(TagAssistantMode), options.Mode) || !Enum.IsDefined(typeof(TagAssistantScope), options.Scope)) errors.Add("Choose a valid operation and scope.");
            if (!Enum.IsDefined(typeof(TagLeaderStyle), options.LeaderStyle) || !Enum.IsDefined(typeof(TagTextOrientation), options.Orientation)) errors.Add("Choose a valid leader style and text orientation.");
            Range(errors, options.SpacingMm, 0, 100, "Spacing");
            Range(errors, options.OffsetMm, 0, 500, "Offset");
            Range(errors, options.ShoulderMm, 0, 100, "Leader shoulder");
            Range(errors, options.EstimatedWidthMm, 0.5, 200, "Preview label width");
            Range(errors, options.EstimatedHeightMm, 0.5, 200, "Preview label height");
            Range(errors, options.MinimumCurveLengthMm, 0, 500, "Minimum curve length");
            if (options.MaximumTags < 1 || options.MaximumTags > MaximumBatchSize) errors.Add("Maximum tags must be between 1 and 500.");
            if (options.Mode == TagAssistantMode.CreateMissing && !snapshot.CanCreateMissing)
                errors.Add("Some existing tag references could not be read safely. Resolve the reported tags before creating missing tags; Arrange existing remains available.");
            if (options.Pattern == TagLayoutPattern.NearHost)
            {
                Range(errors, options.MaximumDistanceMm, 1, 100, "Maximum label-centre distance");
                if (options.PickOrigin || options.Origin.HasValue) errors.Add("Near elements uses each host as its origin. Turn off Pick origin or choose an alignment pattern.");
                if (!snapshot.NearHostAvailable) errors.Add(string.IsNullOrWhiteSpace(snapshot.NearHostUnavailableReason) ? "Near elements is unavailable for this view crop." : snapshot.NearHostUnavailableReason);
            }
            if (options.LeaderStyle == TagLeaderStyle.Elbow && options.ShoulderMm == 0) errors.Add("Use a leader shoulder greater than zero for elbow leaders.");
            var selected = Candidates(snapshot, options);
            if (selected.Count == 0) errors.Add("No eligible elements match this operation, scope and category selection.");
            if (selected.Count > MaximumBatchSize) errors.Add("Select up to 500 elements per batch. Narrow the selection or categories.");
            else if (selected.Count > options.MaximumTags) errors.Add("This batch has " + selected.Count + " candidates, above your limit of " + options.MaximumTags + ". Uncheck elements or raise Maximum tags explicitly.");
            if (options.Mode == TagAssistantMode.CreateMissing || !options.PreserveExistingTypes)
            {
                foreach (var key in selected.Select(c => c.CategoryKey).Distinct())
                {
                    var category = snapshot.Categories.FirstOrDefault(c => c.Key == key);
                    long typeId;
                    if (category == null || !options.SelectedTypeIds.TryGetValue(key, out typeId) || !category.Types.Any(t => t.Id == typeId))
                        errors.Add("Choose a loaded tag family/type for " + (category == null ? key : category.Name) + ". Load a matching tag family in Revit if none is listed.");
                }
            }
            if (errors.Count == 0)
            {
                // Estimated label bounds can be wider than the loaded family. A crowded
                // schematic does not prevent actual-size measurement before confirmation.
                try { Preview(snapshot, options); }
                catch (ArgumentException ex) { errors.Add(ex.Message); }
                catch (InvalidOperationException ex) { errors.Add(ex.Message); }
            }
            return errors;
        }

        private static void Range(List<string> errors, double value, double minimum, double maximum, string label)
        {
            if (double.IsNaN(value) || double.IsInfinity(value) || value < minimum || value > maximum)
                errors.Add(label + " must be between " + minimum + " and " + maximum + " paper mm.");
        }
    }
}
