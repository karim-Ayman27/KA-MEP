using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using PipeTakeoff.Core;
using TaskDialog = Autodesk.Revit.UI.TaskDialog;

namespace PipeTakeoff.Revit
{
    [Transaction(TransactionMode.Manual)]
    public sealed class ClashManagerCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData data, ref string message, ElementSet elements)
        {
            try
            {
                if (data.Application.ActiveUIDocument == null || data.Application.ActiveUIDocument.Document.IsFamilyDocument)
                {
                    TaskDialog.Show("KA MEP - Clash Manager", "Open a Revit project, then import an HTML clash report.");
                    return Result.Cancelled;
                }
                ClashManagerController.Open(data.Application);
                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = ex.Message; TaskDialog.Show("KA MEP - Clash Manager", ex.Message);
                return Result.Failed;
            }
        }
    }

    /// <summary>Modeless UI reads Revit only through this document-bound ExternalEvent.</summary>
    internal sealed class ClashManagerController : IExternalEventHandler
    {
        private enum Operation { None, Sources, Check, Focus, Export }
        private static ClashManagerController _current;
        private readonly Document _document;
        private readonly string _projectTitle, _revitVersion;
        private readonly ClashRevitService _service = new ClashRevitService();
        private readonly ClashManagerForm _form = new ClashManagerForm();
        private readonly Queue<ClashRecord> _queue = new Queue<ClashRecord>();
        private ExternalEvent _event;
        private ClashReport _report, _exportReport;
        private ClashCheckOptions _options;
        private ClashRecord _focusRow;
        private string _exportFilter, _cancelReason;
        private double _margin;
        private bool _isolate, _closed, _busy, _executing, _raised, _continuation, _cancel, _focusing;
        private long _revision, _batchRevision;
        private int _total, _completed;
        private Operation _pending;

        private ClashManagerController(UIApplication app)
        {
            _document = app.ActiveUIDocument.Document;
            _projectTitle = _document.Title; _revitVersion = app.Application.VersionName;
            try
            {
                _event = ExternalEvent.Create(this);
                _form.SetSources(_service.GetSources(_document));
                _form.ImportRequested += Import;
                _form.RefreshRequested += StartCheck;
                _form.FocusRequested += (row, margin, isolate) =>
                {
                    if (_busy || _closed) return;
                    _focusRow = row; _margin = margin; _isolate = isolate;
                    Begin(Operation.Focus, "Waiting for Revit to open the clash view…");
                };
                _form.ExportRequested += (report, filter) =>
                {
                    if (_busy || _closed) return;
                    _exportReport = report; _exportFilter = filter;
                    Begin(Operation.Export, "Waiting for Revit to validate the report context…");
                };
                _form.CancelRequested += () => { _cancel = true; _cancelReason = "Cancelled. Completed checks remain; unchecked rows are not treated as solved."; };
                _form.SourcesChanged += () => { _revision++; };
                _form.FormClosed += delegate
                {
                    _closed = true; _cancel = true; _queue.Clear();
                    if (!_executing && !_raised) DisposeEvent();
                    if (ReferenceEquals(_current, this)) _current = null;
                };
                _form.Show(new WindowOwner(app.MainWindowHandle));
            }
            catch
            {
                _form.Dispose(); DisposeEvent(); throw;
            }
        }

        public static void Open(UIApplication app)
        {
            if (_current != null && !_current._closed)
            {
                if (_current._document.Equals(app.ActiveUIDocument.Document))
                {
                    _current._form.WindowState = FormWindowState.Normal;
                    _current._form.Show(); _current._form.Activate(); return;
                }
                _current._form.Close();
            }
            _current = new ClashManagerController(app);
        }

        public static void Shutdown()
        {
            var current = _current; _current = null;
            if (current == null) return;
            current._form.Close(); current.DisposeEvent();
        }

        // Called from App.DocumentChanged on Revit's API thread. Invalidate immediately;
        // only presentation is deferred, so an export cannot retain a stale green result.
        public static void NotifyDocumentChanged(Document changed)
        {
            var current = _current;
            if (current == null || current._closed || current._focusing || current._report == null) return;
            bool relevant = true;
            try
            {
                if (current._document.IsValidObject && !current._document.Equals(changed))
                {
                    using (var collector = new FilteredElementCollector(current._document))
                        relevant = collector.OfClass(typeof(RevitLinkInstance)).Cast<RevitLinkInstance>()
                            .Any(link => { var document = link.GetLinkDocument(); return document != null && document.Equals(changed); });
                }
            }
            catch { relevant = true; }
            if (!relevant) return;
            current._revision++;
            const string reason = "The model or a linked source changed. Refresh clash status before relying on previous results.";
            foreach (var row in current._report.Rows) row.Invalidate(reason);
            if (current._busy) { current._cancel = true; current._cancelReason = reason; }
            current.Post(() => { current._form.RefreshRows(); current._form.ShowStatus(reason); });
        }

        public string GetName() { return "KA MEP Clash Manager"; }

        private void Import(string path)
        {
            if (_busy || _closed) return;
            bool importedSuccessfully = false;
            _busy = true; _form.SetBusy(true, "Reading HTML report text…");
            try
            {
                ClashManagerForm.ValidateImportPath(path);
                ClashReport imported;
                try { imported = ClashHtmlImporter.ImportFile(path); }
                catch (InvalidDataException autoError)
                {
                    var tables = ClashHtmlImporter.InspectFile(path);
                    if (tables.Count == 0) throw;
                    using (var mapping = new ClashMappingForm(tables))
                    {
                        if (mapping.ShowDialog(_form) != DialogResult.OK)
                        {
                            _form.ShowStatus("Import cancelled. The previous report, if any, is unchanged."); return;
                        }
                        imported = ClashHtmlImporter.ImportFile(path, mapping.Mapping);
                        imported.Notes.Add("Automatic layout detection required manual mapping: " + autoError.Message);
                    }
                }
                _report = imported; _revision++;
                _form.SetReport(imported);
                importedSuccessfully = true;
            }
            catch (Exception ex) { _form.ShowFailure("Import failed; the previous report is unchanged. " + ex.Message); }
            finally { _busy = false; if (!_closed) _form.SetBusy(false, ""); }
            if (!_closed && importedSuccessfully) Begin(Operation.Sources, "Updating the available model sources…");
        }

        private void StartCheck(IList<ClashRecord> requested, ClashCheckOptions options)
        {
            if (_busy || _closed || _report == null || requested == null) return;
            var current = new HashSet<ClashRecord>(_report.Rows);
            var rows = requested.Where(current.Contains).Distinct().ToList();
            if (rows.Count == 0) return;
            _queue.Clear(); foreach (var row in rows) { row.Invalidate("Queued for a current-model check."); _queue.Enqueue(row); }
            _options = new ClashCheckOptions { AssumeHardForUnknown = options != null && options.AssumeHardForUnknown,
                IntersectionVolumeToleranceCubicMillimeters = options == null ? 1 : options.IntersectionVolumeToleranceCubicMillimeters };
            _total = rows.Count; _completed = 0; _batchRevision = _revision; _cancel = false; _cancelReason = "";
            _form.RefreshRows();
            Begin(Operation.Check, "Waiting for Revit to check " + _total + " clashes…");
        }

        private void Begin(Operation operation, string message)
        {
            if (_closed || _busy) return;
            _busy = true; _cancel = false; _pending = operation;
            _form.SetBusy(true, message, 0, operation == Operation.Check ? _total : 0);
            Raise();
        }

        private void Raise()
        {
            if (_closed) { if (!_executing && !_raised) DisposeEvent(); return; }
            try
            {
                var result = _event.Raise();
                if (result != ExternalEventRequest.Accepted && result != ExternalEventRequest.Pending)
                    throw new InvalidOperationException("Revit did not accept the request. Finish the current Revit command and try again.");
                _raised = true;
            }
            catch (Exception ex) { Finish("Request failed: " + ex.Message); }
        }

        public void Execute(UIApplication app)
        {
            _raised = false;
            if (_closed) { DisposeEvent(); return; }
            var operation = _pending; _pending = Operation.None; _executing = true;
            bool more = false;
            try
            {
                if (operation == Operation.None) { Finish(""); return; }
                RequireOriginalProject(app);
                if (_cancel) { Finish(_cancelReason ?? "Cancelled."); return; }
                if (operation == Operation.Sources)
                {
                    _form.SetSources(_service.GetSources(_document));
                    Finish("Model sources updated. Review IDs and sources, then refresh clash status.");
                }
                else if (operation == Operation.Check)
                {
                    if (_batchRevision != _revision) { Finish("The model or mapping changed. Refresh again to check a consistent snapshot."); return; }
                    if (_completed == 0) _form.SetSources(_service.GetSources(_document));
                    var watch = Stopwatch.StartNew(); int batch = 0;
                    while (_queue.Count > 0 && batch < 10 && (batch == 0 || watch.ElapsedMilliseconds < 200))
                    {
                        var row = _queue.Dequeue();
                        _service.Check(_document, row, _options).ApplyTo(row);
                        _completed++; batch++;
                    }
                    _form.RefreshRows();
                    if (_queue.Count == 0) Finish("Checked " + _completed + " clashes. Review the check basis and any Needs review results.");
                    else
                    {
                        _pending = Operation.Check; more = true;
                        _form.SetBusy(true, "Checked " + _completed + " / " + _total + " clashes…", _completed, _total);
                    }
                }
                else if (operation == Operation.Focus)
                {
                    string result;
                    _focusing = true;
                    try { result = _service.Focus(app.ActiveUIDocument, _focusRow, _margin, _isolate); }
                    finally { _focusing = false; }
                    _form.RefreshRows(); Finish(result);
                }
                else if (operation == Operation.Export) { Export(); Finish(""); }
            }
            catch (Exception ex) { Finish("Could not complete the action: " + ex.Message); }
            finally
            {
                _executing = false;
                if (_closed) DisposeEvent();
                else if (more && !_continuation)
                {
                    _continuation = true;
                    Post(() => { _continuation = false; Raise(); });
                }
            }
        }

        private void RequireOriginalProject(UIApplication app)
        {
            if (!_document.IsValidObject || app.ActiveUIDocument == null || !app.ActiveUIDocument.Document.Equals(_document))
                throw new InvalidOperationException("This report belongs to '" + _projectTitle + "'. Activate that project, or close this window and reopen Clash Manager in the intended project.");
        }

        private void Export()
        {
            if (_exportReport == null) return;
            using (var save = new SaveFileDialog { Title = "KA MEP - Export clash review", Filter = "Excel workbook (*.xlsx)|*.xlsx", DefaultExt = "xlsx", AddExtension = true, OverwritePrompt = true })
            {
                string name = string.Concat(_projectTitle.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c));
                save.FileName = name + "_KA_MEP_Clashes_" + DateTime.Now.ToString("yyyyMMdd_HHmm", CultureInfo.InvariantCulture) + ".xlsx";
                if (save.ShowDialog(_form) != DialogResult.OK) { _form.ShowStatus("Excel export cancelled."); return; }
                ClashXlsxExporter.Export(save.FileName, _exportReport, new ClashExportOptions
                {
                    ProjectTitle = _projectTitle, RevitVersion = _revitVersion,
                    Release = KAMEP.Branding.ReleaseIdentity.Display, FilterDescription = _exportFilter
                });
                _form.ShowStatus("Exported " + _exportReport.Rows.Count + " clashes to " + save.FileName);
            }
        }

        private void Finish(string message)
        {
            _busy = false; _pending = Operation.None; _queue.Clear(); _cancel = false;
            _exportReport = null; _focusRow = null;
            if (!_closed) _form.SetBusy(false, message);
        }

        private void Post(Action action)
        {
            if (_closed || _form.IsDisposed || !_form.IsHandleCreated) return;
            try { _form.BeginInvoke(new Action(() => { if (!_closed && !_form.IsDisposed) action(); })); }
            catch (InvalidOperationException) { if (!_raised && !_executing) DisposeEvent(); }
        }

        private void DisposeEvent()
        {
            var external = _event; _event = null;
            if (external != null) { try { external.Dispose(); } catch (InvalidOperationException) { } }
        }
        private sealed class WindowOwner : IWin32Window
        {
            public WindowOwner(IntPtr handle) { Handle = handle; }
            public IntPtr Handle { get; private set; }
        }
    }
}
