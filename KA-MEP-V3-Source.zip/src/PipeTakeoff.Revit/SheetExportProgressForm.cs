using System;
using System.Drawing;
using System.Windows.Forms;

namespace PipeTakeoff.Revit
{
    /// <summary>Work remains on the Revit command thread; Refresh paints without pumping arbitrary callbacks.</summary>
    internal sealed class SheetExportProgressForm : Form
    {
        private readonly Label _status = new Label { AutoSize = true, Dock = DockStyle.Fill, Margin = new Padding(0, 12, 0, 10) };
        private readonly ProgressBar _bar = new ProgressBar { Dock = DockStyle.Fill, Height = 22, Style = ProgressBarStyle.Continuous };
        internal SheetExportResult Result { get; private set; }
        internal Exception Error { get; private set; }

        internal SheetExportProgressForm(Func<Action<int, int, string>, SheetExportResult> work)
        {
            KaTheme.ApplyForm(this, "Exporting sheets", 680, 280);
            MinimumSize = new Size(500, 220);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            ControlBox = false;
            MaximizeBox = false;
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, Padding = new Padding(18) };
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 24));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            layout.Controls.Add(KaTheme.Header("EXPORTING", "Creating your PDF + DWG package"), 0, 0);
            layout.Controls.Add(_status, 0, 1);
            layout.Controls.Add(_bar, 0, 2);
            layout.Controls.Add(KaTheme.Hint("Revit is processing the current sheet. Use Cancel in Revit's export dialog when offered; remaining sheets will then stop."), 0, 3);
            Controls.Add(layout);
            Shown += (s, e) =>
            {
                KaTheme.ClampToScreen(this);
                try { Result = work(UpdateProgress); }
                catch (Exception ex) { Error = ex; }
                finally { DialogResult = DialogResult.OK; Close(); }
            };
        }

        private void UpdateProgress(int completed, int total, string text)
        {
            _bar.Maximum = Math.Max(1, total);
            _bar.Value = Math.Max(0, Math.Min(completed, _bar.Maximum));
            _status.Text = completed + " / " + total + " operations completed · " + text;
            Refresh();
        }
    }
}
