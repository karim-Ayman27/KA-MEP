using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.UI;
using PipeTakeoff.Core;

namespace PipeTakeoff.Revit
{
    internal sealed class DuctSnapshot
    {
        public List<PipeRecord> Records { get; set; }
        public List<FieldDefinition> Fields { get; set; }
        public string ScopeLabel { get; set; }
    }

    /// <summary>Creates detached records while running on Revit's API thread.</summary>
    internal static class DuctReader
    {
        private sealed class ParameterField
        {
            public string Key;
            public FieldDefinition Field;
        }

        private sealed class Section
        {
            public string Shape;
            public string Key;
            public string Label;
            public double? Diameter;
            public double? Width;
            public double? Height;
        }

        private static readonly HashSet<long> MappedParameters = new HashSet<long>
        {
            (long)BuiltInParameter.CURVE_ELEM_LENGTH,
            (long)BuiltInParameter.RBS_CURVE_DIAMETER_PARAM,
            (long)BuiltInParameter.RBS_CURVE_WIDTH_PARAM,
            (long)BuiltInParameter.RBS_CURVE_HEIGHT_PARAM,
            (long)BuiltInParameter.RBS_CURVE_SURFACE_AREA,
            (long)BuiltInParameter.RBS_SYSTEM_NAME_PARAM,
            (long)BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM,
            (long)BuiltInParameter.RBS_CALCULATED_SIZE,
            (long)BuiltInParameter.ALL_MODEL_MARK,
            (long)BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS
        };

        public static DuctSnapshot Read(UIDocument uiDocument, PipeScope scope)
        {
            var document = uiDocument.Document;
            List<Element> elements;
            string scopeLabel;
            if (scope == PipeScope.Selection)
            {
                elements = uiDocument.Selection.GetElementIds().Select(document.GetElement).Where(IsIncluded).ToList();
                scopeLabel = "Selected ducts and duct fittings (current model)";
            }
            else
            {
                if (scope == PipeScope.ActiveView && !FilteredElementCollector.IsViewValidForElementIteration(document, document.ActiveView.Id))
                    throw new InvalidOperationException("This view cannot be used for duct collection. Choose a model view or use all ducts.");
                using (var collector = scope == PipeScope.ActiveView
                    ? new FilteredElementCollector(document, document.ActiveView.Id)
                    : new FilteredElementCollector(document))
                using (var categories = new ElementMulticategoryFilter(new[] { BuiltInCategory.OST_DuctCurves, BuiltInCategory.OST_DuctFitting }))
                {
                    elements = collector.WherePasses(categories).WhereElementIsNotElementType().Where(IsIncluded).ToList();
                }
                scopeLabel = scope == PipeScope.ActiveView
                    ? "Active view: " + document.ActiveView.Name + " (ducts and duct fittings)"
                    : "All ducts and duct fittings (current model)";
            }

            var fields = DuctStandardFields.Create();
            var custom = new Dictionary<string, ParameterField>(StringComparer.Ordinal);
            var typeValues = new Dictionary<long, Dictionary<string, object>>();
            var rows = new List<PipeRecord>(elements.Count);
            foreach (var element in elements.OrderBy(e => RevitCompat.Id(e.Id)))
            {
                var row = new PipeRecord();
                var type = document.GetElement(element.GetTypeId()) as ElementType;
                var duct = element as Duct;
                row.Values["ElementId"] = RevitCompat.Id(element.Id).ToString(CultureInfo.InvariantCulture);
                row.Values["Category"] = duct == null ? "Duct Fitting" : "Duct";
                row.Values["Family"] = type == null ? "" : type.FamilyName;
                row.Values["Type"] = type == null ? "" : type.Name;
                row.Values["SystemName"] = Text(element.get_Parameter(BuiltInParameter.RBS_SYSTEM_NAME_PARAM), document);
                row.Values["SystemType"] = Text(element.get_Parameter(BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM), document);
                row.Values["Size"] = Text(element.get_Parameter(BuiltInParameter.RBS_CALCULATED_SIZE), document);
                row.Values["Level"] = LevelName(element, duct, document);
                row.Values["Mark"] = Text(element.get_Parameter(BuiltInParameter.ALL_MODEL_MARK), document);
                row.Values["Comments"] = Text(element.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS), document);

                if (duct != null) ReadDuct(duct, row);
                else ReadFitting((FamilyInstance)element, type, row);
                ReadArea(element, row);
                ReadParameters(element, "Instance", document, row.Values, custom);
                if (type != null)
                {
                    Dictionary<string, object> values;
                    if (!typeValues.TryGetValue(RevitCompat.Id(type.Id), out values))
                    {
                        values = new Dictionary<string, object>(StringComparer.Ordinal);
                        ReadParameters(type, "Type", document, values, custom);
                        typeValues.Add(RevitCompat.Id(type.Id), values);
                    }
                    foreach (var item in values) row.Values[item.Key] = item.Value;
                }
                rows.Add(row);
            }

            foreach (var duplicates in custom.Values.GroupBy(f => f.Field.Header).Where(g => g.Count() > 1))
                foreach (var field in duplicates) field.Field.Header += " {" + field.Key + "}";
            fields.AddRange(custom.Values.Select(f => f.Field).OrderBy(f => f.Header, StringComparer.CurrentCultureIgnoreCase));
            return new DuctSnapshot { Records = rows, Fields = fields, ScopeLabel = scopeLabel };
        }

        private static bool IsIncluded(Element element)
        {
            var duct = element as Duct;
            if (duct != null) return !duct.IsPlaceholder;
            return element is FamilyInstance && element.Category != null
                && RevitCompat.Id(element.Category.Id) == (long)BuiltInCategory.OST_DuctFitting;
        }

        private static void ReadDuct(Duct duct, PipeRecord row)
        {
            var length = Number(duct.get_Parameter(BuiltInParameter.CURVE_ELEM_LENGTH), UnitTypeId.Meters);
            if (!length.HasValue)
                throw new InvalidOperationException("A duct has no valid length parameter: " + RevitCompat.Id(duct.Id).ToString(CultureInfo.InvariantCulture));
            row.Values["Length"] = length.Value;
            row.Values["FittingKind"] = "";
            row.Values["Angle"] = null;
            var shape = duct.DuctType == null ? ConnectorProfileType.Invalid : duct.DuctType.Shape;
            var section = MakeSection(shape,
                Number(duct.get_Parameter(BuiltInParameter.RBS_CURVE_DIAMETER_PARAM), UnitTypeId.Millimeters),
                Number(duct.get_Parameter(BuiltInParameter.RBS_CURVE_WIDTH_PARAM), UnitTypeId.Millimeters),
                Number(duct.get_Parameter(BuiltInParameter.RBS_CURVE_HEIGHT_PARAM), UnitTypeId.Millimeters));
            AssignSection(row, section, duct.Id);
        }

        private static void ReadFitting(FamilyInstance fitting, ElementType type, PipeRecord row)
        {
            // Fittings are counted separately. Their centreline lengths are not added to duct lengths.
            row.Values["Length"] = null;
            var mechanical = fitting.MEPModel as MechanicalFitting;
            var kind = mechanical == null ? "Unknown" : mechanical.PartType.ToString();
            row.Values["FittingKind"] = kind;

            var sections = new List<Section>();
            var ports = new List<Connector>();
            bool incomplete = false;
            var manager = fitting.MEPModel == null ? null : fitting.MEPModel.ConnectorManager;
            if (manager != null)
            {
                foreach (Connector connector in manager.Connectors)
                {
                    if (connector.Domain != Domain.DomainHvac || !IsPhysicalPort(connector.ConnectorType)) continue;
                    ports.Add(connector);
                    Section section;
                    try
                    {
                        var shape = connector.Shape;
                        section = MakeSection(shape,
                            shape == ConnectorProfileType.Round ? (double?)ToMillimeters(2 * connector.Radius) : null,
                            shape == ConnectorProfileType.Rectangular || shape == ConnectorProfileType.Oval ? (double?)ToMillimeters(connector.Width) : null,
                            shape == ConnectorProfileType.Rectangular || shape == ConnectorProfileType.Oval ? (double?)ToMillimeters(connector.Height) : null);
                    }
                    catch (Autodesk.Revit.Exceptions.InvalidOperationException)
                    {
                        // A malformed family connector must not silently match another section.
                        section = null;
                    }
                    if (section == null) incomplete = true;
                    else sections.Add(section);
                }
            }

            // Outward connector normals give the actual two-port elbow deflection,
            // independently of instance rotation and localized family parameter names.
            var angle = mechanical != null && mechanical.PartType == PartType.Elbow ? ElbowDeflection(ports) : null;
            if (!angle.HasValue) angle = ReadAngle(fitting, type);
            row.Values["Angle"] = angle.HasValue ? (object)angle.Value : null;

            row.Values["Diameter"] = null;
            row.Values["Width"] = null;
            row.Values["Height"] = null;
            if (sections.Count == 0)
            {
                AssignSection(row, null, fitting.Id);
            }
            else
            {
                sections = sections.OrderBy(s => s.Key, StringComparer.Ordinal).ToList();
                row.Values["Shape"] = sections.Select(s => s.Shape).Distinct(StringComparer.Ordinal).Count() == 1 ? sections[0].Shape : "Mixed";
                // Keep repeated ports: a tee with three equal connections is not a two-port fitting.
                row.Values["SectionKey"] = string.Join("|", sections.Select(s => s.Key));
                row.Values["SectionLabel"] = string.Join(" + ", sections.GroupBy(s => s.Key).Select(g =>
                    g.Count().ToString(CultureInfo.InvariantCulture) + " × [" + g.First().Shape + " " + g.First().Label + "]"));
                if (!incomplete && sections.All(s => s.Key == sections[0].Key))
                {
                    row.Values["Diameter"] = sections[0].Diameter;
                    row.Values["Width"] = sections[0].Width;
                    row.Values["Height"] = sections[0].Height;
                }
                if (incomplete)
                {
                    row.Values["SectionKey"] += "|Incomplete:" + RevitCompat.Id(fitting.Id).ToString(CultureInfo.InvariantCulture);
                    row.Values["SectionLabel"] += " + [unavailable port dimensions]";
                }
            }
            // Do not merge unresolved elbow angles (for example 45° and 90° of one family type).
            if (mechanical != null && mechanical.PartType == PartType.Elbow && !angle.HasValue)
                row.Values["SectionKey"] += "|UnresolvedAngle:" + RevitCompat.Id(fitting.Id).ToString(CultureInfo.InvariantCulture);
            if (mechanical == null)
                row.Values["SectionKey"] += "|UnknownFittingKind:" + RevitCompat.Id(fitting.Id).ToString(CultureInfo.InvariantCulture);
        }

        private static bool IsPhysicalPort(ConnectorType type)
        {
            return type == ConnectorType.End || type == ConnectorType.Curve || type == ConnectorType.Physical
                || type == ConnectorType.EndSurface || type == ConnectorType.BlankEnd;
        }

        private static double? ElbowDeflection(IList<Connector> ports)
        {
            if (ports.Count != 2) return null;
            try
            {
                var first = ports[0].CoordinateSystem.BasisZ;
                var second = ports[1].CoordinateSystem.BasisZ;
                if (first.GetLength() < 1e-9 || second.GetLength() < 1e-9) return null;
                var dot = first.Normalize().DotProduct(second.Normalize());
                var deflection = Math.PI - Math.Acos(Math.Max(-1.0, Math.Min(1.0, dot)));
                var degrees = UnitUtils.ConvertFromInternalUnits(deflection, UnitTypeId.Degrees);
                return double.IsNaN(degrees) || double.IsInfinity(degrees) ? null : (double?)Math.Round(degrees, 6);
            }
            catch (Autodesk.Revit.Exceptions.InvalidOperationException) { return null; }
        }

        private static Section MakeSection(ConnectorProfileType shape, double? diameter, double? width, double? height)
        {
            if (shape == ConnectorProfileType.Round && IsPositive(diameter))
                return new Section { Shape = "Round", Diameter = diameter,
                    Key = "Round:" + Canonical(diameter.Value), Label = "Ø " + Display(diameter.Value) + " mm" };
            if ((shape == ConnectorProfileType.Rectangular || shape == ConnectorProfileType.Oval) && IsPositive(width) && IsPositive(height))
            {
                var name = shape == ConnectorProfileType.Rectangular ? "Rectangular" : "Oval";
                return new Section { Shape = name, Width = width, Height = height,
                    Key = name + ":" + Canonical(width.Value) + "x" + Canonical(height.Value),
                    Label = Display(width.Value) + " × " + Display(height.Value) + " mm" };
            }
            return null;
        }

        private static void AssignSection(PipeRecord row, Section section, ElementId id)
        {
            row.Values["Shape"] = section == null ? "Unknown" : section.Shape;
            row.Values["SectionKey"] = section == null ? "Unknown:" + RevitCompat.Id(id).ToString(CultureInfo.InvariantCulture) : section.Key;
            row.Values["SectionLabel"] = section == null ? "Not available" : section.Label;
            row.Values["Diameter"] = section == null ? null : (object)section.Diameter;
            row.Values["Width"] = section == null ? null : (object)section.Width;
            row.Values["Height"] = section == null ? null : (object)section.Height;
        }

        private static void ReadArea(Element element, PipeRecord row)
        {
            // Only Revit's duct surface-area quantity is authoritative here. Family geometry,
            // connector perimeters and arbitrary parameters named "Area" are not substitutes.
            var parameter = element.get_Parameter(BuiltInParameter.RBS_CURVE_SURFACE_AREA);
            var area = parameter != null && parameter.Definition != null && SpecTypeId.Area.Equals(parameter.Definition.GetDataType())
                ? Number(parameter, UnitTypeId.SquareMeters) : null;
            row.Values["Area"] = area.HasValue ? (object)area.Value : null;
            row.Values["AreaSource"] = area.HasValue ? "Revit surface area (RBS_CURVE_SURFACE_AREA)" : "Not available";
        }

        private static double? ReadAngle(Element fitting, ElementType type)
        {
            foreach (var builtIn in new[] { BuiltInParameter.CONNECTOR_ANGLE_OF_DEFLECTION, BuiltInParameter.CONNECTOR_ANGLE })
            {
                var value = Angle(fitting.get_Parameter(builtIn));
                if (value.HasValue) return value;
            }
            // Family parameter names are localized. Accept only genuinely angular parameters,
            // and only when all populated candidate values agree; ambiguity remains blank.
            var instanceAngles = AngularValues(fitting);
            if (instanceAngles.Count > 0) return instanceAngles.Count == 1 ? (double?)instanceAngles[0] : null;
            if (type == null) return null;
            foreach (var builtIn in new[] { BuiltInParameter.CONNECTOR_ANGLE_OF_DEFLECTION, BuiltInParameter.CONNECTOR_ANGLE })
            {
                var value = Angle(type.get_Parameter(builtIn));
                if (value.HasValue) return value;
            }
            var typeAngles = AngularValues(type);
            return typeAngles.Count == 1 ? (double?)typeAngles[0] : null;
        }

        private static List<double> AngularValues(Element element)
        {
            return element.Parameters.Cast<Parameter>().Select(Angle).Where(v => v.HasValue)
                .Select(v => Math.Round(v.Value, 6)).Distinct().ToList();
        }

        private static double? Angle(Parameter parameter)
        {
            if (parameter == null || parameter.Definition == null || !SpecTypeId.Angle.Equals(parameter.Definition.GetDataType())) return null;
            var value = Number(parameter, UnitTypeId.Degrees);
            return value.HasValue && value.Value <= 180.000001 ? (double?)Math.Round(value.Value, 6) : null;
        }

        private static string LevelName(Element element, Duct duct, Document document)
        {
            if (duct != null && duct.ReferenceLevel != null) return duct.ReferenceLevel.Name;
            var level = document.GetElement(element.LevelId) as Level;
            return level == null ? "" : level.Name;
        }

        private static bool IsPositive(double? number)
        { return number.HasValue && number.Value > 0 && !double.IsNaN(number.Value) && !double.IsInfinity(number.Value); }

        private static double? Number(Parameter parameter, ForgeTypeId units)
        {
            if (parameter == null || !parameter.HasValue || parameter.StorageType != StorageType.Double) return null;
            var value = UnitUtils.ConvertFromInternalUnits(parameter.AsDouble(), units);
            return double.IsNaN(value) || double.IsInfinity(value) || value < 0 ? null : (double?)value;
        }

        private static double ToMillimeters(double internalLength)
        { return UnitUtils.ConvertFromInternalUnits(internalLength, UnitTypeId.Millimeters); }

        private static string Canonical(double value)
        { return Math.Round(value, 6).ToString("0.######", CultureInfo.InvariantCulture); }

        private static string Display(double value)
        { return value.ToString("0.###", CultureInfo.CurrentCulture); }

        private static void ReadParameters(Element element, string source, Document document,
            Dictionary<string, object> values, Dictionary<string, ParameterField> fields)
        {
            foreach (Parameter parameter in element.Parameters)
            {
                if (parameter.Definition == null || parameter.StorageType == StorageType.None) continue;
                if (source == "Instance" && MappedParameters.Contains(RevitCompat.Id(parameter.Id))) continue;
                var key = source + ":" + (parameter.IsShared ? parameter.GUID.ToString("D") : RevitCompat.Id(parameter.Id).ToString(CultureInfo.InvariantCulture));
                var numeric = parameter.StorageType == StorageType.Double || parameter.StorageType == StorageType.Integer;
                var measured = parameter.StorageType == StorageType.Double && UnitUtils.IsMeasurableSpec(parameter.Definition.GetDataType());
                ForgeTypeId unit = measured ? parameter.GetUnitTypeId() : null;
                if (!fields.ContainsKey(key))
                {
                    var suffix = measured ? " (" + LabelUtils.GetLabelForUnit(unit) + ")" : "";
                    fields.Add(key, new ParameterField
                    {
                        Key = key,
                        Field = new FieldDefinition { Key = key, Header = parameter.Definition.Name + suffix + " [" + source + "]", IsNumeric = numeric }
                    });
                }
                if (!parameter.HasValue) { values[key] = null; continue; }
                if (parameter.StorageType == StorageType.Double)
                    values[key] = measured ? UnitUtils.ConvertFromInternalUnits(parameter.AsDouble(), unit) : parameter.AsDouble();
                else if (parameter.StorageType == StorageType.Integer) values[key] = parameter.AsInteger();
                else values[key] = Text(parameter, document);
            }
        }

        private static string Text(Parameter parameter, Document document)
        {
            if (parameter == null || !parameter.HasValue) return "";
            if (parameter.StorageType == StorageType.String) return parameter.AsString() ?? "";
            if (parameter.StorageType == StorageType.ElementId)
            {
                var id = parameter.AsElementId();
                var element = id == ElementId.InvalidElementId ? null : document.GetElement(id);
                return element == null ? parameter.AsValueString() ?? "" : element.Name;
            }
            return parameter.AsValueString() ?? "";
        }
    }
}
