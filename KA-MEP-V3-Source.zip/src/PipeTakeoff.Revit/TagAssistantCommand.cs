using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using TaskDialog = Autodesk.Revit.UI.TaskDialog;

namespace PipeTakeoff.Revit
{
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    public sealed class TagAssistantCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            bool changesSaved = false;
            try
            {
                var uiDocument = commandData.Application.ActiveUIDocument;
                var unsupported = TagAssistantRevitService.UnsupportedReason(uiDocument);
                if (unsupported != null)
                {
                    TaskDialog.Show("KA MEP - Tag Assistant", unsupported);
                    return Result.Cancelled;
                }
                var service = new TagAssistantRevitService(uiDocument);
                var snapshot = service.Read();
                if (snapshot.Candidates.Count == 0)
                {
                    TaskDialog.Show("KA MEP - Tag Assistant", "No eligible MEP elements or editable tags were found in this view.\n\n" +
                        string.Join("\n", snapshot.Notes.Take(12)));
                    return Result.Cancelled;
                }
                TagAssistantOptions options;
                using (var form = new TagAssistantForm(snapshot))
                {
                    if (form.ShowDialog(new RevitWindow(commandData.Application.MainWindowHandle)) != DialogResult.OK) return Result.Cancelled;
                    options = form.Options;
                }
                var errors = TagAssistantModel.Validate(snapshot, options);
                if (errors.Count != 0)
                {
                    TaskDialog.Show("KA MEP - Tag Assistant", string.Join("\n", errors));
                    return Result.Cancelled;
                }
                if (options.PickOrigin)
                {
                    try { options.Origin = service.PickOrigin(); }
                    catch (Autodesk.Revit.Exceptions.OperationCanceledException) { return Result.Cancelled; }
                    catch (Autodesk.Revit.Exceptions.InvalidOperationException ex)
                    {
                        TaskDialog.Show("KA MEP - Pick pattern origin", "Revit could not pick a point in this view. Set a suitable work plane in Revit, or disable Pick origin and use automatic placement.\n\nNo changes were made.\n\n" + ex.Message);
                        return Result.Cancelled;
                    }
                }
                var result = service.Apply(snapshot, options, ConfirmMeasuredLayout);
                changesSaved = result.Created + result.Moved > 0 && !result.RolledBack && !result.Cancelled;
                ShowReport(uiDocument.Document.Title, snapshot, options, result);
                if (result.Cancelled) return Result.Cancelled;
                // A rolled-back or empty run was handled and reported; do not trigger a second Revit error dialog.
                return Result.Succeeded;
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException) { return Result.Cancelled; }
            catch (Exception ex)
            {
                message = ex.Message;
                TaskDialog.Show("KA MEP - Tag Assistant", changesSaved
                    ? "The tag changes were saved, but the completion report could not be displayed. Review the layout in Revit; Undo once restores the operation.\n\n" + ex.Message
                    : "Tag Assistant could not complete. No tag changes were saved by this operation.\n\n" + ex.Message);
                return changesSaved ? Result.Succeeded : Result.Failed;
            }
        }

        private static bool ConfirmMeasuredLayout(IReadOnlyList<string> warnings)
        {
            var dialog = new TaskDialog("KA MEP - Review tags before applying")
            {
                MainInstruction = "Review the measured tag layout",
                MainContent = "Check the proposed count, distance and skipped elements below. No changes have been saved.\n\n" + string.Join("\n", warnings.Take(8)) +
                    (warnings.Count > 8 ? "\nAdditional details are available below." : ""),
                ExpandedContent = string.Join("\n", warnings),
                CommonButtons = TaskDialogCommonButtons.Cancel,
                DefaultButton = TaskDialogResult.Cancel
            };
            dialog.AddCommandLink(TaskDialogCommandLinkId.CommandLink1, "Apply reviewed tags", "Apply these placements as one undoable operation.");
            return dialog.Show() == TaskDialogResult.CommandLink1;
        }

        private static void ShowReport(string project, TagAssistantSnapshot snapshot, TagAssistantOptions options, TagAssistantApplyResult result)
        {
            var text = new StringBuilder();
            text.AppendLine("KA MEP | " + KAMEP.Branding.ReleaseIdentity.VersionLabel + " - Tag Assistant");
            text.AppendLine(KAMEP.Branding.ReleaseIdentity.Display);
            text.AppendLine("Time: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
            text.AppendLine("Project: " + project);
            text.AppendLine("View: " + snapshot.ViewName + " | Scale 1:" + snapshot.ViewScale);
            text.AppendLine("Operation: " + options.Mode + " | Scope: " + options.Scope + " | Pattern: " + options.Pattern);
            text.AppendLine("Excluded by element review / short-curve settings: " +
                (TagAssistantModel.CandidatesForReview(snapshot, options).Count - TagAssistantModel.Candidates(snapshot, options).Count));
            text.AppendLine("Maximum requested tags: " + options.MaximumTags + " | Nearby label-center limit (paper mm): " + options.MaximumDistanceMm.ToString("0.##", CultureInfo.InvariantCulture));
            text.AppendLine("Requested: " + result.Requested + " | Created: " + result.Created + " | Arranged: " + result.Moved + " | Skipped: " + result.Skipped);
            if (result.Cancelled) text.AppendLine("Cancelled before applying; no changes were saved.");
            if (result.RolledBack) text.AppendLine("The final transaction was rolled back; no changes were saved.");
            text.AppendLine();
            foreach (var note in snapshot.Notes) text.AppendLine("NOTE: " + note);
            foreach (var warning in result.Warnings.Distinct()) text.AppendLine("WARNING: " + warning);
            text.AppendLine();
            foreach (var detail in result.Details) text.AppendLine(detail);
            string logPath = null;
            string logError = null;
            try
            {
                var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KAMEP", "Logs");
                Directory.CreateDirectory(folder);
                logPath = Path.Combine(folder, "TagAssistant-" + DateTime.Now.ToString("yyyyMMdd-HHmmss-fff", CultureInfo.InvariantCulture) + ".txt");
                File.WriteAllText(logPath, text.ToString(), new UTF8Encoding(true));
            }
            catch (Exception ex) { logError = ex.Message; }
            var dialog = new TaskDialog("KA MEP - Tag Assistant")
            {
                MainInstruction = result.Cancelled ? "Cancelled - no changes saved" : result.RolledBack ? "No changes saved - transaction rolled back" :
                    result.Created + result.Moved == 0 ? "No tags changed" : "Tag layout applied",
                MainContent = "Created: " + result.Created + "\nArranged: " + result.Moved + "\nSkipped: " + result.Skipped +
                    (result.Created + result.Moved > 0 ? "\n\nReview the layout in Revit. Undo once (Ctrl+Z) restores this entire operation." : "") +
                    (result.Warnings.Count > 0 ? "\n\nWarnings: " + result.Warnings.Count + ". Expand the details below." : "") +
                    (logPath == null ? "\n\nThe report could not be saved: " + logError : "\n\nFull report:\n" + logPath),
                ExpandedContent = text.Length > 18000 ? text.ToString(0, 18000) + "\n\nDisplay shortened. See the full report file for all details." : text.ToString(),
                CommonButtons = TaskDialogCommonButtons.Close
            };
            dialog.Show();
        }

        private sealed class RevitWindow : IWin32Window
        {
            public RevitWindow(IntPtr handle) { Handle = handle; }
            public IntPtr Handle { get; private set; }
        }
    }
}
