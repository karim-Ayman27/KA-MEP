using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using TaskDialog = Autodesk.Revit.UI.TaskDialog;

namespace PipeTakeoff.Revit
{
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    public sealed class SheetEditorCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            bool changesSaved = false;
            try
            {
                var uiDocument = commandData.Application.ActiveUIDocument;
                var unsupported = SheetEditorRevitService.UnsupportedReason(uiDocument);
                if (unsupported != null)
                {
                    TaskDialog.Show("KA MEP - Sheet Parameters", unsupported);
                    return Result.Cancelled;
                }
                var service = new SheetEditorRevitService(uiDocument.Document);
                var snapshot = service.Read();
                if (snapshot.Sheets.Count == 0)
                {
                    TaskDialog.Show("KA MEP - Sheet Parameters", "The project contains no sheets. Create a sheet or placeholder sheet first.");
                    return Result.Cancelled;
                }
                while (true)
                {
                    using (var form = new SheetEditorForm(snapshot))
                    {
                        if (form.ShowDialog(new RevitWindow(commandData.Application.MainWindowHandle)) != DialogResult.OK) return Result.Cancelled;
                    }
                    if (!snapshot.Sheets.Any(s => s.Changed)) return Result.Cancelled;
                    var result = service.Apply(snapshot);
                    changesSaved = result.Committed;
                    ShowReport(snapshot, result);
                    if (result.Committed || result.Errors.Count == 0) return Result.Succeeded;
                    // Revit-only validation (for example unit parsing) occurs after the modal form.
                    // Keep the same detached drafts so a rejected value can be corrected without retyping the batch.
                }
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException) { return Result.Cancelled; }
            catch (Exception ex)
            {
                message = ex.Message;
                TaskDialog.Show("KA MEP - Sheet Parameters", changesSaved
                    ? "The sheet changes were saved, but the completion report could not be displayed. Undo once restores the complete operation.\n\n" + ex.Message
                    : "Sheet Parameters could not complete. No sheet changes were saved by this operation.\n\n" + ex.Message);
                return changesSaved ? Result.Succeeded : Result.Failed;
            }
        }

        private static void ShowReport(SheetEditorSnapshot snapshot, SheetEditorApplyResult result)
        {
            var text = new StringBuilder();
            text.AppendLine("KA MEP - Sheet Parameters");
            text.AppendLine(KAMEP.Branding.ReleaseIdentity.Display);
            text.AppendLine("Time: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss zzz", CultureInfo.InvariantCulture));
            text.AppendLine("Project: " + snapshot.ProjectTitle);
            text.AppendLine("Status: " + (result.Committed ? "COMMITTED" : "NO CHANGES SAVED"));
            text.AppendLine("Sheets changed: " + result.SheetsChanged);
            text.AppendLine("Parameters changed: " + result.ParametersChanged);
            text.AppendLine("Sheets with revision changes: " + result.RevisionSheetsChanged);
            text.AppendLine();
            foreach (var error in result.Errors.Distinct()) text.AppendLine("ERROR: " + error);
            foreach (var warning in result.Warnings.Distinct()) text.AppendLine("WARNING: " + warning);
            if (result.Committed)
            {
                text.AppendLine("Actual before -> after values (read from Revit):");
                foreach (var detail in result.Details) text.AppendLine(detail);
            }
            else text.AppendLine("Staged edits were not applied to the model.");
            string logPath = null;
            string logError = null;
            try
            {
                var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KAMEP", "Logs");
                Directory.CreateDirectory(folder);
                logPath = Path.Combine(folder, "SheetEditor-" + DateTime.Now.ToString("yyyyMMdd-HHmmss-fff", CultureInfo.InvariantCulture) + "-" + Guid.NewGuid().ToString("N").Substring(0, 6) + ".txt");
                File.WriteAllText(logPath, text.ToString(), new UTF8Encoding(true));
            }
            catch (Exception ex) { logError = ex.Message; logPath = null; }
            var dialog = new TaskDialog("KA MEP - Sheet Parameters")
            {
                MainInstruction = result.Committed ? "Sheet changes saved" : result.Errors.Count > 0 ? "No changes saved - review the errors" : "No model values changed",
                MainContent = "Sheets changed: " + result.SheetsChanged + "\nParameters changed: " + result.ParametersChanged +
                    "\nSheets with revision changes: " + result.RevisionSheetsChanged +
                    (result.Committed ? "\n\nUndo once (Ctrl+Z) restores this complete operation." : "\n\nThe project was not modified by this operation.") +
                    (!result.Committed && result.Errors.Count > 0 ? "\nClose this report to return to your drafts. Correct the values, or Cancel the editor to exit." : "") +
                    (result.Errors.Count > 0 ? "\n\n" + string.Join("\n", result.Errors.Take(4)) + (result.Errors.Count > 4 ? "\nMore errors are listed in the details below." : "") : "") +
                    (result.Warnings.Count > 0 ? "\n\nWarnings: " + result.Warnings.Count + ". Expand the details below." : "") +
                    (logPath == null ? "\n\nThe report could not be saved: " + logError : "\n\nFull report:\n" + logPath),
                ExpandedContent = text.Length > 18000 ? text.ToString(0, 18000) + "\n\nDisplay shortened. See the full report file." : text.ToString(),
                CommonButtons = TaskDialogCommonButtons.Close
            };
            dialog.Show();
        }

        private sealed class RevitWindow : IWin32Window
        {
            public RevitWindow(IntPtr handle) { Handle = handle; }
            public IntPtr Handle { get; private set; }
        }
    }
}
