using System.Collections.Generic;
using PipeTakeoff.Core;

namespace PipeTakeoff.Revit
{
    /// <summary>Cable tray or conduit takeoff editor operating only on detached model data.</summary>
    public sealed class ElectricalTakeoffForm : TakeoffForm
    {
        public ElectricalTakeoffForm(IList<PipeRecord> records, IList<FieldDefinition> fields, string scopeLabel, bool cableTray)
            : base(records, fields, scopeLabel, false, true, cableTray) { }
    }
}
