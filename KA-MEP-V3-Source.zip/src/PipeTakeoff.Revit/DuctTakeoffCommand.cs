using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using PipeTakeoff.Core;
using TaskDialog = Autodesk.Revit.UI.TaskDialog;

namespace PipeTakeoff.Revit
{
    [Transaction(TransactionMode.ReadOnly)]
    [Regeneration(RegenerationOption.Manual)]
    public sealed class DuctTakeoffCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            try
            {
                var uiDocument = commandData.Application.ActiveUIDocument;
                if (uiDocument == null || uiDocument.Document.IsFamilyDocument)
                {
                    TaskDialog.Show("KA MEP", "Open a Revit project containing ducts first.");
                    return Result.Cancelled;
                }
                var choice = new TaskDialog("KA MEP - Duct takeoff scope")
                {
                    MainInstruction = "Choose the ducts and fittings to include",
                    MainContent = "Rigid ducts and duct fittings in the current model. You can exclude fittings in the takeoff window. Linked models, flex ducts, placeholders, accessories, insulation and lining are excluded.",
                    CommonButtons = TaskDialogCommonButtons.Cancel
                };
                choice.AddCommandLink(TaskDialogCommandLinkId.CommandLink1, "All ducts and duct fittings in the current model");
                choice.AddCommandLink(TaskDialogCommandLinkId.CommandLink2, "Ducts and duct fittings in the active view");
                choice.AddCommandLink(TaskDialogCommandLinkId.CommandLink3, "Selected ducts and duct fittings only");
                var result = choice.Show();
                PipeScope scope;
                if (result == TaskDialogResult.CommandLink1) scope = PipeScope.Model;
                else if (result == TaskDialogResult.CommandLink2) scope = PipeScope.ActiveView;
                else if (result == TaskDialogResult.CommandLink3) scope = PipeScope.Selection;
                else return Result.Cancelled;

                var snapshot = DuctReader.Read(uiDocument, scope);
                if (snapshot.Records.Count == 0)
                {
                    TaskDialog.Show("KA MEP", "No rigid ducts or duct fittings were found in this scope. Choose another scope or select duct elements.");
                    return Result.Cancelled;
                }
                var owner = new RevitWindow(commandData.Application.MainWindowHandle);
                using (var form = new DuctTakeoffForm(snapshot.Records, snapshot.Fields, snapshot.ScopeLabel))
                {
                    if (form.ShowDialog(owner) != DialogResult.OK) return Result.Cancelled;
                    using (var save = new SaveFileDialog())
                    {
                        save.Title = "KA MEP - Export duct takeoff to Excel";
                        save.Filter = "Excel workbook (*.xlsx)|*.xlsx";
                        save.DefaultExt = "xlsx";
                        save.AddExtension = true;
                        save.OverwritePrompt = true;
                        var safeTitle = string.Concat(uiDocument.Document.Title.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c));
                        save.FileName = safeTitle + "_KA_MEP_Ducts_" + DateTime.Now.ToString("yyyyMMdd_HHmm", CultureInfo.InvariantCulture) + ".xlsx";
                        if (save.ShowDialog(owner) != DialogResult.OK) return Result.Cancelled;
                        DuctXlsxExporter.Export(save.FileName, form.FilteredRecords, form.Options, new ExportMetadata
                        {
                            Project = uiDocument.Document.Title,
                            RevitVersion = commandData.Application.Application.VersionName,
                            Scope = snapshot.ScopeLabel + (form.IncludesDuctFittings ? "; fittings included" : "; fittings excluded")
                        });
                        var ducts = form.FilteredRecords.Count(r => string.Equals(r.Get("Category") as string, "Duct", StringComparison.Ordinal));
                        var fittings = form.FilteredRecords.Count - ducts;
                        var measured = form.FilteredRecords.Where(r => r.Get("Area") != null).ToList();
                        var area = measured.Sum(r => Convert.ToDouble(r.Get("Area"), CultureInfo.InvariantCulture));
                        TaskDialog.Show("KA MEP", string.Format(CultureInfo.CurrentCulture,
                            "Export complete.\n\nDucts: {0:N0}\nDuct fittings: {1:N0}\nDuct length: {2:N3} m\nKnown surface area: {3:N3} m²\nElements without surface area: {4:N0}\n\n{5}",
                            ducts, fittings, form.FilteredRecords.Sum(r => r.LengthMeters), area,
                            form.FilteredRecords.Count - measured.Count, save.FileName));
                    }
                }
                return Result.Succeeded;
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException) { return Result.Cancelled; }
            catch (Exception ex)
            {
                message = ex.Message;
                TaskDialog.Show("KA MEP - Error", "The duct takeoff could not be completed.\n\n" + ex.Message);
                return Result.Failed;
            }
        }

        private sealed class RevitWindow : IWin32Window
        {
            public RevitWindow(IntPtr handle) { Handle = handle; }
            public IntPtr Handle { get; private set; }
        }
    }
}
