using Autodesk.Revit.UI;

namespace PipeTakeoff.Revit
{
    public sealed class App : IExternalApplication
    {
        public Result OnStartup(UIControlledApplication application)
        {
            application.ControlledApplication.DocumentChanged += OnDocumentChanged;
            application.ControlledApplication.DocumentClosing += OnDocumentClosing;
            const string tab = "KA MEP";
            try { application.CreateRibbonTab(tab); }
            catch (Autodesk.Revit.Exceptions.ArgumentException) { /* The tab already exists. */ }
            var workspace = application.CreateRibbonPanel(tab, "Workspace");
            AddButton(workspace, "KAMEP.Home", "KA\nMEP", typeof(HubCommand), "home", "Open the KA MEP workspace.", true);
            AddButton(workspace, "KAMEP.Claude", "Claude\nMCP", typeof(McpConnectionCommand), "mcp", "Enable local read-only access from Claude Desktop. Requested model data is returned to your Claude conversation.");
            var quantities = application.CreateRibbonPanel(tab, "Quantities");
            AddButton(quantities, "KAMEP.Pipes", "Pipe\nTakeoff", typeof(TakeoffCommand), "pipes", "Filter pipe quantities and export details and diameter totals to Excel.");
            AddButton(quantities, "KAMEP.Ducts", "Duct\nTakeoff", typeof(DuctTakeoffCommand), "ducts", "Review duct and fitting quantities, section sizes, lengths and measured areas.");
            var electrical = application.CreateRibbonPanel(tab, "Electrical");
            AddButton(electrical, "KAMEP.CableTrays", "Cable Tray\nTakeoff", typeof(CableTrayTakeoffCommand), "trays", "Filter cable trays and fittings, group matching sizes and export quantities to Excel.");
            AddButton(electrical, "KAMEP.Conduits", "Conduit\nTakeoff", typeof(ConduitTakeoffCommand), "conduits", "Filter conduits and fittings, group matching diameters and export quantities to Excel.");
            var annotation = application.CreateRibbonPanel(tab, "Annotation");
            var hvac = application.CreateRibbonPanel(tab, "HVAC");
            AddButton(hvac, "KAMEP.Spaces", "HVAC\nSpaces", typeof(SpaceTakeoffCommand), "spaces", "Review space and room identities, areas and sampled floor-to-ceiling or slab clear heights from architectural links. Export a formatted Excel report.");
            AddButton(annotation, "KAMEP.TagAssistant", "Tag\nAssistant", typeof(TagAssistantCommand), "tags", "Review selected MEP elements and place tags nearby with distance and count limits. Arrange existing tags or choose five additional patterns.");
            var publish = application.CreateRibbonPanel(tab, "Sheets");
            AddButton(publish, "KAMEP.SheetParameters", "Sheet\nParameters", typeof(SheetEditorCommand), "sheetparams", "Review and edit sheet instance parameters, apply values to selected sheets, and assign existing revisions.");
            AddButton(publish, "KAMEP.ExportSheets", "Sheet\nExport", typeof(SheetExportCommand), "sheets", "Select Revit sheets and publish PDF and DWG files.");
            var review = application.CreateRibbonPanel(tab, "Model");
            AddButton(review, "KAMEP.ClashManager", "Clash\nManager", typeof(ClashManagerCommand), "clashes", "Import HTML clash reports, resolve model elements, open a focused 3D view and refresh hard-clash status. Export the review to Excel.");
            AddButton(review, "KAMEP.ModelReview", "Model Review\n& Cleanup", typeof(ModelReviewCommand), "review", "Review CAD imports, unplaced views, potential duplicates and Revit warnings. Refresh the KA MEP health score and preview selected cleanup.");
            var about = application.CreateRibbonPanel(tab, "About");
            AddButton(about, "KAMEP.Info", "Info", typeof(InfoCommand), "info", "About KA MEP and its creator, Karim Ayman.", true);
            return Result.Succeeded;
        }

        private static void AddButton(RibbonPanel panel, string id, string label, System.Type command, string icon, string tooltip, bool availableWithoutDocument = false)
        {
            var data = new PushButtonData(id, label, typeof(App).Assembly.Location, command.FullName);
            if (availableWithoutDocument) data.AvailabilityClassName = typeof(InfoCommandAvailability).FullName;
            var button = (PushButton)panel.AddItem(data);
            button.ToolTip = tooltip;
            button.LargeImage = RibbonIcons.Create(icon, 32);
            button.Image = RibbonIcons.Create(icon, 16);
        }

        private static void OnDocumentChanged(object sender, Autodesk.Revit.DB.Events.DocumentChangedEventArgs args)
        {
            ModelReviewService.NotifyDocumentChanged(args.GetDocument());
            ClashManagerController.NotifyDocumentChanged(args.GetDocument());
            McpConnectionController.NotifyDocumentChanged(args.GetDocument());
        }

        private static void OnDocumentClosing(object sender, Autodesk.Revit.DB.Events.DocumentClosingEventArgs args)
        {
            McpConnectionController.NotifyDocumentClosing(args.Document);
        }

        public Result OnShutdown(UIControlledApplication application)
        {
            application.ControlledApplication.DocumentChanged -= OnDocumentChanged;
            application.ControlledApplication.DocumentClosing -= OnDocumentClosing;
            ModelReviewController.Shutdown();
            ClashManagerController.Shutdown();
            McpConnectionController.Shutdown();
            return Result.Succeeded;
        }
    }
}
