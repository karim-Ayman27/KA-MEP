using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB;
using PipeTakeoff.Core;

namespace PipeTakeoff.Revit
{
    internal sealed class SheetExportItem
    {
        public ElementId Id { get; set; }
        public string Number { get; set; }
        public string Name { get; set; }
        public bool Selected { get; set; }
        public IDictionary<string, string> Parameters { get; private set; } = new Dictionary<string, string>(StringComparer.Ordinal);
        public string Label { get { return Number + " — " + Name; } }
    }

    internal sealed class SheetExportRequest
    {
        public IList<SheetExportItem> Sheets { get; set; }
        public string Folder { get; set; }
        public SheetNameOptions Naming { get; set; } = new SheetNameOptions();
        public IList<SheetNamingParameter> NamingParameters { get; set; } = new List<SheetNamingParameter>();
        public bool ExportPdf { get; set; }
        public bool ExportDwg { get; set; }
        public bool CombinedPdf { get; set; }
        public string CombinedName { get; set; }
        public ExportPaperFormat Paper { get; set; }
        public PageOrientationType Orientation { get; set; }
        public bool FitToPage { get; set; }
        public int ZoomPercent { get; set; }
        public ColorDepthType PdfColor { get; set; }
        public PDFExportQualityType PdfQuality { get; set; }
        public bool Raster { get; set; }
        public RasterQualityType RasterQuality { get; set; }
        public bool HideCrop { get; set; }
        public bool HideReference { get; set; }
        public bool HideScope { get; set; }
        public bool HideUnreferenced { get; set; }
        public bool ThinHalftone { get; set; }
        public string DwgPreset { get; set; }
        public bool OverrideDwg { get; set; }
        public ACADVersion DwgVersion { get; set; }
        public ExportUnit DwgUnit { get; set; }
        public ExportColorMode DwgColor { get; set; }
        public bool MergeViews { get; set; }
    }

    internal sealed class SheetExportEntry
    {
        public string Format { get; set; }
        public string Sheet { get; set; }
        public bool Success { get; set; }
        public string Path { get; set; }
        public string Detail { get; set; }
    }

    internal sealed class SheetExportResult
    {
        public string Folder { get; set; }
        public string ReportPath { get; set; }
        public string ReportError { get; set; }
        public bool Cancelled { get; set; }
        public int PlannedOperations { get; set; }
        public int NotStarted { get { return Math.Max(0, PlannedOperations - Entries.Count(x => x.Format == "PDF" || x.Format == "DWG")); } }
        public string StopReason { get; set; }
        public IList<SheetExportEntry> Entries { get; private set; } = new List<SheetExportEntry>();
        public int Succeeded { get { return Entries.Count(x => x.Success); } }
        public int Failed { get { return Entries.Count(x => !x.Success); } }
    }

    internal static class SheetExportService
    {
        internal static SheetExportResult Export(Document document, SheetExportRequest request,
            Action<int, int, string> progress)
        {
            if (document.IsModifiable) throw new InvalidOperationException("Finish the current Revit transaction before exporting sheets.");
            if (request.Sheets == null || request.Sheets.Count == 0) throw new InvalidOperationException("Select at least one printable sheet.");
            if (!request.ExportPdf && !request.ExportDwg) throw new InvalidOperationException("Select PDF, DWG, or both formats.");
            if (request.Sheets.Select(x => x.Id).Distinct().Count() != request.Sheets.Count)
                throw new InvalidOperationException("A sheet may only appear once in an export set.");
            var result = new SheetExportResult();
            result.Folder = Path.Combine(request.Folder, "KA_MEP_" + DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture)
                + "_" + Guid.NewGuid().ToString("N").Substring(0, 6));
            Directory.CreateDirectory(result.Folder);
            var names = BuildNames(request);
            var total = (request.ExportPdf ? (request.CombinedPdf ? 1 : request.Sheets.Count) : 0)
                + (request.ExportDwg ? request.Sheets.Count : 0);
            result.PlannedOperations = total;
            var done = 0;
            try
            {
                if (request.ExportPdf)
                {
                    var pdfFolder = Path.Combine(result.Folder, "PDF");
                    Directory.CreateDirectory(pdfFolder);
                    if (request.CombinedPdf)
                    {
                        var stem = SafeStem(request.CombinedName, "KA_MEP_Sheets");
                        progress(done, total, "PDF · Combined document (" + request.Sheets.Count + " sheets)");
                        Attempt(result, "PDF", "Combined: " + request.Sheets.Count + " sheets", Path.Combine(pdfFolder, stem + ".pdf"), () =>
                        {
                            using (var options = PdfOptions(request, stem))
                                return document.Export(pdfFolder, request.Sheets.Select(x => x.Id).ToList(), options);
                        });
                        done++;
                    }
                    else
                    {
                        for (int i = 0; i < request.Sheets.Count; i++)
                        {
                            var sheet = request.Sheets[i];
                            var stem = names[i];
                            progress(done, total, "PDF · " + sheet.Label);
                            Attempt(result, "PDF", sheet.Label, Path.Combine(pdfFolder, stem + ".pdf"), () =>
                            {
                                using (var options = PdfOptions(request, stem))
                                    return document.Export(pdfFolder, new List<ElementId> { sheet.Id }, options);
                            });
                            done++;
                        }
                    }
                }
                if (request.ExportDwg)
                {
                    var available = OptionalFunctionalityUtils.IsDWGExportAvailable();
                    for (int i = 0; i < request.Sheets.Count; i++)
                    {
                        var sheet = request.Sheets[i];
                        var stem = names[i];
                        // Keep each sheet and all generated Xrefs together without cross-sheet name collisions.
                        var dwgFolder = Path.Combine(result.Folder, "DWG", (i + 1).ToString("D3", CultureInfo.InvariantCulture)
                            + "_" + SafeStem(sheet.Number, "Sheet", 32));
                        progress(done, total, "DWG · " + sheet.Label);
                        Attempt(result, "DWG", sheet.Label, dwgFolder, () =>
                        {
                            if (!available) throw new InvalidOperationException("The DWG export module is not available in this Revit installation.");
                            Directory.CreateDirectory(dwgFolder);
                            using (var options = DwgOptions(document, request))
                                return document.Export(dwgFolder, stem, new List<ElementId> { sheet.Id }, options);
                        });
                        done++;
                    }
                }
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException ex)
            {
                result.Cancelled = true;
                result.StopReason = "Export cancelled in Revit. Remaining operations were not started. " + ex.Message;
            }
            catch (System.OperationCanceledException ex)
            {
                result.Cancelled = true;
                result.StopReason = "Export cancelled. Remaining operations were not started. " + ex.Message;
            }
            catch (SheetExportStoppedException ex)
            {
                result.StopReason = ex.Message;
            }
            catch (Exception ex)
            {
                result.StopReason = "Batch interrupted: " + ex.Message;
                result.Entries.Add(new SheetExportEntry { Format = "Batch", Sheet = "Remaining operations", Success = false,
                    Path = result.Folder, Detail = "Batch interrupted: " + ex.Message });
            }
            finally
            {
                progress(done, total, "Writing the export report…");
                WriteReport(document, request, result);
            }
            return result;
        }

        private sealed class SheetExportStoppedException : Exception
        {
            public SheetExportStoppedException(string message) : base(message) { }
        }

        private static void Attempt(SheetExportResult result, string format, string sheet, string path, Func<bool> export)
        {
            var entry = new SheetExportEntry { Format = format, Sheet = sheet, Path = path };
            try
            {
                entry.Success = export();
                if (!entry.Success)
                {
                    entry.Detail = "Revit reported an incomplete, cancelled, or failed export. Remaining operations were stopped. Check any files created before using them.";
                    throw new SheetExportStoppedException(entry.Detail);
                }
                bool verified = format == "PDF" ? HasContent(path) : Directory.EnumerateFiles(path, "*.dwg").Any(HasContent);
                if (!verified)
                {
                    entry.Success = false;
                    entry.Detail = "Revit returned success but no non-empty " + format + " output was found. Remaining operations were stopped.";
                    throw new SheetExportStoppedException(entry.Detail);
                }
                entry.Detail = "Export completed; non-empty output verified.";
                if (format == "DWG") entry.Detail += " Files: " + string.Join(", ", Directory.EnumerateFiles(path).Select(Path.GetFileName));
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException ex)
            {
                entry.Success = false;
                entry.Detail = "Cancelled in Revit: " + ex.Message;
                throw;
            }
            catch (System.OperationCanceledException ex)
            {
                entry.Success = false;
                entry.Detail = "Cancelled: " + ex.Message;
                throw;
            }
            catch (SheetExportStoppedException) { throw; }
            catch (Exception ex)
            {
                entry.Success = false;
                entry.Detail = ex.GetType().Name + ": " + ex.Message;
            }
            finally { result.Entries.Add(entry); }
        }

        private static bool HasContent(string path) { return File.Exists(path) && new FileInfo(path).Length > 0; }

        private static PDFExportOptions PdfOptions(SheetExportRequest request, string name)
        {
            return new PDFExportOptions
            {
                Combine = true,
                FileName = name,
                StopOnError = true,
                PaperFormat = request.Paper,
                PaperOrientation = request.Orientation,
                PaperPlacement = PaperPlacementType.Center,
                ZoomType = request.FitToPage ? ZoomType.FitToPage : ZoomType.Zoom,
                ZoomPercentage = request.ZoomPercent,
                ColorDepth = request.PdfColor,
                ExportQuality = request.PdfQuality,
                RasterQuality = request.RasterQuality,
                AlwaysUseRaster = request.Raster,
                HideCropBoundaries = request.HideCrop,
                HideReferencePlane = request.HideReference,
                HideScopeBoxes = request.HideScope,
                HideUnreferencedViewTags = request.HideUnreferenced,
                ReplaceHalftoneWithThinLines = request.ThinHalftone
            };
        }

        private static DWGExportOptions DwgOptions(Document document, SheetExportRequest request)
        {
            DWGExportOptions options;
            if (string.IsNullOrWhiteSpace(request.DwgPreset)) options = new DWGExportOptions();
            else
            {
                options = DWGExportOptions.GetPredefinedOptions(document, request.DwgPreset);
                if (options == null) throw new InvalidOperationException("The selected DWG export setup no longer exists in the project.");
            }
            try
            {
                if (request.OverrideDwg || string.IsNullOrWhiteSpace(request.DwgPreset))
                {
                    options.FileVersion = request.DwgVersion;
                    options.TargetUnit = request.DwgUnit;
                    options.Colors = request.DwgColor;
                    options.MergedViews = request.MergeViews;
                }
                return options;
            }
            catch { options.Dispose(); throw; }
        }

        internal static List<string> BuildNames(SheetExportRequest request)
        {
            return SheetFileNaming.BuildNames(request.Sheets.Select(sheet => new SheetNameRecord
            {
                Values = sheet.Parameters, Fallback = sheet.Number + "_" + sheet.Id.ToString()
            }).ToList(), request.Naming);
        }

        internal static string SafeStem(string value, string fallback, int limit = SheetFileNaming.MaximumStemLength)
        { return SheetFileNaming.SafeStem(value, fallback, limit); }

        private static void WriteReport(Document document, SheetExportRequest request, SheetExportResult result)
        {
            result.ReportPath = Path.Combine(result.Folder, "KA_MEP_Export_Report.txt");
            var text = new StringBuilder();
            text.AppendLine("KA MEP | SHEET EXPORT REPORT");
            text.AppendLine("Project: " + document.Title);
            text.AppendLine("Created: " + DateTimeOffset.Now.ToString("O", CultureInfo.InvariantCulture));
            text.AppendLine("Output: " + result.Folder);
            text.AppendLine("Succeeded export operations: " + result.Succeeded);
            text.AppendLine("Failed/incomplete operations: " + result.Failed);
            text.AppendLine("Operations not started: " + result.NotStarted);
            if (!string.IsNullOrWhiteSpace(result.StopReason)) text.AppendLine("STOPPED: " + result.StopReason);
            text.AppendLine("Filename fields: " + string.Join(" | ", request.NamingParameters.Select(x => x.Label + " [" + x.Key + "]")));
            text.AppendLine("Filename separator: " + request.Naming.Separator + "; Prefix=" + request.Naming.Prefix + "; Suffix=" + request.Naming.Suffix);
            text.AppendLine("Missing/unreadable parameter values use NA; collisions receive ordered numeric suffixes.");
            text.AppendLine("Combined PDF counts as one operation. Failed operations may leave incomplete files.");
            text.AppendLine();
            text.AppendLine("Selected sheets in export order:");
            var names = BuildNames(request);
            for (int i = 0; i < request.Sheets.Count; i++)
                text.AppendLine("  " + request.Sheets[i].Label + " [Element " + request.Sheets[i].Id.ToString() + "] => " + names[i]);
            text.AppendLine();
            if (request.ExportPdf)
            {
                text.AppendLine("PDF: " + (request.CombinedPdf ? "Combined" : "Separate files") + "; Paper=" + request.Paper
                    + "; Orientation=" + request.Orientation + "; Scale=" + (request.FitToPage ? "Fit" : request.ZoomPercent + "%")
                    + "; Color=" + request.PdfColor + "; Quality=" + request.PdfQuality + "; Raster=" + request.Raster
                    + "; Raster quality=" + request.RasterQuality);
                text.AppendLine("Hide: Crop=" + request.HideCrop + "; Reference planes=" + request.HideReference
                    + "; Scope boxes=" + request.HideScope + "; Unreferenced tags=" + request.HideUnreferenced + "; Thin halftone=" + request.ThinHalftone);
                if (request.Paper == ExportPaperFormat.Default) text.AppendLine("Use Sheet Size preserves the sheet size; Revit ignores orientation and scale overrides.");
            }
            if (request.ExportDwg)
            {
                text.AppendLine("DWG setup: " + (string.IsNullOrWhiteSpace(request.DwgPreset) ? "Revit defaults" : request.DwgPreset));
                if (request.OverrideDwg || string.IsNullOrWhiteSpace(request.DwgPreset))
                    text.AppendLine("Overrides: Version=" + request.DwgVersion + "; Units=" + request.DwgUnit
                        + "; Colors=" + request.DwgColor + "; MergedViews=" + request.MergeViews);
                else text.AppendLine("All options preserved from the selected project setup.");
                text.AppendLine("Each DWG sheet has a separate folder. Keep generated supporting files and Xrefs with it.");
            }
            text.AppendLine();
            foreach (var entry in result.Entries)
            {
                text.AppendLine((entry.Success ? "SUCCESS" : "FAILED") + " | " + entry.Format + " | " + entry.Sheet);
                text.AppendLine("  " + entry.Detail);
                text.AppendLine("  " + entry.Path);
            }
            try { File.WriteAllText(result.ReportPath, text.ToString(), new UTF8Encoding(true)); }
            catch (Exception ex) { result.ReportError = "The export report could not be saved: " + ex.Message; }
        }
    }
}
