using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;
using PipeTakeoff.Core;

namespace PipeTakeoff.Revit
{
    /// <summary>A detached, view-plane schematic. It never accesses the Revit document.</summary>
    public sealed class TagPatternPreview : Control
    {
        private TagLayoutResult _layout;
        private TagLeaderStyle _leaderStyle;
        private string _emptyMessage = "Choose elements and a pattern to preview their layout.";

        public TagPatternPreview()
        {
            Name = "TagPatternPreview";
            DoubleBuffered = true;
            BackColor = Color.White;
            ForeColor = KaTheme.Ink;
            MinimumSize = new Size(80, 45);
            AccessibleName = "Tag layout schematic";
            AccessibleDescription = "The selected elements are dots, proposed tag heads are boxes and leaders are lines. Widths are estimates.";
            SetStyle(ControlStyles.ResizeRedraw, true);
        }

        public void ShowLayout(TagLayoutResult layout, TagLeaderStyle leaderStyle, string emptyMessage)
        {
            _layout = layout;
            _leaderStyle = leaderStyle;
            _emptyMessage = emptyMessage ?? "No matching elements.";
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            int margin = Math.Max(3, Math.Min(Math.Max(20, (int)(Font.Height * 1.6)), Math.Min(Width, Height) / 8));
            Rectangle plot = Rectangle.Inflate(ClientRectangle, -margin, -margin);
            if (plot.Width < 8 || plot.Height < 8) return;
            using (var grid = new Pen(Color.FromArgb(237, 242, 246)))
            {
                int gridStep = Math.Max(24, (int)(Font.Height * 2));
                for (int x = plot.Left; x <= plot.Right; x += gridStep) g.DrawLine(grid, x, plot.Top, x, plot.Bottom);
                for (int y = plot.Top; y <= plot.Bottom; y += gridStep) g.DrawLine(grid, plot.Left, y, plot.Right, y);
            }
            if (_layout == null || _layout.Placements.Count == 0)
            {
                TextRenderer.DrawText(g, _emptyMessage, Font, plot, KaTheme.Muted,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.WordBreak);
                return;
            }

            // Preview is deliberately bounded; the engine still places the complete candidate set.
            var visible = _layout.Placements.Take(200).ToList();
            double minX = visible.Min(p => Math.Min(p.Anchor.X, p.Bounds.Left));
            double maxX = visible.Max(p => Math.Max(p.Anchor.X, p.Bounds.Right));
            double minY = visible.Min(p => Math.Min(p.Anchor.Y, p.Bounds.Bottom));
            double maxY = visible.Max(p => Math.Max(p.Anchor.Y, p.Bounds.Top));
            if (_leaderStyle == TagLeaderStyle.Elbow || _leaderStyle == TagLeaderStyle.Orthogonal)
            {
                minX = Math.Min(minX, visible.Min(p => p.Elbow.X));
                maxX = Math.Max(maxX, visible.Max(p => p.Elbow.X));
                minY = Math.Min(minY, visible.Min(p => p.Elbow.Y));
                maxY = Math.Max(maxY, visible.Max(p => p.Elbow.Y));
            }
            double spanX = Math.Max(maxX - minX, .01), spanY = Math.Max(maxY - minY, .01);
            double scale = Math.Min(plot.Width / spanX, plot.Height / spanY) * .90;
            double centerX = (minX + maxX) / 2, centerY = (minY + maxY) / 2;
            Func<TagPoint, PointF> map = p => new PointF(
                (float)(plot.Left + plot.Width / 2.0 + (p.X - centerX) * scale),
                (float)(plot.Top + plot.Height / 2.0 - (p.Y - centerY) * scale));
            using (var leader = new Pen(Color.FromArgb(117, 140, 155), 1.2F))
            using (var outline = new Pen(Color.FromArgb(0, 131, 122), 1.5F))
            using (var fill = new SolidBrush(Color.FromArgb(222, 247, 242)))
            using (var anchorBrush = new SolidBrush(KaTheme.Navy))
            {
                foreach (var placement in visible)
                {
                    PointF anchor = map(placement.Anchor), head = map(placement.Head);
                    if (_leaderStyle == TagLeaderStyle.Straight) g.DrawLine(leader, anchor, head);
                    else if (_leaderStyle == TagLeaderStyle.Elbow || _leaderStyle == TagLeaderStyle.Orthogonal)
                    {
                        PointF elbow = map(placement.Elbow);
                        g.DrawLine(leader, anchor, elbow);
                        g.DrawLine(leader, elbow, head);
                    }
                    g.FillEllipse(anchorBrush, anchor.X - 3, anchor.Y - 3, 6, 6);
                    PointF upperLeft = map(new TagPoint(placement.Bounds.Left, placement.Bounds.Top));
                    float width = Math.Max(5, (float)((placement.Bounds.Right - placement.Bounds.Left) * scale));
                    float height = Math.Max(5, (float)((placement.Bounds.Top - placement.Bounds.Bottom) * scale));
                    var bounds = new RectangleF(upperLeft.X, upperLeft.Y, width, height);
                    g.FillRectangle(fill, bounds);
                    g.DrawRectangle(outline, bounds.X, bounds.Y, bounds.Width, bounds.Height);
                    if (bounds.Width >= 23 && bounds.Height >= 12)
                        TextRenderer.DrawText(g, (visible.IndexOf(placement) + 1).ToString(), Font,
                            Rectangle.Round(bounds), KaTheme.Navy,
                            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
                }
            }
            if (_layout.Placements.Count > visible.Count)
                TextRenderer.DrawText(g, "Showing first 200 of " + _layout.Placements.Count + " proposed tags", Font,
                    new Rectangle(8, Height - Font.Height - 6, Width - 16, Font.Height + 2), KaTheme.Muted,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.EndEllipsis);
        }
    }

    /// <summary>A keyboard-selectable pattern card with a compact layout illustration.</summary>
    internal sealed class TagPatternChoice : RadioButton
    {
        public TagLayoutPattern Pattern { get; private set; }

        public TagPatternChoice(TagLayoutPattern pattern, string caption)
        {
            Pattern = pattern;
            Text = caption;
            Name = "Pattern" + pattern;
            Appearance = Appearance.Button;
            AutoSize = false;
            Dock = DockStyle.Fill;
            MinimumSize = new Size(100, 64);
            Height = 70;
            Margin = new Padding(0, 0, 7, 7);
            Cursor = Cursors.Hand;
            AccessibleName = caption + " tag distribution pattern";
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (var fill = new SolidBrush(Checked ? Color.FromArgb(225, 246, 242) : Color.White))
                g.FillRectangle(fill, ClientRectangle);
            using (var border = new Pen(Checked ? Color.FromArgb(0, 131, 122) : KaTheme.Line, Checked ? 2 : 1))
                g.DrawRectangle(border, 1, 1, Math.Max(0, Width - 3), Math.Max(0, Height - 3));
            int captionHeight = Math.Max(27, Font.Height * 2 + 3);
            var caption = new Rectangle(5, Height - captionHeight - 3, Math.Max(1, Width - 10), captionHeight);
            TextRenderer.DrawText(g, Text, Font, caption, Checked ? KaTheme.Navy : KaTheme.Muted,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.WordBreak);
            float glyphScale = Math.Max(1, Font.Height / 15F);
            float cx = Width / 2F, cy = Math.Max(16 * glyphScale, (Height - captionHeight) / 2F);
            float step = Math.Min(18 * glyphScale, Width / 6F);
            using (var pen = new Pen(Color.FromArgb(0, 131, 122), 1.5F * glyphScale))
            using (var dot = new SolidBrush(KaTheme.Navy))
            {
                for (int i = 0; i < 4; i++)
                {
                    float x, y;
                    switch (Pattern)
                    {
                        case TagLayoutPattern.NearHost:
                            x = cx + (i % 2 == 0 ? -step : step);
                            y = cy + (i / 2 - .5F) * 16 * glyphScale;
                            break;
                        case TagLayoutPattern.VerticalColumn: x = cx; y = cy + (i - 1.5F) * 8 * glyphScale; break;
                        case TagLayoutPattern.TwoColumns: x = cx + (i % 2 == 0 ? -step : step); y = cy + (i / 2 - .5F) * 12 * glyphScale; break;
                        case TagLayoutPattern.StaggeredRows: x = cx + (i % 2 - .5F) * step * 1.6F + (i / 2) * 6 * glyphScale; y = cy + (i / 2 - .5F) * 12 * glyphScale; break;
                        case TagLayoutPattern.DiagonalRow: x = cx + (i - 1.5F) * step; y = cy - (i - 1.5F) * 7 * glyphScale; break;
                        default: x = cx + (i - 1.5F) * step; y = cy; break;
                    }
                    g.DrawRectangle(pen, x - 6 * glyphScale, y - 3 * glyphScale, 12 * glyphScale, 6 * glyphScale);
                    g.DrawLine(pen, x, y + 3 * glyphScale, x - 3 * glyphScale, y + 7 * glyphScale);
                    g.FillEllipse(dot, x - 4.5F * glyphScale, y + 6.5F * glyphScale, 3 * glyphScale, 3 * glyphScale);
                }
            }
            if (Focused) ControlPaint.DrawFocusRectangle(g, Rectangle.Inflate(ClientRectangle, -5, -5));
        }
    }
}
