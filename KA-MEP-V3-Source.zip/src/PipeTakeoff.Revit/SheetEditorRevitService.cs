using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace PipeTakeoff.Revit
{
    /// <summary>All Revit access is confined to the external command, outside the detached modal form.</summary>
    internal sealed class SheetEditorRevitService
    {
        private readonly Document document;
        public SheetEditorRevitService(Document document) { this.document = document; }

        internal static string UnsupportedReason(UIDocument uiDocument)
        {
            if (uiDocument == null || uiDocument.Document.IsFamilyDocument) return "Open a Revit project containing sheets first.";
            if (uiDocument.Document.IsReadOnly) return "The project is currently read-only. Open an editable project to change sheet parameters.";
            if (uiDocument.Document.IsModifiable) return "Finish the current Revit transaction before opening Sheet Parameters.";
            return null;
        }

        public SheetEditorSnapshot Read()
        {
            var snapshot = new SheetEditorSnapshot { ProjectTitle = document.Title };
            snapshot.Notes.Add("Sheet instance parameters, including sheet-bound Shared and Project Parameters. Title block and Project Information parameters have separate owners and are not edited here.");
#if REVIT2022 || REVIT2023
            if (!RevitCompat.HasExactSheetCloudApi) snapshot.Notes.Add("This Revit version reports potential sheet clouds. Related primary/dependent view clouds are conservatively protected even if hidden or cropped.");
#endif
            snapshot.Notes.Add("Current Revision is calculated by Revit. Use Additional revisions to manage existing, unissued project revisions on sheets.");
            snapshot.Notes.Add("Numeric values use project units and the current locale. Blank text clears a text value; numeric values cannot be cleared.");
            snapshot.Notes.Add("Apply saves the complete batch in one transaction. Undo once restores all changes.");
            if (document.IsWorkshared) snapshot.Notes.Add("Worksharing ownership is checked again before Apply; Revit makes the final decision when committing the batch.");
            foreach (var id in Revision.GetAllRevisionIds(document))
            {
                var revision = document.GetElement(id) as Revision;
                if (revision == null) continue;
                string number;
                try { number = revision.RevisionNumber ?? ""; }
                catch (Autodesk.Revit.Exceptions.InvalidOperationException) { number = "Per sheet"; }
                snapshot.Revisions.Add(new SheetEditorRevision
                {
                    Id = Id(id), UniqueId = revision.UniqueId, Sequence = revision.SequenceNumber,
                    Number = number, Description = revision.Description ?? "", Date = revision.RevisionDate ?? "", Issued = revision.Issued
                });
            }
            foreach (var sheet in AllSheets().OrderBy(s => s.SheetNumber, StringComparer.CurrentCultureIgnoreCase).ThenBy(s => s.Name, StringComparer.CurrentCultureIgnoreCase))
            {
                var item = new SheetEditorSheet
                {
                    Id = Id(sheet.Id), UniqueId = sheet.UniqueId, Number = sheet.SheetNumber, Name = sheet.Name,
                    IsPlaceholder = sheet.IsPlaceholder, ReadOnlyReason = SheetLockReason(sheet),
                    OriginalAdditionalRevisionIds = new HashSet<long>(sheet.GetAdditionalRevisionIds().Select(Id)),
                    OriginalAllRevisionIds = new HashSet<long>(sheet.GetAllRevisionIds().Select(Id)),
                    CloudRevisionIds = CloudRevisions(sheet)
                };
                item.AdditionalRevisionIds = new HashSet<long>(item.OriginalAdditionalRevisionIds);
                foreach (var revision in snapshot.Revisions)
                    item.RevisionNumbers[revision.Id] = sheet.GetRevisionNumberOnSheet(RevitCompat.ElementId(revision.Id)) ?? "";
                foreach (Parameter parameter in sheet.Parameters)
                {
                    if (parameter == null || parameter.Definition == null) continue;
                    item.Parameters.Add(ReadParameter(parameter));
                }
                item.Parameters = item.Parameters.OrderBy(p => p.IsSheetNumber ? 0 : p.IsSheetName ? 1 : 2)
                    .ThenBy(p => p.Group, StringComparer.CurrentCultureIgnoreCase).ThenBy(p => p.Name, StringComparer.CurrentCultureIgnoreCase)
                    .ThenBy(p => p.Key, StringComparer.Ordinal).ToList();
                snapshot.Sheets.Add(item);
            }
            return snapshot;
        }

        public SheetEditorApplyResult Apply(SheetEditorSnapshot snapshot)
        {
            var result = new SheetEditorApplyResult();
            result.Errors.AddRange(SheetEditorModel.Validate(snapshot));
            if (result.Errors.Count != 0) return result;
            var changed = snapshot.Sheets.Where(s => s.Changed).ToList();
            if (changed.Count == 0) return result;
            if (document.IsReadOnly || document.IsModifiable)
            {
                result.Errors.Add("The document is no longer available for an independent editing transaction. Reopen Sheet Parameters.");
                return result;
            }
            var prepared = new List<PreparedParameter>();
            var sheets = new Dictionary<long, ViewSheet>();
            foreach (var item in changed)
            {
                var sheet = document.GetElement(RevitCompat.ElementId(item.Id)) as ViewSheet;
                if (sheet == null || sheet.UniqueId != item.UniqueId)
                {
                    result.Errors.Add(item.Label + ": the sheet was deleted or replaced. Reopen the editor.");
                    continue;
                }
                sheets[item.Id] = sheet;
                var sheetLock = SheetLockReason(sheet);
                if (!string.IsNullOrEmpty(sheetLock)) result.Errors.Add(item.Label + ": " + sheetLock);
                foreach (var staged in item.Parameters.Where(p => p.Changed))
                {
                    try
                    {
                        var live = FindParameter(sheet, staged);
                        if (live == null) throw new InvalidOperationException("The parameter was removed or its identity changed.");
                        var current = ReadParameter(live);
                        if (current.Key != staged.Key || current.Kind != staged.Kind || current.DataTypeId != staged.DataTypeId ||
                            current.OriginalFingerprint != staged.OriginalFingerprint || current.IsSheetNumber != staged.IsSheetNumber || current.IsSheetName != staged.IsSheetName)
                            throw new InvalidOperationException("The original value or parameter definition changed. Reopen the editor before applying.");
                        if (current.IsReadOnly) throw new InvalidOperationException(current.ReadOnlyReason);
                        var entry = new PreparedParameter { Sheet = item, Staged = staged, Before = DisplayValue(live) };
                        Parse(live, staged.Value, entry);
                        if (!IsEqual(live, entry)) prepared.Add(entry);
                    }
                    catch (Autodesk.Revit.Exceptions.OperationCanceledException) { throw; }
                    catch (Exception ex) { result.Errors.Add(item.Label + " / " + staged.Name + ": " + ex.Message); }
                }
                if (item.RevisionsChanged) ValidateRevisions(snapshot, item, sheet, result.Errors);
            }
            ValidateFinalNumbers(prepared, result.Errors);
            if (result.Errors.Count != 0) return result;
            var revisionChanges = changed.Where(s => s.RevisionsChanged).ToList();
            if (prepared.Count == 0 && revisionChanges.Count == 0)
            {
                result.Warnings.Add("The entered values resolve to the existing model values; no changes were needed.");
                return result;
            }
            var originalRevisionDescriptions = revisionChanges.ToDictionary(s => s.Id, s => DescribeRevisions(sheets[s.Id]));
            var actualDetails = new List<string>();
            using (var transaction = new Transaction(document, "KA MEP - Sheet Parameters"))
            {
                try
                {
                    if (transaction.Start() != TransactionStatus.Started) throw new InvalidOperationException("Revit could not start the sheet editing transaction.");
                    transaction.SetFailureHandlingOptions(transaction.GetFailureHandlingOptions()
                        .SetFailuresPreprocessor(new SheetFailureHandler(result)).SetClearAfterRollback(true).SetForcedModalHandling(true));
                    // Free every changing sheet number first, so exchanges such as A101 <-> A102 are valid.
                    var usedNumbers = new HashSet<string>(AllSheets().Select(s => s.SheetNumber), StringComparer.OrdinalIgnoreCase);
                    foreach (var entry in prepared.Where(p => p.Staged.IsSheetNumber))
                    {
                        string temporary;
                        do { temporary = "KA-MEP-TEMP-" + Guid.NewGuid().ToString("N"); } while (!usedNumbers.Add(temporary));
                        sheets[entry.Sheet.Id].SheetNumber = temporary;
                    }
                    foreach (var entry in prepared)
                    {
                        var parameter = FindParameter(sheets[entry.Sheet.Id], entry.Staged);
                        if (parameter == null || ParameterLockReason(parameter) != null)
                            throw new InvalidOperationException(entry.Sheet.Label + " / " + entry.Staged.Name + ": parameter became unavailable or read-only.");
                        if (!Set(parameter, entry) && !IsEqual(parameter, entry))
                            throw new InvalidOperationException(entry.Sheet.Label + " / " + entry.Staged.Name + ": Revit rejected the entered value.");
                    }
                    foreach (var item in revisionChanges)
                        sheets[item.Id].SetAdditionalRevisionIds(item.AdditionalRevisionIds.Select(x => RevitCompat.ElementId(x)).ToList());
                    document.Regenerate();
                    // Verify the requested batch before committing. Any rejected or constrained assignment rolls everything back.
                    foreach (var entry in prepared)
                    {
                        var parameter = FindParameter(sheets[entry.Sheet.Id], entry.Staged);
                        if (parameter == null || !IsEqual(parameter, entry))
                            throw new InvalidOperationException(entry.Sheet.Label + " / " + entry.Staged.Name + ": Revit did not retain the requested value.");
                    }
                    foreach (var item in revisionChanges)
                        if (!item.AdditionalRevisionIds.SetEquals(sheets[item.Id].GetAdditionalRevisionIds().Select(Id)))
                            throw new InvalidOperationException(item.Label + ": Revit did not retain the requested additional revisions.");
                    var status = transaction.Commit();
                    if (status != TransactionStatus.Committed)
                    {
                        if (transaction.GetStatus() == TransactionStatus.Started) transaction.RollBack();
                        result.Errors.Add("Revit rolled back the complete sheet editing transaction. No changes from this batch were saved.");
                        return result;
                    }
                    // From this point onwards, reporting must never turn a saved batch into a claimed rollback.
                    result.Committed = true;
                    result.ParametersChanged = prepared.Count;
                    result.RevisionSheetsChanged = revisionChanges.Count;
                    result.SheetsChanged = prepared.Select(p => p.Sheet.Id).Union(revisionChanges.Select(s => s.Id)).Count();
                }
                catch (Exception ex)
                {
                    if (result.Committed)
                    {
                        result.Warnings.Add("Changes were committed, but completion information could not be collected: " + ex.Message);
                        return result;
                    }
                    if (transaction.GetStatus() == TransactionStatus.Started) transaction.RollBack();
                    result.Errors.Add("The complete batch was cancelled; no sheet changes were saved. " + ex.Message);
                    return result;
                }
            }
            // Read actual post-commit values, including changes made by Revit updaters. No modifications occur here.
            foreach (var entry in prepared)
            {
                try
                {
                    var sheet = document.GetElement(RevitCompat.ElementId(entry.Sheet.Id)) as ViewSheet;
                    var parameter = sheet == null ? null : FindParameter(sheet, entry.Staged);
                    if (parameter == null) throw new InvalidOperationException("Changed sheet or parameter is no longer available for reporting.");
                    actualDetails.Add("Sheet " + Quote(entry.Sheet.Number) + " [" + entry.Sheet.Id + "] / " + entry.Staged.Name + " [" + entry.Staged.Key + "]: " + Quote(entry.Before) + " -> " + Quote(DisplayValue(parameter)));
                    if (!IsEqual(parameter, entry)) result.Warnings.Add(entry.Sheet.Label + " / " + entry.Staged.Name + ": a Revit updater changed the requested value during commit; the report shows the saved value.");
                }
                catch (Exception ex) { result.Warnings.Add(entry.Sheet.Label + " / " + entry.Staged.Name + ": saved, but the actual final value could not be read: " + ex.Message); }
            }
            foreach (var item in revisionChanges)
            {
                try
                {
                    var sheet = document.GetElement(RevitCompat.ElementId(item.Id)) as ViewSheet;
                    if (sheet == null) throw new InvalidOperationException("The sheet is no longer available for reporting.");
                    actualDetails.Add("Sheet " + Quote(item.Number) + " [" + item.Id + "] / revisions: " + originalRevisionDescriptions[item.Id] + " -> " + DescribeRevisions(sheet));
                    if (!item.AdditionalRevisionIds.SetEquals(sheet.GetAdditionalRevisionIds().Select(Id)))
                        result.Warnings.Add(item.Label + ": a Revit updater changed the revision selection during commit; the report shows the saved values.");
                }
                catch (Exception ex) { result.Warnings.Add(item.Label + ": revisions saved, but final values could not be read: " + ex.Message); }
            }
            result.Details.AddRange(actualDetails);
            return result;
        }

        private SheetEditorParameter ReadParameter(Parameter parameter)
        {
            var definition = parameter.Definition;
            string spec = definition.GetDataType().TypeId;
            var item = new SheetEditorParameter
            {
                Id = Id(parameter.Id), SharedGuid = parameter.IsShared ? parameter.GUID.ToString("D") : null,
                Key = ParameterKey(parameter), Name = definition.Name, DataTypeId = spec,
                Kind = Kind(parameter), IsSheetNumber = parameter.Id == new ElementId(BuiltInParameter.SHEET_NUMBER),
                IsSheetName = parameter.Id == new ElementId(BuiltInParameter.SHEET_NAME)
            };
            try { item.Group = LabelUtils.GetLabelForGroup(definition.GetGroupTypeId()); }
            catch { item.Group = "Other"; }
            try
            {
                item.OriginalValue = item.Value = DisplayValue(parameter);
                item.OriginalFingerprint = Fingerprint(parameter);
                item.ReadOnlyReason = ParameterLockReason(parameter);
                if (item.Kind == SheetParameterKind.Number)
                {
                    var type = definition.GetDataType();
                    item.UnitHint = UnitUtils.IsMeasurableSpec(type)
                        ? "Project units: " + LabelUtils.GetLabelForUnit(document.GetUnits().GetFormatOptions(type).GetUnitTypeId())
                        : "Number (current locale)";
                }
                else item.UnitHint = item.Kind == SheetParameterKind.YesNo ? "Yes / No" : item.Kind == SheetParameterKind.Integer ? "Whole number" : "";
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                item.OriginalValue = item.Value = "[Unable to read]";
                item.ReadOnlyReason = "Revit could not safely read this parameter: " + ex.Message;
            }
            item.IsReadOnly = item.ReadOnlyReason != null;
            return item;
        }

        private string SheetLockReason(ViewSheet sheet)
        {
            if (document.IsWorkshared)
            {
                string owner;
                if (WorksharingUtils.GetCheckoutStatus(document, sheet.Id, out owner) == CheckoutStatus.OwnedByOtherUser)
                    return "Owned by another Revit user" + (string.IsNullOrWhiteSpace(owner) ? "." : ": " + owner + ".");
            }
            return null;
        }

        private static string ParameterLockReason(Parameter parameter)
        {
            var definition = parameter.Definition as InternalDefinition;
            string builtIn = definition == null ? "" : definition.BuiltInParameter.ToString();
            if (builtIn.StartsWith("SHEET_CURRENT_REVISION", StringComparison.Ordinal)) return "Calculated by Revit from revisions on this sheet.";
            if (builtIn == "SHEET_REVISIONS_ON_SHEET") return "Use the Revisions tab to edit additional revisions.";
            if (parameter.IsReadOnly) return "Read-only, formula-driven, or calculated by Revit.";
            if (parameter.IsShared && !parameter.UserModifiable) return "This shared parameter was defined as not user-modifiable.";
            if (parameter.GetAssociatedGlobalParameter() != ElementId.InvalidElementId) return "Controlled by a global parameter.";
            if (parameter.StorageType == StorageType.ElementId) return "Element reference: requires a Revit-specific selection editor.";
            if (parameter.StorageType == StorageType.None) return "This parameter has no directly editable value.";
            return null;
        }

        private static SheetParameterKind Kind(Parameter parameter)
        {
            switch (parameter.StorageType)
            {
                case StorageType.String: return SheetParameterKind.Text;
                case StorageType.Integer: return parameter.Definition.GetDataType() == SpecTypeId.Boolean.YesNo ? SheetParameterKind.YesNo : SheetParameterKind.Integer;
                case StorageType.Double: return SheetParameterKind.Number;
                case StorageType.ElementId: return SheetParameterKind.ElementReference;
                default: return SheetParameterKind.Unsupported;
            }
        }

        private string DisplayValue(Parameter parameter)
        {
            if (!parameter.HasValue) return "";
            switch (parameter.StorageType)
            {
                case StorageType.String: return parameter.AsString() ?? "";
                case StorageType.Integer: return Kind(parameter) == SheetParameterKind.YesNo ? (parameter.AsInteger() == 0 ? "No" : "Yes") : parameter.AsInteger().ToString(CultureInfo.CurrentCulture);
                case StorageType.Double:
                    var spec = parameter.Definition.GetDataType();
                    if (UnitUtils.IsMeasurableSpec(spec)) return UnitFormatUtils.Format(document.GetUnits(), spec, parameter.AsDouble(), true);
                    return parameter.AsDouble().ToString("G17", CultureInfo.CurrentCulture);
                case StorageType.ElementId:
                    var display = parameter.AsValueString();
                    if (!string.IsNullOrEmpty(display)) return display;
                    var id = parameter.AsElementId();
                    if (id == ElementId.InvalidElementId) return "";
                    var element = document.GetElement(id);
                    return element == null ? "ID " + Id(id).ToString(CultureInfo.InvariantCulture) : element.Name + " [" + Id(id) + "]";
                default: return parameter.AsValueString() ?? "";
            }
        }

        private static string Fingerprint(Parameter parameter)
        {
            string raw;
            switch (parameter.StorageType)
            {
                case StorageType.String: raw = parameter.AsString() ?? ""; break;
                case StorageType.Integer: raw = parameter.AsInteger().ToString(CultureInfo.InvariantCulture); break;
                case StorageType.Double: raw = parameter.AsDouble().ToString("R", CultureInfo.InvariantCulture); break;
                case StorageType.ElementId: raw = Id(parameter.AsElementId()).ToString(CultureInfo.InvariantCulture); break;
                default: raw = ""; break;
            }
            string data = ParameterKey(parameter) + "\n" + RevitCompat.Id(parameter.Id).ToString(CultureInfo.InvariantCulture) + "\n" + parameter.Definition.Name + "\n" +
                parameter.StorageType + "\n" + parameter.Definition.GetDataType().TypeId + "\n" + parameter.HasValue + "\n" + raw;
            using (var hash = SHA256.Create()) return Convert.ToBase64String(hash.ComputeHash(Encoding.UTF8.GetBytes(data)));
        }

        private static string ParameterKey(Parameter parameter)
        {
            return parameter.IsShared ? "guid:" + parameter.GUID.ToString("D") : "id:" + Id(parameter.Id).ToString(CultureInfo.InvariantCulture);
        }

        private static Parameter FindParameter(ViewSheet sheet, SheetEditorParameter staged)
        {
            foreach (Parameter parameter in sheet.Parameters)
                if (Id(parameter.Id) == staged.Id && ParameterKey(parameter) == staged.Key &&
                    string.Equals(parameter.IsShared ? parameter.GUID.ToString("D") : null, staged.SharedGuid, StringComparison.OrdinalIgnoreCase)) return parameter;
            return null;
        }

        private void Parse(Parameter parameter, string text, PreparedParameter entry)
        {
            text = text ?? "";
            switch (parameter.StorageType)
            {
                case StorageType.String: entry.Text = text; return;
                case StorageType.Integer:
                    if (Kind(parameter) == SheetParameterKind.YesNo)
                    {
                        bool boolean;
                        if (!SheetEditorModel.TryYesNo(text, out boolean)) throw new InvalidOperationException("Enter Yes or No.");
                        entry.Integer = boolean ? 1 : 0;
                    }
                    else if (!int.TryParse(text, NumberStyles.Integer, CultureInfo.CurrentCulture, out entry.Integer))
                        throw new InvalidOperationException("Enter a whole number within the 32-bit integer range.");
                    return;
                case StorageType.Double:
                    var spec = parameter.Definition.GetDataType();
                    if (UnitUtils.IsMeasurableSpec(spec))
                    {
                        string parseError;
                        if (!UnitFormatUtils.TryParse(document.GetUnits(), spec, text, out entry.Number, out parseError))
                            throw new InvalidOperationException("Invalid project-unit value. " + parseError);
                    }
                    else if (!double.TryParse(text, NumberStyles.Float, CultureInfo.CurrentCulture, out entry.Number))
                        throw new InvalidOperationException("Enter a number using the current locale.");
                    if (double.IsInfinity(entry.Number) || double.IsNaN(entry.Number)) throw new InvalidOperationException("Enter a finite number.");
                    return;
                default: throw new InvalidOperationException("This parameter cannot be edited as a raw value.");
            }
        }

        private static bool Set(Parameter parameter, PreparedParameter entry)
        {
            switch (parameter.StorageType)
            {
                case StorageType.String: return parameter.Set(entry.Text);
                case StorageType.Integer: return parameter.Set(entry.Integer);
                case StorageType.Double: return parameter.Set(entry.Number);
                default: return false;
            }
        }

        private static bool IsEqual(Parameter parameter, PreparedParameter entry)
        {
            if (parameter.StorageType == StorageType.String)
                return string.Equals(parameter.AsString() ?? "", entry.Text ?? "", StringComparison.Ordinal);
            if (!parameter.HasValue) return false;
            switch (parameter.StorageType)
            {
                case StorageType.Integer: return parameter.AsInteger() == entry.Integer;
                case StorageType.Double: return parameter.AsDouble().Equals(entry.Number);
                default: return false;
            }
        }

        private void ValidateFinalNumbers(IReadOnlyList<PreparedParameter> prepared, List<string> errors)
        {
            var changes = prepared.Where(p => p.Staged.IsSheetNumber).ToDictionary(p => p.Sheet.Id, p => p.Text);
            if (changes.Count == 0) return;
            var numbers = AllSheets().Select(s => new { Sheet = s, Number = changes.ContainsKey(Id(s.Id)) ? changes[Id(s.Id)] : s.SheetNumber });
            foreach (var group in numbers.GroupBy(n => n.Number, StringComparer.OrdinalIgnoreCase).Where(g => g.Count() > 1))
                errors.Add("Final sheet number '" + group.Key + "' is duplicated in the current model: " + string.Join(", ", group.Select(s => s.Sheet.Name)));
        }

        private void ValidateRevisions(SheetEditorSnapshot snapshot, SheetEditorSheet item, ViewSheet sheet, List<string> errors)
        {
            if (!item.OriginalAdditionalRevisionIds.SetEquals(sheet.GetAdditionalRevisionIds().Select(Id)) ||
                !item.OriginalAllRevisionIds.SetEquals(sheet.GetAllRevisionIds().Select(Id)) || !item.CloudRevisionIds.SetEquals(CloudRevisions(sheet)))
            {
                errors.Add(item.Label + ": the sheet's revisions or visible revision clouds changed. Reopen the editor.");
                return;
            }
            foreach (long id in item.OriginalAdditionalRevisionIds.Union(item.AdditionalRevisionIds))
            {
                var revision = document.GetElement(RevitCompat.ElementId(id)) as Revision;
                var original = snapshot.Revisions.FirstOrDefault(r => r.Id == id);
                if (revision == null || original == null || revision.UniqueId != original.UniqueId || revision.SequenceNumber != original.Sequence ||
                    revision.Description != original.Description || revision.RevisionDate != original.Date || revision.Issued != original.Issued)
                {
                    errors.Add(item.Label + ": revision " + id + " changed or was removed. Reopen the editor.");
                    continue;
                }
                if (item.OriginalAdditionalRevisionIds.Contains(id) == item.AdditionalRevisionIds.Contains(id)) continue;
                if (revision.Issued) errors.Add(item.Label + ": issued revision " + revision.SequenceNumber + " is protected.");
                if (item.CloudRevisionIds.Contains(id)) errors.Add(item.Label + ": revision " + revision.SequenceNumber + " is required by revision clouds and is protected.");
            }
        }

        private HashSet<long> CloudRevisions(ViewSheet sheet)
        {
            var revisions = new HashSet<long>();
            foreach (var id in RevitCompat.RevisionCloudIds(sheet))
            {
                var cloud = document.GetElement(id) as RevisionCloud;
                if (cloud != null) revisions.Add(Id(cloud.RevisionId));
            }
#if REVIT2022 || REVIT2023
            // A hidden/cropped cloud can be returned by GetSheetIds without its
            // revision participating in this sheet. Never display that revision
            // as checked merely because its view has been placed on the sheet.
            if (!RevitCompat.HasExactSheetCloudApi)
                revisions.IntersectWith(sheet.GetAllRevisionIds().Select(Id));
#endif
            return revisions;
        }

        private string DescribeRevisions(ViewSheet sheet)
        {
            var additional = new HashSet<long>(sheet.GetAdditionalRevisionIds().Select(Id));
            var entries = new List<string>();
            foreach (var id in sheet.GetAllRevisionIds())
            {
                var revision = document.GetElement(id) as Revision;
                if (revision != null) entries.Add("#" + revision.SequenceNumber + " [" + Id(id) + "] " + Quote(sheet.GetRevisionNumberOnSheet(id) ?? "") + " " + Quote(revision.Description) + (additional.Contains(Id(id)) ? " (additional)" : " (cloud)"));
            }
            return "[" + string.Join("; ", entries) + "]";
        }

        private IEnumerable<ViewSheet> AllSheets() { return new FilteredElementCollector(document).OfClass(typeof(ViewSheet)).Cast<ViewSheet>(); }
        private static long Id(ElementId id) { return RevitCompat.Id(id); }
        private static string Quote(string text) { return "\"" + (text ?? "").Replace("\\", "\\\\").Replace("\r", "\\r").Replace("\n", "\\n").Replace("\"", "\\\"") + "\""; }

        private sealed class PreparedParameter
        {
            public SheetEditorSheet Sheet;
            public SheetEditorParameter Staged;
            public string Before;
            public string Text;
            public int Integer;
            public double Number;
        }

        private sealed class SheetFailureHandler : IFailuresPreprocessor
        {
            private readonly SheetEditorApplyResult result;
            public SheetFailureHandler(SheetEditorApplyResult result) { this.result = result; }
            public FailureProcessingResult PreprocessFailures(FailuresAccessor accessor)
            {
                bool error = false;
                foreach (var failure in accessor.GetFailureMessages())
                {
                    if (failure.GetSeverity() == FailureSeverity.Warning)
                    {
                        result.Warnings.Add("Revit: " + failure.GetDescriptionText());
                        accessor.DeleteWarning(failure);
                    }
                    else { result.Errors.Add("Revit: " + failure.GetDescriptionText()); error = true; }
                }
                return error ? FailureProcessingResult.ProceedWithRollBack : FailureProcessingResult.Continue;
            }
        }
    }
}
