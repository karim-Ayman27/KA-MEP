using System;
using System.Drawing;
using System.Windows.Forms;

namespace PipeTakeoff.Revit
{
    public enum HubAction { None, Pipes, Ducts, CableTrays, Conduits, Sheets, Tags, Info, SheetParameters, ModelReview, Spaces, Clashes, Claude }

    /// <summary>Launches one modal tool; command dispatch happens after this window closes.</summary>
    public sealed class HubForm : Form
    {
        public HubAction SelectedAction { get; private set; }

        public HubForm()
        {
            KaTheme.ApplyForm(this, "Workspace", 1060, 660);
            MinimumSize = new Size(820, 540);
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Padding = new Padding(0), Margin = new Padding(0) };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 28F));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 72F));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            Controls.Add(layout);
            layout.Controls.Add(BuildBrand(), 0, 0);
            layout.Controls.Add(BuildWorkspace(), 1, 0);
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            KaTheme.ClampToScreen(this);
        }

        private Control BuildBrand()
        {
            var brand = new TableLayoutPanel
            {
                Dock = DockStyle.Fill, BackColor = KaTheme.Navy, ColumnCount = 1, RowCount = 6,
                Padding = new Padding(25, 28, 25, 22), Margin = new Padding(0)
            };
            brand.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            brand.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            brand.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            brand.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            brand.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            brand.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            brand.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var identity = new TableLayoutPanel
            {
                AutoSize = true, Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1,
                Margin = new Padding(0, 0, 0, 12)
            };
            identity.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 76F));
            identity.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            var logo = new PictureBox
            {
                Name = "KAMEPBrandLogo", Image = KAMEP.Branding.BrandImages.Logo(128),
                SizeMode = PictureBoxSizeMode.Zoom, Size = new Size(64, 64), BackColor = Color.Transparent,
                Margin = new Padding(0, 0, 12, 0), Anchor = AnchorStyles.Left
            };
            logo.Disposed += delegate { if (logo.Image != null) logo.Image.Dispose(); };
            identity.Controls.Add(logo, 0, 0);
            identity.Controls.Add(new Label
            {
                Text = "KA MEP", Font = new Font("Segoe UI", 20F, FontStyle.Bold), ForeColor = Color.White,
                AutoSize = true, Anchor = AnchorStyles.Left, Margin = new Padding(0)
            }, 1, 0);
            brand.Controls.Add(identity, 0, 0);
            brand.Controls.Add(new Label
            {
                Text = KAMEP.Branding.ReleaseIdentity.VersionLabel + "\r\nBuild " + KAMEP.Branding.ReleaseIdentity.BuildId + "\r\nMEP WORKSPACE", Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = KaTheme.Teal, AutoSize = true, Dock = DockStyle.Fill, Margin = new Padding(0, 0, 0, 26)
            }, 0, 1);
            brand.Controls.Add(new Panel { BackColor = KaTheme.Teal, Height = 3, Width = 46, Margin = new Padding(0, 0, 0, 24) }, 0, 2);
            brand.Controls.Add(new Label
            {
                Text = "From your model\r\nto your next deliverable.",
                Font = new Font("Segoe UI", 17F), ForeColor = Color.White,
                AutoSize = true, Dock = DockStyle.Fill, Margin = new Padding(0)
            }, 0, 3);
            brand.Controls.Add(new Label
            {
                Text = "CREATED BY\r\nKarim Ayman\r\n\r\nAutodesk Revit 2022.1+ / 2023\r\n2024 / 2025 / 2026 / 2027",
                ForeColor = Color.FromArgb(183, 204, 218), AutoSize = true, Dock = DockStyle.Fill, Margin = new Padding(0)
            }, 0, 5);
            return brand;
        }

        private Control BuildWorkspace()
        {
            var main = new TableLayoutPanel
            {
                Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, Padding = new Padding(25, 25, 25, 19), Margin = new Padding(0)
            };
            main.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            main.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            main.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            main.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            main.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            main.Controls.Add(new Label
            {
                Text = "Your MEP workspace", Font = new Font("Segoe UI", 22F, FontStyle.Bold),
                AutoSize = true, Dock = DockStyle.Fill, Margin = new Padding(0, 0, 0, 5)
            }, 0, 0);
            var hint = KaTheme.Hint("Choose a tool to work with the active Revit document.");
            hint.Margin = new Padding(0, 0, 0, 19);
            main.Controls.Add(hint, 0, 1);

            var viewport = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Margin = new Padding(0) };
            var cards = new TableLayoutPanel
            {
                Dock = DockStyle.Top, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink,
                ColumnCount = 1, RowCount = 11, Margin = new Padding(0)
            };
            cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            for (int row = 0; row < cards.RowCount; row++) cards.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            cards.Controls.Add(Card("01", "Clash Manager", "Import HTML clash reports, map element IDs, open focused 3D views and refresh hard-clash status. Export a formatted Excel review.", "OPEN CLASH MANAGER", HubAction.Clashes), 0, 0);
            cards.Controls.Add(Card("02", "HVAC Spaces", "Review room names, areas and sampled floor-to-ceiling or slab clear heights from architectural links. Export a formatted Excel report.", "OPEN HVAC SPACES", HubAction.Spaces), 0, 1);
            cards.Controls.Add(Card("03", "Sheet Parameters", "Review sheet values, edit one or many sheets, and manage additional revisions before applying.", "OPEN SHEET PARAMETERS", HubAction.SheetParameters), 0, 2);
            cards.Controls.Add(Card("04", "Tag Assistant", "Place tags near selected elements, review each target and limit distance and count. Arrange existing tags or choose other patterns.", "OPEN TAG ASSISTANT", HubAction.Tags), 0, 3);
            cards.Controls.Add(Card("05", "Pipe takeoff", "Filter parameters, group equal diameters and export quantities to Excel.", "OPEN PIPE TAKEOFF", HubAction.Pipes), 0, 4);
            cards.Controls.Add(Card("06", "Duct takeoff", "Review ducts and fittings by shape, size, system, length and known area.", "OPEN DUCT TAKEOFF", HubAction.Ducts), 0, 5);
            cards.Controls.Add(Card("07", "Cable tray takeoff", "Measure cable trays, count fittings and group by section, service, family or type.", "OPEN CABLE TRAY TAKEOFF", HubAction.CableTrays), 0, 6);
            cards.Controls.Add(Card("08", "Conduit takeoff", "Measure conduits, count fittings and export filtered quantities by diameter.", "OPEN CONDUIT TAKEOFF", HubAction.Conduits), 0, 7);
            cards.Controls.Add(Card("09", "Sheet export", "Choose sheet parameters for file names and configure PDF and DWG output.", "OPEN SHEET EXPORT", HubAction.Sheets), 0, 8);
            cards.Controls.Add(Card("10", "Model Review & Cleanup", "Review CAD, unplaced views, potential duplicates and warnings. Refresh the health score and preview cleanup.", "OPEN MODEL REVIEW", HubAction.ModelReview), 0, 9);
            cards.Controls.Add(Card("11", "Claude Desktop / MCP", "Enable read-only access to project data, selected elements, parameters, sheets and warnings from Claude Desktop on this computer.", "OPEN CLAUDE MCP", HubAction.Claude), 0, 10);
            viewport.Controls.Add(cards);
            main.Controls.Add(viewport, 0, 2);
            var footer = new TableLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, ColumnCount = 2, RowCount = 1, Margin = new Padding(0, 14, 0, 0) };
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            var info = KaTheme.Button("Info · Karim Ayman");
            info.Click += delegate { Choose(HubAction.Info); };
            footer.Controls.Add(info, 0, 0);
            var close = KaTheme.Button("Close");
            close.DialogResult = DialogResult.Cancel;
            footer.Controls.Add(close, 1, 0);
            main.Controls.Add(footer, 0, 3);
            CancelButton = close;
            return main;
        }

        private Control Card(string number, string title, string description, string action, HubAction destination)
        {
            var card = new TableLayoutPanel
            {
                BackColor = Color.White, Dock = DockStyle.Fill, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink,
                ColumnCount = 2, RowCount = 3,
                Padding = new Padding(15, 11, 15, 10), Margin = new Padding(0, 0, 0, 10)
            };
            card.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            card.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            for (int row = 0; row < card.RowCount; row++) card.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var badge = new Label
            {
                Text = number, ForeColor = Color.FromArgb(0, 128, 119), AutoSize = true,
                Font = new Font("Segoe UI", 13F, FontStyle.Bold), Margin = new Padding(0, 3, 6, 0)
            };
            card.Controls.Add(badge, 0, 0);
            card.Controls.Add(new Label
            {
                Text = title, AutoSize = true, Font = new Font("Segoe UI", 13F, FontStyle.Bold),
                Dock = DockStyle.Fill, Margin = new Padding(0, 0, 0, 3)
            }, 1, 0);
            var hint = KaTheme.Hint(description);
            // Constrain wrapping before the outer table measures the card's preferred height.
            card.Layout += delegate
            {
                int width = Math.Max(1, card.ClientSize.Width - card.Padding.Horizontal
                    - badge.PreferredSize.Width - badge.Margin.Horizontal - hint.Margin.Horizontal);
                if (hint.MaximumSize.Width != width) hint.MaximumSize = new Size(width, 0);
            };
            card.Controls.Add(hint, 1, 1);
            var open = KaTheme.Button(action);
            open.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            open.ForeColor = Color.FromArgb(0, 118, 108);
            open.Margin = new Padding(0, 6, 0, 0);
            open.Click += delegate { Choose(destination); };
            card.Controls.Add(open, 1, 2);
            return card;
        }

        private void Choose(HubAction action)
        {
            SelectedAction = action;
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
