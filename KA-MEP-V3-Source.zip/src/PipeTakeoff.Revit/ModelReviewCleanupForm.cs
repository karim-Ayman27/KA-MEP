using System;
using System.Drawing;
using System.Windows.Forms;

namespace PipeTakeoff.Revit
{
    internal sealed class ModelReviewCleanupForm : Form
    {
        internal ModelReviewCleanupForm(ReviewCleanupPlan plan)
        {
            KaTheme.ApplyForm(this, "Confirm cleanup", 900, 650);
            Name = "ModelReviewCleanupForm";
            var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, Padding = new Padding(14) };
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var viewport = new Panel { Name = "CleanupViewport", Dock = DockStyle.Fill, AutoScroll = true, Margin = new Padding(0) };
            var layout = new TableLayoutPanel { Name = "CleanupWorkspace", Dock = DockStyle.Top, ColumnCount = 1, RowCount = 3, Padding = new Padding(4), Margin = new Padding(0) };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            layout.Controls.Add(KaTheme.Header("Review deletion impact", plan.RequestedIds.Count + " selected elements / " +
                plan.AffectedIds.Count + " total elements will be deleted, including dependencies."), 0, 0);
            layout.Controls.Add(KaTheme.Hint("Read the complete list below. Views may contain annotations or other dependent elements. " +
                "The deletion is one Revit Undo operation. Cancel keeps the model unchanged."), 0, 1);
            layout.Controls.Add(new TextBox { Name = "CleanupImpactList", Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Both,
                WordWrap = false, Dock = DockStyle.Fill, Text = string.Join(Environment.NewLine, plan.Lines), BackColor = Color.White }, 0, 2);
            viewport.Controls.Add(layout);
            bool sizing = false;
            viewport.Layout += delegate
            {
                if (sizing) return;
                sizing = true;
                try { layout.Height = Math.Max(viewport.ClientSize.Height, Font.Height * 16); }
                finally { sizing = false; }
            };
            root.Controls.Add(viewport, 0, 0);
            var actions = new TableLayoutPanel { Name = "CleanupActions", Dock = DockStyle.Fill, AutoSize = true, ColumnCount = 1, RowCount = 2, Margin = new Padding(0) };
            actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            actions.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            actions.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var entry = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = true };
            entry.Controls.Add(KaTheme.Hint("Type DELETE to confirm this exact list:"));
            var text = new TextBox { Name = "CleanupConfirmation", Width = 155, Margin = new Padding(10, 5, 5, 5) };
            entry.Controls.Add(text);
            actions.Controls.Add(entry, 0, 0);
            var footer = KaTheme.Flow();
            footer.Dock = DockStyle.Fill;
            var cancel = KaTheme.Button("Cancel");
            cancel.Name = "CleanupCancel";
            cancel.DialogResult = DialogResult.Cancel;
            var apply = KaTheme.Button("Delete listed elements", true);
            apply.Name = "CleanupApply";
            apply.Enabled = false;
            apply.Click += delegate { DialogResult = DialogResult.OK; Close(); };
            text.TextChanged += delegate { apply.Enabled = string.Equals(text.Text, "DELETE", StringComparison.Ordinal); };
            footer.Controls.Add(cancel);
            footer.Controls.Add(apply);
            actions.Controls.Add(footer, 0, 1);
            root.Controls.Add(actions, 0, 1);
            Controls.Add(root);
            CancelButton = cancel;
            AcceptButton = cancel;
            Shown += delegate { KaTheme.ClampToScreen(this); };
        }
    }
}
