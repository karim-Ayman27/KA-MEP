using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using PipeTakeoff.Core.Mcp;
using TaskDialog = Autodesk.Revit.UI.TaskDialog;

namespace PipeTakeoff.Revit
{
    [Transaction(TransactionMode.Manual)]
    public sealed class McpConnectionCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData data, ref string message, ElementSet elements)
        {
            try
            {
                if (data.Application.ActiveUIDocument == null || data.Application.ActiveUIDocument.Document.IsFamilyDocument)
                { TaskDialog.Show("KA MEP - Claude Desktop", "Open a Revit project first."); return Result.Cancelled; }
                McpConnectionController.Open(data.Application); return Result.Succeeded;
            }
            catch (Exception ex) { message=ex.Message; TaskDialog.Show("KA MEP - Claude Desktop",message); return Result.Failed; }
        }
    }

    /// <summary>Explicit, document-bound read-only access. No socket worker ever reads a Revit object.</summary>
    internal sealed class McpConnectionController : IExternalEventHandler
    {
        private sealed class Work
        {
            internal McpWireRequest Request;
            internal string Session;
            internal CancellationToken Cancellation;
            internal readonly TaskCompletionSource<McpWireResponse> Completion = new TaskCompletionSource<McpWireResponse>(TaskCreationOptions.RunContinuationsAsynchronously);
        }
        private static McpConnectionController _current;
        private readonly object _gate=new object();
        private readonly Document _document;
        private readonly string _title, _year, _profilePath, _helperPath;
        private readonly McpConnectionForm _form=new McpConnectionForm();
        private readonly List<Work> _queue=new List<Work>();
        private ExternalEvent _event;
        private McpLoopbackServer _server;
        private FileStream _lease;
        private bool _closed, _enabled, _starting, _raised, _executing, _pumpPosted;
        private string _session;
        private long _revision;
        private int _completed;

        private McpConnectionController(UIApplication app)
        {
            _document=app.ActiveUIDocument.Document; _title=_document.Title; _year=app.Application.VersionNumber;
            var local=Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            if (string.IsNullOrWhiteSpace(local)) throw new InvalidOperationException("The current user's local application-data folder is unavailable.");
            _profilePath=Path.Combine(local,"KAMEP","MCP","connection-"+_year+".json");
            _helperPath=Path.Combine(Path.GetDirectoryName(typeof(McpConnectionCommand).Assembly.Location),"KAMEP.Mcp.Server.exe");
            try
            {
                _event=ExternalEvent.Create(this);
                _form.SetContext(_title,_profilePath,_helperPath,HelperAvailable());
                _form.EnableRequested+=StartRequested;
                _form.StopRequested+=Stop;
                _form.SaveConfigRequested+=SaveConfiguration;
                _form.FormClosed+=delegate
                {
                    lock(_gate) _closed=true;
                    Stop();
                    if (!_executing && !_raised) DisposeEvent();
                    if (ReferenceEquals(_current,this)) _current=null;
                };
                _form.Show(new Owner(app.MainWindowHandle));
            }
            catch { _form.Dispose(); DisposeEvent(); throw; }
        }
        public static void Open(UIApplication app)
        {
            if (_current!=null && !_current._closed)
            {
                if (_current._document.Equals(app.ActiveUIDocument.Document))
                { _current._form.WindowState=FormWindowState.Normal; _current._form.Activate(); return; }
                _current._form.Close();
            }
            _current=new McpConnectionController(app);
        }
        public static void NotifyDocumentChanged(Document document)
        {
            var current=_current;
            if (current!=null && !current._closed && current._document.Equals(document)) Interlocked.Increment(ref current._revision);
        }
        public static void NotifyDocumentClosing(Document document)
        {
            var current=_current;
            if (current!=null && !current._closed && current._document.Equals(document)) current._form.Close();
        }
        public static void Shutdown()
        {
            var current=_current; _current=null;
            if (current==null) return;
            current._form.Close(); current.DisposeEvent();
        }
        public string GetName() { return "KA MEP Claude Desktop read-only requests"; }

        private bool HelperAvailable()
        {
            if (!File.Exists(_helperPath) || !File.Exists(_helperPath+".config")) return false;
            try
            {
                var identity=typeof(McpConnectionCommand).Assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>();
                return identity!=null && FileVersionInfo.GetVersionInfo(_helperPath).ProductVersion==identity.InformationalVersion;
            }
            catch { return false; }
        }
        private void StartRequested()
        {
            lock(_gate) { if (_closed || _enabled || _starting) return; _starting=true; }
            _form.SetState(false,"Waiting for Revit to enable the connection for this project…"); PostPump();
        }
        private void Start(UIApplication app)
        {
            RequireProject(app);
            if (!HelperAvailable()) throw new InvalidOperationException("The matching Claude Desktop helper is missing or outdated. Repair the KA MEP installation.");
            PreparePrivateDirectory(Path.GetDirectoryName(_profilePath));
            AssertRegularFile(_profilePath); AssertRegularFile(_profilePath+".lock");
            try { _lease=new FileStream(_profilePath+".lock",FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None); }
            catch(IOException) { throw new InvalidOperationException("Another Revit "+_year+" window owns this connection. Stop its Claude connection first."); }
            try
            {
                // File.Replace preserves the destination's ACL. Restrict an existing
                // profile before it can receive a fresh session token.
                AssertRegularFile(_profilePath);
                if(File.Exists(_profilePath)) ProtectPrivateFile(_profilePath);
                string session=Guid.NewGuid().ToString("N"), token;
                var secret=new byte[32]; using(var random=RandomNumberGenerator.Create()) random.GetBytes(secret);
                token=BitConverter.ToString(secret).Replace("-","").ToLowerInvariant(); Array.Clear(secret,0,secret.Length);
                var server=new McpLoopbackServer((request,cancellation)=>Enqueue(request,session,cancellation));
                _server=server;
                int port=server.Start(token);
                var connection=new McpConnection { Port=port,Token=token,ProcessId=Process.GetCurrentProcess().Id,ProjectKey=session,ProjectTitle=_title,StartedUtc=DateTime.UtcNow.ToString("O") };
                var temporary=_profilePath+"."+Guid.NewGuid().ToString("N")+".tmp";
                try
                {
                    // CreateNew never follows or overwrites a pre-existing temporary file.
                    // The protected parent ACL applies from the moment of creation.
                    using(var output=new FileStream(temporary,FileMode.CreateNew,FileAccess.Write,FileShare.None))
                    {
                        var bytes=McpWireCodec.Serialize(connection);
                        try { output.Write(bytes,0,bytes.Length); output.Flush(true); }
                        finally { Array.Clear(bytes,0,bytes.Length); }
                    }
                    if(File.Exists(_profilePath)) File.Replace(temporary,_profilePath,null); else File.Move(temporary,_profilePath);
                }
                finally { if(File.Exists(temporary)) File.Delete(temporary); }
                lock(_gate) { _session=session; _enabled=true; _starting=false; }
                _form.SetState(true,"Read-only connection enabled for '"+_title+"'. Keep this window open and this project active. Requested data is returned to Claude.");
            }
            catch { Stop(); throw; }
        }
        private static void PreparePrivateDirectory(string path)
        {
            if(path.StartsWith(@"\\",StringComparison.Ordinal)) throw new IOException("The MCP connection folder must be on a local drive.");
            var directory=new DirectoryInfo(path);
            // Checking only MCP would still follow a junction at KAMEP or another ancestor.
            for(var parent=directory; parent!=null; parent=parent.Parent)
                if(parent.Exists && (parent.Attributes&FileAttributes.ReparsePoint)!=0) throw new IOException("The MCP connection folder and its parents must be regular directories.");
            directory.Create();
            var user=WindowsIdentity.GetCurrent().User;
            if(user==null) throw new InvalidOperationException("The current Windows user could not be identified.");
            var security=new DirectorySecurity(); security.SetAccessRuleProtection(true,false);
            security.SetOwner(user);
            security.AddAccessRule(new FileSystemAccessRule(user,FileSystemRights.FullControl,InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit,PropagationFlags.None,AccessControlType.Allow));
            directory.SetAccessControl(security);
        }
        private static void ProtectPrivateFile(string path)
        {
            var user=WindowsIdentity.GetCurrent().User;
            if(user==null) throw new InvalidOperationException("The current Windows user could not be identified.");
            var security=new FileSecurity(); security.SetAccessRuleProtection(true,false); security.SetOwner(user);
            security.AddAccessRule(new FileSystemAccessRule(user,FileSystemRights.FullControl,AccessControlType.Allow));
            new FileInfo(path).SetAccessControl(security);
        }
        private static void AssertRegularFile(string path)
        {
            FileAttributes attributes;
            try { attributes=File.GetAttributes(path); }
            catch(FileNotFoundException) { return; }
            catch(DirectoryNotFoundException) { return; }
            if((attributes&(FileAttributes.ReparsePoint|FileAttributes.Directory))!=0) throw new IOException("The MCP connection path must be a regular local file.");
        }
        private async Task<McpWireResponse> Enqueue(McpWireRequest request,string session,CancellationToken cancellation)
        {
            var work=new Work { Request=request,Session=session,Cancellation=cancellation };
            lock(_gate)
            {
                if(_closed || !_enabled || _session!=session) return McpWireResponse.Fail(request.RequestId,"disconnected","Enable the connection in Revit and retry.");
                if(_queue.Count>=16) return McpWireResponse.Fail(request.RequestId,"busy","Too many pending requests. Wait for Revit and retry.");
                _queue.Add(work);
            }
            using(cancellation.Register(()=>
            {
                lock(_gate) _queue.Remove(work);
                work.Completion.TrySetResult(McpWireResponse.Fail(request.RequestId,"cancelled","The request was cancelled or timed out; no model changes were made."));
            }))
            {
                PostPump(); return await work.Completion.Task.ConfigureAwait(false);
            }
        }
        private void PostPump()
        {
            lock(_gate)
            {
                if(_closed || _pumpPosted || _form.IsDisposed || !_form.IsHandleCreated) return;
                _pumpPosted=true;
            }
            try
            {
                _form.BeginInvoke(new Action(()=>
                {
                    lock(_gate)
                    {
                        _pumpPosted=false;
                        if(_closed || _raised || _executing || (!_starting && _queue.Count==0)) return;
                        _raised=true;
                    }
                    try
                    {
                        var result=_event.Raise();
                        if(result!=ExternalEventRequest.Accepted && result!=ExternalEventRequest.Pending) throw new InvalidOperationException("Revit is not accepting requests. Finish its current command and retry.");
                    }
                    catch(Exception ex)
                    {
                        lock(_gate) _raised=false;
                        Stop(); if(!_closed) _form.SetState(false,ex.Message);
                    }
                }));
            }
            catch(InvalidOperationException) { lock(_gate) _pumpPosted=false; }
        }
        public void Execute(UIApplication app)
        {
            lock(_gate) { _raised=false; _executing=true; }
            try
            {
                if(_closed) return;
                if(_starting)
                {
                    try { Start(app); }
                    catch(Exception ex) { Stop(); _form.SetState(false,"Could not enable the connection: "+ex.Message); }
                    return;
                }
                Work work=null;
                lock(_gate) { if(_queue.Count>0) { work=_queue[0]; _queue.RemoveAt(0); } }
                if(work==null || work.Completion.Task.IsCompleted || work.Cancellation.IsCancellationRequested) return;
                McpWireResponse response;
                try
                {
                    RequireProject(app);
                    if(!_enabled || work.Session!=_session) throw new InvalidOperationException("This connection session ended. Read project info again.");
                    McpLimits.ValidateRequest(work.Request);
                    if(work.Request.Tool!="ka_revit_project_info" && work.Request.Arguments.ProjectKey!=_session)
                        throw new InvalidOperationException("The projectKey belongs to a different or expired session. Read project info again.");
                    work.Cancellation.ThrowIfCancellationRequested();
                    var result=McpReadService.Read(app.ActiveUIDocument,_session,Interlocked.Read(ref _revision),work.Request.Tool,work.Request.Arguments,work.Cancellation);
                    work.Cancellation.ThrowIfCancellationRequested();
                    var json=McpWireCodec.Json(result);
                    if(Encoding.UTF8.GetByteCount(json)>McpLimits.MaxResponseBytes/2) throw new InvalidOperationException("The result is too large. Request a smaller page.");
                    response=new McpWireResponse { RequestId=work.Request.RequestId,Success=true,PayloadJson=json };
                }
                catch(OperationCanceledException) { response=McpWireResponse.Fail(work.Request.RequestId,"cancelled","The request was cancelled or timed out; no model changes were made."); }
                catch(Exception ex) { response=McpWireResponse.Fail(work.Request.RequestId,"read_failed",ex.Message.Length>1200?ex.Message.Substring(0,1200):ex.Message); }
                if(!work.Cancellation.IsCancellationRequested) work.Completion.TrySetResult(response);
                _completed++; _form.SetActivity(work.Request.Tool,response.Success?"Succeeded":"Failed",_completed);
            }
            finally
            {
                lock(_gate) _executing=false;
                if(_closed) DisposeEvent(); else PostPump();
            }
        }
        private void RequireProject(UIApplication app)
        {
            if(!_document.IsValidObject || app.ActiveUIDocument==null || !app.ActiveUIDocument.Document.Equals(_document))
                throw new InvalidOperationException("Activate the project '"+_title+"' that owns this connection, or stop and reopen the tool in the intended project.");
        }
        private void Stop()
        {
            List<Work> pending;
            lock(_gate) { _enabled=false; _starting=false; _session=null; pending=_queue.ToList(); _queue.Clear(); }
            foreach(var work in pending) work.Completion.TrySetResult(McpWireResponse.Fail(work.Request.RequestId,"disconnected","The Revit connection was stopped."));
            var server=_server; _server=null;
            var lease=_lease; _lease=null;
            bool profileRemoved=true;
            try { if(server!=null) server.Dispose(); }
            catch(Exception) { /* Session checks above already reject every further read. Cleanup must continue. */ }
            finally
            {
                if(lease!=null)
                {
                    try
                    {
                        // The exclusive lease owns this per-year profile even if its JSON
                        // was corrupted. Do not parse or allocate unbounded file contents.
                        AssertRegularFile(_profilePath);
                        File.Delete(_profilePath);
                    }
                    catch(IOException) { profileRemoved=false; }
                    catch(UnauthorizedAccessException) { profileRemoved=false; }
                    catch(System.Security.SecurityException) { profileRemoved=false; }
                    finally { lease.Dispose(); }
                }
            }
            if(!_closed && !_form.IsDisposed) _form.SetState(false,profileRemoved
                ? "Connection stopped. Claude cannot read this project until you choose Enable again."
                : "Connection stopped. The saved connection file could not be removed; its session token is no longer accepted.");
        }
        private void SaveConfiguration()
        {
            if(!HelperAvailable()) { _form.SetState(_enabled,"The matching desktop helper is unavailable. Repair the installation first."); return; }
            using(var save=new SaveFileDialog { Title="Save KA MEP Claude configuration snippet", Filter="JSON configuration (*.json)|*.json",DefaultExt="json",AddExtension=true,OverwritePrompt=true,FileName="KA-MEP-Claude-Revit-"+_year+".json" })
            {
                if(save.ShowDialog(_form)!=DialogResult.OK) return;
                // Never silently replace the user's full Claude settings or the authenticated endpoint.
                var target=Path.GetFullPath(save.FileName);
                if(string.Equals(Path.GetFileName(target),"claude_desktop_config.json",StringComparison.OrdinalIgnoreCase) || string.Equals(target,_profilePath,StringComparison.OrdinalIgnoreCase))
                { _form.SetState(_enabled,"Save a separate snippet, then merge its mcpServers entry into Claude's existing configuration."); return; }
                try
                {
                    string json="{\n  \"mcpServers\": {\n    \"ka-mep-revit-"+_year+"\": {\n      \"command\": "+McpWireCodec.Json(_helperPath)+",\n      \"args\": [\"--connection-file\", "+McpWireCodec.Json(_profilePath)+"]\n    }\n  }\n}\n";
                    File.WriteAllText(target,json,new UTF8Encoding(false));
                    _form.SetState(_enabled,"Saved a configuration snippet. Merge its mcpServers entry into Claude Desktop's existing configuration, then restart Claude Desktop. The snippet contains no session token.");
                }
                catch(Exception ex) { _form.SetState(_enabled,"Could not save configuration: "+ex.Message); }
            }
        }
        private void DisposeEvent() { var external=_event; _event=null; if(external!=null) { try { external.Dispose(); } catch(InvalidOperationException) { } } }
        private sealed class Owner : IWin32Window { public Owner(IntPtr handle) { Handle=handle; } public IntPtr Handle { get; private set; } }
    }
}
