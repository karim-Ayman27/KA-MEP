using System;
using System.Drawing;
using System.Windows.Forms;

namespace PipeTakeoff.Revit
{
    /// <summary>Shared Windows Forms presentation. No Revit document or API access.</summary>
    public static class KaTheme
    {
        public static readonly Color Navy = Color.FromArgb(20, 45, 66);
        public static readonly Color Teal = Color.FromArgb(0, 181, 165);
        public static readonly Color Surface = Color.FromArgb(242, 246, 249);
        public static readonly Color Ink = Color.FromArgb(28, 49, 67);
        public static readonly Color Muted = Color.FromArgb(85, 104, 118);
        public static readonly Color Line = Color.FromArgb(218, 228, 234);
        public static readonly Color Warning = Color.FromArgb(150, 91, 12);

        public static void ApplyForm(Form form, string title, int width = 1180, int height = 710)
        {
            form.Text = "KA MEP | " + KAMEP.Branding.ReleaseIdentity.VersionLabel + " | " + title;
            form.Icon = KAMEP.Branding.BrandImages.WindowIcon();
            form.Font = new Font("Segoe UI", 9F);
            form.ForeColor = Ink;
            form.BackColor = Surface;
            form.AutoScaleDimensions = new SizeF(96F, 96F);
            form.AutoScaleMode = AutoScaleMode.Dpi;
            form.StartPosition = FormStartPosition.CenterParent;
            form.Size = new Size(width, height);
            form.MinimumSize = new Size(900, 610);
            form.ShowInTaskbar = false;
            form.MinimizeBox = false;
        }

        public static void ClampToScreen(Form form)
        {
            Rectangle area = Screen.FromHandle(form.Handle).WorkingArea;
            int width = Math.Max(1, area.Width - 24);
            int height = Math.Max(1, area.Height - 24);
            form.MinimumSize = new Size(Math.Min(form.MinimumSize.Width, width), Math.Min(form.MinimumSize.Height, height));
            form.Size = new Size(Math.Min(form.Width, width), Math.Min(form.Height, height));
            form.Location = new Point(
                Math.Max(area.Left + 12, Math.Min(form.Left, area.Right - form.Width - 12)),
                Math.Max(area.Top + 12, Math.Min(form.Top, area.Bottom - form.Height - 12)));
        }

        public static Button Button(string text, bool primary = false)
        {
            var button = new Button { Text = text, AutoSize = true, MinimumSize = new Size(72, 32), Padding = new Padding(11, 5, 11, 5) };
            StyleButton(button, primary);
            return button;
        }

        public static void StyleButton(Button button, bool primary = false)
        {
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = primary ? 0 : 1;
            button.FlatAppearance.BorderColor = Line;
            button.FlatAppearance.MouseOverBackColor = primary ? Color.FromArgb(0, 128, 119) : Surface;
            button.FlatAppearance.MouseDownBackColor = primary ? Navy : Line;
            button.BackColor = primary ? Color.FromArgb(0, 131, 122) : Color.White;
            button.ForeColor = primary ? Color.White : Ink;
            button.UseVisualStyleBackColor = false;
            button.Cursor = Cursors.Hand;
            button.Margin = new Padding(0, 3, 7, 3);
        }

        public static Label Hint(string text)
        {
            return new Label { Text = text, AutoSize = true, Dock = DockStyle.Fill, ForeColor = Muted, Margin = new Padding(0, 4, 0, 4) };
        }

        public static FlowLayoutPanel Flow()
        {
            return new FlowLayoutPanel { AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, WrapContents = true, Margin = new Padding(0) };
        }

        public static Control Header(string title, string subtitle)
        {
            var header = new TableLayoutPanel
            {
                AutoSize = true, Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2,
                BackColor = Navy, Padding = new Padding(18, 12, 18, 12), Margin = new Padding(0, 0, 0, 10)
            };
            header.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            header.Controls.Add(new Label
            {
                Text = "KA MEP", AutoSize = true, ForeColor = Teal,
                Font = new Font("Segoe UI", 18F, FontStyle.Bold), Margin = new Padding(0, 0, 28, 0), Anchor = AnchorStyles.Left
            }, 0, 0);
            header.Controls.Add(new Label
            {
                Text = title, AutoSize = true, ForeColor = Color.White,
                Font = new Font("Segoe UI", 15F, FontStyle.Bold), Margin = new Padding(0), Anchor = AnchorStyles.Left
            }, 1, 0);
            var caption = new Label { Text = subtitle, AutoSize = true, ForeColor = Color.FromArgb(194, 211, 223), Dock = DockStyle.Fill, Margin = new Padding(0, 5, 0, 0) };
            header.Controls.Add(caption, 0, 1);
            header.SetColumnSpan(caption, 2);
            return header;
        }

        public static Control Section(string number, string title, Control content, bool autoSize = false)
        {
            var section = new TableLayoutPanel
            {
                BackColor = Color.White, Dock = DockStyle.Fill, AutoSize = autoSize,
                ColumnCount = 1, RowCount = 2, Padding = new Padding(12, 9, 12, 10), Margin = new Padding(0)
            };
            section.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            section.RowStyles.Add(new RowStyle(autoSize ? SizeType.AutoSize : SizeType.Percent, 100F));
            section.Controls.Add(new Label
            {
                Text = (string.IsNullOrEmpty(number) ? "" : number + "  /  ") + title,
                AutoSize = true, ForeColor = Navy, Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                Dock = DockStyle.Fill, Margin = new Padding(0, 0, 0, 7)
            }, 0, 0);
            content.Dock = DockStyle.Fill;
            content.Margin = new Padding(0);
            section.Controls.Add(content, 0, 1);
            return section;
        }

        public static Control Metric(string caption, out Label value)
        {
            var metric = new TableLayoutPanel
            {
                Dock = DockStyle.Fill, AutoSize = true, ColumnCount = 1, RowCount = 2,
                BackColor = Color.White, Padding = new Padding(13, 7, 13, 7), Margin = new Padding(0, 0, 8, 0)
            };
            metric.Controls.Add(new Label { Text = caption.ToUpperInvariant(), AutoSize = true, ForeColor = Muted, Margin = new Padding(0) }, 0, 0);
            value = new Label
            {
                Text = "—", AutoSize = true, ForeColor = Navy,
                Font = new Font("Segoe UI", 17F, FontStyle.Bold), Margin = new Padding(0, 1, 0, 0)
            };
            metric.Controls.Add(value, 0, 1);
            return metric;
        }

        public static void StyleGrid(DataGridView grid, bool readOnly)
        {
            grid.Dock = DockStyle.Fill;
            grid.AutoGenerateColumns = false;
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.AllowUserToResizeRows = false;
            grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            grid.BackgroundColor = Color.White;
            grid.BorderStyle = BorderStyle.None;
            grid.GridColor = Line;
            grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            grid.RowHeadersVisible = false;
            grid.ReadOnly = readOnly;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grid.EnableHeadersVisualStyles = false;
            grid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            grid.ColumnHeadersHeight = 34;
            grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grid.ColumnHeadersDefaultCellStyle.BackColor = Navy;
            grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            grid.ColumnHeadersDefaultCellStyle.SelectionBackColor = Navy;
            grid.ColumnHeadersDefaultCellStyle.SelectionForeColor = Color.White;
            grid.ColumnHeadersDefaultCellStyle.Padding = new Padding(5);
            grid.DefaultCellStyle.ForeColor = Ink;
            grid.DefaultCellStyle.BackColor = Color.White;
            grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(216, 244, 240);
            grid.DefaultCellStyle.SelectionForeColor = Navy;
            grid.DefaultCellStyle.Padding = new Padding(4, 2, 4, 2);
            grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(246, 249, 251);
            grid.RowTemplate.Height = 29;
        }
    }
}
