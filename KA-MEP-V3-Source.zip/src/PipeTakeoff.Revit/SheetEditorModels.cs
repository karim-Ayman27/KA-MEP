using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace PipeTakeoff.Revit
{
    // Detached data only: the form never holds or edits live Revit elements.
    internal enum SheetParameterKind { Text, Integer, Number, YesNo, ElementReference, Unsupported }

    internal sealed class SheetEditorParameter
    {
        public string Key { get; set; }
        public long Id { get; set; }
        public string SharedGuid { get; set; }
        public string Name { get; set; }
        public string Group { get; set; }
        public string DataTypeId { get; set; }
        public SheetParameterKind Kind { get; set; }
        public string UnitHint { get; set; }
        public bool IsReadOnly { get; set; }
        public string ReadOnlyReason { get; set; }
        public bool IsSheetNumber { get; set; }
        public bool IsSheetName { get; set; }
        public string OriginalFingerprint { get; set; }
        public string OriginalValue { get; set; } = "";
        public string Value { get; set; } = "";
        public bool Changed { get { return !string.Equals(OriginalValue ?? "", Value ?? "", StringComparison.Ordinal); } }
    }

    internal sealed class SheetEditorSheet
    {
        public long Id { get; set; }
        public string UniqueId { get; set; }
        public string Number { get; set; }
        public string Name { get; set; }
        public bool IsPlaceholder { get; set; }
        public string ReadOnlyReason { get; set; }
        public List<SheetEditorParameter> Parameters { get; set; } = new List<SheetEditorParameter>();
        public HashSet<long> OriginalAdditionalRevisionIds { get; set; } = new HashSet<long>();
        public HashSet<long> AdditionalRevisionIds { get; set; } = new HashSet<long>();
        public HashSet<long> CloudRevisionIds { get; set; } = new HashSet<long>();
        public HashSet<long> OriginalAllRevisionIds { get; set; } = new HashSet<long>();
        public Dictionary<long, string> RevisionNumbers { get; set; } = new Dictionary<long, string>();
        public bool RevisionsChanged { get { return !OriginalAdditionalRevisionIds.SetEquals(AdditionalRevisionIds); } }
        public bool Changed { get { return Parameters.Any(p => p.Changed) || RevisionsChanged; } }
        public string Label { get { return (Number ?? "") + " — " + (Name ?? ""); } }
    }

    internal sealed class SheetEditorRevision
    {
        public long Id { get; set; }
        public string UniqueId { get; set; }
        public int Sequence { get; set; }
        public string Number { get; set; }
        public string Description { get; set; }
        public string Date { get; set; }
        public bool Issued { get; set; }
        public string Label { get { return "#" + Sequence + " · " + (Description ?? "") + " · " + (Date ?? ""); } }
    }

    internal sealed class SheetEditorSnapshot
    {
        public string ProjectTitle { get; set; }
        public List<SheetEditorSheet> Sheets { get; set; } = new List<SheetEditorSheet>();
        public List<SheetEditorRevision> Revisions { get; set; } = new List<SheetEditorRevision>();
        public List<string> Notes { get; set; } = new List<string>();
    }

    internal sealed class SheetEditorChange
    {
        public long SheetId { get; set; }
        public string Sheet { get; set; }
        public string Parameter { get; set; }
        public string Before { get; set; }
        public string After { get; set; }
    }

    internal sealed class SheetEditorStageResult
    {
        public int Changed { get; set; }
        public int Unchanged { get; set; }
        public List<string> Skipped { get; private set; } = new List<string>();
        public string Summary { get { return Changed + " staged, " + Unchanged + " unchanged, " + Skipped.Count + " skipped."; } }
    }

    internal sealed class SheetEditorApplyResult
    {
        public bool Committed { get; set; }
        public int SheetsChanged { get; set; }
        public int ParametersChanged { get; set; }
        public int RevisionSheetsChanged { get; set; }
        public List<string> Errors { get; set; } = new List<string>();
        public List<string> Warnings { get; set; } = new List<string>();
        public List<string> Details { get; set; } = new List<string>();
    }

    internal static class SheetEditorModel
    {
        internal static bool TryYesNo(string value, out bool result)
        {
            var text = (value ?? "").Trim();
            if (string.Equals(text, "Yes", StringComparison.OrdinalIgnoreCase) || string.Equals(text, "True", StringComparison.OrdinalIgnoreCase) || text == "1") { result = true; return true; }
            if (string.Equals(text, "No", StringComparison.OrdinalIgnoreCase) || string.Equals(text, "False", StringComparison.OrdinalIgnoreCase) || text == "0") { result = false; return true; }
            result = false;
            return false;
        }

        internal static string ValidateValue(SheetEditorParameter parameter, string value)
        {
            if (parameter.IsReadOnly) return parameter.ReadOnlyReason ?? "Read-only parameter.";
            value = value ?? "";
            if ((parameter.IsSheetName || parameter.IsSheetNumber) && string.IsNullOrWhiteSpace(value)) return "Sheet name and number cannot be empty.";
            if (parameter.Kind == SheetParameterKind.Integer)
            {
                int number;
                if (!int.TryParse(value, NumberStyles.Integer, CultureInfo.CurrentCulture, out number)) return "Enter a whole number within the 32-bit integer range.";
            }
            else if (parameter.Kind == SheetParameterKind.YesNo)
            {
                bool boolean;
                if (!TryYesNo(value, out boolean)) return "Choose Yes or No.";
            }
            else if (parameter.Kind == SheetParameterKind.Number)
            {
                if (string.IsNullOrWhiteSpace(value)) return "Enter a number, with project units if needed.";
                if (new[] { "NaN", "Infinity", "+Infinity", "-Infinity", "∞", "+∞", "-∞" }.Contains(value.Trim(), StringComparer.OrdinalIgnoreCase)) return "Enter a finite number.";
                // Unit-aware parsing is performed by Revit before applying the staged batch.
            }
            else if (parameter.Kind != SheetParameterKind.Text) return "This parameter requires a Revit-specific editor.";
            return null;
        }

        internal static string RevisionLockReason(SheetEditorSheet sheet, SheetEditorRevision revision)
        {
            if (!string.IsNullOrEmpty(sheet.ReadOnlyReason)) return sheet.ReadOnlyReason;
            if (revision.Issued) return "Issued revision: assignment is protected.";
            if (sheet.CloudRevisionIds.Contains(revision.Id)) return "Required by revision clouds on this sheet.";
            return null;
        }

        internal static SheetEditorStageResult StageValue(SheetEditorSnapshot snapshot, IEnumerable<long> sheetIds, string parameterKey, string value)
        {
            var result = new SheetEditorStageResult();
            var ids = new HashSet<long>(sheetIds ?? Enumerable.Empty<long>());
            foreach (var sheet in snapshot.Sheets.Where(s => ids.Contains(s.Id)))
            {
                var parameter = sheet.Parameters.FirstOrDefault(p => p.Key == parameterKey);
                var error = !string.IsNullOrEmpty(sheet.ReadOnlyReason) ? sheet.ReadOnlyReason : parameter == null ? "Parameter is not present on this sheet." : ValidateValue(parameter, value);
                if (error != null) { result.Skipped.Add(sheet.Label + ": " + error); continue; }
                var normalized = value ?? "";
                bool boolean;
                if (parameter.Kind == SheetParameterKind.YesNo && TryYesNo(normalized, out boolean)) normalized = boolean ? "Yes" : "No";
                if (string.Equals(parameter.Value ?? "", normalized, StringComparison.Ordinal)) result.Unchanged++;
                else { parameter.Value = normalized; result.Changed++; }
            }
            return result;
        }

        internal static SheetEditorStageResult StageRevision(SheetEditorSnapshot snapshot, IEnumerable<long> sheetIds, long revisionId, bool additional)
        {
            var result = new SheetEditorStageResult();
            var revision = snapshot.Revisions.FirstOrDefault(r => r.Id == revisionId);
            var ids = new HashSet<long>(sheetIds ?? Enumerable.Empty<long>());
            foreach (var sheet in snapshot.Sheets.Where(s => ids.Contains(s.Id)))
            {
                var error = revision == null ? "Revision no longer exists." : RevisionLockReason(sheet, revision);
                if (error != null) { result.Skipped.Add(sheet.Label + ": " + error); continue; }
                bool changed = additional ? sheet.AdditionalRevisionIds.Add(revisionId) : sheet.AdditionalRevisionIds.Remove(revisionId);
                if (changed) result.Changed++; else result.Unchanged++;
            }
            return result;
        }

        internal static List<SheetEditorChange> Changes(SheetEditorSnapshot snapshot)
        {
            var changes = new List<SheetEditorChange>();
            foreach (var sheet in snapshot.Sheets)
            {
                foreach (var parameter in sheet.Parameters.Where(p => p.Changed))
                    changes.Add(new SheetEditorChange { SheetId = sheet.Id, Sheet = sheet.Label, Parameter = parameter.Name, Before = parameter.OriginalValue ?? "", After = parameter.Value ?? "" });
                foreach (long id in sheet.OriginalAdditionalRevisionIds.Union(sheet.AdditionalRevisionIds).OrderBy(x => x))
                {
                    bool before = sheet.OriginalAdditionalRevisionIds.Contains(id), after = sheet.AdditionalRevisionIds.Contains(id);
                    if (before == after) continue;
                    var revision = snapshot.Revisions.FirstOrDefault(r => r.Id == id);
                    changes.Add(new SheetEditorChange { SheetId = sheet.Id, Sheet = sheet.Label, Parameter = "Additional revision: " + (revision == null ? id.ToString(CultureInfo.InvariantCulture) : revision.Label), Before = before ? "Included" : "Not additional", After = after ? "Included" : "Not additional" });
                }
            }
            return changes;
        }

        internal static List<string> Validate(SheetEditorSnapshot snapshot)
        {
            var errors = new List<string>();
            foreach (var sheet in snapshot.Sheets.Where(s => s.Changed))
            {
                if (!string.IsNullOrEmpty(sheet.ReadOnlyReason)) errors.Add(sheet.Label + ": " + sheet.ReadOnlyReason);
                foreach (var parameter in sheet.Parameters.Where(p => p.Changed))
                {
                    var error = ValidateValue(parameter, parameter.Value);
                    if (error != null) errors.Add(sheet.Label + " / " + parameter.Name + ": " + error);
                }
                foreach (long id in sheet.OriginalAdditionalRevisionIds.Union(sheet.AdditionalRevisionIds))
                {
                    if (sheet.OriginalAdditionalRevisionIds.Contains(id) == sheet.AdditionalRevisionIds.Contains(id)) continue;
                    var revision = snapshot.Revisions.FirstOrDefault(r => r.Id == id);
                    var error = revision == null ? "Unknown revision." : RevisionLockReason(sheet, revision);
                    if (error != null) errors.Add(sheet.Label + " / revision " + id + ": " + error);
                }
            }
            if (snapshot.Sheets.Any(s => s.Parameters.Any(p => p.IsSheetNumber && p.Changed)))
            {
                var finalNumbers = snapshot.Sheets.Select(s => new { Sheet = s, Number = s.Parameters.FirstOrDefault(p => p.IsSheetNumber)?.Value ?? s.Number });
                foreach (var group in finalNumbers.GroupBy(s => s.Number, StringComparer.OrdinalIgnoreCase).Where(g => g.Count() > 1))
                    errors.Add("Duplicate final sheet number '" + group.Key + "': " + string.Join(", ", group.Select(s => s.Sheet.Label)));
            }
            return errors;
        }

        internal static void Reset(SheetEditorSnapshot snapshot, IEnumerable<long> sheetIds = null)
        {
            var ids = sheetIds == null ? null : new HashSet<long>(sheetIds);
            foreach (var sheet in snapshot.Sheets.Where(s => ids == null || ids.Contains(s.Id)))
            {
                foreach (var parameter in sheet.Parameters) parameter.Value = parameter.OriginalValue;
                sheet.AdditionalRevisionIds = new HashSet<long>(sheet.OriginalAdditionalRevisionIds);
            }
        }
    }
}
