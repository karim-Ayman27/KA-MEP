using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using PipeTakeoff.Core;
using TaskDialog = Autodesk.Revit.UI.TaskDialog;

namespace PipeTakeoff.Revit
{
    [Transaction(TransactionMode.ReadOnly)]
    [Regeneration(RegenerationOption.Manual)]
    public sealed class SpaceTakeoffCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            try
            {
                var uiDocument = commandData.Application.ActiveUIDocument;
                if (uiDocument == null || uiDocument.Document.IsFamilyDocument)
                {
                    TaskDialog.Show("KA MEP - HVAC Spaces", "Open an MEP project containing Spaces. Architectural geometry can be read from loaded Revit Links.");
                    return Result.Cancelled;
                }
                var document = uiDocument.Document;
                var owner = new WindowOwner(commandData.Application.MainWindowHandle);
                var links = SpaceTakeoffReader.GetLinks(document);
                var loadedLinks = links.Where(link => link.IsLoaded).ToList();
                var options = new SpaceTakeoffOptions { PhaseId = SpaceTakeoffReader.DefaultPhaseId(document), IncludeLinkedGeometry = true, IncludeHostGeometry = false };
                if (loadedLinks.Count == 1) options.SelectedLinkInstanceId = loadedLinks[0].Id;
                using (var form = new SpaceTakeoffForm(SpaceTakeoffReader.GetPhases(document), options, links))
                {
                    // These callbacks run synchronously while Execute is on the stack and the modal window owns Revit.
                    // Never dispatch document reads onto tasks, timers, or a modeless event handler.
                    Action requireOriginalProject = () =>
                    {
                        if (!document.IsValidObject || commandData.Application.ActiveUIDocument == null ||
                            !commandData.Application.ActiveUIDocument.Document.Equals(document))
                            throw new InvalidOperationException("The active project changed. Close this window and reopen HVAC Spaces from the intended model.");
                    };
                    form.ScanRequested += selected =>
                    {
                        requireOriginalProject();
                        var snapshot = SpaceTakeoffReader.Read(uiDocument, selected);
                        snapshot.RevitVersion = commandData.Application.Application.VersionName;
                        snapshot.Release = KAMEP.Branding.ReleaseIdentity.Display;
                        form.SetSnapshot(snapshot);
                    };
                    form.ExportRequested += (snapshot, millimeters, filter) =>
                    {
                        requireOriginalProject();
                        using (var save = new SaveFileDialog())
                        {
                            save.Title = "KA MEP - Export HVAC Spaces to Excel";
                            save.Filter = "Excel workbook (*.xlsx)|*.xlsx"; save.DefaultExt = "xlsx";
                            save.AddExtension = true; save.OverwritePrompt = true;
                            string project = string.Concat(snapshot.ProjectTitle.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c));
                            save.FileName = project + "_KA_MEP_HVAC_Spaces_" + DateTime.Now.ToString("yyyyMMdd_HHmm", CultureInfo.InvariantCulture) + ".xlsx";
                            if (save.ShowDialog(owner) != DialogResult.OK) { form.ShowStatus("Excel export cancelled. The current results are unchanged."); return; }
                            SpaceTakeoffXlsxExporter.Export(save.FileName, snapshot, new SpaceTakeoffExportOptions { HeightsInMillimeters = millimeters, FilterDescription = filter });
                            form.ShowStatus("Exported " + snapshot.Rows.Count.ToString(CultureInfo.CurrentCulture) + " Spaces to " + save.FileName);
                        }
                    };
                    form.ShowDialog(owner);
                }
                return Result.Succeeded;
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException) { return Result.Cancelled; }
            catch (Exception ex)
            {
                message = ex.Message;
                TaskDialog.Show("KA MEP - HVAC Spaces", "The tool could not be opened.\n\n" + ex.Message);
                return Result.Failed;
            }
        }
        private sealed class WindowOwner : IWin32Window
        {
            public WindowOwner(IntPtr handle) { Handle = handle; }
            public IntPtr Handle { get; private set; }
        }
    }
}
