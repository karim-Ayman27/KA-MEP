using System.Collections.Generic;
using PipeTakeoff.Core;

namespace PipeTakeoff.Revit
{
    /// <summary>Duct and fitting takeoff editor operating only on detached model data.</summary>
    public sealed class DuctTakeoffForm : TakeoffForm
    {
        public DuctTakeoffForm(IList<PipeRecord> records, IList<FieldDefinition> fields, string scopeLabel)
            : base(records, fields, scopeLabel, true) { }
    }
}
