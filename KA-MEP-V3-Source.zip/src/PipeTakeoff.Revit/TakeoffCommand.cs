using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using PipeTakeoff.Core;
using TaskDialog = Autodesk.Revit.UI.TaskDialog;

namespace PipeTakeoff.Revit
{
    [Transaction(TransactionMode.ReadOnly)]
    [Regeneration(RegenerationOption.Manual)]
    public sealed class TakeoffCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            try
            {
                var uiDocument = commandData.Application.ActiveUIDocument;
                if (uiDocument == null || uiDocument.Document.IsFamilyDocument)
                {
                    TaskDialog.Show("KA MEP", "Open a Revit project containing pipes first.");
                    return Result.Cancelled;
                }
                var choice = new TaskDialog("KA MEP - Scope")
                {
                    MainInstruction = "Choose the pipes to include",
                    MainContent = "Rigid Pipes in the current model only. Linked models, fittings, accessories, insulation, flex pipes and placeholders are excluded.",
                    CommonButtons = TaskDialogCommonButtons.Cancel
                };
                choice.AddCommandLink(TaskDialogCommandLinkId.CommandLink1, "All pipes in the current model");
                choice.AddCommandLink(TaskDialogCommandLinkId.CommandLink2, "Pipes in the active view");
                choice.AddCommandLink(TaskDialogCommandLinkId.CommandLink3, "Selected pipes only");
                var result = choice.Show();
                PipeScope scope;
                if (result == TaskDialogResult.CommandLink1) scope = PipeScope.Model;
                else if (result == TaskDialogResult.CommandLink2) scope = PipeScope.ActiveView;
                else if (result == TaskDialogResult.CommandLink3) scope = PipeScope.Selection;
                else return Result.Cancelled;

                var snapshot = PipeReader.Read(uiDocument, scope);
                if (snapshot.Records.Count == 0)
                {
                    TaskDialog.Show("KA MEP", "No rigid pipes were found in this scope. Choose another scope or select pipe elements.");
                    return Result.Cancelled;
                }
                var owner = new RevitWindow(commandData.Application.MainWindowHandle);
                using (var form = new TakeoffForm(snapshot.Records, snapshot.Fields, snapshot.ScopeLabel))
                {
                    if (form.ShowDialog(owner) != DialogResult.OK) return Result.Cancelled;
                    using (var save = new SaveFileDialog())
                    {
                        save.Title = "KA MEP - Export Excel";
                        save.Filter = "Excel workbook (*.xlsx)|*.xlsx";
                        save.DefaultExt = "xlsx";
                        save.AddExtension = true;
                        save.OverwritePrompt = true;
                        var safeTitle = string.Concat(uiDocument.Document.Title.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c));
                        save.FileName = safeTitle + "_KA_MEP_" + DateTime.Now.ToString("yyyyMMdd_HHmm") + ".xlsx";
                        if (save.ShowDialog(owner) != DialogResult.OK) return Result.Cancelled;
                        XlsxExporter.Export(save.FileName, form.FilteredRecords, form.Options, new ExportMetadata
                        {
                            Project = uiDocument.Document.Title,
                            RevitVersion = commandData.Application.Application.VersionName,
                            Scope = snapshot.ScopeLabel
                        });
                        TaskDialog.Show("KA MEP", string.Format(System.Globalization.CultureInfo.CurrentCulture,
                            "Export complete.\n\nPipes: {0:N0}\nTotal length: {1:N3} m\n\n{2}",
                            form.FilteredRecords.Count, form.FilteredRecords.Sum(p => p.LengthMeters), save.FileName));
                    }
                }
                return Result.Succeeded;
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException) { return Result.Cancelled; }
            catch (Exception ex)
            {
                message = ex.Message;
                TaskDialog.Show("KA MEP - Error", "The takeoff could not be completed.\n\n" + ex.Message);
                return Result.Failed;
            }
        }

        private sealed class RevitWindow : IWin32Window
        {
            public RevitWindow(IntPtr handle) { Handle = handle; }
            public IntPtr Handle { get; private set; }
        }
    }
}
