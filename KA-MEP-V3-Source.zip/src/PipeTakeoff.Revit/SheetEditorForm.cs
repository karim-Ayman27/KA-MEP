using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace PipeTakeoff.Revit
{
    /// <summary>A detached, staged editor. Revit document writes are performed only by the command.</summary>
    internal sealed class SheetEditorForm : Form
    {
        private readonly SheetEditorSnapshot _snapshot;
        private readonly HashSet<long> _checked = new HashSet<long>();
        private readonly DataGridView _sheets = new DataGridView();
        private readonly DataGridView _parameters = new DataGridView();
        private readonly DataGridView _revisions = new DataGridView();
        private readonly DataGridView _review = new DataGridView();
        private readonly TextBox _sheetSearch = new TextBox();
        private readonly TextBox _parameterSearch = new TextBox();
        private readonly CheckBox _editableOnly = new CheckBox { Text = "Editable only", AutoSize = true };
        private readonly Label _sheetCount = new Label();
        private readonly Label _selectedSheet = new Label();
        private readonly Label _parameterHelp = new Label();
        private readonly Label _revisionHelp = new Label();
        private readonly Label _status = new Label();
        private readonly TabControl _tabs = new TabControl();
        private readonly Button _apply = KaTheme.Button("Apply changes", true);
        private readonly Button _batchParameter = KaTheme.Button("Edit checked sheets…");
        private readonly Button _revertParameter = KaTheme.Button("Revert value");
        private readonly Button _batchRevisionAdd = KaTheme.Button("Add to checked");
        private readonly Button _batchRevisionRemove = KaTheme.Button("Remove from checked");
        private readonly ToolTip _tips = new ToolTip { AutoPopDelay = 18000, InitialDelay = 300 };
        private bool _loading;
        private SheetEditorSheet _currentSheet;
        private string _lastAction;
        private readonly TextBox _validation = new TextBox();

        public SheetEditorSnapshot Snapshot { get { return _snapshot; } }

        public SheetEditorForm(SheetEditorSnapshot snapshot)
        {
            if (snapshot == null) throw new ArgumentNullException("snapshot");
            _snapshot = snapshot;
            KaTheme.ApplyForm(this, "Sheet Parameters", 1240, 800);
            Name = "SheetEditorForm";
            MinimumSize = new Size(940, 640);
            BuildInterface();
            WireEvents();
            RefreshSheets(); RefreshReview(); RefreshStatus();
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            KaTheme.ClampToScreen(this);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _tips.Dispose();
            base.Dispose(disposing);
        }

        private void BuildInterface()
        {
            var workspace = CreateLayout("SheetWorkspace", 1, 2);
            workspace.Padding = new Padding(14, 12, 14, 8);
            workspace.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            workspace.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            workspace.Controls.Add(KaTheme.Header("Sheet Parameters", "Edit sheet information and revision membership  /  Preview every change before applying"), 0, 0);
            var columns = CreateLayout("SheetColumns", 2, 1);
            columns.ColumnStyles.Clear();
            columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 31));
            columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 69));
            columns.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            columns.Controls.Add(SheetList(), 0, 0);
            columns.Controls.Add(Details(), 1, 0);
            workspace.Controls.Add(columns, 0, 1);
            // The workspace can scroll at very small/high-DPI viewports; Apply/Cancel stay fixed.
            var viewport = new Panel { Name = "SheetWorkspaceViewport", Dock = DockStyle.Fill, AutoScroll = true };
            workspace.Dock = DockStyle.Top;
            viewport.Controls.Add(workspace);
            bool sizing = false;
            viewport.Layout += delegate
            {
                if (sizing) return;
                sizing = true;
                try { workspace.Height = Math.Max(viewport.ClientSize.Height, Font.Height * 26); }
                finally { sizing = false; }
            };
            Controls.Add(viewport);
            Controls.Add(Footer());
        }

        private Control SheetList()
        {
            var panel = CreateLayout("SheetListPanel", 1, 5);
            panel.BackColor = Color.White;
            panel.Padding = new Padding(10);
            panel.Margin = new Padding(0, 0, 12, 0);
            for (int i = 0; i < 4; i++) panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            var heading = Label("PROJECT SHEETS", true);
            panel.Controls.Add(heading, 0, 0);
            _sheetSearch.Name = "SheetSearch";
            _sheetSearch.Dock = DockStyle.Fill;
            _sheetSearch.Margin = new Padding(0, 6, 0, 6);
            _tips.SetToolTip(_sheetSearch, "Search sheet number and name. Hidden rows keep their checks and drafts.");
            panel.Controls.Add(_sheetSearch, 0, 1);
            var buttons = KaTheme.Flow(); buttons.Dock = DockStyle.Fill;
            var all = KaTheme.Button("Check visible"); all.Name = "SheetCheckVisible";
            all.Click += delegate { SetVisibleChecks(true); };
            var clear = KaTheme.Button("Clear checks"); clear.Name = "SheetClearChecks";
            clear.Click += delegate { _checked.Clear(); RefreshSheetChecks(); RefreshStatus(); };
            buttons.Controls.Add(all); buttons.Controls.Add(clear);
            panel.Controls.Add(buttons, 0, 2);
            _sheetCount.Name = "SheetCount";
            ConfigureLabel(_sheetCount, false);
            panel.Controls.Add(_sheetCount, 0, 3);
            Grid(_sheets, "SheetListGrid", false);
            _sheets.MultiSelect = false;
            _sheets.Columns.Add(new DataGridViewCheckBoxColumn { Name = "Checked", HeaderText = "Use", Width = 42, MinimumWidth = 38, AutoSizeMode = DataGridViewAutoSizeColumnMode.None });
            _sheets.Columns.Add(TextColumn("Number", "Number", 35, 72, true));
            _sheets.Columns.Add(TextColumn("Sheet", "Sheet name", 65, 110, true));
            panel.Controls.Add(_sheets, 0, 4);
            return panel;
        }

        private Control Details()
        {
            var panel = CreateLayout("SheetDetails", 1, 2);
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            _selectedSheet.Name = "SheetSelectedTitle";
            ConfigureLabel(_selectedSheet, true);
            _selectedSheet.AutoSize = false;
            _selectedSheet.AutoEllipsis = true;
            _selectedSheet.Height = Font.Height + 14;
            panel.Controls.Add(_selectedSheet, 0, 0);
            _tabs.Name = "SheetEditorTabs";
            _tabs.Dock = DockStyle.Fill;
            _tabs.Padding = new Point(12, 7);
            _tabs.TabPages.Add(ParametersTab());
            _tabs.TabPages.Add(RevisionsTab());
            _tabs.TabPages.Add(ReviewTab());
            panel.Controls.Add(_tabs, 0, 1);
            return panel;
        }

        private TabPage ParametersTab()
        {
            var page = Page("Parameters");
            var panel = CreateLayout("SheetParametersPanel", 1, 4);
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var search = CreateLayout("SheetParameterToolbar", 2, 1);
            search.AutoSize = true; search.Dock = DockStyle.Top;
            search.ColumnStyles.Clear();
            search.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            search.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            search.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            _parameterSearch.Name = "SheetParameterSearch";
            _parameterSearch.Dock = DockStyle.Fill;
            _parameterSearch.Margin = new Padding(0, 4, 10, 6);
            _tips.SetToolTip(_parameterSearch, "Search parameter name, group or value.");
            _editableOnly.Name = "SheetEditableOnly";
            _editableOnly.Anchor = AnchorStyles.Left;
            _editableOnly.Margin = new Padding(0, 4, 0, 6);
            search.Controls.Add(_parameterSearch, 0, 0); search.Controls.Add(_editableOnly, 1, 0);
            panel.Controls.Add(search, 0, 0);
            Grid(_parameters, "SheetParameterGrid", false);
            _parameters.SelectionMode = DataGridViewSelectionMode.CellSelect;
            _parameters.MultiSelect = false;
            _parameters.EditMode = DataGridViewEditMode.EditOnEnter;
            _parameters.Columns.Add(TextColumn("Parameter", "Parameter", 23, 130, true));
            _parameters.Columns.Add(TextColumn("Current", "Current value", 22, 135, true));
            _parameters.Columns.Add(TextColumn("Proposed", "New value", 25, 150, false));
            _parameters.Columns.Add(TextColumn("Type", "Type / group", 15, 115, true));
            _parameters.Columns.Add(TextColumn("Access", "Status", 15, 135, true));
            panel.Controls.Add(_parameters, 0, 1);
            ConfigureLabel(_parameterHelp, false); _parameterHelp.Name = "SheetParameterHelp";
            _parameterHelp.AutoSize = false; _parameterHelp.AutoEllipsis = true;
            _parameterHelp.Height = Font.Height * 2 + 10;
            panel.Controls.Add(_parameterHelp, 0, 2);
            var actions = KaTheme.Flow(); actions.Dock = DockStyle.Fill;
            _batchParameter.Name = "SheetBatchParameter";
            _revertParameter.Name = "SheetRevertParameter";
            actions.Controls.Add(_batchParameter); actions.Controls.Add(_revertParameter);
            panel.Controls.Add(actions, 0, 3);
            page.Controls.Add(panel);
            return page;
        }

        private TabPage RevisionsTab()
        {
            var page = Page("Revisions");
            var panel = CreateLayout("SheetRevisionsPanel", 1, 4);
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.Controls.Add(Label("Choose additional revisions for this sheet. Cloud revisions are managed by Revit."), 0, 0);
            Grid(_revisions, "SheetRevisionGrid", false);
            _revisions.MultiSelect = false;
            _revisions.Columns.Add(new DataGridViewCheckBoxColumn { Name = "Additional", HeaderText = "Include", MinimumWidth = 64, FillWeight = 10 });
            _revisions.Columns.Add(TextColumn("Sequence", "Sequence", 10, 65, true));
            _revisions.Columns.Add(TextColumn("Number", "Number", 10, 65, true));
            _revisions.Columns.Add(TextColumn("Description", "Description", 30, 150, true));
            _revisions.Columns.Add(TextColumn("Date", "Date", 15, 85, true));
            _revisions.Columns.Add(TextColumn("Status", "Membership / status", 25, 170, true));
            panel.Controls.Add(_revisions, 0, 1);
            ConfigureLabel(_revisionHelp, false); _revisionHelp.Name = "SheetRevisionHelp";
            _revisionHelp.AutoSize = false; _revisionHelp.AutoEllipsis = true;
            _revisionHelp.Height = Font.Height * 2 + 10;
            panel.Controls.Add(_revisionHelp, 0, 2);
            var actions = KaTheme.Flow(); actions.Dock = DockStyle.Fill;
            _batchRevisionAdd.Name = "SheetBatchRevisionAdd";
            _batchRevisionRemove.Name = "SheetBatchRevisionRemove";
            actions.Controls.Add(_batchRevisionAdd); actions.Controls.Add(_batchRevisionRemove);
            panel.Controls.Add(actions, 0, 3);
            page.Controls.Add(panel);
            return page;
        }

        private TabPage ReviewTab()
        {
            var page = Page("Review changes");
            var panel = CreateLayout("SheetReviewPanel", 1, 3);
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            panel.Controls.Add(Label("Only the changes listed here are applied. Sheet checks select batch targets; they do not discard individual edits."), 0, 0);
            Grid(_review, "SheetReviewGrid", true);
            _review.Columns.Add(TextColumn("Sheet", "Sheet", 18, 120, true));
            _review.Columns.Add(TextColumn("Field", "Parameter / revision", 26, 160, true));
            _review.Columns.Add(TextColumn("Before", "Current", 23, 140, true));
            _review.Columns.Add(TextColumn("After", "Proposed", 23, 140, true));
            _review.Columns.Add(TextColumn("Result", "Validation", 10, 100, true));
            _validation.Name = "SheetValidationErrors"; _validation.Multiline = true; _validation.ReadOnly = true;
            _validation.ScrollBars = ScrollBars.Vertical; _validation.Dock = DockStyle.Fill; _validation.Height = 85;
            _validation.BackColor = Color.FromArgb(255, 244, 229); _validation.ForeColor = KaTheme.Warning;
            _validation.Visible = false; panel.RowStyles.Insert(1, new RowStyle(SizeType.AutoSize));
            panel.Controls.Add(_validation, 0, 1);
            panel.Controls.Add(_review, 0, 2);
            page.Controls.Add(panel);
            return page;
        }

        private Control Footer()
        {
            var panel = CreateLayout("SheetFooter", 3, 2);
            panel.Dock = DockStyle.Bottom; panel.AutoSize = true;
            panel.BackColor = Color.White; panel.Padding = new Padding(14, 8, 14, 10);
            panel.ColumnStyles.Clear();
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            _status.Name = "SheetFooterStatus";
            _status.Dock = DockStyle.Fill; _status.AutoEllipsis = true;
            _status.Height = Font.Height + 10; _status.ForeColor = KaTheme.Muted;
            panel.Controls.Add(_status, 0, 0); panel.SetColumnSpan(_status, 3);
            var reset = KaTheme.Button("Reset drafts"); reset.Name = "SheetResetButton";
            var cancel = KaTheme.Button("Cancel"); cancel.Name = "SheetCancelButton";
            _apply.Name = "SheetApplyButton";
            foreach (var button in new[] { reset, _apply, cancel })
            { button.AutoSize = false; button.Dock = DockStyle.Fill; button.Height = 38; }
            reset.Click += delegate { ResetDrafts(); };
            _apply.Click += ApplyChanges;
            cancel.DialogResult = DialogResult.Cancel;
            panel.Controls.Add(reset, 0, 1); panel.Controls.Add(_apply, 1, 1); panel.Controls.Add(cancel, 2, 1);
            CancelButton = cancel; AcceptButton = _apply;
            return panel;
        }

                private void WireEvents()
        {
            _sheetSearch.TextChanged += delegate { FinishEditing(); RefreshSheets(); };
            _parameterSearch.TextChanged += delegate { FinishEditing(); RefreshParameters(); };
            _editableOnly.CheckedChanged += delegate { FinishEditing(); RefreshParameters(); };
            _sheets.CurrentCellDirtyStateChanged += delegate { if (_sheets.IsCurrentCellDirty) _sheets.CommitEdit(DataGridViewDataErrorContexts.Commit); };
            _sheets.CellValueChanged += delegate(object sender, DataGridViewCellEventArgs e)
            {
                if (_loading || e.RowIndex < 0 || e.ColumnIndex != 0) return;
                var sheet = (SheetEditorSheet)_sheets.Rows[e.RowIndex].Tag;
                if (Convert.ToBoolean(_sheets.Rows[e.RowIndex].Cells[0].Value)) _checked.Add(sheet.Id); else _checked.Remove(sheet.Id);
                RefreshStatus();
            };
            _sheets.SelectionChanged += delegate
            {
                if (_loading || _sheets.CurrentRow == null) return;
                var sheet = (SheetEditorSheet)_sheets.CurrentRow.Tag;
                if (ReferenceEquals(sheet, _currentSheet)) return;
                FinishEditing(); _currentSheet = sheet; RefreshDetails();
            };
            _parameters.CurrentCellDirtyStateChanged += delegate
            {
                if (_parameters.IsCurrentCellDirty && _parameters.CurrentCell is DataGridViewCheckBoxCell)
                    _parameters.CommitEdit(DataGridViewDataErrorContexts.Commit);
            };
            _parameters.CellValueChanged += ParameterChanged;
            _parameters.SelectionChanged += delegate { UpdateParameterActions(); };
            _revisions.CurrentCellDirtyStateChanged += delegate { if (_revisions.IsCurrentCellDirty) _revisions.CommitEdit(DataGridViewDataErrorContexts.Commit); };
            _revisions.CellValueChanged += delegate(object sender, DataGridViewCellEventArgs e)
            {
                if (_loading || e.RowIndex < 0 || e.ColumnIndex != 0 || _currentSheet == null) return;
                var row = _revisions.Rows[e.RowIndex]; var revision = (SheetEditorRevision)row.Tag;
                var result = SheetEditorModel.StageRevision(_snapshot, new[] { _currentSheet.Id }, revision.Id, Convert.ToBoolean(row.Cells[0].Value));
                _lastAction = result.Summary;
                UpdateRevisionRow(row, revision);
                RefreshSheetMarkers(); RefreshReview(); RefreshStatus(); UpdateRevisionActions();
            };
            _revisions.SelectionChanged += delegate { UpdateRevisionActions(); };
            _tabs.SelectedIndexChanged += delegate { FinishEditing(); RefreshReview(); };
            _batchParameter.Click += delegate { EditCheckedSheets(); };
            _revertParameter.Click += delegate
            {
                FinishEditing(); var parameter = SelectedParameter();
                if (parameter == null) return;
                parameter.Value = parameter.OriginalValue;
                _lastAction = "Reverted the selected parameter draft.";
                RefreshParameters(); RefreshSheetMarkers(); RefreshReview(); RefreshStatus();
            };
            _batchRevisionAdd.Click += delegate { StageRevisionForChecked(true); };
            _batchRevisionRemove.Click += delegate { StageRevisionForChecked(false); };
        }

        private void FinishEditing()
        {
            _parameters.EndEdit(); _revisions.EndEdit(); _sheets.EndEdit();
        }

        private void RefreshSheets()
        {
            long selected = _currentSheet == null ? -1 : _currentSheet.Id;
            var query = (_sheetSearch.Text ?? "").Trim();
            var visible = _snapshot.Sheets.Where(sheet => Contains(sheet.Number, query) || Contains(sheet.Name, query)).ToList();
            _loading = true;
            try
            {
                _sheets.Rows.Clear();
                foreach (var sheet in visible)
                {
                    int index = _sheets.Rows.Add(_checked.Contains(sheet.Id), sheet.Number, sheet.Name);
                    _sheets.Rows[index].Tag = sheet;
                    PaintSheetRow(_sheets.Rows[index], sheet);
                }
                var target = _sheets.Rows.Cast<DataGridViewRow>().FirstOrDefault(row => ((SheetEditorSheet)row.Tag).Id == selected)
                    ?? _sheets.Rows.Cast<DataGridViewRow>().FirstOrDefault();
                _sheets.ClearSelection();
                if (target != null) { _sheets.CurrentCell = target.Cells[1]; target.Selected = true; _currentSheet = (SheetEditorSheet)target.Tag; }
                else _currentSheet = null;
            }
            finally { _loading = false; }
            RefreshDetails(); RefreshStatus();
        }

        private void RefreshSheetChecks()
        {
            _loading = true;
            try { foreach (DataGridViewRow row in _sheets.Rows) row.Cells[0].Value = _checked.Contains(((SheetEditorSheet)row.Tag).Id); }
            finally { _loading = false; }
        }

        private void SetVisibleChecks(bool value)
        {
            FinishEditing();
            foreach (DataGridViewRow row in _sheets.Rows)
            {
                long id = ((SheetEditorSheet)row.Tag).Id;
                if (value) _checked.Add(id); else _checked.Remove(id);
            }
            RefreshSheetChecks(); RefreshStatus();
        }

        private void RefreshSheetMarkers()
        { foreach (DataGridViewRow row in _sheets.Rows) PaintSheetRow(row, (SheetEditorSheet)row.Tag); }

        private static void PaintSheetRow(DataGridViewRow row, SheetEditorSheet sheet)
        {
            row.Cells[2].Value = (sheet.Changed ? "● " : "") + sheet.Name;
            row.Cells[2].Style.ForeColor = sheet.Changed ? Color.FromArgb(0, 131, 122) : KaTheme.Ink;
            row.Cells[2].ToolTipText = sheet.Label + (sheet.IsPlaceholder ? "\r\nPlaceholder sheet" : "")
                + (string.IsNullOrEmpty(sheet.ReadOnlyReason) ? "" : "\r\n" + sheet.ReadOnlyReason);
        }

        private void RefreshDetails()
        {
            _selectedSheet.Text = _currentSheet == null ? "No matching sheet" : _currentSheet.Label + (_currentSheet.IsPlaceholder ? "  ·  Placeholder" : "");
            _tips.SetToolTip(_selectedSheet, _selectedSheet.Text);
            RefreshParameters(); RefreshRevisions(); RefreshReview();
        }

        private void RefreshParameters()
        {
            string selectedKey = SelectedParameter() == null ? null : SelectedParameter().Key;
            string query = (_parameterSearch.Text ?? "").Trim();
            _loading = true;
            try
            {
                _parameters.Rows.Clear();
                if (_currentSheet != null)
                    foreach (var parameter in _currentSheet.Parameters.Where(parameter =>
                        (!_editableOnly.Checked || !IsReadOnly(parameter)) &&
                        (Contains(parameter.Name, query) || Contains(parameter.Group, query) || Contains(parameter.Value, query) || Contains(parameter.OriginalValue, query))))
                    {
                        // Set cell types before attaching the row. Replacing a live cell can
                        // invalidate column ownership/editing state on some WinForms runtimes.
                        var row = (DataGridViewRow)_parameters.RowTemplate.Clone();
                        row.Cells.Clear();
                        DataGridViewCell proposedCell = new DataGridViewTextBoxCell { ValueType = typeof(string) };
                        object proposed = parameter.Value;
                        if (parameter.Kind == SheetParameterKind.YesNo && !IsReadOnly(parameter))
                        {
                            bool value;
                            proposedCell = new DataGridViewCheckBoxCell(true) { ValueType = typeof(CheckState) };
                            proposed = SheetEditorModel.TryYesNo(parameter.Value, out value)
                                ? (value ? CheckState.Checked : CheckState.Unchecked) : CheckState.Indeterminate;
                        }
                        row.Cells.AddRange(new DataGridViewTextBoxCell { ValueType = typeof(string) },
                            new DataGridViewTextBoxCell { ValueType = typeof(string) }, proposedCell,
                            new DataGridViewTextBoxCell { ValueType = typeof(string) }, new DataGridViewTextBoxCell { ValueType = typeof(string) });
                        row.SetValues(ParameterDisplayName(parameter), parameter.OriginalValue, proposed, parameter.Kind + " / " + parameter.Group, "");
                        row.Tag = parameter;
                        _parameters.Rows.Add(row);
                        row.Cells[2].ReadOnly = IsReadOnly(parameter);
                        UpdateParameterRow(row, parameter);
                    }
                var selected = _parameters.Rows.Cast<DataGridViewRow>().FirstOrDefault(row => ((SheetEditorParameter)row.Tag).Key == selectedKey);
                if (selected != null) _parameters.CurrentCell = selected.Cells[2];
            }
            finally { _loading = false; }
            UpdateParameterActions();
        }

        private string ParameterDisplayName(SheetEditorParameter parameter)
        {
            if (_currentSheet == null || _currentSheet.Parameters.Count(p => string.Equals(p.Name, parameter.Name, StringComparison.CurrentCultureIgnoreCase)) < 2) return parameter.Name;
            return parameter.Name + " [" + parameter.Key + "]";
        }

        private bool IsReadOnly(SheetEditorParameter parameter)
        { return parameter.IsReadOnly || _currentSheet == null || !string.IsNullOrEmpty(_currentSheet.ReadOnlyReason); }

        private string ParameterLockReason(SheetEditorParameter parameter)
        {
            if (_currentSheet == null) return "Select a sheet.";
            return !string.IsNullOrEmpty(_currentSheet.ReadOnlyReason) ? _currentSheet.ReadOnlyReason
                : parameter.IsReadOnly ? parameter.ReadOnlyReason ?? "Read-only parameter." : null;
        }

        private void ParameterChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (_loading || e.RowIndex < 0 || e.ColumnIndex != 2) return;
            var row = _parameters.Rows[e.RowIndex]; var parameter = (SheetEditorParameter)row.Tag;
            if (IsReadOnly(parameter)) return;
            // Keep even invalid drafts so switching sheets or filters never silently discards input.
            var rawValue = row.Cells[2].Value;
            if (parameter.Kind == SheetParameterKind.YesNo && rawValue is CheckState)
                parameter.Value = (CheckState)rawValue == CheckState.Checked ? "Yes" : (CheckState)rawValue == CheckState.Unchecked ? "No" : "";
            else parameter.Value = Convert.ToString(rawValue, CultureInfo.CurrentCulture) ?? "";
            bool boolean;
            if (parameter.Kind == SheetParameterKind.YesNo && SheetEditorModel.TryYesNo(parameter.Value, out boolean)) parameter.Value = boolean ? "Yes" : "No";
            UpdateParameterRow(row, parameter);
            _lastAction = "Draft saved. Revit is unchanged until Apply changes.";
            RefreshSheetMarkers(); RefreshReview(); RefreshStatus(); UpdateParameterActions();
        }

        private void UpdateParameterRow(DataGridViewRow row, SheetEditorParameter parameter)
        {
            string reason = ParameterLockReason(parameter);
            string error = reason == null && parameter.Changed ? SheetEditorModel.ValidateValue(parameter, parameter.Value) : null;
            row.Cells[4].Value = reason != null ? "Read only" : error != null ? "Check value" : parameter.Changed ? "Staged" : "Editable";
            row.Cells[4].ToolTipText = reason ?? error ?? "Edit the New value column; no document change is made yet.";
            row.Cells[2].ToolTipText = reason ?? ((parameter.UnitHint ?? "") + (error == null ? "" : "\r\n" + error));
            row.Cells[0].ToolTipText = parameter.Name + "\r\n" + parameter.Group + "\r\nIdentity: " + parameter.Key;
            row.Cells[2].Style.BackColor = reason != null ? Color.FromArgb(238, 241, 244) : error != null ? Color.FromArgb(255, 235, 221)
                : parameter.Changed ? Color.FromArgb(221, 247, 242) : Color.White;
            row.Cells[2].Style.ForeColor = reason == null ? KaTheme.Ink : KaTheme.Muted;
            row.ErrorText = error ?? "";
        }

        private SheetEditorParameter SelectedParameter()
        { return _parameters.CurrentRow == null ? null : _parameters.CurrentRow.Tag as SheetEditorParameter; }

        private void UpdateParameterActions()
        {
            var parameter = SelectedParameter();
            _batchParameter.Enabled = parameter != null && !IsReadOnly(parameter) && _checked.Count > 0;
            _revertParameter.Enabled = parameter != null && parameter.Changed;
            string text = parameter == null ? "Select a parameter. Edit the New value column to stage a change." :
                parameter.Name + "  ·  " + (ParameterLockReason(parameter) ?? (string.IsNullOrEmpty(parameter.UnitHint) ? "Edit the New value column." : parameter.UnitHint));
            if (parameter != null && parameter.Changed)
            {
                var error = SheetEditorModel.ValidateValue(parameter, parameter.Value);
                if (error != null) text = parameter.Name + "  ·  " + error;
            }
            _parameterHelp.Text = text; _tips.SetToolTip(_parameterHelp, text);
        }

        private void RefreshRevisions()
        {
            long selected = SelectedRevision() == null ? -1 : SelectedRevision().Id;
            _loading = true;
            try
            {
                _revisions.Rows.Clear();
                if (_currentSheet != null)
                    foreach (var revision in _snapshot.Revisions.OrderBy(revision => revision.Sequence))
                    {
                        int index = _revisions.Rows.Add(); var row = _revisions.Rows[index]; row.Tag = revision;
                        UpdateRevisionRow(row, revision);
                    }
                var target = _revisions.Rows.Cast<DataGridViewRow>().FirstOrDefault(row => ((SheetEditorRevision)row.Tag).Id == selected);
                if (target != null) _revisions.CurrentCell = target.Cells[3];
            }
            finally { _loading = false; }
            UpdateRevisionActions();
        }

        private void UpdateRevisionRow(DataGridViewRow row, SheetEditorRevision revision)
        {
            if (_currentSheet == null) return;
            bool wasLoading = _loading; _loading = true;
            try
            {
                bool cloud = _currentSheet.CloudRevisionIds.Contains(revision.Id);
                bool additional = _currentSheet.AdditionalRevisionIds.Contains(revision.Id);
                string locked = SheetEditorModel.RevisionLockReason(_currentSheet, revision);
                string number;
                if (!_currentSheet.RevisionNumbers.TryGetValue(revision.Id, out number)) number = revision.Number;
                row.Cells[0].Value = additional || cloud;
                row.Cells[0].ReadOnly = locked != null;
                row.Cells[0].ToolTipText = locked ?? "Include or remove this additional revision on the selected sheet.";
                row.Cells[1].Value = revision.Sequence;
                row.Cells[2].Value = string.IsNullOrEmpty(number) ? "—" : number;
                row.Cells[3].Value = revision.Description;
                row.Cells[4].Value = revision.Date;
                string state = cloud ? "Cloud / required" : additional ? "Additional" : "Not included";
                if (revision.Issued) state += " · Issued";
                if (locked != null && !cloud && !revision.Issued) state += " · Locked";
                bool changed = _currentSheet.OriginalAdditionalRevisionIds.Contains(revision.Id) != additional;
                row.Cells[5].Value = state + (changed ? " · Staged" : "");
                row.Cells[5].ToolTipText = locked ?? (changed ? "Membership change is staged." : "Editable additional-revision membership.");
                row.Cells[0].Style.BackColor = locked != null ? Color.FromArgb(238, 241, 244) : changed ? Color.FromArgb(221, 247, 242) : Color.White;
            }
            finally { _loading = wasLoading; }
        }

        private SheetEditorRevision SelectedRevision()
        { return _revisions.CurrentRow == null ? null : _revisions.CurrentRow.Tag as SheetEditorRevision; }

        private void UpdateRevisionActions()
        {
            var revision = SelectedRevision();
            int eligible = revision == null ? 0 : _snapshot.Sheets.Count(sheet => _checked.Contains(sheet.Id) && SheetEditorModel.RevisionLockReason(sheet, revision) == null);
            _batchRevisionAdd.Enabled = eligible > 0;
            _batchRevisionRemove.Enabled = eligible > 0;
            string text = revision == null ? "No project revision selected. Create revision definitions in Revit first." :
                (SheetEditorModel.RevisionLockReason(_currentSheet, revision) ?? "Unissued additional revision: editable on this sheet.")
                + "  ·  Checked batch: " + eligible + " eligible, " + (_checked.Count - eligible) + " protected.";
            _revisionHelp.Text = text; _tips.SetToolTip(_revisionHelp, text);
        }

        private void RefreshReview()
        {
            var changes = SheetEditorModel.Changes(_snapshot);
            var errors = SheetEditorModel.Validate(_snapshot);
            _review.Rows.Clear();
            foreach (var change in changes)
            {
                int index = _review.Rows.Add(change.Sheet, change.Parameter, change.Before, change.After, errors.Count == 0 ? "Staged" : "Review");
                _review.Rows[index].Tag = change;
            }
            _validation.Text = string.Join("\r\n", errors);
            _validation.Visible = errors.Count > 0;
            _tabs.TabPages[2].Text = "Review changes (" + changes.Count + ")";
        }

        private void RefreshStatus()
        {
            int changedSheets = _snapshot.Sheets.Count(sheet => sheet.Changed);
            int changedValues = SheetEditorModel.Changes(_snapshot).Count;
            var errors = SheetEditorModel.Validate(_snapshot);
            _sheetCount.Text = _sheets.Rows.Count + " shown / " + _snapshot.Sheets.Count + " sheets  ·  " + _checked.Count + " checked";
            _status.Text = changedValues + " staged changes on " + changedSheets + " sheets"
                + (errors.Count > 0 ? "  ·  " + errors.Count + " validation errors — see Review changes" : "  ·  " + (_lastAction ?? "Revit is unchanged until Apply changes."));
            _status.ForeColor = errors.Count > 0 ? KaTheme.Warning : KaTheme.Muted;
            _tips.SetToolTip(_status, errors.Count > 0 ? string.Join("\r\n", errors) : _status.Text);
            _apply.Enabled = changedValues > 0 && errors.Count == 0;
            UpdateParameterActions(); UpdateRevisionActions();
        }

        private void EditCheckedSheets()
        {
            FinishEditing(); var parameter = SelectedParameter();
            if (parameter == null || _checked.Count == 0) return;
            using (var dialog = new SheetBatchValueForm(parameter, _snapshot, _checked))
            {
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                var result = SheetEditorModel.StageValue(_snapshot, _checked, parameter.Key, dialog.Value);
                _lastAction = result.Summary;
                RefreshParameters(); RefreshSheetMarkers(); RefreshReview(); RefreshStatus();
                _tips.SetToolTip(_status, result.Summary + (result.Skipped.Count == 0 ? "" : "\r\n" + string.Join("\r\n", result.Skipped)));
            }
        }

        private void StageRevisionForChecked(bool include)
        {
            FinishEditing(); var revision = SelectedRevision();
            if (revision == null || _checked.Count == 0) return;
            var result = SheetEditorModel.StageRevision(_snapshot, _checked, revision.Id, include);
            _lastAction = result.Summary;
            RefreshRevisions(); RefreshSheetMarkers(); RefreshReview(); RefreshStatus();
            _tips.SetToolTip(_status, result.Summary + (result.Skipped.Count == 0 ? "" : "\r\n" + string.Join("\r\n", result.Skipped)));
        }

        private void ResetDrafts()
        {
            FinishEditing(); SheetEditorModel.Reset(_snapshot);
            _lastAction = "All drafts reset to the captured project values.";
            RefreshDetails(); RefreshSheetMarkers(); RefreshStatus();
        }

        private void ApplyChanges(object sender, EventArgs e)
        {
            FinishEditing(); RefreshReview(); RefreshStatus();
            if (!_apply.Enabled) { _tabs.SelectedIndex = 2; return; }
            DialogResult = DialogResult.OK; Close();
        }

        private static bool Contains(string value, string query)
        { return (value ?? "").IndexOf(query, StringComparison.CurrentCultureIgnoreCase) >= 0; }


        private static TableLayoutPanel CreateLayout(string name, int columns, int rows)
        {
            var panel = new TableLayoutPanel { Name = name, Dock = DockStyle.Fill, ColumnCount = columns, RowCount = rows, Margin = new Padding(0) };
            for (int i = 0; i < columns; i++) panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F / columns));
            return panel;
        }

        private static TabPage Page(string text)
        { return new TabPage(text) { BackColor = Color.White, Padding = new Padding(10) }; }

        private static void Grid(DataGridView grid, string name, bool readOnly)
        {
            KaTheme.StyleGrid(grid, readOnly); grid.Name = name;
            grid.AllowUserToOrderColumns = false;
            grid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            grid.FontChanged += delegate
            {
                grid.DefaultCellStyle.Font = grid.Font;
                grid.ColumnHeadersDefaultCellStyle.Font = grid.Font;
                grid.RowTemplate.Height = Math.Max(29, grid.Font.Height + 12);
                grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
                grid.ColumnHeadersHeight = Math.Max(34, grid.Font.Height + 14);
            };
            grid.DefaultCellStyle.Font = grid.Font;
            grid.ColumnHeadersDefaultCellStyle.Font = grid.Font;
            grid.DataError += delegate(object sender, DataGridViewDataErrorEventArgs e) { e.ThrowException = false; e.Cancel = true; };
        }

        private static DataGridViewTextBoxColumn TextColumn(string name, string heading, float weight, int minimumWidth, bool readOnly)
        { return new DataGridViewTextBoxColumn { Name = name, HeaderText = heading, FillWeight = weight, MinimumWidth = minimumWidth, ReadOnly = readOnly, SortMode = DataGridViewColumnSortMode.NotSortable }; }

        private static Label Label(string text, bool bold = false)
        {
            var label = new Label { Text = text }; ConfigureLabel(label, bold); return label;
        }

        private static void ConfigureLabel(Label label, bool bold)
        {
            label.AutoSize = true; label.Dock = DockStyle.Fill;
            label.Margin = new Padding(0, 4, 0, 6);
            label.ForeColor = bold ? KaTheme.Navy : KaTheme.Muted;
            if (bold) label.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        }
    }
    /// <summary>Values and explicit eligible/skip counts are reviewed before staging a batch.</summary>
    internal sealed class SheetBatchValueForm : Form
    {
        private readonly SheetEditorParameter _parameter;
        private readonly SheetEditorSnapshot _snapshot;
        private readonly HashSet<long> _ids;
        private readonly TextBox _text = new TextBox();
        private readonly ComboBox _boolean = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
        private readonly Label _summary = new Label();
        private readonly TextBox _reasons = new TextBox();
        private readonly Button _stage = KaTheme.Button("Stage for checked sheets", true);
        public string Value { get { return _parameter.Kind == SheetParameterKind.YesNo ? Convert.ToString(_boolean.SelectedItem) : _text.Text; } }

        public SheetBatchValueForm(SheetEditorParameter parameter, SheetEditorSnapshot snapshot, IEnumerable<long> ids)
        {
            _parameter = parameter; _snapshot = snapshot; _ids = new HashSet<long>(ids);
            KaTheme.ApplyForm(this, "Batch sheet value", 700, 480);
            Name = "SheetBatchValueForm"; MinimumSize = new Size(470, 340);
            var scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(14) };
            var content = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 1, RowCount = 6 };
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            for (int i = 0; i < 6; i++) content.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var title = KaTheme.Hint(parameter.Name + "\r\nIdentity: " + parameter.Key); title.Font = new Font("Segoe UI", 14F, FontStyle.Bold); title.ForeColor = KaTheme.Navy;
            var hint = KaTheme.Hint("Set the same proposed value on checked sheets with this editable parameter. Review all drafts in the main window before Apply.");
            content.Controls.Add(title, 0, 0); content.Controls.Add(hint, 0, 1);
            _text.Name = "SheetBatchText"; _text.Dock = DockStyle.Fill; _text.Text = parameter.Value;
            _boolean.Name = "SheetBatchYesNo"; _boolean.Dock = DockStyle.Fill;
            _boolean.Items.AddRange(new object[] { "Yes", "No" });
            bool boolean; _boolean.SelectedItem = SheetEditorModel.TryYesNo(parameter.Value, out boolean) && boolean ? "Yes" : "No";
            content.Controls.Add(parameter.Kind == SheetParameterKind.YesNo ? (Control)_boolean : _text, 0, 2);
            var unit = KaTheme.Hint(parameter.UnitHint ?? "Text values may be empty unless the parameter requires a value.");
            content.Controls.Add(unit, 0, 3);
            _summary.Name = "SheetBatchSummary"; _summary.AutoSize = true; _summary.Dock = DockStyle.Fill; _summary.Margin = new Padding(0, 10, 0, 8);
            content.Controls.Add(_summary, 0, 4);
            _reasons.Name = "SheetBatchSkippedReasons"; _reasons.Dock = DockStyle.Fill; _reasons.Multiline = true; _reasons.ReadOnly = true;
            _reasons.ScrollBars = ScrollBars.Vertical; _reasons.Height = 110; _reasons.BackColor = KaTheme.Surface;
            content.Controls.Add(_reasons, 0, 5);
            content.Layout += delegate
            {
                int width = Math.Max(100, content.ClientSize.Width - 8);
                foreach (var label in new[] { title, hint, unit, _summary }) label.MaximumSize = new Size(width, 0);
            };
            scroll.Controls.Add(content); Controls.Add(scroll);
            var footer = new TableLayoutPanel { Name = "SheetBatchFooter", Dock = DockStyle.Bottom, AutoSize = true, ColumnCount = 2, RowCount = 1, Padding = new Padding(14, 8, 14, 10), BackColor = Color.White };
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70)); footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30)); footer.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            _stage.Name = "SheetBatchStage"; _stage.AutoSize = false; _stage.Dock = DockStyle.Fill; _stage.Height = 40;
            var cancel = KaTheme.Button("Cancel"); cancel.Name = "SheetBatchCancel"; cancel.AutoSize = false; cancel.Dock = DockStyle.Fill; cancel.Height = 40; cancel.DialogResult = DialogResult.Cancel;
            _stage.Click += delegate { UpdateCounts(); if (!_stage.Enabled) return; DialogResult = DialogResult.OK; Close(); };
            footer.Controls.Add(_stage, 0, 0); footer.Controls.Add(cancel, 1, 0); Controls.Add(footer);
            AcceptButton = _stage; CancelButton = cancel;
            _text.TextChanged += delegate { UpdateCounts(); }; _boolean.SelectedIndexChanged += delegate { UpdateCounts(); };
            UpdateCounts();
        }

        protected override void OnShown(EventArgs e) { base.OnShown(e); KaTheme.ClampToScreen(this); }

        private void UpdateCounts()
        {
            int editable = 0, same = 0; var skipped = new List<string>();
            foreach (var sheet in _snapshot.Sheets.Where(sheet => _ids.Contains(sheet.Id)))
            {
                var parameter = sheet.Parameters.FirstOrDefault(item => item.Key == _parameter.Key);
                string error = !string.IsNullOrEmpty(sheet.ReadOnlyReason) ? sheet.ReadOnlyReason : parameter == null ? "Parameter is not present on this sheet." : SheetEditorModel.ValidateValue(parameter, Value);
                if (error != null) { skipped.Add(sheet.Label + ": " + error); continue; }
                editable++; if (string.Equals(parameter.Value ?? "", Value ?? "", StringComparison.Ordinal)) same++;
            }
            _summary.Text = _ids.Count + " checked  ·  " + editable + " eligible  ·  " + skipped.Count + " skipped\r\n"
                + (editable - same) + " values will change; " + same + " already match.";
            _summary.ForeColor = editable > 0 ? Color.FromArgb(0, 131, 122) : KaTheme.Warning;
            _reasons.Text = skipped.Count == 0 ? "All checked sheets can accept this value." : string.Join("\r\n", skipped);
            _stage.Enabled = editable > 0;
        }
    }
}
