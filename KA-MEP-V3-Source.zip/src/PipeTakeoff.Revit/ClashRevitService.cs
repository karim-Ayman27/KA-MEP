using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using PipeTakeoff.Core;

namespace PipeTakeoff.Revit
{
    /// <summary>
    /// Invoke only inside a Revit command or ExternalEvent. No Revit object escapes into the UI DTOs.
    /// Keep this instance for the controller lifetime so that Focus can reuse its own view.
    /// </summary>
    public sealed class ClashRevitService
    {
        private const double MillimetersPerFoot = 304.8;
        private const double CubicMillimetersPerCubicFoot = MillimetersPerFoot * MillimetersPerFoot * MillimetersPerFoot;
        private const int MaxGeometryObjects = 10000;
        private const int MaxSolids = 128;
        private const int MaxFaces = 20000;
        private const int MaxEdges = 40000;
        private const int MaxPairs = 4096;
        private const int MaxDepth = 32;
        private const int MaxSources = 2048;
        private Document focusDocument;
        private ElementId focusViewId;
        private string focusViewUniqueId;

        private sealed class Source
        {
            public ClashModelSource Data;
            public Document Document;
            public RevitLinkInstance Link;
            public readonly List<string> Names = new List<string>();
        }

        private sealed class Resolved
        {
            public Source Source;
            public Element Element;
            public Transform ToHost;
            public ElementId HostSelectionId { get { return Source.Link == null ? Element.Id : Source.Link.Id; } }
        }

        private sealed class Bounds
        {
            public XYZ Min;
            public XYZ Max;
            public void Include(XYZ point)
            {
                if (!Finite(point)) throw new InvalidOperationException("Geometry contains non-finite coordinates.");
                if (Min == null) { Min = point; Max = point; return; }
                Min = new XYZ(Math.Min(Min.X, point.X), Math.Min(Min.Y, point.Y), Math.Min(Min.Z, point.Z));
                Max = new XYZ(Math.Max(Max.X, point.X), Math.Max(Max.Y, point.Y), Math.Max(Max.Z, point.Z));
            }
            public void Include(Bounds other) { Include(other.Min); Include(other.Max); }
            public bool IsDisjoint(Bounds other)
            {
                // Strict separation only; touching bounds still reach the exact solid check.
                return Max.X < other.Min.X || other.Max.X < Min.X ||
                    Max.Y < other.Min.Y || other.Max.Y < Min.Y || Max.Z < other.Min.Z || other.Max.Z < Min.Z;
            }
        }

        private sealed class SolidPart
        {
            public Solid Solid;
            public Bounds Bounds;
        }

        private sealed class GeometrySet : IDisposable
        {
            public readonly List<SolidPart> Parts = new List<SolidPart>();
            public readonly List<GeometryObject> OwnedGeometry = new List<GeometryObject>();
            public readonly Bounds Bounds = new Bounds();
            public int ObjectCount;
            public int FaceCount;
            public int EdgeCount;
            public bool Reflected;
            public void Dispose()
            {
                for (int i = OwnedGeometry.Count - 1; i >= 0; i--)
                    OwnedGeometry[i].Dispose();
            }
        }

        public IList<ClashModelSource> GetSources(Document document)
        {
            RequireDocument(document);
            return ReadSources(document).Select(source => source.Data).ToList();
        }

        public ClashCheckResult Check(Document document, ClashRecord row, ClashCheckOptions options)
        {
            if (row == null) throw new ArgumentNullException(nameof(row));
            options = options ?? new ClashCheckOptions();
            string basis = "Current model; host and direct Revit link instances; exact element identity.";
            try
            {
                RequireDocument(document);
                if (document.IsFamilyDocument) return Review("Clash checking requires a Revit project document.", basis);
                var sources = ReadSources(document);
                string firstError, secondError;
                var first = Resolve(row.Element1, sources, out firstError);
                var second = Resolve(row.Element2, sources, out secondError);
                if (first == null || second == null)
                    return Review(JoinErrors(firstError, secondError), basis);
                if (first.Source.Data.Key == second.Source.Data.Key && first.Element.UniqueId == second.Element.UniqueId)
                    return Review("Both report objects resolve to the same physical element. Correct the IDs or source mapping.", basis);
                if (row.TestKind == ClashTestKind.Clearance || row.TestKind == ClashTestKind.Duplicate)
                    return Review("The imported " + row.TestKind + " criterion is not implemented. This tool checks volumetric hard intersections only.", basis);
                if (!ClashVerificationPolicy.SupportsCriterion(row.TestKind, options.AssumeHardForUnknown))
                    return Review("The report does not establish a supported hard-clash criterion. Explicitly enable the hard-clash assumption to check an unknown test.", basis);
                if (row.TestKind == ClashTestKind.Unknown)
                {
                    basis += " Unknown report criterion explicitly treated as Hard by the user.";
                }
                else basis += " Imported criterion: Hard.";
                double tolerance = options.IntersectionVolumeToleranceCubicMillimeters;
                if (!ClashVerificationPolicy.IsValidTolerance(tolerance))
                    return Review("Intersection tolerance must be finite and between 0 and 1,000,000 mm³.", basis);
                basis += " Fine-detail model solids including contextual/non-visible geometry, independent of the active view; Revit-measured intersection volume tolerance " +
                    tolerance.ToString("0.########", CultureInfo.InvariantCulture) + " mm³. Touching without volume is clear under this criterion.";
                using (var a = ReadGeometry(first))
                using (var b = ReadGeometry(second))
                {
                    if (a.Reflected || b.Reflected) basis += " Reflected placement geometry transformed by Revit's geometry API.";
                    if (a.Bounds.IsDisjoint(b.Bounds))
                        return Result(ClashState.Solved, "Complete solid geometry has disjoint bounds in host coordinates.", basis);
                    if ((long)a.Parts.Count * b.Parts.Count > MaxPairs)
                        return Review("Geometry exceeds the " + MaxPairs + " solid-pair limit. No clear result was inferred.", basis);
                    var evidence = new ClashIntersectionEvidence(tolerance);
                    foreach (var partA in a.Parts)
                    foreach (var partB in b.Parts)
                    {
                        if (partA.Bounds.IsDisjoint(partB.Bounds)) continue;
                        using (var intersection = BooleanOperationsUtils.ExecuteBooleanOperation(partA.Solid, partB.Solid, BooleanOperationsType.Intersect))
                        {
                            if (intersection == null) throw new InvalidOperationException("Revit returned no intersection result.");
                            double volume = Math.Abs(intersection.Volume) * CubicMillimetersPerCubicFoot;
                            evidence.Record(volume);
                            if (evidence.GetState(false) == ClashState.Unsolved)
                                return Result(ClashState.Unsolved, "A solid intersection remains (" + VolumeLabel(volume) + " mm³; tolerance " + VolumeLabel(tolerance) + " mm³).", basis);
                        }
                    }
                    // A sum is an upper bound when the element contains overlapping solids. It safely
                    // proves clear below tolerance, but must not claim a clash above it without a witness.
                    if (evidence.GetState(true) == ClashState.NeedsReview)
                        return Review("Several small intersections total " + VolumeLabel(evidence.TotalUpperBound) + " mm³ (largest " + VolumeLabel(evidence.Largest) +
                            " mm³). Their union was not measured, so the tolerance result needs review.", basis);
                    return Result(ClashState.Solved, "All solid intersections were checked; their combined upper bound is " +
                        VolumeLabel(evidence.TotalUpperBound) + " mm³, within the specified tolerance.", basis);
                }
            }
            catch (Exception ex)
            {
                return Review("The check could not establish complete, valid geometry: " + ErrorMessage(ex) + " No clear result was inferred.", basis);
            }
        }

        public string Focus(UIDocument uiDocument, ClashRecord row, double marginMeters, bool isolate)
        {
            if (uiDocument == null || row == null) return "Focus unavailable: open a project and select a clash.";
            var document = uiDocument.Document;
            try
            {
                RequireDocument(document);
                if (document.IsFamilyDocument) return "Focus requires a Revit project document.";
                if (document.IsReadOnly || document.IsModifiable) return "Focus requires a writable document with no open transaction.";
                var previousView = uiDocument.ActiveView;
                if (previousView == null || !previousView.IsValidObject || previousView.IsTemplate)
                    return "Focus requires a valid active project view.";
                if (!Finite(marginMeters) || marginMeters < 0 || marginMeters > 1000)
                    return "Focus margin must be finite and between 0 and 1,000 metres.";
                var sources = ReadSources(document);
                string firstError, secondError;
                var first = Resolve(row.Element1, sources, out firstError);
                var second = Resolve(row.Element2, sources, out secondError);
                if (first == null || second == null) return "Focus unavailable: " + JoinErrors(firstError, secondError);
                var bounds = ElementBounds(first);
                bounds.Include(ElementBounds(second));
                double margin = marginMeters * 1000 / MillimetersPerFoot;
                var section = new BoundingBoxXYZ
                {
                    Transform = Transform.Identity,
                    Min = new XYZ(bounds.Min.X - margin, bounds.Min.Y - margin, bounds.Min.Z - margin),
                    Max = new XYZ(bounds.Max.X + margin, bounds.Max.Y + margin, bounds.Max.Z + margin)
                };
                if (!Finite(section.Min) || !Finite(section.Max) || section.Max.X - section.Min.X <= 1e-6 ||
                    section.Max.Y - section.Min.Y <= 1e-6 || section.Max.Z - section.Min.Z <= 1e-6)
                    return "Focus unavailable: the element bounds and margin do not form a valid section box.";
                var managedView = GetOwnedView(document);
                string managedViewName = "";
                ViewFamilyType viewType = null;
                if (managedView == null)
                {
                    using (var collector = new FilteredElementCollector(document))
                        viewType = collector.OfClass(typeof(ViewFamilyType)).Cast<ViewFamilyType>().FirstOrDefault(type => type.ViewFamily == ViewFamily.ThreeDimensional);
                    if (viewType == null) return "Focus unavailable: this project has no 3D view family type.";
                }
                // All prerequisites, source resolution, transforms and bounds have been validated
                // before changing the model. The group also covers a failed view activation.
                using (var group = new TransactionGroup(document, "KA MEP Clash Focus"))
                {
                    if (group.Start() != TransactionStatus.Started) return "Focus unavailable: Revit could not start the view transaction group.";
                    try
                    {
                        using (var transaction = new Transaction(document, "Set clash inspection view"))
                        {
                            if (transaction.Start() != TransactionStatus.Started) throw new InvalidOperationException("Could not start the view transaction.");
                            var failureOptions = transaction.GetFailureHandlingOptions();
                            failureOptions.SetFailuresPreprocessor(new RollbackFocusFailures());
                            failureOptions.SetClearAfterRollback(true);
                            transaction.SetFailureHandlingOptions(failureOptions);
                            if (managedView == null)
                            {
                                managedView = View3D.CreateIsometric(document, viewType.Id);
                                managedView.Name = UniqueViewName(document);
                                // A 3D view type can assign a default template. This view is
                                // ours, so release its controls before setting inspection options.
                                managedView.ViewTemplateId = ElementId.InvalidElementId;
                            }
                            if (!managedView.CanUseTemporaryVisibilityModes()) throw new InvalidOperationException("The inspection view cannot use temporary visibility modes.");
                            if (managedView.IsTemporaryHideIsolateActive()) managedView.DisableTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate);
                            managedView.DetailLevel = ViewDetailLevel.Fine;
                            managedView.IsSectionBoxActive = true;
                            managedView.SetSectionBox(section);
                            if (isolate)
                            {
                                var ids = new[] { first.HostSelectionId, second.HostSelectionId }.GroupBy(RevitCompat.Id).Select(g => g.First()).ToList();
                                managedView.IsolateElementsTemporary(ids);
                            }
                            if (transaction.Commit() != TransactionStatus.Committed) throw new InvalidOperationException("Revit rolled back the inspection view changes.");
                        }
                        // ActiveView cannot be assigned during an open Transaction.
                        var managedViewId = managedView.Id;
                        string managedViewUniqueId = managedView.UniqueId;
                        managedViewName = managedView.Name;
                        uiDocument.ActiveView = managedView;
                        if (group.Assimilate() != TransactionStatus.Committed) throw new InvalidOperationException("The inspection view transaction group did not commit.");
                        focusDocument = document;
                        focusViewId = managedViewId;
                        focusViewUniqueId = managedViewUniqueId;
                    }
                    catch
                    {
                        try
                        {
                            if (previousView.IsValidObject && uiDocument.ActiveView.Id != previousView.Id)
                                uiDocument.ActiveView = previousView;
                        }
                        finally
                        {
                            if (group.GetStatus() == TransactionStatus.Started) group.RollBack();
                        }
                        throw;
                    }
                }
                string zoomNote = "";
                try
                {
                    var uiView = uiDocument.GetOpenUIViews().FirstOrDefault(view => view.ViewId == focusViewId);
                    if (uiView != null) uiView.ZoomToFit();
                    else zoomNote = " Automatic zoom was unavailable: Revit did not expose the inspection view window.";
                }
                catch (Exception ex) { zoomNote = " Automatic zoom was unavailable: " + ErrorMessage(ex); }
                bool hasLink = first.Source.Link != null || second.Source.Link != null;
                return "Focused in the managed view '" + managedViewName + "'. " +
                    (isolate ? "Temporary isolation is active. " : "Temporary isolation is off. ") +
                    (hasLink ? "Linked items are framed in host coordinates; isolation applies to their whole link instances. " : "") +
                    "Visibility still follows the inspection view's phases and design options." + zoomNote;
            }
            catch (Exception ex) { return "Focus failed: " + ErrorMessage(ex); }
        }

        private sealed class RollbackFocusFailures : IFailuresPreprocessor
        {
            public FailureProcessingResult PreprocessFailures(FailuresAccessor accessor)
            {
                // Never dismiss model warnings silently or leave the modeless tool waiting on a dialog.
                return accessor.GetFailureMessages().Count == 0 ? FailureProcessingResult.Continue : FailureProcessingResult.ProceedWithRollBack;
            }
        }

        private View3D GetOwnedView(Document document)
        {
            if (!ReferenceEquals(focusDocument, document) || focusViewId == null || string.IsNullOrEmpty(focusViewUniqueId)) return null;
            var view = document.GetElement(focusViewId) as View3D;
            return view != null && view.UniqueId == focusViewUniqueId && !view.IsTemplate && !view.IsPerspective &&
                view.ViewTemplateId == ElementId.InvalidElementId ? view : null;
        }

        private static string UniqueViewName(Document document)
        {
            const string stem = "KA MEP - Clash Inspection";
            HashSet<string> names;
            using (var collector = new FilteredElementCollector(document))
                names = new HashSet<string>(collector.OfClass(typeof(View)).Cast<View>().Select(view => view.Name), StringComparer.OrdinalIgnoreCase);
            if (!names.Contains(stem)) return stem;
            for (int i = 2; i < 10000; i++)
            {
                string candidate = stem + " " + i.ToString(CultureInfo.InvariantCulture);
                if (!names.Contains(candidate)) return candidate;
            }
            return stem + " " + Guid.NewGuid().ToString("N");
        }

        private static IList<Source> ReadSources(Document document)
        {
            var result = new List<Source>();
            var host = new Source
            {
                Document = document,
                Data = new ClashModelSource { Key = "host", DocumentTitle = document.Title, PathHint = document.PathName ?? "", DisplayName = "Host — " + document.Title }
            };
            host.Names.Add(document.Title); host.Names.Add(document.PathName ?? ""); result.Add(host);
            using (var collector = new FilteredElementCollector(document))
            foreach (var link in collector.OfClass(typeof(RevitLinkInstance)).Cast<RevitLinkInstance>().OrderBy(item => RevitCompat.Id(item.Id)))
            {
                if (result.Count >= MaxSources) throw new InvalidOperationException("The model exceeds the supported source count (" + MaxSources + ").");
                var linked = link.GetLinkDocument();
                var linkType = document.GetElement(link.GetTypeId());
                string path = linked == null ? "" : linked.PathName ?? "";
                if (string.IsNullOrWhiteSpace(path))
                {
                    try
                    {
                        var external = ExternalFileUtils.GetExternalFileReference(document, link.GetTypeId());
                        if (external != null) path = ModelPathUtils.ConvertModelPathToUserVisiblePath(external.GetAbsolutePath());
                    }
                    catch { /* Cloud and unavailable paths need not prevent explicit instance mapping. */ }
                }
                long id = RevitCompat.Id(link.Id);
                string title = linked == null ? (linkType == null ? link.Name : linkType.Name) : linked.Title;
                var source = new Source
                {
                    Document = linked, Link = link,
                    Data = new ClashModelSource
                    {
                        // Numeric IDs can be reused after deletion. Pin the actual placement.
                        Key = "link:" + link.UniqueId, LinkInstanceId = id,
                        DocumentTitle = title, PathHint = path, IsLoaded = linked != null,
                        DisplayName = "Link " + id.ToString(CultureInfo.InvariantCulture) + " — " + title + (linked == null ? " (unloaded)" : "")
                    }
                };
                source.Names.Add(title); source.Names.Add(path); source.Names.Add(link.Name);
                if (linkType != null) source.Names.Add(linkType.Name);
                result.Add(source);
            }
            return result;
        }

        private static Resolved Resolve(ClashElementReference reference, IList<Source> allSources, out string error)
        {
            error = "";
            if (reference == null) { error = "Missing element reference."; return null; }
            try
            {
                var candidates = allSources.ToList();
                bool explicitSource = !string.IsNullOrWhiteSpace(reference.SourceOverrideKey);
                if (explicitSource)
                    candidates = candidates.Where(source => string.Equals(source.Data.Key, reference.SourceOverrideKey.Trim(), StringComparison.Ordinal)).ToList();
                else if (!string.IsNullOrWhiteSpace(reference.SourceHint))
                    candidates = candidates.Where(source => ClashVerificationPolicy.MatchesSource(reference.SourceHint, source.Names)).ToList();
                ClashVerificationPolicy.RequireSourceCandidates(reference, candidates.Count,
                    candidates.Any(source => source.Document == null || !source.Document.IsValidObject));
                ClashVerificationPolicy.RequireReportedIdentity(reference);
                bool hasUniqueId = !string.IsNullOrWhiteSpace(reference.UniqueId);
                ElementId reportedId = reference.ElementId.HasValue ? RevitCompat.ElementId(reference.ElementId.Value) : null;
                var matches = new List<Resolved>();
                foreach (var source in candidates)
                {
                    Element element;
                    if (hasUniqueId)
                    {
                        element = source.Document.GetElement(reference.UniqueId.Trim());
                        if (element == null) continue;
                        if (reportedId != null && element.Id != reportedId)
                            throw new InvalidOperationException("The supplied Element ID and UniqueId disagree in '" + source.Data.DisplayName + "'.");
                    }
                    else element = source.Document.GetElement(reportedId);
                    if (element != null) matches.Add(new Resolved { Source = source, Element = element });
                }
                ClashVerificationPolicy.RequireSingleMatch(matches.Count);
                var match = matches[0];
                if (match.Element is ElementType || match.Element is RevitLinkInstance)
                    throw new InvalidOperationException("The identity refers to a type or link container, not the individual clash object.");
                ClashVerificationPolicy.RequireConsistentIdentity(reference, RevitCompat.Id(match.Element.Id), match.Element.UniqueId, match.Source.Data.Key);
                string currentCategory = match.Element.Category == null ? "(No category)" : match.Element.Category.Name;
                ClashVerificationPolicy.RequireConsistentCategory(reference.ReportedCategory, currentCategory);
                match.ToHost = match.Source.Link == null ? Transform.Identity : match.Source.Link.GetTotalTransform();
                ValidateTransform(match.ToHost);
                reference.ResolvedSourceKey = match.Source.Data.Key;
                reference.ResolvedSourceName = match.Source.Data.DisplayName;
                reference.ResolvedElementId = RevitCompat.Id(match.Element.Id);
                reference.ResolvedUniqueId = match.Element.UniqueId;
                reference.ResolvedCategory = currentCategory;
                reference.ResolvedName = match.Element.Name ?? "";
                reference.ResolutionNote = "Exact " + (hasUniqueId ? "UniqueId" : "Element ID") + " match in " + match.Source.Data.DisplayName + ".";
                return match;
            }
            catch (Exception ex)
            {
                // Retain the previous resolved UniqueId and source as an identity pin. Clearing them
                // on deletion would permit a later element reusing the numeric ID to turn green.
                error = ErrorMessage(ex);
                reference.ResolutionNote = error;
                return null;
            }
        }

        private static GeometrySet ReadGeometry(Resolved element)
        {
            var result = new GeometrySet();
            try
            {
                using (var options = new Options { DetailLevel = ViewDetailLevel.Fine, ComputeReferences = false, IncludeNonVisibleObjects = true })
                {
                    // No View is assigned: geometry must not be clipped by the active section box,
                    // visibility, selected phase, or current view's detail level.
                    var geometry = element.Element.get_Geometry(options);
                    if (geometry == null) throw new InvalidOperationException("Element " + RevitCompat.Id(element.Element.Id) + " has no model geometry.");
                    result.OwnedGeometry.Add(geometry);
                    WalkGeometry(geometry, element.ToHost, result, 0);
                }
                if (result.Parts.Count == 0)
                    throw new InvalidOperationException("Element " + RevitCompat.Id(element.Element.Id) + " has no valid volumetric solids (phase, design option or unsupported representation may be involved).");
                return result;
            }
            catch { result.Dispose(); throw; }
        }

        private static void WalkGeometry(GeometryElement geometry, Transform transform, GeometrySet result, int depth)
        {
            if (depth > MaxDepth) throw new InvalidOperationException("Geometry nesting exceeds " + MaxDepth + " levels.");
            ValidateTransform(transform);
            if (transform.HasReflection)
            {
                // SolidUtils.CreateTransformed rejects some negative-scale transforms. The geometry
                // element API supports conformal reflected transforms without tessellating solids.
                // Bake this level once, then use instance geometry to consume any nested transforms.
                var reflected = geometry.GetTransformed(transform);
                if (reflected == null) throw new InvalidOperationException("Revit could not transform reflected geometry.");
                result.OwnedGeometry.Add(reflected);
                result.Reflected = true;
                WalkBakedGeometry(reflected, result, depth + 1);
                return;
            }
            foreach (GeometryObject item in geometry)
            {
                CountObject(result);
                var instance = item as GeometryInstance;
                if (instance != null)
                {
                    var nested = instance.GetSymbolGeometry();
                    if (nested == null) throw new InvalidOperationException("A geometry instance could not be expanded.");
                    result.OwnedGeometry.Add(nested);
                    WalkGeometry(nested, transform.Multiply(instance.Transform), result, depth + 1);
                    continue;
                }
                var solid = item as Solid;
                if (solid != null)
                {
                    if (EmptySolid(solid)) continue;
                    var transformed = transform.IsIdentity ? solid : SolidUtils.CreateTransformed(solid, transform);
                    if (!ReferenceEquals(solid, transformed)) result.OwnedGeometry.Add(transformed);
                    AddSolid(transformed, result);
                    continue;
                }
                ValidateNonSolid(item);
            }
        }

        private static void WalkBakedGeometry(GeometryElement geometry, GeometrySet result, int depth)
        {
            if (depth > MaxDepth) throw new InvalidOperationException("Geometry nesting exceeds " + MaxDepth + " levels.");
            foreach (GeometryObject item in geometry)
            {
                CountObject(result);
                var instance = item as GeometryInstance;
                if (instance != null)
                {
                    // GetInstanceGeometry returns a copy with this instance's transform already
                    // applied. Applying instance.Transform again would double-transform the geometry.
                    var nested = instance.GetInstanceGeometry();
                    if (nested == null) throw new InvalidOperationException("Reflected instance geometry could not be expanded.");
                    result.OwnedGeometry.Add(nested);
                    WalkBakedGeometry(nested, result, depth + 1);
                    continue;
                }
                var solid = item as Solid;
                if (solid != null) { if (!EmptySolid(solid)) AddSolid(solid, result); continue; }
                ValidateNonSolid(item);
            }
        }

        private static void CountObject(GeometrySet result)
        {
            if (++result.ObjectCount > MaxGeometryObjects) throw new InvalidOperationException("Geometry object count exceeds " + MaxGeometryObjects + ".");
        }

        private static bool EmptySolid(Solid solid)
        {
            return solid.Faces.Size == 0 && solid.Edges.Size == 0;
        }

        private static void AddSolid(Solid solid, GeometrySet result)
        {
            if (solid == null || solid.Faces.Size == 0 || solid.Edges.Size == 0)
                throw new InvalidOperationException("A solid has incomplete topology.");
            double volume = Math.Abs(solid.Volume);
            if (!Finite(volume) || volume <= 0) throw new InvalidOperationException("A solid has no valid positive volume; open or degenerate geometry cannot establish a clear result.");
            if (solid.Faces.Size > MaxFaces - result.FaceCount || solid.Edges.Size > MaxEdges - result.EdgeCount || result.Parts.Count >= MaxSolids)
                throw new InvalidOperationException("Geometry complexity exceeds " + MaxSolids + " solids, " + MaxFaces + " faces or " + MaxEdges + " edges per object.");
            result.FaceCount += solid.Faces.Size;
            result.EdgeCount += solid.Edges.Size;
            // The API can expose open shells as Solid. Signed volume alone does not prove
            // a closed boundary, especially before the disjoint-bounds shortcut.
            foreach (Edge edge in solid.Edges)
                if (edge.GetFace(0) == null || edge.GetFace(1) == null)
                    throw new InvalidOperationException("A solid has an open edge; incomplete geometry cannot establish a clear result.");
            var bounds = TransformedBounds(solid.GetBoundingBox(), Transform.Identity);
            result.Parts.Add(new SolidPart { Solid = solid, Bounds = bounds });
            result.Bounds.Include(bounds);
        }

        private static void ValidateNonSolid(GeometryObject item)
        {
            if (item == null) throw new InvalidOperationException("Geometry contains an unreadable object.");
            if (item is Mesh) throw new InvalidOperationException("Mesh geometry cannot be verified by the supported solid intersection check.");
            // Curves, points and polylines are common non-volumetric family representations.
            // They do not make a valid solid incomplete; an entirely non-solid element still fails.
            if (!(item is Curve) && !(item is PolyLine) && !(item is Point))
                throw new InvalidOperationException("Unsupported geometry type: " + item.GetType().Name + ".");
        }

        private static Bounds ElementBounds(Resolved resolved)
        {
            var box = resolved.Element.get_BoundingBox(null);
            if (box == null) throw new InvalidOperationException("Element " + RevitCompat.Id(resolved.Element.Id) + " has no usable model bounding box.");
            return TransformedBounds(box, resolved.ToHost);
        }

        private static Bounds TransformedBounds(BoundingBoxXYZ box, Transform toHost)
        {
            if (box == null || !box.Enabled || !Finite(box.Min) || !Finite(box.Max) ||
                box.Min.X > box.Max.X || box.Min.Y > box.Max.Y || box.Min.Z > box.Max.Z)
                throw new InvalidOperationException("Geometry has invalid or unavailable bounds.");
            var transform = toHost.Multiply(box.Transform);
            ValidateTransform(transform);
            var result = new Bounds();
            for (int x = 0; x < 2; x++)
            for (int y = 0; y < 2; y++)
            for (int z = 0; z < 2; z++)
                result.Include(transform.OfPoint(new XYZ(x == 0 ? box.Min.X : box.Max.X, y == 0 ? box.Min.Y : box.Max.Y, z == 0 ? box.Min.Z : box.Max.Z)));
            return result;
        }

        private static void ValidateTransform(Transform transform)
        {
            if (transform == null || !transform.IsConformal || !Finite(transform.Origin) || !Finite(transform.BasisX) ||
                !Finite(transform.BasisY) || !Finite(transform.BasisZ) || !Finite(transform.Determinant) || Math.Abs(transform.Determinant) < 1e-12)
                throw new InvalidOperationException("The model or geometry transform is invalid or non-conformal.");
        }

        private static void RequireDocument(Document document)
        {
            if (document == null || !document.IsValidObject) throw new InvalidOperationException("The Revit document is unavailable.");
        }
        private static bool Finite(double value) { return !double.IsNaN(value) && !double.IsInfinity(value); }
        private static bool Finite(XYZ point) { return point != null && Finite(point.X) && Finite(point.Y) && Finite(point.Z); }
        private static string VolumeLabel(double value) { return value.ToString("0.########", CultureInfo.InvariantCulture); }
        private static string ErrorMessage(Exception exception)
        {
            string message = exception.Message ?? exception.GetType().Name;
            return message.Length <= 500 ? message : message.Substring(0, 500);
        }
        private static string JoinErrors(string first, string second)
        {
            return (string.IsNullOrEmpty(first) ? "" : "Object 1: " + first) +
                (string.IsNullOrEmpty(first) || string.IsNullOrEmpty(second) ? "" : " ") +
                (string.IsNullOrEmpty(second) ? "" : "Object 2: " + second);
        }
        private static ClashCheckResult Review(string note, string basis) { return Result(ClashState.NeedsReview, note, basis); }
        private static ClashCheckResult Result(ClashState state, string note, string basis)
        {
            return new ClashCheckResult { State = state, Note = note, Basis = basis, CheckedAt = DateTime.Now };
        }
    }
}
