using System;
using System.Collections.Generic;
using PipeTakeoff.Core;

namespace PipeTakeoff.Revit
{
    // Detached policy shared by the Revit service and its API-free decision tests.
    internal static class ClashVerificationPolicy
    {
        public static bool SupportsCriterion(ClashTestKind kind, bool assumeHardForUnknown)
        {
            return kind == ClashTestKind.Hard || (kind == ClashTestKind.Unknown && assumeHardForUnknown);
        }

        public static bool IsValidTolerance(double tolerance)
        {
            return Finite(tolerance) && tolerance >= 0 && tolerance <= 1000000;
        }

        public static void RequireSourceCandidates(ClashElementReference reference, int candidateCount, bool anyUnavailable)
        {
            if (reference == null) throw new InvalidOperationException("Missing element reference.");
            if (candidateCount <= 0)
                throw new InvalidOperationException("The report source is absent or cannot be matched exactly. Map it to the host or a direct link instance.");
            if (candidateCount > 1 && (!string.IsNullOrWhiteSpace(reference.SourceHint) || !string.IsNullOrWhiteSpace(reference.SourceOverrideKey)))
                throw new InvalidOperationException("The source name matches multiple models or repeated link placements. Choose an explicit source instance.");
            if (anyUnavailable)
                throw new InvalidOperationException("A possible source is unloaded or unavailable. Load it or choose an explicit loaded source; identity cannot be inferred.");
        }

        public static void RequireReportedIdentity(ClashElementReference reference)
        {
            if (reference == null) throw new InvalidOperationException("Missing element reference.");
            if (string.IsNullOrWhiteSpace(reference.UniqueId) && !reference.ElementId.HasValue)
                throw new InvalidOperationException("The report provides neither a Revit Element ID nor a UniqueId.");
            if (reference.ElementId.HasValue && reference.ElementId.Value <= 0)
                throw new InvalidOperationException("A model element ID must be positive.");
        }

        public static void RequireSingleMatch(int matchCount)
        {
            if (matchCount <= 0)
                throw new InvalidOperationException("The referenced element is missing. Deletion or an unavailable source is not proof that a clash is solved.");
            if (matchCount > 1)
                throw new InvalidOperationException("The identity matches multiple sources or repeated link placements. Choose an explicit source instance.");
        }

        public static void RequireConsistentIdentity(ClashElementReference reference, long elementId, string uniqueId, string sourceKey)
        {
            RequireReportedIdentity(reference);
            if (elementId <= 0 || string.IsNullOrWhiteSpace(uniqueId) || string.IsNullOrWhiteSpace(sourceKey))
                throw new InvalidOperationException("The resolved element has incomplete identity information.");
            if (reference.ElementId.HasValue && reference.ElementId.Value != elementId)
                throw new InvalidOperationException("The supplied Element ID and resolved UniqueId disagree.");
            if (!string.IsNullOrWhiteSpace(reference.UniqueId) && !string.Equals(reference.UniqueId.Trim(), uniqueId, StringComparison.Ordinal))
                throw new InvalidOperationException("The supplied UniqueId does not match the resolved element.");
            bool hasPin = !string.IsNullOrEmpty(reference.ResolvedUniqueId) || !string.IsNullOrEmpty(reference.ResolvedSourceKey) || reference.ResolvedElementId.HasValue;
            if (hasPin && (!string.Equals(reference.ResolvedUniqueId, uniqueId, StringComparison.Ordinal) ||
                !string.Equals(reference.ResolvedSourceKey, sourceKey, StringComparison.Ordinal) ||
                (reference.ResolvedElementId.HasValue && reference.ResolvedElementId.Value != elementId)))
                throw new InvalidOperationException("The previously verified identity changed. An ID may have been reused or the source changed; review and remap this reference.");
        }

        public static void RequireConsistentCategory(string reportedCategory, string currentCategory)
        {
            string reported = NormalizeWhitespace(reportedCategory);
            if (reported.Length == 0) return;
            string current = NormalizeWhitespace(currentCategory);
            if (!string.Equals(reported, current, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Reported category '" + reported + "' differs from current category '" + current +
                    "'. The ID may be stale, or the report may use a different category language. Review the original identity; no clear result was inferred.");
        }

        private static string NormalizeWhitespace(string value)
        {
            return string.Join(" ", (value ?? "").Split((char[])null, StringSplitOptions.RemoveEmptyEntries));
        }

        public static bool MatchesSource(string hint, IEnumerable<string> sourceNames)
        {
            string expected = NormalizeSource(hint);
            if (expected.Length == 0 || sourceNames == null) return false;
            bool hasPath = expected.IndexOf('/') >= 0;
            foreach (string name in sourceNames)
            {
                string actual = NormalizeSource(name);
                // A supplied path is provenance. Do not discard it and accidentally match
                // another model with the same filename in an unrelated directory.
                if (hasPath)
                {
                    if (string.Equals(expected, actual, StringComparison.OrdinalIgnoreCase)) return true;
                }
                else
                {
                    int slash = actual.LastIndexOf('/');
                    if (slash >= 0) actual = actual.Substring(slash + 1);
                    if (string.Equals(expected, actual, StringComparison.OrdinalIgnoreCase)) return true;
                }
            }
            return false;
        }

        private static string NormalizeSource(string value)
        {
            value = (value ?? "").Trim().Trim('"').Replace('\\', '/');
            // A Revit-exported NWC cache may identify its originating RVT by the same
            // exact stem. An NWD federation or RFA family is not a project-model alias.
            foreach (string extension in new[] { ".rvt", ".nwc" })
                if (value.EndsWith(extension, StringComparison.OrdinalIgnoreCase))
                    return value.Substring(0, value.Length - extension.Length);
            return value;
        }

        private static bool Finite(double value) { return !double.IsNaN(value) && !double.IsInfinity(value); }
    }

    internal sealed class ClashIntersectionEvidence
    {
        private readonly double tolerance;
        public double TotalUpperBound { get; private set; }
        public double Largest { get; private set; }

        public ClashIntersectionEvidence(double toleranceCubicMillimeters)
        {
            if (!ClashVerificationPolicy.IsValidTolerance(toleranceCubicMillimeters))
                throw new ArgumentOutOfRangeException(nameof(toleranceCubicMillimeters));
            tolerance = toleranceCubicMillimeters;
        }

        public void Record(double volumeCubicMillimeters)
        {
            if (double.IsNaN(volumeCubicMillimeters) || double.IsInfinity(volumeCubicMillimeters) || volumeCubicMillimeters < 0)
                throw new InvalidOperationException("Revit returned an invalid intersection volume.");
            double total = TotalUpperBound + volumeCubicMillimeters;
            if (double.IsInfinity(total)) throw new InvalidOperationException("Accumulated intersection volume is non-finite.");
            TotalUpperBound = total;
            Largest = Math.Max(Largest, volumeCubicMillimeters);
        }

        public ClashState GetState(bool allPairsChecked)
        {
            if (Largest > tolerance) return ClashState.Unsolved;
            // Summed pair volumes bound the union from above; overlapping parts can
            // double-count. Only a complete sum within tolerance proves clearance.
            if (!allPairsChecked || TotalUpperBound > tolerance) return ClashState.NeedsReview;
            return ClashState.Solved;
        }
    }
}
