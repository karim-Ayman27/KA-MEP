using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Electrical;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;

namespace PipeTakeoff.Revit
{
    /// <summary>Call only inside a Revit external command/event. Scans never change the document.</summary>
    public static class ModelReviewService
    {
        private static long changeGeneration;
        // A conservative global generation avoids relying on managed Document wrapper identity.
        // App subscribes to DocumentChanged before any review opens. Any document change requires Refresh.
        public static void NotifyDocumentChanged(Document document)
        {
            if (document != null) Interlocked.Increment(ref changeGeneration);
        }
        public static void ClearChangeTracking() { /* No Document references are retained; never reset the monotonic generation. */ }
        private static long Generation(Document document) { return Interlocked.Read(ref changeGeneration); }
        private static void ValidateGeneration(Document document, long generation)
        {
            if (Generation(document) != generation) throw new InvalidOperationException("A Revit document changed after this review. Refresh and preview again.");
        }
        private static readonly HashSet<string> PlaceableViewTypes = new HashSet<string>(StringComparer.Ordinal)
        { "FloorPlan", "CeilingPlan", "Elevation", "ThreeD", "Schedule", "DraftingView", "Legend", "EngineeringPlan", "AreaPlan", "Section", "Detail", "PanelSchedule", "ColumnSchedule" };
        private static readonly BuiltInCategory[] MepFamilyCategories = {
            BuiltInCategory.OST_PipeFitting, BuiltInCategory.OST_PipeAccessory, BuiltInCategory.OST_DuctFitting,
            BuiltInCategory.OST_DuctAccessory, BuiltInCategory.OST_MechanicalEquipment, BuiltInCategory.OST_PlumbingFixtures,
            BuiltInCategory.OST_Sprinklers, BuiltInCategory.OST_CableTrayFitting, BuiltInCategory.OST_ConduitFitting,
            BuiltInCategory.OST_ElectricalEquipment, BuiltInCategory.OST_ElectricalFixtures, BuiltInCategory.OST_LightingFixtures,
            BuiltInCategory.OST_LightingDevices, BuiltInCategory.OST_CommunicationDevices, BuiltInCategory.OST_DataDevices,
            BuiltInCategory.OST_FireAlarmDevices, BuiltInCategory.OST_SecurityDevices, BuiltInCategory.OST_NurseCallDevices,
            BuiltInCategory.OST_TelephoneDevices };

        public static ReviewSnapshot Scan(Document document)
        {
            RequireProject(document);
            var result = new ReviewSnapshot { ProjectTitle = document.Title, DocumentKey = DocumentKey(document), ScannedAt = DateTime.Now, ChangeGeneration = Generation(document) };
            var duplicateGroups = new List<IEnumerable<long>>();
            var duplicateSources = new Dictionary<long, HashSet<string>>();
            RunCheck(result, "Element count", () => result.ModelElementCount = new FilteredElementCollector(document).WhereElementIsNotElementType().GetElementCount());
            RunCheck(result, "CAD imports", () => ReadCad(document, result));
            RunCheck(result, "Unplaced views", () => ReadViews(document, result));
            RunCheck(result, "Revit warnings", () => ReadWarnings(document, result, duplicateGroups, duplicateSources));
            RunCheck(result, "MEP duplicate candidates", () => ReadCoincidentMep(document, result, duplicateGroups, duplicateSources));
            foreach (var ids in ReviewDuplicateGroups.Merge(duplicateGroups))
            {
                var sources = ids.Where(duplicateSources.ContainsKey).SelectMany(id => duplicateSources[id]).Distinct().OrderBy(x => x);
                result.Findings.Add(new ReviewFinding {
                    Key = ReviewHealth.DuplicateKey(ids), Kind = ReviewKind.PotentialDuplicate,
                    IssueCode = "potential-duplicates", IssueTitle = "Potential duplicate elements",
                    Title = "Potential duplicate group · " + ids.Count + " elements",
                    Detail = string.Join("; ", sources) + ". Inspect IDs " + string.Join(", ", ids) + ". Coincidence does not prove that an element is redundant. Choose any deletion manually in Revit after checking connections and design intent.",
                    ElementIds = ids, CanClean = false, CleanupBlockReason = "Duplicate groups are review-only. The tool never chooses which element to delete."
                });
            }
            foreach (long id in result.Findings.SelectMany(f => f.ElementIds).Distinct())
            {
                var element = document.GetElement(RevitCompat.ElementId(id));
                if (element == null) continue;
                result.UniqueIds[id] = element.UniqueId;
                result.Fingerprints[id] = Fingerprint(element);
            }
            result.Notes.Add("This document only; linked model contents are not scanned. The element count includes all non-type project elements.");
            result.Notes.Add("Unplaced views are review candidates, not errors. Templates, browser/internal views and titleblock/internal keynote schedules are excluded. Schedule and panel-schedule placements are included.");
            result.Notes.Add("Duplicate checks use native duplicate-instance warnings plus matching straight MEP curve/point-family signatures; curved runs and non-MEP geometry are not covered by the signature check.");
            result.Notes.Add("Issue summary shows each check/repeated warning reason once, with its occurrence and distinct affected-element counts. Open issue details to select individual cleanup candidates. Grouping does not change the health score.");
            result.Findings = result.Findings.OrderBy(f => f.Kind).ThenBy(f => f.Title, StringComparer.CurrentCultureIgnoreCase).ThenBy(f => f.Key, StringComparer.Ordinal).ToList();
            return result;
        }

        public static ReviewCleanupPlan PreviewCleanup(Document document, ReviewSnapshot snapshot, IEnumerable<string> findingKeys)
        {
            RequireWritable(document);
            if (snapshot == null || snapshot.DocumentKey != DocumentKey(document)) throw new InvalidOperationException("This review belongs to another document. Refresh the current document first.");
            ValidateGeneration(document, snapshot.ChangeGeneration);
            var selected = ReviewHealth.CleanableSelection(snapshot, findingKeys);
            var current = Scan(document);
            var keys = selected.Select(f => f.Key).ToList();
            var live = ReviewHealth.CleanableSelection(current, keys);
            var requested = live.SelectMany(f => f.ElementIds).Distinct().OrderBy(x => x).ToList();
            foreach (long id in requested) ValidateOriginal(document, id, snapshot.UniqueIds, snapshot.Fingerprints);
            var affected = DeleteInGroup(document, requested, null, false);
            var plan = new ReviewCleanupPlan { DocumentKey = snapshot.DocumentKey, ChangeGeneration = Generation(document), FindingKeys = keys, RequestedIds = requested, AffectedIds = affected };
            var selectedIds = new HashSet<long>(requested);
            foreach (long id in affected)
            {
                var element = document.GetElement(RevitCompat.ElementId(id));
                if (element == null) throw new InvalidOperationException("Unable to inspect affected element " + id + ". No cleanup was applied.");
                string blocked = ProtectionReason(document, element);
                if (element is View && !selectedIds.Contains(id)) blocked = "An additional view would be deleted. Select and review it explicitly first.";
                if (!string.IsNullOrEmpty(blocked)) throw new InvalidOperationException("Cleanup would also affect protected element " + Label(element) + ": " + blocked);
                plan.UniqueIds[id] = element.UniqueId;
                plan.Fingerprints[id] = Fingerprint(element);
                plan.Lines.Add((selectedIds.Contains(id) ? "SELECTED  " : "DEPENDENT  ") + Label(element));
            }
            plan.Fingerprint = PlanFingerprint(plan);
            return plan;
        }

        public static string ApplyCleanup(Document document, ReviewCleanupPlan plan)
        {
            RequireWritable(document);
            if (plan == null || plan.DocumentKey != DocumentKey(document) || plan.Fingerprint != PlanFingerprint(plan))
                throw new InvalidOperationException("The cleanup preview is invalid or belongs to another document. Preview again.");
            if (plan.RequestedIds.Count == 0 || plan.AffectedIds.Count == 0) throw new InvalidOperationException("The cleanup preview contains no elements.");
            ValidateGeneration(document, plan.ChangeGeneration);
            var current = Scan(document);
            var live = ReviewHealth.CleanableSelection(current, plan.FindingKeys);
            var requested = live.SelectMany(f => f.ElementIds).Distinct().OrderBy(x => x).ToList();
            if (!requested.SequenceEqual(plan.RequestedIds)) throw new InvalidOperationException("The cleanup selection changed. Refresh and preview again.");
            foreach (long id in plan.AffectedIds)
            {
                ValidateOriginal(document, id, plan.UniqueIds, plan.Fingerprints);
                string blocked = ProtectionReason(document, document.GetElement(RevitCompat.ElementId(id)));
                if (!string.IsNullOrEmpty(blocked)) throw new InvalidOperationException("Element " + id + ": " + blocked);
            }
            DeleteInGroup(document, requested, plan.AffectedIds, true);
            return "Deleted " + plan.RequestedIds.Count + " selected elements and " + (plan.AffectedIds.Count - plan.RequestedIds.Count) + " reviewed dependent elements. Use one Revit Undo to restore this cleanup.";
        }

        private static void ReadCad(Document document, ReviewSnapshot result)
        {
            foreach (var import in new FilteredElementCollector(document).OfClass(typeof(ImportInstance)).Cast<ImportInstance>())
            {
                bool linked = import.IsLinked;
                string blocked = linked ? "CAD links are informational and must be managed in Revit Manage Links." : ProtectionReason(document, import);
                var type = document.GetElement(import.GetTypeId());
                var owner = document.GetElement(import.OwnerViewId) as View;
                result.Findings.Add(new ReviewFinding {
                    Key = (linked ? "cad-link:" : "cad-import:") + RevitCompat.Id(import.Id),
                    Kind = linked ? ReviewKind.CadLink : ReviewKind.CadImport,
                    IssueCode = linked ? "cad-links" : "cad-imports", IssueTitle = linked ? "Linked CAD files (informational)" : "Imported CAD files",
                    Title = (type == null ? import.Name : type.Name) + " · " + RevitCompat.Id(import.Id),
                    Detail = (linked ? "Linked CAD" : "Imported CAD") + (owner == null ? " · model instance" : " · view: " + owner.Name) + ". " + (string.IsNullOrEmpty(blocked) ? "Select explicitly to preview deletion and dependent elements." : blocked),
                    ElementIds = new List<long> { RevitCompat.Id(import.Id) }, CanClean = !linked && string.IsNullOrEmpty(blocked), CleanupBlockReason = blocked
                });
            }
        }

        private static void ReadViews(Document document, ReviewSnapshot result)
        {
            var placed = new HashSet<long>();
            foreach (var sheet in new FilteredElementCollector(document).OfClass(typeof(ViewSheet)).Cast<ViewSheet>())
                foreach (var id in sheet.GetAllPlacedViews()) placed.Add(RevitCompat.Id(id));
            foreach (var instance in new FilteredElementCollector(document).OfClass(typeof(ScheduleSheetInstance)).Cast<ScheduleSheetInstance>())
                placed.Add(RevitCompat.Id(instance.ScheduleId));
            foreach (var instance in new FilteredElementCollector(document).OfClass(typeof(PanelScheduleSheetInstance)).Cast<PanelScheduleSheetInstance>())
                placed.Add(RevitCompat.Id(instance.ScheduleId));
            foreach (var view in new FilteredElementCollector(document).OfClass(typeof(View)).Cast<View>())
            {
                if (view.IsTemplate || IsPanelTemplate(view) || !PlaceableViewTypes.Contains(view.ViewType.ToString()) || placed.Contains(RevitCompat.Id(view.Id))) continue;
                var schedule = view as ViewSchedule;
                if (schedule != null && (schedule.IsTitleblockRevisionSchedule || schedule.IsInternalKeynoteSchedule)) continue;
                string blocked = ProtectionReason(document, view);
                if (view.GetPrimaryViewId() != ElementId.InvalidElementId) blocked = "Dependent view: review its primary view before any manual removal.";
                if (view.GetDependentViewIds().Count > 0) blocked = "This primary view has dependent views; cleanup is protected.";
                result.Findings.Add(new ReviewFinding {
                    Key = "unplaced-view:" + RevitCompat.Id(view.Id), Kind = ReviewKind.UnplacedView,
                    IssueCode = "unplaced-views", IssueTitle = "Views not placed on sheets",
                    Title = view.Name + " · " + view.ViewType,
                    Detail = "Not placed on a sheet. It may still be used for working, coordination, references or exports. " + (string.IsNullOrEmpty(blocked) ? "Preview shows all elements that Revit would delete with this view." : blocked),
                    ElementIds = new List<long> { RevitCompat.Id(view.Id) }, CanClean = string.IsNullOrEmpty(blocked), CleanupBlockReason = blocked
                });
            }
        }

        private static void ReadWarnings(Document document, ReviewSnapshot result, List<IEnumerable<long>> groups, Dictionary<long, HashSet<string>> sources)
        {
            var duplicateIds = new HashSet<Guid> { BuiltInFailures.OverlapFailures.DuplicateInstances.Guid, BuiltInFailures.PerformanceFailures.DuplicateInstances.Guid };
            int index = 0;
            foreach (var warning in document.GetWarnings())
            {
                var failingIds = warning.GetFailingElements().Select(RevitCompat.Id).Distinct().OrderBy(x => x).ToList();
                var ids = failingIds.Concat(warning.GetAdditionalElements().Select(RevitCompat.Id)).Distinct().OrderBy(x => x).ToList();
                if (duplicateIds.Contains(warning.GetFailureDefinitionId().Guid) && failingIds.Count >= 2)
                {
                    AddDuplicate(groups, sources, failingIds, "Revit duplicate-instance warning: " + warning.GetDescriptionText());
                    continue;
                }
                result.Findings.Add(new ReviewFinding {
                    Key = "warning:" + warning.GetFailureDefinitionId().Guid.ToString("N") + ":" + index++, Kind = ReviewKind.RevitWarning,
                    IssueCode = "revit-warning:" + warning.GetFailureDefinitionId().Guid.ToString("N"), IssueTitle = warning.GetDescriptionText(),
                    Title = warning.GetDescriptionText(), Detail = "Existing Revit warning. Resolve the underlying condition in Revit, then Refresh. IDs: " + string.Join(", ", ids),
                    ElementIds = ids, CanClean = false, CleanupBlockReason = "Warnings are reviewed in Revit; the tool does not dismiss or suppress them."
                });
            }
        }

        private static void ReadCoincidentMep(Document document, ReviewSnapshot result, List<IEnumerable<long>> groups, Dictionary<long, HashSet<string>> sources)
        {
            var signatures = new Dictionary<string, List<long>>(StringComparer.Ordinal);
            int skipped = 0;
            var elements = new FilteredElementCollector(document).OfClass(typeof(MEPCurve)).WhereElementIsNotElementType().ToElements()
                .Concat(new FilteredElementCollector(document).OfClass(typeof(FamilyInstance)).WherePasses(new ElementMulticategoryFilter(MepFamilyCategories)).WhereElementIsNotElementType().ToElements());
            foreach (var element in elements)
            {
                try
                {
                    string signature = GeometrySignature(element);
                    if (signature == null) { skipped++; continue; }
                    List<long> ids;
                    if (!signatures.TryGetValue(signature, out ids)) signatures.Add(signature, ids = new List<long>());
                    ids.Add(RevitCompat.Id(element.Id));
                }
                catch (Autodesk.Revit.Exceptions.RegenerationFailedException) { throw; }
                catch (Exception ex)
                {
                    result.IsComplete = false;
                    if (result.Notes.Count < 25) result.Notes.Add("Duplicate check could not read element " + RevitCompat.Id(element.Id) + ": " + ex.Message);
                }
            }
            foreach (var ids in signatures.Values.Where(ids => ids.Count > 1))
                AddDuplicate(groups, sources, ids, "Matching MEP type, placement, phase, workset and rounded geometry signature (0.0000001 ft)");
            if (skipped > 0) result.Notes.Add(skipped + " MEP elements are outside the straight-curve/point-family signature scope. Native Revit duplicate warnings still apply.");
        }

        private static string GeometrySignature(Element element)
        {
            if (element.Category == null) return null;
            string prefix = RevitCompat.Id(element.Category.Id) + "|" + RevitCompat.Id(element.GetTypeId()) + "|" + RevitCompat.Id(element.LevelId) + "|" +
                RevitCompat.Id(element.CreatedPhaseId) + "|" + RevitCompat.Id(element.DemolishedPhaseId) + "|" + (element.DesignOption == null ? -1 : RevitCompat.Id(element.DesignOption.Id)) + "|" +
                element.WorksetId.IntegerValue + "|" + RevitCompat.Id(element.GroupId) + "|";
            var curve = element as MEPCurve;
            if (curve != null)
            {
                var location = curve.Location as LocationCurve;
                var line = location == null ? null : location.Curve as Line;
                if (line == null || !line.IsBound) return null;
                var ends = new[] { Point(line.GetEndPoint(0)), Point(line.GetEndPoint(1)) }.OrderBy(x => x, StringComparer.Ordinal).ToArray();
                return prefix + "curve|" + string.Join("|", ends) + "|" + ParameterValue(element, BuiltInParameter.RBS_CURVE_DIAMETER_PARAM) + "|" + ParameterValue(element, BuiltInParameter.RBS_PIPE_DIAMETER_PARAM) + "|" +
                    ParameterValue(element, BuiltInParameter.RBS_CURVE_WIDTH_PARAM) + "|" + ParameterValue(element, BuiltInParameter.RBS_CURVE_HEIGHT_PARAM) + "|" +
                    ParameterValue(element, BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM) + "|" + ParameterValue(element, BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM) + "|" +
                    ParameterValue(element, BuiltInParameter.RBS_CONDUIT_DIAMETER_PARAM);
            }
            var family = element as FamilyInstance;
            var point = family == null ? null : family.Location as LocationPoint;
            if (family == null || point == null) return null;
            var transform = family.GetTransform();
            var bounds = family.get_BoundingBox(null);
            if (bounds == null) return null;
            return prefix + "family|" + (family.Host == null ? -1 : RevitCompat.Id(family.Host.Id)) + "|" + Point(point.Point) + "|" +
                Point(transform.BasisX) + "|" + Point(transform.BasisY) + "|" + Point(transform.BasisZ) + "|" + Point(bounds.Min) + "|" + Point(bounds.Max);
        }

        private static string ParameterValue(Element element, BuiltInParameter id)
        {
            var parameter = element.get_Parameter(id);
            return parameter != null && parameter.HasValue && parameter.StorageType == StorageType.Double ? Number(parameter.AsDouble()) : "-";
        }
        private static string Point(XYZ value) { return Number(value.X) + "," + Number(value.Y) + "," + Number(value.Z); }
        private static string Number(double value) { return Math.Round(value, 7).ToString("0.0000000", CultureInfo.InvariantCulture); }
        private static void AddDuplicate(List<IEnumerable<long>> groups, Dictionary<long, HashSet<string>> sources, IEnumerable<long> ids, string source)
        {
            var group = ids.Distinct().OrderBy(x => x).ToList();
            if (group.Count < 2) return;
            groups.Add(group);
            foreach (long id in group)
            {
                HashSet<string> values;
                if (!sources.TryGetValue(id, out values)) sources.Add(id, values = new HashSet<string>(StringComparer.Ordinal));
                values.Add(source);
            }
        }

        private static List<long> DeleteInGroup(Document document, IList<long> requested, IList<long> expectedDeleted, bool apply)
        {
            // Commit inside a rollback-capable group to observe dynamic updater deletions as well as Delete()'s return value.
            // A preview always rolls the group back. Apply assimilates only after the full observed deletion set matches.
            var before = AllElementIds(document);
            using (var group = new TransactionGroup(document, apply ? "KA MEP · Review cleanup" : "KA MEP · Cleanup preview (rolled back)"))
            {
                if (group.Start() != TransactionStatus.Started) throw new InvalidOperationException("Revit could not start cleanup review.");
                try
                {
                    var errors = new CleanupFailures();
                    using (var transaction = new Transaction(document, "KA MEP · Review deletion"))
                    {
                        if (transaction.Start() != TransactionStatus.Started) throw new InvalidOperationException("Revit could not start the deletion transaction.");
                        transaction.SetFailureHandlingOptions(transaction.GetFailureHandlingOptions().SetFailuresPreprocessor(errors).SetClearAfterRollback(true).SetForcedModalHandling(true));
                        try
                        {
                            document.Delete(requested.Select(RevitCompat.ElementId).ToList());
                            document.Regenerate();
                            if (transaction.Commit() != TransactionStatus.Committed)
                                throw new InvalidOperationException("Revit rolled back cleanup. " + string.Join("; ", errors.Messages));
                        }
                        finally { if (transaction.GetStatus() == TransactionStatus.Started) transaction.RollBack(); }
                    }
                    var after = AllElementIds(document);
                    var affected = before.Except(after).OrderBy(id => id).ToList();
                    if (after.Except(before).Any()) throw new InvalidOperationException("An updater created elements during deletion. Cleanup was rolled back; handle this case manually in Revit.");
                    if (requested.Except(affected).Any()) throw new InvalidOperationException("Revit did not delete every requested element. Cleanup was rolled back.");
                    if (expectedDeleted != null && !affected.SequenceEqual(expectedDeleted))
                        throw new InvalidOperationException("Deletion dependencies changed after preview, including updater effects. Nothing was kept deleted; refresh and preview again.");
                    if (apply)
                    {
                        if (group.Assimilate() != TransactionStatus.Committed) throw new InvalidOperationException("Cleanup could not be finalized.");
                    }
                    else if (group.RollBack() != TransactionStatus.RolledBack) throw new InvalidOperationException("The cleanup preview could not be rolled back.");
                    return affected;
                }
                finally { if (group.GetStatus() == TransactionStatus.Started) group.RollBack(); }
            }
        }
        private static HashSet<long> AllElementIds(Document document)
        {
            return new HashSet<long>(new FilteredElementCollector(document).WhereElementIsNotElementType().ToElementIds().Select(RevitCompat.Id)
                .Concat(new FilteredElementCollector(document).WhereElementIsElementType().ToElementIds().Select(RevitCompat.Id)));
        }
        private static bool IsPanelTemplate(View view)
        {
            var panel = view as PanelScheduleView;
            return panel != null && panel.IsPanelScheduleTemplate();
        }
        private static string ProtectionReason(Document document, Element element)
        {
            if (element == null) return "Element no longer exists.";
            if (document.IsReadOnly) return "Document is read-only.";
            if (element.Pinned) return "Pinned element; unpin manually only after review.";
            if (element.GroupId != ElementId.InvalidElementId) return "Member of a group; edit the group manually.";
            if (element.IsTransient) return "Transient element cannot be cleaned.";
            var view = element as View;
            if (view != null)
            {
                if (view.IsTemplate || IsPanelTemplate(view) || view is ViewSheet || !PlaceableViewTypes.Contains(view.ViewType.ToString())) return "Protected view type.";
                if (StartingViewSettings.GetStartingViewSettings(document).ViewId == view.Id) return "Project starting view is protected. Change the starting view manually before considering removal.";
                if (document.ActiveView != null && view.Id == document.ActiveView.Id) return "Active view. Switch to another view in Revit and Refresh before cleanup.";
                if (view.GetDependentViewIds().Count > 0 || view.GetPrimaryViewId() != ElementId.InvalidElementId) return "Primary/dependent view relationship is protected.";
            }
            if (document.IsWorkshared && WorksharingUtils.GetCheckoutStatus(document, element.Id) == CheckoutStatus.OwnedByOtherUser)
                return "Owned by another user; ask the owner to release it.";
            return "";
        }
        private static void ValidateOriginal(Document document, long id, IDictionary<long, string> uniqueIds, IDictionary<long, string> fingerprints)
        {
            var element = document.GetElement(RevitCompat.ElementId(id));
            string expectedId, expectedVersion;
            if (element == null || !uniqueIds.TryGetValue(id, out expectedId) || !fingerprints.TryGetValue(id, out expectedVersion) || element.UniqueId != expectedId || Fingerprint(element) != expectedVersion)
                throw new InvalidOperationException("Element " + id + " changed since review. Refresh and preview again.");
        }
        private static string Fingerprint(Element element) { return element.UniqueId + "|" + element.VersionGuid.ToString("N"); }
        private static string PlanFingerprint(ReviewCleanupPlan plan)
        {
            return plan.DocumentKey + "|" + plan.ChangeGeneration + "\n" + string.Join(",", plan.RequestedIds) + "\n" + string.Join("\n", plan.FindingKeys.OrderBy(x => x, StringComparer.Ordinal)) + "\n" +
                string.Join("\n", plan.AffectedIds.Select(id => id + ":" + (plan.Fingerprints.ContainsKey(id) ? plan.Fingerprints[id] : "missing")));
        }
        private static string Label(Element element)
        {
            return "[" + RevitCompat.Id(element.Id) + "] " + (element.Category == null ? element.GetType().Name : element.Category.Name) + " · " + element.Name;
        }
        private static string DocumentKey(Document document) { return document.ProjectInformation.UniqueId; }
        private static void RequireProject(Document document)
        {
            if (document == null || !document.IsValidObject || document.IsFamilyDocument) throw new InvalidOperationException("Open a Revit project to review the model.");
        }
        private static void RequireWritable(Document document)
        {
            RequireProject(document);
            if (document.IsReadOnly || document.IsModifiable) throw new InvalidOperationException("The document is not ready for a cleanup transaction. Finish the active operation and try again.");
        }
        private static void RunCheck(ReviewSnapshot snapshot, string name, Action action)
        {
            try { action(); }
            catch (Autodesk.Revit.Exceptions.RegenerationFailedException) { throw; }
            catch (Exception ex) { snapshot.IsComplete = false; snapshot.Notes.Add(name + " scan incomplete: " + ex.Message); }
        }
        private sealed class CleanupFailures : IFailuresPreprocessor
        {
            public readonly List<string> Messages = new List<string>();
            public FailureProcessingResult PreprocessFailures(FailuresAccessor accessor)
            {
                bool failed = false;
                foreach (var message in accessor.GetFailureMessages())
                {
                    Messages.Add(message.GetDescriptionText());
                    if (message.GetSeverity() != FailureSeverity.Warning) failed = true;
                }
                return failed ? FailureProcessingResult.ProceedWithRollBack : FailureProcessingResult.Continue;
            }
        }
    }
}
