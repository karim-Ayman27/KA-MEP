using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using PipeTakeoff.Core;

namespace PipeTakeoff.Revit
{
    /// <summary>Configuration and preview over detached data only; changes are applied by the Revit command.</summary>
    public sealed class TagAssistantForm : Form
    {
        private readonly TagAssistantSnapshot _snapshot;
        private readonly ComboBox _mode = Choice("Create missing tags", "Arrange existing tags");
        private readonly ComboBox _scope = Choice("Current selection", "Active view");
        private readonly ComboBox _side = Choice("Positive / top / right", "Negative / bottom / left");
        private readonly ComboBox _leaders = Choice("No leaders", "Straight leaders", "Elbow + parallel shoulders", "Right angle (90°)");
        private readonly ComboBox _orientation = Choice("Horizontal text", "Vertical text");
        private readonly NumericUpDown _spacing = Number(1.5M, .5M, 100, 1);
        private readonly NumericUpDown _offset = Number(3, 0, 500, 1);
        private readonly NumericUpDown _shoulder = Number(2, .5M, 100, 1);
        private readonly NumericUpDown _maximumDistance = Number(20, 1, 100, 1);
        private readonly NumericUpDown _maximumTags = Number(50, 1, 500, 0);
        private readonly NumericUpDown _minimumCurveLength = Number(5, 0, 200, 1);
        private readonly CheckBox _skipShortCurves = Check("Skip short curve segments when creating tags");
        private readonly NumericUpDown _angle = Number(30, -80, 80, 0);
        private readonly NumericUpDown _columns = Number(3, 2, 20, 0);
        private readonly NumericUpDown _estimatedWidth = Number(25, 2, 200, 1);
        private readonly NumericUpDown _estimatedHeight = Number(4, 1, 100, 1);
        private readonly CheckBox _preserve = Check("Keep each existing tag's family / type");
        private readonly CheckBox _pickOrigin = Check("Pick the layout centre in Revit after Apply");
        private readonly DataGridView _categories = new DataGridView();
        private readonly DataGridView _elements = new DataGridView();
        private readonly TextBox _elementSearch = new TextBox();
        private readonly Label _reviewCount = new Label();
        private readonly HashSet<string> _excluded = new HashSet<string>(StringComparer.Ordinal);
        private readonly List<TagPatternChoice> _patterns = new List<TagPatternChoice>();
        private readonly TagPatternPreview _preview = new TagPatternPreview { Dock = DockStyle.Fill };
        private readonly Label _summary = new Label();
        private readonly Label _footerStatus = new Label();
        private readonly TextBox _warnings = new TextBox();
        private readonly Button _apply = KaTheme.Button("Create tags", true);
        private readonly ToolTip _tips = new ToolTip { AutoPopDelay = 12000, InitialDelay = 300 };
        private bool _updating;
        private TagAssistantOptions _defaults;

        public TagAssistantOptions Options { get; private set; }

        public TagAssistantForm(TagAssistantSnapshot snapshot)
        {
            if (snapshot == null) throw new ArgumentNullException("snapshot");
            _snapshot = snapshot;
            _defaults = TagAssistantModel.CreateDefaults(snapshot);
            Options = _defaults;
            KaTheme.ApplyForm(this, "Tag Assistant", 1220, 800);
            MinimumSize = new Size(940, 640);
            Name = "TagAssistantForm";
            KeyPreview = true;
            BuildInterface();
            SetControls(_defaults);
            WireEvents();
            UpdatePreview();
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            KaTheme.ClampToScreen(this);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _tips.Dispose();
            base.Dispose(disposing);
        }

        private void BuildInterface()
        {
            var workspace = new TableLayoutPanel
            {
                Name = "TagWorkspace", Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2,
                Padding = new Padding(14, 12, 14, 8), Margin = new Padding(0)
            };
            workspace.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            workspace.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            workspace.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            workspace.Controls.Add(KaTheme.Header("Tag Assistant",
                "Organise your annotations  /  " + _snapshot.ViewName + "  /  Scale 1:" + _snapshot.ViewScale), 0, 0);
            var columns = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Margin = new Padding(0) };
            columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 54));
            columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 46));
            columns.SizeChanged += delegate
            {
                // Keep both family/type selectors visible on narrow windows while
                // retaining a useful preview beside the settings.
                float settingsWidth = columns.ClientSize.Width < 1050 ? 64F : 54F;
                if (columns.ColumnStyles[0].Width == settingsWidth) return;
                columns.ColumnStyles[0].Width = settingsWidth;
                columns.ColumnStyles[1].Width = 100F - settingsWidth;
            };
            columns.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            var tabs = new TabControl { Name = "TagSettingsTabs", Dock = DockStyle.Fill, Padding = new Point(13, 7), Margin = new Padding(0, 0, 12, 0) };
            tabs.TabPages.Add(ElementsTab());
            tabs.TabPages.Add(ReviewTab());
            tabs.TabPages.Add(LayoutTab());
            tabs.TabPages.Add(LeadersTab());
            columns.Controls.Add(tabs, 0, 0);
            columns.Controls.Add(PreviewPanel(), 1, 0);
            workspace.Controls.Add(columns, 0, 1);
            Controls.Add(workspace);
            // Footer is deliberately outside the workspace and its scrolling controls.
            Controls.Add(Footer());
        }

        private TabPage ElementsTab()
        {
            var page = Page("1  Scope & types");
            var layout = Stack();
            var settings = Fields();
            AddField(settings, "Action", _mode);
            AddField(settings, "Elements from", _scope);
            AddField(settings, "Maximum tags per batch", _maximumTags);
            _maximumTags.Name = "TagMaximumTags";
            _mode.Name = "TagMode";
            _scope.Name = "TagScope";
            layout.Controls.Add(Section("01", "Choose the elements", settings, true));
            layout.Controls.Add(Hint("Start with a small selection in Revit. Nothing expands to the whole view automatically. To use Active view, choose it explicitly and enable only the categories you need."));
            layout.Controls.Add(Hint("Create missing skips already tagged hosts. To bring existing tags closer, select them and use Arrange existing tags."));
            _preserve.Name = "TagPreserveTypes";
            layout.Controls.Add(_preserve);
            layout.Controls.Add(Hint("When arranging existing tags, turn this off to choose a different family and type below."));
            var bar = KaTheme.Flow();
            var selectAll = KaTheme.Button("Enable all categories");
            selectAll.Name = "TagSelectAllCategories";
            var clear = KaTheme.Button("Clear categories");
            clear.Name = "TagClearCategories";
            selectAll.Click += delegate { SelectCategories(true); };
            clear.Click += delegate { SelectCategories(false); };
            bar.Controls.Add(selectAll);
            bar.Controls.Add(clear);
            layout.Controls.Add(bar);
            KaTheme.StyleGrid(_categories, false);
            _categories.Name = "TagCategoryTypes";
            _categories.Height = 260;
            _categories.MinimumSize = new Size(0, 180);
            _categories.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            _categories.SelectionMode = DataGridViewSelectionMode.CellSelect;
            _categories.MultiSelect = false;
            _categories.EditMode = DataGridViewEditMode.EditOnEnter;
            _categories.Columns.Add(new DataGridViewCheckBoxColumn { Name = "Enabled", HeaderText = "Use", FillWeight = 11, MinimumWidth = 36 });
            _categories.Columns.Add(new DataGridViewTextBoxColumn { Name = "Category", HeaderText = "Category", FillWeight = 32, MinimumWidth = 100, ReadOnly = true });
            _categories.Columns.Add(new DataGridViewTextBoxColumn { Name = "Count", HeaderText = "Count", FillWeight = 13, MinimumWidth = 50, ReadOnly = true });
            _categories.Columns.Add(new DataGridViewComboBoxColumn { Name = "TagFamily", HeaderText = "Tag family", FillWeight = 40, MinimumWidth = 145, ValueType = typeof(string), DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton, FlatStyle = FlatStyle.Flat });
            _categories.Columns.Add(new DataGridViewComboBoxColumn { Name = "TagType", HeaderText = "Tag type", FillWeight = 35, MinimumWidth = 125, DisplayMember = "TypeDisplayName", ValueMember = "Id", ValueType = typeof(long), DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton, FlatStyle = FlatStyle.Flat });
            foreach (var category in _snapshot.Categories)
            {
                int index = _categories.Rows.Add();
                DataGridViewRow row = _categories.Rows[index];
                row.Tag = category;
                row.Cells[0].Value = false;
                row.Cells[1].Value = category.Name;
                row.Cells[2].Value = 0;
                var families = category.Types.Select(t => t.FamilyDisplayName).Distinct(StringComparer.Ordinal)
                    .OrderBy(name => name, StringComparer.CurrentCultureIgnoreCase).ToList();
                if (families.Count == 0) families.Add("No compatible family loaded");
                ((DataGridViewComboBoxCell)row.Cells["TagFamily"]).DataSource = families;
                SetCategoryType(row, category.Types.Count == 0 ? -1 : category.Types[0].Id);
                row.Cells["TagFamily"].ToolTipText = "Choose the loaded tag family; Tag type then shows only that family's types.";
                row.Cells["TagType"].ToolTipText = "Choose a type from the selected tag family.";
            }
            layout.Controls.Add(_categories);
            layout.Controls.Add(Hint("Choose Tag family first, then Tag type. Only compatible families loaded in this project are offered. Use the horizontal scrollbar if both choices do not fit on screen."));
            layout.Controls.Add(Hint("Fittings and flex runs start off in mixed selections. Enable their categories only when those tags are needed."));
            page.Controls.Add(MakeScrollPanel(layout));
            return page;
        }

        private TabPage ReviewTab()
        {
            var page = Page("2  Review elements");
            var layout = Stack();
            layout.Controls.Add(Heading("Choose exactly which elements need a tag"));
            layout.Controls.Add(Hint("Uncheck unnecessary elements before continuing. Your exclusions stay in place when the scope, category selection or search changes."));
            _skipShortCurves.Name = "TagSkipShortCurves";
            layout.Controls.Add(_skipShortCurves);
            var filters = Fields();
            _minimumCurveLength.Name = "TagMinimumCurveLengthMm";
            AddField(filters, "Minimum visible curve length (paper mm)", _minimumCurveLength);
            _elementSearch.Name = "TagElementSearch";
            AddField(filters, "Find element / ID", _elementSearch);
            layout.Controls.Add(filters);
            var buttons = KaTheme.Flow();
            var include = KaTheme.Button("Include visible"); include.Name = "TagIncludeVisibleButton";
            var exclude = KaTheme.Button("Exclude visible"); exclude.Name = "TagExcludeVisibleButton";
            include.Click += delegate { SetVisibleElements(true); };
            exclude.Click += delegate { SetVisibleElements(false); };
            buttons.Controls.Add(include); buttons.Controls.Add(exclude);
            layout.Controls.Add(buttons);
            _reviewCount.Name = "TagReviewCount";
            _reviewCount.AutoSize = true;
            _reviewCount.Dock = DockStyle.Fill;
            _reviewCount.ForeColor = KaTheme.Muted;
            layout.Controls.Add(_reviewCount);
            KaTheme.StyleGrid(_elements, false);
            _elements.Name = "TagElementReview";
            _elements.Height = 310;
            _elements.MinimumSize = new Size(0, 180);
            _elements.MultiSelect = false;
            _elements.EditMode = DataGridViewEditMode.EditOnEnter;
            _elements.Columns.Add(new DataGridViewCheckBoxColumn { Name = "Use", HeaderText = "Use", FillWeight = 10, MinimumWidth = 40 });
            _elements.Columns.Add(new DataGridViewTextBoxColumn { Name = "HostId", HeaderText = "Element ID", FillWeight = 18, MinimumWidth = 85, ReadOnly = true });
            _elements.Columns.Add(new DataGridViewTextBoxColumn { Name = "Element", HeaderText = "Element / existing tag", FillWeight = 42, MinimumWidth = 160, ReadOnly = true });
            _elements.Columns.Add(new DataGridViewTextBoxColumn { Name = "Status", HeaderText = "Included / excluded", FillWeight = 30, MinimumWidth = 120, ReadOnly = true });
            foreach (DataGridViewColumn column in _elements.Columns) column.SortMode = DataGridViewColumnSortMode.NotSortable;
            layout.Controls.Add(_elements);
            layout.Controls.Add(Hint("Short-curve filtering applies to new tags only. To include a short segment, turn that filter off, then choose the required elements. Hidden rows retain their choices."));
            page.Controls.Add(MakeScrollPanel(layout));
            return page;
        }

        private void SetVisibleElements(bool include)
        {
            foreach (DataGridViewRow row in _elements.Rows)
            {
                var candidate = row.Tag as TagAssistantCandidate;
                if (candidate == null) continue;
                if (include) _excluded.Remove(candidate.Key);
                else _excluded.Add(candidate.Key);
            }
            UpdatePreview();
        }

        private void UpdateElementRows()
        {
            string key = _elements.CurrentRow == null ? null : (_elements.CurrentRow.Tag as TagAssistantCandidate)?.Key;
            int first = Math.Max(0, _elements.FirstDisplayedScrollingRowIndex);
            var source = TagAssistantModel.CandidatesForReview(_snapshot, Options);
            string search = _elementSearch.Text.Trim();
            var visible = source.Where(c => search.Length == 0 || (c.Label ?? "").IndexOf(search, StringComparison.CurrentCultureIgnoreCase) >= 0 ||
                c.HostId.ToString().Contains(search) || (c.ExistingTagId != 0 && c.ExistingTagId.ToString().Contains(search))).ToList();
            bool same = _elements.Rows.Count == visible.Count && _elements.Rows.Cast<DataGridViewRow>().Select(r => ((TagAssistantCandidate)r.Tag).Key).SequenceEqual(visible.Select(c => c.Key));
            if (!same) _elements.Rows.Clear();
            for (int index = 0; index < visible.Count; index++)
            {
                var candidate = visible[index];
                string reason = TagAssistantModel.CandidateExclusionReason(_snapshot, Options, candidate);
                string label = candidate.Label + (candidate.ExistingTagId == 0 ? "" : " / tag " + candidate.ExistingTagId);
                DataGridViewRow row;
                if (same) row = _elements.Rows[index];
                else
                {
                    int added = _elements.Rows.Add(reason == null, candidate.HostId.ToString(), label, reason ?? "Included");
                    row = _elements.Rows[added];
                    row.Tag = candidate;
                }
                row.Cells[0].Value = reason == null;
                row.Cells[0].ReadOnly = reason != null && !_excluded.Contains(candidate.Key);
                row.Cells[3].Value = reason ?? "Included";
                row.Cells[2].ToolTipText = label;
                row.Cells[3].ToolTipText = reason ?? "This element is included in the proposed batch.";
                row.DefaultCellStyle.ForeColor = reason == null ? KaTheme.Ink : KaTheme.Muted;
                if (!same && candidate.Key == key) _elements.CurrentCell = row.Cells[2];
            }
            if (!same && _elements.Rows.Count > 0) _elements.FirstDisplayedScrollingRowIndex = Math.Min(first, _elements.Rows.Count - 1);
            int included = TagAssistantModel.Candidates(_snapshot, Options).Count;
            _reviewCount.Text = visible.Count + " shown / " + source.Count + " matching · " + included + " included · " + (source.Count - included) + " filtered out";
        }

        private TabPage LayoutTab()
        {
            var page = Page("3  Pattern & spacing");
            var layout = Stack();
            layout.Controls.Add(Heading("Keep tags near their elements"));
            var cards = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 3, RowCount = 2, Margin = new Padding(0, 3, 0, 6) };
            for (int i = 0; i < 3; i++) cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F / 3));
            cards.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            cards.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            AddPattern(cards, TagLayoutPattern.NearHost, "Near elements (recommended)", 0);
            AddPattern(cards, TagLayoutPattern.HorizontalRow, "Horizontal row", 1);
            AddPattern(cards, TagLayoutPattern.VerticalColumn, "Vertical column", 2);
            AddPattern(cards, TagLayoutPattern.TwoColumns, "Two-sided columns", 3);
            AddPattern(cards, TagLayoutPattern.StaggeredRows, "Staggered rows", 4);
            AddPattern(cards, TagLayoutPattern.DiagonalRow, "Diagonal row", 5);
            layout.Controls.Add(cards);
            layout.Controls.Add(Hint("Near elements searches for nearby clear space and skips crowded labels. Row and column patterns are optional layouts for small groups and may place labels farther away."));
            var fields = Fields();
            AddField(fields, "Clear spacing (paper mm)", _spacing);
            AddField(fields, "Offset from elements (paper mm)", _offset);
            AddField(fields, "Maximum label-centre distance (paper mm)", _maximumDistance);
            _maximumDistance.Name = "TagMaximumDistanceMm";
            AddField(fields, "Layout side", _side);
            AddField(fields, "Diagonal angle (degrees)", _angle);
            AddField(fields, "Staggered row columns", _columns);
            _spacing.Name = "TagSpacingMm";
            _offset.Name = "TagOffsetMm";
            _angle.Name = "TagAngleDegrees";
            _columns.Name = "TagColumns";
            layout.Controls.Add(Section("02", "Layout dimensions", fields, true));
            _pickOrigin.Name = "TagPickOrigin";
            layout.Controls.Add(_pickOrigin);
            layout.Controls.Add(Hint("Near elements stays around each element; a remote pattern centre is disabled. Other patterns can use a picked centre. Dimensions are printed millimetres at this view scale."));
            page.Controls.Add(MakeScrollPanel(layout));
            return page;
        }

        private TabPage LeadersTab()
        {
            var page = Page("4  Leaders & text");
            var layout = Stack();
            var fields = Fields();
            AddField(fields, "Leader style", _leaders);
            AddField(fields, "Parallel shoulder (paper mm)", _shoulder);
            AddField(fields, "Text orientation", _orientation);
            _leaders.Name = "TagLeaderStyle";
            _shoulder.Name = "TagShoulderMm";
            _orientation.Name = "TagOrientation";
            layout.Controls.Add(Section("03", "Leader geometry", fields, true));
            layout.Controls.Add(Hint("Right angle (90°) uses horizontal and vertical segments while keeping the chosen tag alignment. Endpoints already on the same axis use a straight segment. Elbow + parallel shoulders can have a diagonal first segment."));
            layout.Controls.Add(Hint("Right angle requires a free leader end. Compatible attached leaders are changed to Free at the host; existing free endpoints are retained. Unsupported families are reported instead of leaving a diagonal leader. Leader paths can still cross."));
            var estimates = Fields();
            AddField(estimates, "Estimated text width (paper mm)", _estimatedWidth);
            AddField(estimates, "Estimated text height (paper mm)", _estimatedHeight);
            _estimatedWidth.Name = "TagEstimatedWidthMm";
            _estimatedHeight.Name = "TagEstimatedHeightMm";
            layout.Controls.Add(Section("", "Preview estimates", estimates, true));
            layout.Controls.Add(Hint("The schematic uses estimated text boxes. Revit measures actual family extents before applying. Near elements skips tags that cannot fit within the chosen distance."));
            _tips.SetToolTip(_estimatedWidth, "Approximate horizontal family width on the printed sheet, before text orientation is applied.");
            _tips.SetToolTip(_estimatedHeight, "Approximate horizontal family height on the printed sheet, before text orientation is applied.");
            page.Controls.Add(MakeScrollPanel(layout));
            return page;
        }

        private Control PreviewPanel()
        {
            var panel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, BackColor = Color.White,
                Padding = new Padding(9), Margin = new Padding(0)
            };
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 70));
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 30));
            panel.Controls.Add(Heading("LAYOUT PREVIEW"), 0, 0);
            _summary.Name = "TagPreviewSummary";
            _summary.AutoSize = false;
            _summary.AutoEllipsis = true;
            _summary.Height = Font.Height * 2 + 5;
            _summary.FontChanged += delegate { _summary.Height = _summary.Font.Height * 2 + 5; };
            _summary.Dock = DockStyle.Fill;
            _summary.ForeColor = Color.FromArgb(0, 131, 122);
            _summary.Margin = new Padding(0, 3, 0, 5);
            panel.Controls.Add(_summary, 0, 1);
            panel.Controls.Add(_preview, 0, 2);
            _tips.SetToolTip(_preview, "Dots are element anchors; boxes are proposed labels. This is a view-plane schematic with estimated widths, not a Revit rendering.");
            _warnings.Name = "TagPreviewWarnings";
            _warnings.Dock = DockStyle.Fill;
            _warnings.Multiline = true;
            _warnings.ReadOnly = true;
            _warnings.ScrollBars = ScrollBars.Vertical;
            _warnings.BackColor = KaTheme.Surface;
            _warnings.ForeColor = KaTheme.Muted;
            _warnings.BorderStyle = BorderStyle.None;
            _warnings.TabStop = true;
            _warnings.AccessibleName = "Preview warnings and model notes";
            panel.Controls.Add(_warnings, 0, 3);
            return panel;
        }

        private Control Footer()
        {
            var footer = new TableLayoutPanel
            {
                Name = "TagFixedFooter", Dock = DockStyle.Bottom, AutoSize = true, ColumnCount = 3, RowCount = 2,
                BackColor = Color.White, Padding = new Padding(16, 8, 16, 10), Margin = new Padding(0)
            };
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 48));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 32));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
            footer.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            footer.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            _footerStatus.Name = "TagFooterStatus";
            _footerStatus.AutoSize = false;
            _footerStatus.AutoEllipsis = true;
            _footerStatus.Height = Font.Height + 9;
            _footerStatus.Dock = DockStyle.Fill;
            _footerStatus.ForeColor = KaTheme.Muted;
            _footerStatus.Margin = new Padding(0, 0, 0, 5);
            footer.Controls.Add(_footerStatus, 0, 0);
            footer.SetColumnSpan(_footerStatus, 3);
            var reset = KaTheme.Button("Reset settings");
            reset.Name = "TagResetButton";
            reset.AutoSize = false;
            reset.Dock = DockStyle.Fill;
            reset.Click += delegate { SetControls(TagAssistantModel.CreateDefaults(_snapshot)); UpdatePreview(); };
            footer.Controls.Add(reset, 0, 1);
            _apply.Name = "TagApplyButton";
            _apply.AutoSize = false;
            _apply.Dock = DockStyle.Fill;
            _apply.Height = 38;
            _apply.Click += Apply;
            footer.Controls.Add(_apply, 1, 1);
            var cancel = KaTheme.Button("Cancel");
            cancel.Name = "TagCancelButton";
            cancel.AutoSize = false;
            cancel.Dock = DockStyle.Fill;
            cancel.DialogResult = DialogResult.Cancel;
            footer.Controls.Add(cancel, 2, 1);
            CancelButton = cancel;
            AcceptButton = _apply;
            return footer;
        }

        private void SetControls(TagAssistantOptions options)
        {
            _updating = true;
            try
            {
                _defaults = options;
                _mode.SelectedIndex = options.Mode == TagAssistantMode.ArrangeExisting ? 1 : 0;
                _scope.SelectedIndex = options.Scope == TagAssistantScope.ActiveView ? 1 : 0;
                _side.SelectedIndex = options.Side == TagLayoutSide.Negative ? 1 : 0;
                _leaders.SelectedIndex = (int)options.LeaderStyle;
                _orientation.SelectedIndex = (int)options.Orientation;
                SetNumber(_spacing, options.SpacingMm);
                SetNumber(_offset, options.OffsetMm);
                SetNumber(_shoulder, options.ShoulderMm);
                SetNumber(_angle, options.AngleDegrees);
                SetNumber(_columns, options.Columns);
                SetNumber(_estimatedWidth, options.EstimatedWidthMm);
                SetNumber(_estimatedHeight, options.EstimatedHeightMm);
                SetNumber(_maximumDistance, options.MaximumDistanceMm);
                SetNumber(_maximumTags, options.MaximumTags);
                SetNumber(_minimumCurveLength, options.MinimumCurveLengthMm);
                _skipShortCurves.Checked = options.SkipShortCurves;
                _excluded.Clear();
                foreach (var key in options.ExcludedCandidateKeys) _excluded.Add(key);
                _preserve.Checked = options.PreserveExistingTypes;
                _pickOrigin.Checked = options.PickOrigin;
                foreach (var pattern in _patterns) pattern.Checked = pattern.Pattern == options.Pattern;
                foreach (DataGridViewRow row in _categories.Rows)
                {
                    var category = (TagCategoryOption)row.Tag;
                    row.Cells[0].Value = options.EnabledCategoryKeys.Contains(category.Key);
                    long id;
                    if (options.SelectedTypeIds.TryGetValue(category.Key, out id) && category.Types.Any(t => t.Id == id)) SetCategoryType(row, id);
                }
                Options = options;
            }
            finally { _updating = false; }
        }

        private TagAssistantOptions ReadOptions()
        {
            var pattern = _patterns.FirstOrDefault(p => p.Checked);
            var result = new TagAssistantOptions
            {
                Mode = _mode.SelectedIndex == 1 ? TagAssistantMode.ArrangeExisting : TagAssistantMode.CreateMissing,
                Scope = _scope.SelectedIndex == 1 ? TagAssistantScope.ActiveView : TagAssistantScope.Selection,
                Pattern = pattern == null ? TagLayoutPattern.NearHost : pattern.Pattern,
                Side = _side.SelectedIndex == 1 ? TagLayoutSide.Negative : TagLayoutSide.Positive,
                SpacingMm = (double)_spacing.Value, OffsetMm = (double)_offset.Value,
                ShoulderMm = (double)_shoulder.Value, AngleDegrees = (double)_angle.Value,
                Columns = (int)_columns.Value, EstimatedWidthMm = (double)_estimatedWidth.Value,
                EstimatedHeightMm = (double)_estimatedHeight.Value,
                LeaderStyle = (TagLeaderStyle)Math.Max(0, _leaders.SelectedIndex),
                Orientation = (TagTextOrientation)Math.Max(0, _orientation.SelectedIndex),
                PreserveExistingTypes = _preserve.Checked, PickOrigin = pattern != null && pattern.Pattern != TagLayoutPattern.NearHost && _pickOrigin.Checked,
                Origin = pattern != null && pattern.Pattern != TagLayoutPattern.NearHost ? _defaults.Origin : null,
                MaximumDistanceMm = (double)_maximumDistance.Value, MaximumTags = (int)_maximumTags.Value,
                SkipShortCurves = _skipShortCurves.Checked, MinimumCurveLengthMm = (double)_minimumCurveLength.Value,
                ExcludedCandidateKeys = new HashSet<string>(_excluded, StringComparer.Ordinal),
                EnabledCategoryKeys = new HashSet<string>(), SelectedTypeIds = new Dictionary<string, long>()
            };
            foreach (DataGridViewRow row in _categories.Rows)
            {
                var category = (TagCategoryOption)row.Tag;
                if (Convert.ToBoolean(row.Cells[0].Value)) result.EnabledCategoryKeys.Add(category.Key);
                if (row.Cells["TagType"].Value != null)
                {
                    long id = Convert.ToInt64(row.Cells["TagType"].Value);
                    if (id > 0) result.SelectedTypeIds[category.Key] = id;
                }
            }
            return result;
        }

        private void WireEvents()
        {
            foreach (var combo in new[] { _mode, _scope, _side, _leaders, _orientation })
                combo.SelectedIndexChanged += delegate { UpdatePreview(); };
            foreach (var number in new[] { _spacing, _offset, _shoulder, _angle, _columns, _estimatedWidth, _estimatedHeight, _maximumDistance, _maximumTags, _minimumCurveLength })
                number.ValueChanged += delegate { UpdatePreview(); };
            foreach (var pattern in _patterns) pattern.CheckedChanged += delegate { UpdatePreview(); };
            _preserve.CheckedChanged += delegate { UpdatePreview(); };
            _skipShortCurves.CheckedChanged += delegate { UpdatePreview(); };
            _elementSearch.TextChanged += delegate { UpdatePreview(); };
            _elements.CurrentCellDirtyStateChanged += delegate
            {
                if (_elements.IsCurrentCellDirty && _elements.CurrentCell is DataGridViewCheckBoxCell)
                    _elements.CommitEdit(DataGridViewDataErrorContexts.Commit);
            };
            _elements.CellValueChanged += delegate(object sender, DataGridViewCellEventArgs e)
            {
                if (_updating || e.RowIndex < 0 || e.ColumnIndex != 0) return;
                var candidate = _elements.Rows[e.RowIndex].Tag as TagAssistantCandidate;
                if (candidate == null) return;
                if (Convert.ToBoolean(_elements.Rows[e.RowIndex].Cells[0].Value)) _excluded.Remove(candidate.Key);
                else _excluded.Add(candidate.Key);
                if (IsHandleCreated) BeginInvoke((Action)UpdatePreview); else UpdatePreview();
            };
            _pickOrigin.CheckedChanged += delegate { UpdatePreview(); };
            _categories.CurrentCellDirtyStateChanged += delegate
            {
                if (_categories.IsCurrentCellDirty) _categories.CommitEdit(DataGridViewDataErrorContexts.Commit);
            };
            _categories.CellValueChanged += delegate(object sender, DataGridViewCellEventArgs e)
            {
                if (_updating || e.RowIndex < 0 || e.ColumnIndex < 0) return;
                if (_categories.Columns[e.ColumnIndex].Name == "TagFamily")
                {
                    _updating = true;
                    try
                    {
                        var row = _categories.Rows[e.RowIndex];
                        long current;
                        long.TryParse(Convert.ToString(row.Cells["TagType"].Value), out current);
                        SetFamilyTypes(row, Convert.ToString(row.Cells["TagFamily"].Value), current);
                    }
                    finally { _updating = false; }
                }
                UpdatePreview();
            };
            _categories.CellFormatting += delegate(object sender, DataGridViewCellFormattingEventArgs e)
            {
                if (e.ColumnIndex < 0 || _categories.Columns[e.ColumnIndex].Name != "TagType" || e.RowIndex < 0 || e.Value == null) return;
                var category = _categories.Rows[e.RowIndex].Tag as TagCategoryOption;
                long id;
                if (category == null || !long.TryParse(Convert.ToString(e.Value), out id)) return;
                var type = category.Types.FirstOrDefault(t => t.Id == id);
                e.Value = type == null ? "No compatible type loaded" : type.TypeDisplayName;
                e.FormattingApplied = true;
            };
            _categories.DataError += delegate(object sender, DataGridViewDataErrorEventArgs e)
            {
                e.ThrowException = false;
                _footerStatus.Text = "Choose a loaded tag family, then one of its types.";
            };
        }

        private void UpdatePreview()
        {
            if (_updating) return;
            _updating = true;
            try
            {
                Options = ReadOptions();
                bool arrange = Options.Mode == TagAssistantMode.ArrangeExisting;
                _apply.Text = arrange ? "Review arrangement" : "Review new tags";
                bool nearby = Options.Pattern == TagLayoutPattern.NearHost;
                _pickOrigin.Enabled = !nearby;
                if (nearby) _pickOrigin.Checked = false;
                _maximumDistance.Enabled = nearby;
                _skipShortCurves.Enabled = !arrange;
                _minimumCurveLength.Enabled = !arrange && Options.SkipShortCurves;
                _preserve.Enabled = arrange;
                _shoulder.Enabled = Options.LeaderStyle == TagLeaderStyle.Elbow;
                _angle.Enabled = Options.Pattern == TagLayoutPattern.DiagonalRow;
                _columns.Enabled = Options.Pattern == TagLayoutPattern.StaggeredRows;
                foreach (DataGridViewRow row in _categories.Rows)
                {
                    var category = (TagCategoryOption)row.Tag;
                    int count = _snapshot.Candidates.Count(c => c.CategoryKey == category.Key &&
                        (Options.Scope == TagAssistantScope.ActiveView || c.IsSelected) &&
                        (arrange ? c.ExistingTagId != 0 : c.ExistingTagId == 0));
                    row.Cells[2].Value = count;
                    foreach (string column in new[] { "TagFamily", "TagType" })
                    {
                        row.Cells[column].ReadOnly = (arrange && Options.PreserveExistingTypes) || category.Types.Count == 0;
                        row.Cells[column].Style.ForeColor = row.Cells[column].ReadOnly ? KaTheme.Muted : KaTheme.Ink;
                    }
                }
                var candidates = TagAssistantModel.Candidates(_snapshot, Options);
                UpdateElementRows();
                _side.Enabled = Options.Pattern != TagLayoutPattern.TwoColumns || candidates.Count == 1;
                _tips.SetToolTip(_side, Options.Pattern == TagLayoutPattern.TwoColumns
                    ? "Two-sided columns choose both sides automatically. This option applies only when placing a single tag."
                    : "Choose the side of the element group on which to place the tag pattern.");
                var errors = TagAssistantModel.Validate(_snapshot, Options);
                TagLayoutResult result = candidates.Count == 0 || candidates.Count > Options.MaximumTags || candidates.Count > TagAssistantModel.MaximumBatchSize
                    ? null : TagAssistantModel.Preview(_snapshot, Options);
                _preview.ShowLayout(result, Options.LeaderStyle,
                    candidates.Count > Options.MaximumTags ? "Batch limit exceeded.\r\nUncheck unnecessary elements on Review elements, or narrow the selection." :
                    result != null && result.SkippedKeys.Count > 0 && result.Placements.Count == 0 ? "Estimated labels do not fit nearby.\r\nActual family sizes will be measured before confirming." :
                    Options.Scope == TagAssistantScope.Selection ? "No eligible elements in the current selection.\r\nSelect elements in Revit or choose Active view." : "No eligible elements in the enabled categories.");
                int proposed = result == null ? 0 : result.Placements.Count;
                int crowded = result == null ? 0 : result.SkippedKeys.Count;
                int reviewed = TagAssistantModel.CandidatesForReview(_snapshot, Options).Count;
                _summary.Text = proposed + " proposed · " + (reviewed - candidates.Count) + " filtered out · " + crowded + " estimated skips" +
                    Environment.NewLine + PatternCaption(Options.Pattern) + (nearby ? " · max " + Options.MaximumDistanceMm + " paper mm" : "");
                _tips.SetToolTip(_summary, _summary.Text);
                var notes = new List<string>();
                notes.AddRange(errors);
                if (result != null) notes.AddRange(result.Warnings);
                if (_snapshot.Notes != null) notes.AddRange(_snapshot.Notes);
                if ((!arrange || !Options.PreserveExistingTypes) && _snapshot.Categories.Any(c =>
                    Options.EnabledCategoryKeys.Contains(c.Key) && Options.SelectedTypeIds.ContainsKey(c.Key) &&
                    c.Types.Any(t => t.Id == Options.SelectedTypeIds[c.Key] && t.RotatesWithComponent)))
                    notes.Add("A selected family rotates with its component; its family settings may control the final text direction.");
                if (nearby) notes.Add("Labels that cannot fit nearby after actual measurement are skipped; the tool will not push them away from the drawing. Review elements lets you exclude any unnecessary tag.");
                if (nearby && result != null && result.Placements.Count == 0 && candidates.Count > 0)
                    notes.Add("Estimated labels do not fit; actual family sizes will be measured before confirming. No tags are created if the measured labels cannot fit either.");
                if (!nearby) notes.Add("This is a group pattern. Use Near elements to keep each tag close to its own element.");
                if (Options.LeaderStyle == TagLeaderStyle.Orthogonal)
                    notes.Add("Right angle leaders retain the chosen tag alignment. Revit must support a free endpoint; unsupported routing is reported before changes are kept. The schematic uses host anchors, while existing free endpoints are preserved during application.");
                if (Options.PickOrigin) notes.Add("After Apply, select the layout centre in the active view; Escape cancels.");
                if (notes.Count == 0) notes.Add("Ready to apply. Existing annotations outside this group are not part of this preview.");
                _warnings.Text = string.Join(Environment.NewLine + Environment.NewLine, notes.Distinct());
                _warnings.ForeColor = errors.Count > 0 || (result != null && result.Warnings.Count > 0) ? KaTheme.Warning : KaTheme.Muted;
                _apply.Enabled = candidates.Count > 0 && errors.Count == 0;
                _footerStatus.Text = errors.Count > 0 ? errors[0] : proposed + " proposed / " + candidates.Count + " eligible · Review measured layout before applying · Scale 1:" + _snapshot.ViewScale + " · Apply is undoable in Revit";
                _tips.SetToolTip(_footerStatus, _footerStatus.Text);
            }
            catch (Exception ex)
            {
                _apply.Enabled = false;
                _footerStatus.Text = "Preview unavailable: " + ex.Message;
                _warnings.Text = ex.Message;
                _preview.ShowLayout(null, TagLeaderStyle.None, "Adjust the settings to generate a preview.");
            }
            finally { _updating = false; }
        }

        private void Apply(object sender, EventArgs e)
        {
            _categories.EndEdit();
            _elements.EndEdit();
            UpdatePreview();
            if (!_apply.Enabled) return;
            DialogResult = DialogResult.OK;
            Close();
        }

        private void SelectCategories(bool enabled)
        {
            _updating = true;
            try { foreach (DataGridViewRow row in _categories.Rows) row.Cells[0].Value = enabled; }
            finally { _updating = false; }
            UpdatePreview();
        }

        private static void SetCategoryType(DataGridViewRow row, long typeId)
        {
            var category = (TagCategoryOption)row.Tag;
            var type = category.Types.FirstOrDefault(t => t.Id == typeId) ?? category.Types.FirstOrDefault();
            string family = type == null ? "No compatible family loaded" : type.FamilyDisplayName;
            row.Cells["TagFamily"].Value = family;
            SetFamilyTypes(row, family, type == null ? -1 : type.Id);
        }

        private static void SetFamilyTypes(DataGridViewRow row, string family, long preferredId)
        {
            var category = (TagCategoryOption)row.Tag;
            var types = category.Types.Where(t => string.Equals(t.FamilyDisplayName, family, StringComparison.Ordinal)).ToList();
            if (types.Count == 0) types.Add(new TagTypeOption { Id = -1, Name = "No compatible type loaded", TypeName = "No compatible type loaded" });
            var cell = (DataGridViewComboBoxCell)row.Cells["TagType"];
            cell.Value = null;
            cell.DataSource = types;
            cell.DisplayMember = "TypeDisplayName";
            cell.ValueMember = "Id";
            cell.ValueType = typeof(long);
            cell.Value = types.Any(t => t.Id == preferredId) ? preferredId : types[0].Id;
        }

        private void AddPattern(TableLayoutPanel table, TagLayoutPattern pattern, string caption, int index)
        {
            var choice = new TagPatternChoice(pattern, caption);
            _patterns.Add(choice);
            table.Controls.Add(choice, index % 3, index / 3);
        }

        private static string PatternCaption(TagLayoutPattern pattern)
        {
            switch (pattern)
            {
                case TagLayoutPattern.NearHost: return "Near elements";
                case TagLayoutPattern.VerticalColumn: return "Vertical column";
                case TagLayoutPattern.TwoColumns: return "Two-sided columns";
                case TagLayoutPattern.StaggeredRows: return "Staggered rows";
                case TagLayoutPattern.DiagonalRow: return "Diagonal row";
                default: return "Horizontal row";
            }
        }

        private static TabPage Page(string title)
        {
            return new TabPage(title) { BackColor = KaTheme.Surface, Padding = new Padding(8) };
        }

        private static TableLayoutPanel Stack()
        {
            var table = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 1, Padding = new Padding(0, 0, 9, 4), Margin = new Padding(0) };
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            table.ControlAdded += delegate(object sender, ControlEventArgs e)
            {
                table.RowCount = table.Controls.Count;
                while (table.RowStyles.Count < table.RowCount) table.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                table.SetCellPosition(e.Control, new TableLayoutPanelCellPosition(0, table.Controls.Count - 1));
            };
            table.Layout += delegate
            {
                foreach (Control child in table.Controls)
                {
                    if (!(child is Label) && !(child is CheckBox)) continue;
                    int width = Math.Max(1, table.ClientSize.Width - table.Padding.Horizontal - child.Margin.Horizontal);
                    var maximum = new Size(width, 0);
                    if (child.MaximumSize != maximum) child.MaximumSize = maximum;
                }
            };
            return table;
        }

        private static Panel MakeScrollPanel(Control content)
        {
            var scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Margin = new Padding(0) };
            scroll.Controls.Add(content);
            return scroll;
        }

        private static Label Heading(string text)
        {
            return new Label { Text = text, AutoSize = true, Dock = DockStyle.Fill, Font = new Font("Segoe UI", 10, FontStyle.Bold), ForeColor = KaTheme.Navy, Margin = new Padding(0, 1, 0, 7) };
        }

        private static Label Hint(string text)
        {
            var hint = KaTheme.Hint(text);
            hint.Margin = new Padding(0, 7, 0, 9);
            return hint;
        }

        private static Control Section(string number, string title, Control content, bool autoSize)
        {
            var section = (TableLayoutPanel)KaTheme.Section(number, title, content, autoSize);
            // Constrain the single content column before nested percentage fields calculate widths.
            section.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            return section;
        }

        private static TableLayoutPanel Fields()
        {
            var fields = new TableLayoutPanel { AutoSize = true, Dock = DockStyle.Top, ColumnCount = 2, Margin = new Padding(0) };
            fields.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 46));
            fields.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 54));
            fields.Layout += delegate { SizeFieldRows(fields); };
            return fields;
        }

        private static void SizeFieldRows(TableLayoutPanel table)
        {
            if (table.ClientSize.Width < 20) return;
            int labelColumnWidth = Math.Max(1, (int)(table.ClientSize.Width * .46));
            int inputColumnWidth = Math.Max(1, table.ClientSize.Width - labelColumnWidth);
            for (int row = 0; row < table.RowCount; row++)
            {
                var label = table.GetControlFromPosition(0, row) as Label;
                var input = table.GetControlFromPosition(1, row);
                if (label == null || input == null || row >= table.RowStyles.Count) continue;
                int width = Math.Max(1, labelColumnWidth - label.Margin.Horizontal);
                var maximum = new Size(width, 0);
                if (label.MaximumSize != maximum) label.MaximumSize = maximum;
                int labelHeight = label.GetPreferredSize(new Size(width, 0)).Height + label.Margin.Vertical;
                int inputHeight = input.GetPreferredSize(new Size(Math.Max(1, inputColumnWidth - input.Margin.Horizontal), 0)).Height + input.Margin.Vertical;
                int height = Math.Max(labelHeight, inputHeight) + 2;
                var style = table.RowStyles[row];
                if (style.SizeType != SizeType.Absolute || Math.Abs(style.Height - height) > .5)
                {
                    style.SizeType = SizeType.Absolute;
                    style.Height = height;
                }
            }
        }

        private static void AddField(TableLayoutPanel table, string caption, Control input)
        {
            int row = table.RowCount++;
            table.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var label = new Label { Text = caption, AutoSize = true, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Margin = new Padding(0, 7, 9, 7) };
            input.Dock = DockStyle.Fill;
            input.Margin = new Padding(0, 5, 0, 5);
            input.AccessibleName = caption;
            table.Controls.Add(label, 0, row);
            table.Controls.Add(input, 1, row);
        }

        private static ComboBox Choice(params string[] options)
        {
            var combo = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, IntegralHeight = false, DropDownHeight = 180, DropDownWidth = 320 };
            combo.Items.AddRange(options);
            combo.SelectedIndex = 0;
            return combo;
        }

        private static NumericUpDown Number(decimal value, decimal minimum, decimal maximum, int decimals)
        {
            return new NumericUpDown { Minimum = minimum, Maximum = maximum, Value = value, DecimalPlaces = decimals, Increment = decimals > 0 ? .5M : 1, ThousandsSeparator = false };
        }

        private static CheckBox Check(string text)
        {
            return new CheckBox { Text = text, AutoSize = true, Dock = DockStyle.Fill, Margin = new Padding(0, 9, 0, 6), UseVisualStyleBackColor = true };
        }

        private static void SetNumber(NumericUpDown control, double value)
        {
            control.Value = Math.Min(control.Maximum, Math.Max(control.Minimum, (decimal)value));
        }

    }
}
