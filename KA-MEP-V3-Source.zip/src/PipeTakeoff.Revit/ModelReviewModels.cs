using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace PipeTakeoff.Revit
{
    public enum ReviewKind { CadImport, CadLink, UnplacedView, PotentialDuplicate, RevitWarning }

    public sealed class ReviewFinding
    {
        public string Key { get; set; } = "";
        public string Title { get; set; } = "";
        public string Detail { get; set; } = "";
        // A stable check/reason identifier, independent of element IDs and display text.
        public string IssueCode { get; set; } = "";
        public string IssueTitle { get; set; } = "";
        public ReviewKind Kind { get; set; }
        public List<long> ElementIds { get; set; } = new List<long>();
        public bool CanClean { get; set; }
        public string CleanupBlockReason { get; set; } = "";
    }

    public sealed class ReviewSnapshot
    {
        public string ProjectTitle { get; set; } = "";
        public string DocumentKey { get; set; } = "";
        public DateTime ScannedAt { get; set; }
        public long ChangeGeneration { get; set; }
        public List<ReviewFinding> Findings { get; set; } = new List<ReviewFinding>();
        public List<string> Notes { get; set; } = new List<string>();
        public Dictionary<long, string> UniqueIds { get; set; } = new Dictionary<long, string>();
        public Dictionary<long, string> Fingerprints { get; set; } = new Dictionary<long, string>();
        public int ModelElementCount { get; set; }
        public bool IsComplete { get; set; } = true;
        public IList<ReviewIssueGroup> IssueGroups { get { return ReviewIssueGrouping.Group(Findings); } }
        public int Count(ReviewKind kind) { return Findings.Count(f => f.Kind == kind); }
        public double HealthScore { get { return IsComplete ? ReviewHealth.Score(Count(ReviewKind.CadImport), Count(ReviewKind.UnplacedView), Count(ReviewKind.PotentialDuplicate), Count(ReviewKind.RevitWarning)) : double.NaN; } }
        public string HealthBreakdown { get { return ReviewHealth.Breakdown(Count(ReviewKind.CadImport), Count(ReviewKind.UnplacedView), Count(ReviewKind.PotentialDuplicate), Count(ReviewKind.RevitWarning)); } }
        public string HealthExplanation { get { return ReviewHealth.Explanation; } }
    }

    /// <summary>A presentation group only. Members remain individual findings for scoring and cleanup.</summary>
    public sealed class ReviewIssueGroup
    {
        public string Key { get; set; } = "";
        public string Title { get; set; } = "";
        public ReviewKind Kind { get; set; }
        public List<ReviewFinding> Findings { get; set; } = new List<ReviewFinding>();
        public int OccurrenceCount { get { return Findings.Count; } }
        public List<long> ElementIds { get { return Findings.SelectMany(f => f.ElementIds).Distinct().OrderBy(id => id).ToList(); } }
        public int AffectedElementCount { get { return ElementIds.Count; } }
    }

    public static class ReviewIssueGrouping
    {
        public static IList<ReviewIssueGroup> Group(IEnumerable<ReviewFinding> findings)
        {
            if (findings == null) throw new ArgumentNullException(nameof(findings));
            var source = findings.ToList();
            if (source.Any(f => f == null)) throw new ArgumentException("A review finding is missing.", nameof(findings));
            return source.GroupBy(GroupKey, StringComparer.Ordinal).Select(group =>
            {
                var members = group.OrderBy(f => f.Title, StringComparer.CurrentCultureIgnoreCase).ThenBy(f => f.Key, StringComparer.Ordinal).ToList();
                return new ReviewIssueGroup { Key = group.Key, Kind = members[0].Kind,
                    Title = IssueTitle(members[0]), Findings = members };
            }).OrderBy(group => group.Kind).ThenBy(group => group.Title, StringComparer.CurrentCultureIgnoreCase)
                .ThenBy(group => group.Key, StringComparer.Ordinal).ToList();
        }

        private static string GroupKey(ReviewFinding finding)
        {
            string reason = Normalize(finding.IssueCode);
            if (reason.Length == 0)
                reason = finding.Kind == ReviewKind.RevitWarning ? "WARNING:" + Normalize(finding.Title) : "CHECK";
            return "issue:" + ((int)finding.Kind).ToString(CultureInfo.InvariantCulture) + ":" + reason;
        }

        private static string IssueTitle(ReviewFinding finding)
        {
            if (!string.IsNullOrWhiteSpace(finding.IssueTitle)) return finding.IssueTitle.Trim();
            switch (finding.Kind)
            {
                case ReviewKind.CadImport: return "Imported CAD files";
                case ReviewKind.CadLink: return "Linked CAD files (informational)";
                case ReviewKind.UnplacedView: return "Views not placed on sheets";
                case ReviewKind.PotentialDuplicate: return "Potential duplicate elements";
                default: return string.IsNullOrWhiteSpace(finding.Title) ? "Revit warning" : finding.Title.Trim();
            }
        }

        private static string Normalize(string value)
        {
            return string.Join(" ", (value ?? "").Split((char[])null, StringSplitOptions.RemoveEmptyEntries)).ToUpperInvariant();
        }
    }

    public sealed class ReviewCleanupPlan
    {
        public string DocumentKey { get; set; } = "";
        public long ChangeGeneration { get; set; }
        public List<string> FindingKeys { get; set; } = new List<string>();
        public List<long> RequestedIds { get; set; } = new List<long>();
        public List<long> AffectedIds { get; set; } = new List<long>();
        public Dictionary<long, string> UniqueIds { get; set; } = new Dictionary<long, string>();
        public Dictionary<long, string> Fingerprints { get; set; } = new Dictionary<long, string>();
        public List<string> Lines { get; set; } = new List<string>();
        public string Fingerprint { get; set; } = "";
    }

    public static class ReviewHealth
    {
        public const string Explanation = "KA MEP review score (0–100), not an Autodesk health rating or a performance/safety guarantee. " +
            "100 − min(25, imported CAD × 5) − min(20, unplaced views × 1) − min(30, potential duplicate groups × 5) − min(25, other Revit warnings × 0.5). " +
            "CAD links are informational and do not reduce the score. Unplaced views and overlapping elements can be intentional; review before changing them. " +
            "Issue summary groups repeated findings for display; the score still uses all original occurrences, not the number of visible issue rows. " +
            "Duplicate detection covers Revit duplicate-instance warnings and matching rounded geometry signatures of straight MEP curves and point-based MEP family instances in this document. It is not a full clash or all-category duplicate check. " +
            "Refresh recomputes the same checks; a partial scan has no score.";
        public static double Score(int imports, int views, int duplicateGroups, int warnings)
        {
            if (imports < 0 || views < 0 || duplicateGroups < 0 || warnings < 0) throw new ArgumentOutOfRangeException("Counts must be nonnegative.");
            return 100 - Math.Min(25.0, imports * 5.0) - Math.Min(20.0, views) - Math.Min(30.0, duplicateGroups * 5.0) - Math.Min(25.0, warnings * 0.5);
        }
        public static string Breakdown(int imports, int views, int duplicateGroups, int warnings)
        {
            return string.Format(CultureInfo.CurrentCulture, "Penalties: CAD {0:0.#}/25 · Unplaced views {1:0.#}/20 · Duplicate groups {2:0.#}/30 · Other warnings {3:0.#}/25",
                Math.Min(25.0, imports * 5.0), Math.Min(20.0, views), Math.Min(30.0, duplicateGroups * 5.0), Math.Min(25.0, warnings * 0.5));
        }
        public static string DuplicateKey(IEnumerable<long> ids)
        {
            return "duplicate:" + string.Join(",", ids.Distinct().OrderBy(x => x).Select(x => x.ToString(CultureInfo.InvariantCulture)));
        }
        public static IList<ReviewFinding> CleanableSelection(ReviewSnapshot snapshot, IEnumerable<string> keys)
        {
            if (snapshot == null) throw new ArgumentNullException(nameof(snapshot));
            if (!snapshot.IsComplete) throw new InvalidOperationException("Cleanup is unavailable after an incomplete scan. Resolve the scan errors and Refresh.");
            var selected = new HashSet<string>(keys ?? Enumerable.Empty<string>(), StringComparer.Ordinal);
            if (selected.Count == 0) throw new InvalidOperationException("Select at least one CAD import or unplaced view.");
            var findings = snapshot.Findings.Where(f => selected.Contains(f.Key)).ToList();
            if (findings.Count != selected.Count) throw new InvalidOperationException("The selection is stale. Refresh and select the findings again.");
            foreach (var finding in findings)
                if (!finding.CanClean || (finding.Kind != ReviewKind.CadImport && finding.Kind != ReviewKind.UnplacedView))
                    throw new InvalidOperationException(finding.Title + ": " + (string.IsNullOrWhiteSpace(finding.CleanupBlockReason) ? "Review-only finding; automatic cleanup is unavailable." : finding.CleanupBlockReason));
            return findings;
        }
    }
    public static class ReviewDuplicateGroups
    {
        // Union overlapping native-warning/signature groups so one physical group is scored once.
        public static IList<List<long>> Merge(IEnumerable<IEnumerable<long>> groups)
        {
            var parent = new Dictionary<long, long>();
            foreach (var input in groups)
            {
                var ids = input.Distinct().OrderBy(x => x).ToList();
                if (ids.Count < 2) continue;
                foreach (long id in ids) if (!parent.ContainsKey(id)) parent[id] = id;
                long first = Find(parent, ids[0]);
                foreach (long id in ids.Skip(1)) parent[Find(parent, id)] = first;
            }
            return parent.Keys.ToList().GroupBy(id => Find(parent, id)).Select(group => group.OrderBy(id => id).ToList())
                .OrderBy(group => group[0]).ToList();
        }
        private static long Find(Dictionary<long, long> parent, long id)
        {
            long root = id;
            while (parent[root] != root) root = parent[root];
            while (parent[id] != id) { long next = parent[id]; parent[id] = root; id = next; }
            return root;
        }
    }

}
