using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using PipeTakeoff.Core;
using TaskDialog = Autodesk.Revit.UI.TaskDialog;

namespace PipeTakeoff.Revit
{
    [Transaction(TransactionMode.ReadOnly)]
    [Regeneration(RegenerationOption.Manual)]
    public sealed class CableTrayTakeoffCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            return ElectricalTakeoffWorkflow.Execute(commandData, ref message, true);
        }
    }

    internal static class ElectricalTakeoffWorkflow
    {
        public static Result Execute(ExternalCommandData commandData, ref string message, bool cableTray)
        {
            var tool = cableTray ? "Cable tray" : "Conduit";
            var category = cableTray ? "Cable Tray" : "Conduit";
            var plural = cableTray ? "cable trays" : "conduits";
            try
            {
                var uiDocument = commandData.Application.ActiveUIDocument;
                if (uiDocument == null || uiDocument.Document.IsFamilyDocument)
                {
                    TaskDialog.Show("KA MEP", "Open a Revit project containing " + plural + " first.");
                    return Result.Cancelled;
                }
                var choice = new TaskDialog("KA MEP - " + tool + " takeoff scope")
                {
                    MainInstruction = "Choose the " + plural + " and fittings to include",
                    MainContent = "Current-model " + plural + " and their fittings. You can exclude fittings in the takeoff window. "
                        + "Linked models, wires, equipment and other categories are excluded. Straight-run lengths and fitting counts are reported separately.",
                    CommonButtons = TaskDialogCommonButtons.Cancel
                };
                choice.AddCommandLink(TaskDialogCommandLinkId.CommandLink1, "All " + plural + " and fittings in the current model");
                choice.AddCommandLink(TaskDialogCommandLinkId.CommandLink2, tool + " elements in the active view");
                choice.AddCommandLink(TaskDialogCommandLinkId.CommandLink3, "Selected " + plural + " and fittings only");
                var result = choice.Show();
                PipeScope scope;
                if (result == TaskDialogResult.CommandLink1) scope = PipeScope.Model;
                else if (result == TaskDialogResult.CommandLink2) scope = PipeScope.ActiveView;
                else if (result == TaskDialogResult.CommandLink3) scope = PipeScope.Selection;
                else return Result.Cancelled;

                var snapshot = ElectricalReader.Read(uiDocument, scope, cableTray);
                if (snapshot.Records.Count == 0)
                {
                    TaskDialog.Show("KA MEP", "No " + plural + " or matching fittings were found in this scope. Choose another scope or select the required elements.");
                    return Result.Cancelled;
                }
                var owner = new RevitWindow(commandData.Application.MainWindowHandle);
                using (var form = new ElectricalTakeoffForm(snapshot.Records, snapshot.Fields, snapshot.ScopeLabel, cableTray))
                {
                    if (form.ShowDialog(owner) != DialogResult.OK) return Result.Cancelled;
                    using (var save = new SaveFileDialog())
                    {
                        save.Title = "KA MEP - Export " + tool.ToLowerInvariant() + " takeoff to Excel";
                        save.Filter = "Excel workbook (*.xlsx)|*.xlsx";
                        save.DefaultExt = "xlsx";
                        save.AddExtension = true;
                        save.OverwritePrompt = true;
                        var safeTitle = string.Concat(uiDocument.Document.Title.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c));
                        save.FileName = safeTitle + "_KA_MEP_" + (cableTray ? "CableTrays_" : "Conduits_")
                            + DateTime.Now.ToString("yyyyMMdd_HHmm", CultureInfo.InvariantCulture) + ".xlsx";
                        if (save.ShowDialog(owner) != DialogResult.OK) return Result.Cancelled;
                        ElectricalXlsxExporter.Export(save.FileName, form.FilteredRecords, form.Options, new ExportMetadata
                        {
                            Project = uiDocument.Document.Title,
                            RevitVersion = commandData.Application.Application.VersionName,
                            Scope = snapshot.ScopeLabel + (form.IncludesElectricalFittings ? "; fittings included" : "; fittings excluded")
                        });
                        var runs = form.FilteredRecords.Where(r => string.Equals(r.Get("Category") as string, category, StringComparison.Ordinal)).ToList();
                        TaskDialog.Show("KA MEP", string.Format(CultureInfo.CurrentCulture,
                            "Export complete.\n\n{0} elements: {1:N0}\nFittings: {2:N0}\nStraight-run length: {3:N3} m\n\n{4}",
                            tool, runs.Count, form.FilteredRecords.Count - runs.Count, runs.Sum(r => r.LengthMeters), save.FileName));
                    }
                }
                return Result.Succeeded;
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException) { return Result.Cancelled; }
            catch (Exception ex)
            {
                message = ex.Message;
                TaskDialog.Show("KA MEP - Error", "The " + tool.ToLowerInvariant() + " takeoff could not be completed.\n\n" + ex.Message);
                return Result.Failed;
            }
        }

        private sealed class RevitWindow : IWin32Window
        {
            public RevitWindow(IntPtr handle) { Handle = handle; }
            public IntPtr Handle { get; private set; }
        }
    }
}
