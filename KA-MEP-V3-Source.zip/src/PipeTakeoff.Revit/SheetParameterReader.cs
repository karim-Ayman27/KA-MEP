using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Autodesk.Revit.DB;

namespace PipeTakeoff.Revit
{
    internal sealed class SheetNamingParameter
    {
        public string Key { get; set; }
        public string Name { get; set; }
        public string Source { get; set; }
        public string Identity { get; set; }
        public string Label { get; set; }
        public override string ToString() { return Label; }
    }

    internal sealed class SheetExportSnapshot
    {
        public List<SheetExportItem> Sheets { get; set; }
        public List<SheetNamingParameter> Parameters { get; set; }
    }

    internal static class SheetParameterReader
    {
        internal const string SheetNumberKey = "sheet:number";
        internal const string SheetNameKey = "sheet:name";

        // Called only while inside IExternalCommand.Execute, before displaying the modal form.
        internal static SheetExportSnapshot Read(Document document)
        {
            var catalog = new Dictionary<string, SheetNamingParameter>(StringComparer.Ordinal);
            AddDefault(catalog, SheetNumberKey, "Sheet Number");
            AddDefault(catalog, SheetNameKey, "Sheet Name");
            var projectValues = new Dictionary<string, string>(StringComparer.Ordinal);
            ReadParameters(document, document.ProjectInformation, "Project", catalog, projectValues);
            var sheets = new List<SheetExportItem>();
            foreach (var sheet in new FilteredElementCollector(document).OfClass(typeof(ViewSheet)).Cast<ViewSheet>()
                .Where(x => !x.IsPlaceholder && x.CanBePrinted)
                .OrderBy(x => x.SheetNumber, StringComparer.CurrentCultureIgnoreCase).ThenBy(x => x.Name, StringComparer.CurrentCultureIgnoreCase))
            {
                var item = new SheetExportItem { Id = sheet.Id, Number = sheet.SheetNumber, Name = sheet.Name };
                foreach (var pair in projectValues) item.Parameters[pair.Key] = pair.Value;
                ReadParameters(document, sheet, "Sheet", catalog, item.Parameters);
                item.Parameters[SheetNumberKey] = sheet.SheetNumber;
                item.Parameters[SheetNameKey] = sheet.Name;
                sheets.Add(item);
            }
            var fields = catalog.Values.OrderBy(x => x.Source == "Sheet" ? 0 : 1)
                .ThenBy(x => x.Key == SheetNumberKey ? 0 : x.Key == SheetNameKey ? 1 : 2)
                .ThenBy(x => x.Name, StringComparer.CurrentCultureIgnoreCase).ThenBy(x => x.Key, StringComparer.Ordinal).ToList();
            foreach (var group in fields.GroupBy(x => x.Source + "\0" + x.Name, StringComparer.CurrentCultureIgnoreCase))
                foreach (var field in group)
                    field.Label = field.Source + " · " + field.Name + (group.Count() > 1 ? " [" + field.Identity + "]" : "");
            return new SheetExportSnapshot { Sheets = sheets, Parameters = fields };
        }

        private static void AddDefault(IDictionary<string, SheetNamingParameter> catalog, string key, string name)
        {
            catalog[key] = new SheetNamingParameter { Key = key, Name = name, Source = "Sheet", Identity = key };
        }

        private static void ReadParameters(Document document, Element element, string source,
            IDictionary<string, SheetNamingParameter> catalog, IDictionary<string, string> values)
        {
            if (element == null) return;
            foreach (Parameter parameter in element.Parameters)
            {
                if (parameter == null || parameter.Definition == null || parameter.StorageType == StorageType.None) continue;
                string key, identity;
                if (source == "Sheet" && parameter.Id == new ElementId(BuiltInParameter.SHEET_NUMBER)) key = SheetNumberKey;
                else if (source == "Sheet" && parameter.Id == new ElementId(BuiltInParameter.SHEET_NAME)) key = SheetNameKey;
                else key = source.ToLowerInvariant() + ":" + (parameter.IsShared ? "guid:" + parameter.GUID.ToString("D") : "id:" + parameter.Id.ToString());
                identity = parameter.IsShared ? parameter.GUID.ToString("D") : "ID " + parameter.Id.ToString();
                if (!catalog.ContainsKey(key)) catalog[key] = new SheetNamingParameter
                { Key = key, Name = parameter.Definition.Name, Source = source, Identity = identity };
                try { values[key] = ReadValue(document, parameter); }
                catch (Autodesk.Revit.Exceptions.OperationCanceledException) { throw; }
                catch { values[key] = ""; } // Unreadable model values use the same visible NA fallback as empty values.
            }
        }

        private static string ReadValue(Document document, Parameter parameter)
        {
            if (!parameter.HasValue) return "";
            if (parameter.StorageType == StorageType.String) return parameter.AsString() ?? "";
            string display = parameter.AsValueString();
            if (!string.IsNullOrWhiteSpace(display)) return display;
            if (parameter.StorageType == StorageType.Integer) return parameter.AsInteger().ToString(CultureInfo.CurrentCulture);
            if (parameter.StorageType == StorageType.Double)
            {
                double value = parameter.AsDouble();
                if (UnitUtils.IsMeasurableSpec(parameter.Definition.GetDataType()))
                    value = UnitUtils.ConvertFromInternalUnits(value, parameter.GetUnitTypeId());
                return value.ToString("G17", CultureInfo.CurrentCulture);
            }
            if (parameter.StorageType == StorageType.ElementId)
            {
                var id = parameter.AsElementId();
                if (id == ElementId.InvalidElementId) return "";
                var reference = document.GetElement(id);
                return reference == null ? id.ToString() : reference.Name;
            }
            return "";
        }
    }
}
