using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PipeTakeoff.Core;

namespace PipeTakeoff.Revit
{
    /// <summary>Detached modeless presentation. This form never calls Revit or renders imported HTML.</summary>
    public sealed class ClashManagerForm : Form
    {
        public const long MaximumImportBytes = 16L * 1024 * 1024;
        private readonly Button _browse = KaTheme.Button("Browse HTML…");
        private readonly Button _refreshVisible = KaTheme.Button("Refresh visible");
        private readonly Button _refreshSelected = KaTheme.Button("Refresh selected");
        private readonly Button _focus = KaTheme.Button("View pair in 3D");
        private readonly Button _applySources = KaTheme.Button("Apply to selected");
        private readonly Button _export = KaTheme.Button("Export Excel (.xlsx)", true);
        private readonly Button _cancel = KaTheme.Button("Cancel");
        private readonly Button _close = KaTheme.Button("Close");
        private readonly TextBox _search = new TextBox();
        private readonly ComboBox _statusFilter = Choice("All statuses", "Unchecked", "Unsolved", "Solved", "Needs review");
        private readonly ComboBox _testFilter = Choice("All tests");
        private readonly ComboBox _source1 = Choice(), _source2 = Choice();
        private readonly CheckBox _assumeHard = new CheckBox { Text = "Treat unknown tests as hard clashes", AutoSize = true };
        private readonly CheckBox _isolate = new CheckBox { Text = "Temporarily isolate the pair", AutoSize = true };
        private readonly NumericUpDown _margin = new NumericUpDown { Minimum = .05M, Maximum = 100, Value = 1, DecimalPlaces = 2, Increment = .25M, Width = 100 };
        private readonly DataGridView _grid = new DataGridView();
        private readonly TextBox _details = new TextBox { Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Both, WordWrap = false, BorderStyle = BorderStyle.None, BackColor = Color.White, Dock = DockStyle.Fill };
        private readonly Label _status = new Label { AutoEllipsis = true, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };
        private readonly Label _summary = new Label { AutoEllipsis = true, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };
        private readonly Label _importHint = new Label { Text = "Drop one local .htm / .html clash report here", AutoEllipsis = true, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };
        private readonly ProgressBar _progress = new ProgressBar { Dock = DockStyle.Fill, Height = 5, Visible = false };
        private readonly TabControl _tabs = new TabControl { Dock = DockStyle.Fill };
        private readonly ToolTip _tips = new ToolTip { AutoPopDelay = 30000 };
        private TableLayoutPanel _layout, _header, _footer;
        private Label _title, _subtitle;
        private Font _titleFont;
        private ClashReport _report;
        private List<ClashRecord> _visible = new List<ClashRecord>();
        private bool _loading, _busy, _arranging, _built;
        private string _message = "Import a clash report, review model sources, then refresh against the current Revit model.";

        public event Action<string> ImportRequested;
        public event Action<IList<ClashRecord>, ClashCheckOptions> RefreshRequested;
        public event Action<ClashRecord, double, bool> FocusRequested;
        public event Action<ClashReport, string> ExportRequested;
        public event Action CancelRequested;
        public event Action SourcesChanged;
        public ClashReport Report { get { return _report; } }
        public IList<ClashRecord> VisibleRows { get { return _visible.AsReadOnly(); } }
        public IList<ClashRecord> SelectedRows { get { return _grid.SelectedRows.Cast<DataGridViewRow>().OrderBy(r => r.Index).Select(r => r.Tag as ClashRecord).Where(r => r != null).ToList(); } }
        public string FilterDescription
        {
            get { return "Visible rows: " + _visible.Count + " / " + (_report == null ? 0 : _report.Rows.Count) + "; status=" + _statusFilter.Text + "; test=" + _testFilter.Text + "; search=" + _search.Text.Trim() + ". Row selection does not limit export."; }
        }

        public ClashManagerForm()
        {
            KaTheme.ApplyForm(this, "Clash Manager", 1230, 800);
            Name = "ClashManagerForm"; MinimumSize = new Size(850, 560); AllowDrop = true; KeyPreview = true;
            _loading = true; BuildInterface(); SetSources(new List<ClashModelSource>()); _loading = false;
            _search.TextChanged += delegate { if (!_loading) RefreshRows(); };
            _statusFilter.SelectedIndexChanged += delegate { if (!_loading) RefreshRows(); };
            _testFilter.SelectedIndexChanged += delegate { if (!_loading) RefreshRows(); };
            _grid.SelectionChanged += delegate { if (!_loading) { UpdateDetails(); UpdateActions(); } };
            _grid.CellDoubleClick += (sender, e) => { if (e.RowIndex >= 0) FocusSelection(); };
            _browse.Click += delegate { Browse(); };
            _refreshVisible.Click += delegate { RequestRefresh(_visible.ToList()); };
            _refreshSelected.Click += delegate { RequestRefresh(SelectedRows); };
            _focus.Click += delegate { FocusSelection(); };
            _applySources.Click += delegate { ApplySources(); };
            _assumeHard.CheckedChanged += delegate
            {
                if (_loading || _report == null) return;
                foreach (var row in _report.Rows.Where(r => r.TestKind == ClashTestKind.Unknown)) row.Invalidate("Unknown-test assumption changed. Refresh this clash.");
                SourcesChanged?.Invoke(); RefreshRows();
            };
            _cancel.Click += delegate { CancelRequested?.Invoke(); };
            _export.Click += delegate { if (!_busy && _visible.Count > 0) ExportRequested?.Invoke(GetExportReport(), FilterDescription); };
            _close.Click += delegate { Close(); };
            DragEnter += ImportDragEnter; DragDrop += ImportDragDrop;
            foreach (Control target in new Control[] { _importHint, _grid, _tabs }) { target.AllowDrop = true; target.DragEnter += ImportDragEnter; target.DragDrop += ImportDragDrop; }
            RefreshRows();
        }

        public ClashCheckOptions ReadCheckOptions() { return new ClashCheckOptions { AssumeHardForUnknown = _assumeHard.Checked }; }

        public void SetReport(ClashReport report)
        {
            if (report == null || report.Rows == null) throw new ArgumentException("A report and clash rows are required.");
            _report = report; _loading = true;
            try
            {
                _testFilter.Items.Clear(); _testFilter.Items.Add("All tests");
                foreach (var test in report.Rows.Select(r => r.TestName ?? "").Distinct(StringComparer.Ordinal).OrderBy(t => t, StringComparer.CurrentCultureIgnoreCase)) _testFilter.Items.Add(test);
                _testFilter.SelectedIndex = 0; _statusFilter.SelectedIndex = 0; _search.Clear();
            }
            finally { _loading = false; }
            _importHint.Text = Path.GetFileName(report.SourcePath) + "  •  " + report.Rows.Count + " clashes";
            _tips.SetToolTip(_importHint, report.SourcePath + Environment.NewLine + string.Join(Environment.NewLine, report.Notes));
            _message = "Imported " + report.Rows.Count + " clashes. Imported status is separate from the current Revit check. Export includes all visible rows.";
            _tabs.SelectedIndex = 0; RefreshRows();
        }

        public void SetSources(IList<ClashModelSource> sources)
        {
            bool before = _loading; _loading = true;
            try
            {
                foreach (var combo in new[] { _source1, _source2 })
                {
                    string selected = (combo.SelectedItem as ClashModelSource)?.Key ?? "";
                    combo.Items.Clear(); combo.Items.Add(new ClashModelSource { Key = "", DisplayName = "Auto — report source / unique match" });
                    foreach (var source in sources ?? new List<ClashModelSource>()) combo.Items.Add(source);
                    combo.SelectedItem = combo.Items.Cast<ClashModelSource>().FirstOrDefault(s => s.Key == selected) ?? combo.Items[0];
                }
            }
            finally { _loading = before; }
        }

        public void InvalidateResults(string reason)
        {
            if (_report != null) foreach (var row in _report.Rows) row.Invalidate(reason);
            _message = reason; RefreshRows();
        }

        public ClashReport GetExportReport()
        {
            if (_report == null) throw new InvalidOperationException("Import a report first.");
            return new ClashReport { Title = _report.Title, SourcePath = _report.SourcePath, SourceSha256 = _report.SourceSha256,
                Producer = _report.Producer, ImportedAt = _report.ImportedAt, Notes = new List<string>(_report.Notes), Rows = _visible.ToList() };
        }

        public void RefreshRows()
        {
            if (_loading) return;
            var selected = new HashSet<ClashRecord>(SelectedRows);
            string query = _search.Text.Trim();
            IEnumerable<ClashRecord> rows = _report == null ? Enumerable.Empty<ClashRecord>() : _report.Rows;
            if (_statusFilter.SelectedIndex > 0) rows = rows.Where(r => (int)r.State == _statusFilter.SelectedIndex - 1);
            if (_testFilter.SelectedIndex > 0) rows = rows.Where(r => string.Equals(r.TestName, _testFilter.Text, StringComparison.Ordinal));
            if (query.Length > 0) rows = rows.Where(r => SearchText(r).IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0);
            _visible = rows.ToList(); _loading = true;
            try
            {
                _grid.Rows.Clear();
                foreach (var row in _visible)
                {
                    int index = _grid.Rows.Add("●  " + StateLabel(row.State), row.Name, row.TestName, row.Element1.CategoryLabel, row.Element2.CategoryLabel,
                        SourceLabel(row.Element1), row.Element1.IdLabel, SourceLabel(row.Element2), row.Element2.IdLabel, row.ImportedStatus);
                    var display = _grid.Rows[index]; display.Tag = row;
                    display.Cells["State"].Style.ForeColor = StateColor(row.State);
                    display.Cells["State"].Style.SelectionForeColor = StateColor(row.State);
                    display.Cells["State"].ToolTipText = row.CheckNote;
                    display.Selected = selected.Contains(row);
                }
                if (selected.Count == 0) _grid.ClearSelection();
            }
            finally { _loading = false; }
            var counts = ClashSummary.Count(_visible);
            _summary.Text = _visible.Count + " visible  •  " + counts[ClashState.Solved] + " solved  •  " + counts[ClashState.Unsolved] + " unsolved  •  " + counts[ClashState.NeedsReview] + " review  •  " + counts[ClashState.Unchecked] + " unchecked";
            _tips.SetToolTip(_summary, _summary.Text + Environment.NewLine + FilterDescription);
            FitGrid(); UpdateDetails(); UpdateActions();
        }

        public void SetBusy(bool busy, string message, int completed = 0, int total = 0)
        {
            _busy = busy; if (!string.IsNullOrEmpty(message)) _message = message;
            _progress.Visible = busy; _progress.Maximum = Math.Max(1, total); _progress.Value = Math.Max(0, Math.Min(completed, _progress.Maximum));
            _progress.Style = total > 0 ? ProgressBarStyle.Continuous : ProgressBarStyle.Marquee;
            UpdateActions();
        }
        public void ShowStatus(string message) { _message = message ?? ""; UpdateActions(); }
        public void ShowFailure(string message) { ShowStatus("Could not complete the action: " + message); }

        public static bool IsSupportedDrop(IDataObject data, out string path)
        {
            path = null;
            try
            {
                if (data == null || !data.GetDataPresent(DataFormats.FileDrop)) return false;
                var paths = data.GetData(DataFormats.FileDrop) as string[];
                if (paths == null || paths.Length != 1) return false;
                ValidateImportPath(paths[0]); path = Path.GetFullPath(paths[0]); return true;
            }
            catch (Exception) { return false; }
        }

        public static void ValidateImportPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || !Path.IsPathRooted(path) || path.StartsWith(@"\\", StringComparison.Ordinal) || path.StartsWith("//", StringComparison.Ordinal))
                throw new InvalidOperationException("Choose one local HTML file.");
            string extension = Path.GetExtension(path);
            if (!string.Equals(extension, ".htm", StringComparison.OrdinalIgnoreCase) && !string.Equals(extension, ".html", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Only .htm and .html clash reports are supported.");
            var file = new FileInfo(path);
            if (!file.Exists) throw new FileNotFoundException("The selected HTML file no longer exists.");
            if (file.Length > MaximumImportBytes) throw new InvalidOperationException("The HTML report exceeds the 16 MiB import limit.");
        }

        private void BuildInterface()
        {
            _layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, Padding = new Padding(12), Margin = Padding.Empty };
            _layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            _layout.RowStyles.Add(new RowStyle(SizeType.AutoSize)); _layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            _layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); _layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            _header = new TableLayoutPanel { ColumnCount = 1, RowCount = 2, AutoSize = true, Dock = DockStyle.Fill, BackColor = KaTheme.Navy, Padding = new Padding(14, 9, 14, 9), Margin = new Padding(0, 0, 0, 6) };
            _header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            _title = new Label { Text = "KA MEP  /  Clash Manager", AutoSize = true, ForeColor = Color.White, Margin = Padding.Empty };
            _subtitle = new Label { Text = "Import • Check the current model • Resolve • Export", AutoSize = true, ForeColor = Color.FromArgb(194, 211, 223), Margin = new Padding(0, 4, 0, 0) };
            _header.Controls.Add(_title, 0, 0); _header.Controls.Add(_subtitle, 0, 1); _layout.Controls.Add(_header, 0, 0);
            var import = new TableLayoutPanel { ColumnCount = 2, AutoSize = true, Dock = DockStyle.Fill, Margin = new Padding(0, 0, 0, 4) };
            import.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100)); import.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            _browse.Name = "ClashBrowse"; _importHint.Name = "ClashImportHint"; import.Controls.Add(_importHint, 0, 0); import.Controls.Add(_browse, 1, 0); _layout.Controls.Add(import, 0, 1);
            _tabs.Name = "ClashTabs"; var results = new TabPage("Clashes"); var pair = new TabPage("Pair details / Sources"); _tabs.TabPages.Add(results); _tabs.TabPages.Add(pair); _layout.Controls.Add(_tabs, 0, 2);
            var resultLayout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, Padding = new Padding(5) };
            resultLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            resultLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize)); resultLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize)); resultLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            var filters = new TableLayoutPanel { ColumnCount = 3, RowCount = 2, Dock = DockStyle.Fill, AutoSize = true, Margin = Padding.Empty };
            filters.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40)); filters.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 27)); filters.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33));
            AddFilter(filters, "Search clashes", _search, 0, "ClashSearch"); AddFilter(filters, "Current status", _statusFilter, 1, "ClashStatusFilter"); AddFilter(filters, "Clash test", _testFilter, 2, "ClashTestFilter");
            _tips.SetToolTip(_search, "Search clash names, categories, element IDs, models and check notes.");
            resultLayout.Controls.Add(filters, 0, 0); _summary.Name = "ClashSummary"; resultLayout.Controls.Add(_summary, 0, 1);
            _grid.Name = "ClashGrid"; KaTheme.StyleGrid(_grid, true); _grid.MultiSelect = true; _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
            _grid.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.False; _grid.DefaultCellStyle.WrapMode = DataGridViewTriState.False; _grid.ScrollBars = ScrollBars.Both;
            AddColumn("State", "Current status", 145); AddColumn("Name", "Clash name", 180); AddColumn("Test", "Test", 155); AddColumn("Category1", "Category 1", 125); AddColumn("Category2", "Category 2", 125);
            AddColumn("Source1", "Model 1", 150); AddColumn("Id1", "Element ID 1", 125); AddColumn("Source2", "Model 2", 150); AddColumn("Id2", "Element ID 2", 125); AddColumn("ImportedStatus", "Imported status", 130);
            _grid.FontChanged += delegate { FitGrid(); }; resultLayout.Controls.Add(_grid, 0, 2); results.Controls.Add(resultLayout);
            var pairLayout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, Padding = new Padding(6) };
            pairLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            pairLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 52)); pairLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 48));
            var optionsViewport = new Panel { Name = "ClashPairOptions", Dock = DockStyle.Fill, AutoScroll = true };
            var options = new TableLayoutPanel { AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, Dock = DockStyle.Top, ColumnCount = 2, RowCount = 8, Padding = new Padding(4) };
            options.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize)); options.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            AddOption(options, 0, "Element 1 model", _source1, "ClashSource1"); AddOption(options, 1, "Element 2 model", _source2, "ClashSource2");
            _applySources.Name = "ClashApplySources"; options.Controls.Add(_applySources, 1, 2);
            _assumeHard.Name = "ClashAssumeHard"; options.Controls.Add(_assumeHard, 1, 3);
            AddOption(options, 4, "3D margin (m)", _margin, "ClashMargin"); _margin.Dock = DockStyle.None; _margin.Anchor = AnchorStyles.Left;
            _isolate.Name = "ClashIsolate"; options.Controls.Add(_isolate, 1, 5);
            _refreshSelected.Name = "ClashRefreshSelected"; _focus.Name = "ClashFocus"; options.Controls.Add(_refreshSelected, 0, 6); options.Controls.Add(_focus, 1, 6);
            var hint = KaTheme.Hint("Source overrides apply to selected rows. Unknown tests need an explicit assumption; clearance criteria remain review-only. Double-click a clash to view its pair.");
            hint.MaximumSize = new Size(760, 0); options.Controls.Add(hint, 0, 7); options.SetColumnSpan(hint, 2); optionsViewport.Controls.Add(options); pairLayout.Controls.Add(optionsViewport, 0, 0);
            _details.Name = "ClashDetails"; pairLayout.Controls.Add(_details, 0, 1); pair.Controls.Add(pairLayout);
            _footer = new TableLayoutPanel { ColumnCount = 1, RowCount = 3, AutoSize = true, Dock = DockStyle.Fill, Margin = Padding.Empty, Padding = new Padding(0, 3, 0, 0) };
            _footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            _status.Name = "ClashStatus"; _footer.Controls.Add(_status, 0, 0); _footer.Controls.Add(_progress, 0, 1);
            var footerActions = new FlowLayoutPanel { AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, Dock = DockStyle.Fill, WrapContents = false, Margin = Padding.Empty };
            _refreshVisible.Name = "ClashRefreshVisible"; _export.Name = "ClashExportExcel"; _cancel.Name = "ClashCancel"; _close.Name = "ClashClose";
            foreach (var button in new[] { _refreshVisible, _export, _cancel, _close }) footerActions.Controls.Add(button);
            _footer.Controls.Add(footerActions, 0, 2); _layout.Controls.Add(_footer, 0, 3); Controls.Add(_layout); _built = true;
        }

        private void ApplySources()
        {
            if (_busy) return;
            var rows = SelectedRows; if (rows.Count == 0) return;
            string first = ((ClashModelSource)_source1.SelectedItem).Key, second = ((ClashModelSource)_source2.SelectedItem).Key;
            foreach (var row in rows)
            {
                row.Element1.SourceOverrideKey = first; row.Element2.SourceOverrideKey = second;
                ClearResolution(row.Element1); ClearResolution(row.Element2); row.Invalidate("Model source mapping changed. Refresh this clash.");
            }
            SourcesChanged?.Invoke(); _message = "Source mapping applied to " + rows.Count + " selected clashes. Refresh to check their current state."; RefreshRows();
        }
        private static void ClearResolution(ClashElementReference reference)
        {
            reference.ResolvedSourceKey = ""; reference.ResolvedSourceName = ""; reference.ResolvedElementId = null; reference.ResolvedUniqueId = "";
            reference.ResolvedCategory = ""; reference.ResolvedName = ""; reference.ResolutionNote = "";
        }
        private void RequestRefresh(IList<ClashRecord> rows) { if (!_busy && rows.Count > 0) RefreshRequested?.Invoke(rows, ReadCheckOptions()); }
        private void FocusSelection() { var selected = SelectedRows; if (!_busy && selected.Count == 1) FocusRequested?.Invoke(selected[0], (double)_margin.Value, _isolate.Checked); }
        private void Browse()
        {
            if (_busy) return;
            using (var dialog = new OpenFileDialog { Title = "Import a clash report", Filter = "HTML clash reports (*.htm;*.html)|*.htm;*.html", Multiselect = false, CheckFileExists = true })
                if (dialog.ShowDialog(this) == DialogResult.OK) DispatchImport(dialog.FileName);
        }
        private void DispatchImport(string path)
        {
            if (_busy) return;
            try { ValidateImportPath(path); ImportRequested?.Invoke(path); }
            catch (Exception ex) { ShowFailure(ex.Message); }
        }
        private void ImportDragEnter(object sender, DragEventArgs e) { string path; e.Effect = !_busy && IsSupportedDrop(e.Data, out path) ? DragDropEffects.Copy : DragDropEffects.None; }
        private void ImportDragDrop(object sender, DragEventArgs e) { string path; if (!_busy && IsSupportedDrop(e.Data, out path)) DispatchImport(path); }
        private void UpdateActions()
        {
            _browse.Enabled = !_busy; _refreshVisible.Enabled = !_busy && _visible.Count > 0; _export.Enabled = !_busy && _visible.Count > 0;
            _refreshSelected.Enabled = !_busy && SelectedRows.Count > 0; _focus.Enabled = !_busy && SelectedRows.Count == 1;
            _applySources.Enabled = !_busy && SelectedRows.Count > 0; _source1.Enabled = _source2.Enabled = _assumeHard.Enabled = !_busy;
            _search.Enabled = _statusFilter.Enabled = _testFilter.Enabled = !_busy; _cancel.Enabled = _busy;
            _status.Text = _message; _tips.SetToolTip(_status, _message);
        }
        private void UpdateDetails()
        {
            var rows = SelectedRows;
            if (rows.Count != 1) { _details.Text = rows.Count == 0 ? "Select a clash to see its IDs, model provenance and check notes." : rows.Count + " clashes selected. Source mapping and Refresh selected apply to every selected row."; return; }
            var row = rows[0]; var text = new StringBuilder();
            text.AppendLine(row.Name + "  |  " + row.TestName + "  |  " + row.TestKind);
            text.AppendLine("Current: " + StateLabel(row.State) + "  |  Imported: " + row.ImportedStatus);
            text.AppendLine("Checked: " + (row.CheckedAt.HasValue ? row.CheckedAt.Value.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.CurrentCulture) : "Not checked / stale"));
            text.AppendLine("Check: " + row.CheckNote); text.AppendLine("Basis: " + row.CheckBasis);
            AppendReference(text, "Element 1", row.Element1); AppendReference(text, "Element 2", row.Element2);
            text.AppendLine("Distance / tolerance: " + row.DistanceText); text.AppendLine("Clash point: " + row.ClashPointText); text.AppendLine("Assigned to: " + row.AssignedTo); text.AppendLine(row.Description);
            _details.Text = text.ToString();
        }
        private static void AppendReference(StringBuilder text, string title, ClashElementReference reference)
        {
            text.AppendLine(); text.AppendLine(title + ": ID " + reference.IdLabel + " | " + reference.CategoryLabel);
            text.AppendLine("Reported name: " + reference.ReportedName + " | Source: " + reference.SourceHint);
            text.AppendLine("Source override: " + (string.IsNullOrEmpty(reference.SourceOverrideKey) ? "Auto" : reference.SourceOverrideKey));
            text.AppendLine("Resolved: " + reference.ResolvedSourceName + " | " + reference.ResolvedElementId + " | " + reference.ResolvedName);
            text.AppendLine("Unique ID: " + reference.UniqueId + " | Resolved unique ID: " + reference.ResolvedUniqueId); text.AppendLine(reference.ResolutionNote);
        }
        private static string SearchText(ClashRecord row) { return string.Join(" ", new[] { row.Name, row.TestName, row.ImportedStatus, row.Element1.IdLabel, row.Element2.IdLabel, row.Element1.CategoryLabel, row.Element2.CategoryLabel, row.Element1.SourceHint, row.Element2.SourceHint, row.Element1.ResolvedSourceName, row.Element2.ResolvedSourceName, row.Element1.ReportedName, row.Element2.ReportedName, row.CheckNote }); }
        private static string SourceLabel(ClashElementReference reference) { return !string.IsNullOrWhiteSpace(reference.ResolvedSourceName) ? reference.ResolvedSourceName : !string.IsNullOrWhiteSpace(reference.SourceOverrideKey) ? reference.SourceOverrideKey : reference.SourceHint; }
        public static string StateLabel(ClashState state) { return state == ClashState.NeedsReview ? "Needs review" : state.ToString(); }
        public static Color StateColor(ClashState state) { return state == ClashState.Solved ? Color.FromArgb(18, 117, 65) : state == ClashState.Unsolved ? Color.FromArgb(181, 40, 45) : state == ClashState.NeedsReview ? Color.FromArgb(158, 98, 12) : Color.FromArgb(96, 109, 119); }
        private static ComboBox Choice(params string[] values) { var combo = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Dock = DockStyle.Fill, IntegralHeight = false, DropDownHeight = 260 }; combo.Items.AddRange(values); if (values.Length > 0) combo.SelectedIndex = 0; return combo; }
        private static void AddFilter(TableLayoutPanel layout, string caption, Control input, int column, string name) { layout.Controls.Add(new Label { Text = caption, AutoSize = true, Margin = new Padding(0, 0, 7, 2) }, column, 0); input.Name = name; input.Dock = DockStyle.Fill; input.Margin = new Padding(0, 0, 7, 2); layout.Controls.Add(input, column, 1); }
        private static void AddOption(TableLayoutPanel layout, int row, string caption, Control input, string name) { layout.Controls.Add(new Label { Text = caption, AutoSize = true, Anchor = AnchorStyles.Left, Margin = new Padding(0, 4, 8, 4) }, 0, row); input.Name = name; input.Dock = DockStyle.Fill; input.Margin = new Padding(0, 3, 4, 3); layout.Controls.Add(input, 1, row); }
        private void AddColumn(string name, string caption, int width) { _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = name, HeaderText = caption, Width = width, MinimumWidth = 60, SortMode = DataGridViewColumnSortMode.NotSortable }); }
        protected override void OnShown(EventArgs e) { base.OnShown(e); KaTheme.ClampToScreen(this); }
        protected override void OnLayout(LayoutEventArgs e)
        {
            if (_built && !_arranging)
            {
                _arranging = true;
                try
                {
                    bool compact = ClientSize.Height < Font.Height * 30;
                    _layout.Padding = compact ? new Padding(5) : new Padding(12);
                    _subtitle.Visible = !compact; _header.Padding = compact ? new Padding(10, 4, 10, 4) : new Padding(14, 9, 14, 9);
                    float points = Font.SizeInPoints * (compact ? 1.1F : 1.65F);
                    if (_titleFont == null || Math.Abs(_titleFont.SizeInPoints - points) > .01)
                    { var previous = _titleFont; _titleFont = new Font(Font.FontFamily, points, FontStyle.Bold); _title.Font = _titleFont; previous?.Dispose(); }
                    else if (!ReferenceEquals(_title.Font, _titleFont)) _title.Font = _titleFont;
                    _status.Height = Font.Height + 9; _summary.Height = Font.Height + 9;
                    _importHint.MaximumSize = new Size(0, Font.Height + 9);
                    foreach (var button in new[] { _browse, _refreshVisible, _refreshSelected, _focus, _applySources, _export, _cancel, _close })
                    { button.AutoSize = true; button.AutoSizeMode = AutoSizeMode.GrowAndShrink; button.MinimumSize = new Size(0, 32); button.Padding = new Padding(7, 4, 7, 4); }
                    _tabs.Padding = compact ? new Point(7, 3) : new Point(12, 6); FitGrid();
                }
                finally { _arranging = false; }
            }
            base.OnLayout(e);
        }
        private void FitGrid()
        {
            FitGridText(_grid);
        }
        internal static void FitGridText(DataGridView grid)
        {
            if (grid == null || grid.IsDisposed) return;
            grid.DefaultCellStyle.Font = grid.Font; grid.ColumnHeadersDefaultCellStyle.Font = grid.Font;
            int text = TextRenderer.MeasureText("Clash 001", grid.Font, Size.Empty, TextFormatFlags.SingleLine).Height;
            int height = text + grid.DefaultCellStyle.Padding.Vertical + 6;
            grid.RowTemplate.Height = height; foreach (DataGridViewRow row in grid.Rows) row.Height = height;
            grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            grid.ColumnHeadersHeight = text + grid.ColumnHeadersDefaultCellStyle.Padding.Vertical + 6;
            foreach (DataGridViewColumn column in grid.Columns)
                column.MinimumWidth = Math.Max(60, TextRenderer.MeasureText(column.HeaderText, grid.Font, Size.Empty, TextFormatFlags.SingleLine).Width + 24);
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Control | Keys.E)) { if (_export.Enabled) _export.PerformClick(); return true; }
            if (keyData == Keys.F5) { if (_refreshVisible.Enabled) _refreshVisible.PerformClick(); return true; }
            return base.ProcessCmdKey(ref msg, keyData);
        }
        protected override void Dispose(bool disposing) { if (disposing) { _tips.Dispose(); _titleFont?.Dispose(); } base.Dispose(disposing); }
    }

    /// <summary>Text-only table preview and explicit mapping. HTML is never hosted in a browser control.</summary>
    internal sealed class ClashMappingForm : Form
    {
        private readonly ComboBox _table = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Dock = DockStyle.Fill };
        private readonly CheckBox _headers = new CheckBox { Text = "First row contains column headers", Checked = true, AutoSize = true };
        private readonly DataGridView _preview = new DataGridView();
        private readonly Dictionary<string, ComboBox> _columns = new Dictionary<string, ComboBox>();
        private readonly IList<ClashTablePreview> _tables;
        private readonly Label _error = new Label { AutoSize = true, ForeColor = KaTheme.Warning, Dock = DockStyle.Fill };
        public ClashColumnMapping Mapping { get; private set; }
        public ClashMappingForm(IList<ClashTablePreview> tables)
        {
            _tables = tables ?? throw new ArgumentNullException(nameof(tables));
            KaTheme.ApplyForm(this, "Map HTML clash columns", 1000, 740); Name = "ClashMappingForm"; MinimumSize = new Size(700, 480);
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 5, Padding = new Padding(10) };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize)); layout.RowStyles.Add(new RowStyle(SizeType.AutoSize)); layout.RowStyles.Add(new RowStyle(SizeType.Percent, 38)); layout.RowStyles.Add(new RowStyle(SizeType.Percent, 62)); layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.Controls.Add(KaTheme.Hint("This layout needs a column mapping. Preview text below and select identifiers for both elements."), 0, 0);
            var tableRow = KaTheme.Flow(); tableRow.Dock = DockStyle.Fill; tableRow.Controls.Add(new Label { Text = "Report table", AutoSize = true, Margin = new Padding(0, 6, 8, 0) });
            _table.Name = "ClashMappingTable"; _headers.Name = "ClashMappingHeaders"; _table.Width = 350; _table.Dock = DockStyle.None; tableRow.Controls.Add(_table); tableRow.Controls.Add(_headers); layout.Controls.Add(tableRow, 0, 1);
            _preview.Name = "ClashMappingPreview"; KaTheme.StyleGrid(_preview, true); _preview.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None; _preview.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.False; layout.Controls.Add(_preview, 0, 2);
            _preview.FontChanged += delegate { ClashManagerForm.FitGridText(_preview); };
            var viewport = new Panel { Name = "ClashMappingOptions", Dock = DockStyle.Fill, AutoScroll = true }; var mappings = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 2 };
            mappings.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize)); mappings.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            string[,] fields = { {"Id1Column", "Element ID 1"}, {"Id2Column", "Element ID 2"}, {"UniqueId1Column", "Unique ID 1 (optional alternative)"}, {"UniqueId2Column", "Unique ID 2 (optional alternative)"}, {"NameColumn", "Clash name"}, {"TestNameColumn", "Test name"}, {"TestKindColumn", "Test type (hard / clearance)"}, {"Category1Column", "Category 1"}, {"Category2Column", "Category 2"}, {"Source1Column", "Model / file 1"}, {"Source2Column", "Model / file 2"}, {"Name1Column", "Element name 1"}, {"Name2Column", "Element name 2"}, {"StatusColumn", "Imported status"}, {"DistanceColumn", "Distance / tolerance"}, {"ClashPointColumn", "Clash point"}, {"AssignedToColumn", "Assigned to"}, {"DescriptionColumn", "Description"} };
            for (int i = 0; i < fields.GetLength(0); i++) { var combo = new ComboBox { Name = "ClashMapping" + fields[i, 0], DropDownStyle = ComboBoxStyle.DropDownList, Dock = DockStyle.Fill }; _columns.Add(fields[i, 0], combo); mappings.Controls.Add(new Label { Text = fields[i, 1], AutoSize = true, Anchor = AnchorStyles.Left, Margin = new Padding(0, 6, 12, 6) }, 0, i); mappings.Controls.Add(combo, 1, i); }
            viewport.Controls.Add(mappings); layout.Controls.Add(viewport, 0, 3);
            var footer = new TableLayoutPanel { AutoSize = true, Dock = DockStyle.Fill, ColumnCount = 1 }; footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100)); _error.Name = "ClashMappingError"; footer.Controls.Add(_error, 0, 0); var actions = KaTheme.Flow(); var apply = KaTheme.Button("Import with mapping", true); var cancel = KaTheme.Button("Cancel");
            apply.Name = "ClashMappingApply"; cancel.Name = "ClashMappingCancel"; cancel.DialogResult = DialogResult.Cancel; actions.Controls.Add(apply); actions.Controls.Add(cancel); footer.Controls.Add(actions, 0, 1); layout.Controls.Add(footer, 0, 4); Controls.Add(layout);
            CancelButton = cancel; apply.Click += delegate { Apply(); }; _table.SelectedIndexChanged += delegate { ShowTable(); }; _headers.CheckedChanged += delegate { ShowPreview(); }; foreach (var table in tables) _table.Items.Add(table); if (_table.Items.Count > 0) _table.SelectedIndex = 0;
        }
        private void ShowTable()
        {
            var table = _table.SelectedItem as ClashTablePreview; if (table == null) return;
            int width = Math.Max(table.Headers.Count, table.PreviewRows.Count == 0 ? 0 : table.PreviewRows.Max(row => row.Count));
            ShowPreview();
            foreach (var combo in _columns.Values)
            { combo.Items.Clear(); combo.Items.Add("(Not mapped)"); for (int i = 0; i < width; i++) combo.Items.Add((i + 1) + ": " + (i < table.Headers.Count ? table.Headers[i] : "Column " + (i + 1))); combo.SelectedIndex = 0; }
        }
        private void ShowPreview()
        {
            var table = _table.SelectedItem as ClashTablePreview; if (table == null) return;
            _preview.Rows.Clear(); _preview.Columns.Clear();
            int width = Math.Max(table.Headers.Count, table.PreviewRows.Count == 0 ? 0 : table.PreviewRows.Max(row => row.Count));
            for (int i = 0; i < width; i++) _preview.Columns.Add("Column" + i, _headers.Checked && i < table.Headers.Count ? table.Headers[i] : "Column " + (i + 1));
            if (!_headers.Checked && table.Headers.Count > 0) _preview.Rows.Add(table.Headers.Cast<object>().ToArray());
            foreach (var row in table.PreviewRows.Take(12)) _preview.Rows.Add(row.Cast<object>().ToArray());
            ClashManagerForm.FitGridText(_preview);
        }
        private void Apply()
        {
            var table = _table.SelectedItem as ClashTablePreview; if (table == null) { _error.Text = "Choose a table containing clash rows."; return; }
            var mapping = new ClashColumnMapping { TableIndex = table.TableIndex, HasHeaderRow = _headers.Checked };
            foreach (var item in _columns) typeof(ClashColumnMapping).GetProperty(item.Key).SetValue(mapping, item.Value.SelectedIndex - 1, null);
            int first = mapping.Id1Column >= 0 ? mapping.Id1Column : mapping.UniqueId1Column, second = mapping.Id2Column >= 0 ? mapping.Id2Column : mapping.UniqueId2Column;
            if (first < 0 || second < 0) { _error.Text = "Map an Element ID or Unique ID for each element."; return; }
            if (first == second) { _error.Text = "Element 1 and Element 2 need different identifier columns."; return; }
            Mapping = mapping; DialogResult = DialogResult.OK; Close();
        }
        protected override void OnShown(EventArgs e) { base.OnShown(e); KaTheme.ClampToScreen(this); }
    }
}
