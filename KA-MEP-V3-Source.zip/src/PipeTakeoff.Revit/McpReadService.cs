using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using PipeTakeoff.Core.Mcp;

namespace PipeTakeoff.Revit
{
    /// <summary>
    /// Host-document reads only. Invoke synchronously from the bridge's Revit ExternalEvent;
    /// no Revit object or deferred enumeration leaves this method.
    /// </summary>
    internal static class McpReadService
    {
        private const int MaxExaminedElements = 20000;
        private const int MaxExaminedParameters = 2000;
        private const int MaxTextLength = 2048;
        private const int MaxLabelLength = 512;
        private const int MaxWarningIds = 100;

        private static readonly Dictionary<string, BuiltInCategory> Categories =
            new Dictionary<string, BuiltInCategory>(StringComparer.Ordinal)
            {
                { "Pipes", BuiltInCategory.OST_PipeCurves },
                { "PipeFittings", BuiltInCategory.OST_PipeFitting },
                { "Ducts", BuiltInCategory.OST_DuctCurves },
                { "DuctFittings", BuiltInCategory.OST_DuctFitting },
                { "CableTrays", BuiltInCategory.OST_CableTray },
                { "CableTrayFittings", BuiltInCategory.OST_CableTrayFitting },
                { "Conduits", BuiltInCategory.OST_Conduit },
                { "ConduitFittings", BuiltInCategory.OST_ConduitFitting },
                { "MechanicalEquipment", BuiltInCategory.OST_MechanicalEquipment },
                { "PlumbingFixtures", BuiltInCategory.OST_PlumbingFixtures },
                { "Rooms", BuiltInCategory.OST_Rooms },
                { "Spaces", BuiltInCategory.OST_MEPSpaces },
                { "Doors", BuiltInCategory.OST_Doors },
                { "Windows", BuiltInCategory.OST_Windows }
            };

        public static McpReadResult Read(UIDocument uiDocument, string projectKey, long revision, string tool, McpArguments args, CancellationToken cancellation = default(CancellationToken))
        {
            cancellation.ThrowIfCancellationRequested();
            // Repeat the wire boundary's validation so this service cannot become a wider API
            // if another caller is added later.
            McpLimits.ValidateRequest(new McpWireRequest { RequestId = "read", Tool = tool, Arguments = args });
            if (string.IsNullOrWhiteSpace(projectKey) ||
                (!string.IsNullOrEmpty(args.ProjectKey) && !string.Equals(args.ProjectKey, projectKey, StringComparison.Ordinal)))
                throw new InvalidOperationException("The project key does not match this bridge session. Read project info again.");
            if (uiDocument == null || uiDocument.Document == null || !uiDocument.Document.IsValidObject)
                throw new InvalidOperationException("The active Revit project is no longer available.");

            Document document = uiDocument.Document;
            if (document.IsFamilyDocument)
                throw new InvalidOperationException("Open a Revit project document to use the read-only bridge.");

            var result = new McpReadResult
            {
                ProjectKey = projectKey,
                ModelRevision = revision,
                CapturedUtc = DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture),
                Offset = args.Offset
            };
            var context = new ReadContext(result, cancellation);
            result.ProjectTitle = context.Text(document.Title, MaxLabelLength);
            context.Note("Host document only; linked model contents are not read. Reuse pages only while projectKey and modelRevision remain unchanged.");

            switch (tool)
            {
                case "ka_revit_project_info": ReadProject(document, uiDocument, args, context); break;
                case "ka_revit_selection": ReadSelection(document, uiDocument, args, context); break;
                case "ka_revit_find_elements": ReadElements(document, args, context); break;
                case "ka_revit_element_parameters": ReadParameters(document, args, context); break;
                case "ka_revit_sheets": ReadSheets(document, args, context); break;
                case "ka_revit_warnings": ReadWarnings(document, args, context); break;
                default: throw new InvalidOperationException("Unsupported read-only tool.");
            }
            context.CheckCancellation();
            return result;
        }

        private static void ReadProject(Document document, UIDocument uiDocument, McpArguments args, ReadContext context)
        {
            ProjectInfo information = document.ProjectInformation;
            View activeView = uiDocument.ActiveView;
            var project = new McpProjectData
            {
                RevitVersion = context.Text(document.Application.VersionNumber, MaxLabelLength),
                Name = context.Text(information == null ? null : information.Name, MaxLabelLength),
                Number = context.Text(information == null ? null : information.Number, MaxLabelLength),
                IsWorkshared = document.IsWorkshared,
                ActiveViewId = activeView == null ? null : PositiveId(activeView.Id),
                ActiveViewName = context.Text(activeView == null ? null : activeView.Name, MaxLabelLength)
            };
            context.Result.Project = project;
            using (var collector = new FilteredElementCollector(document).OfClass(typeof(RevitLinkInstance)))
            {
                var ids = CollectIds(collector, context);
                foreach (ElementId id in Page(ids, args, context))
                {
                    context.CheckCancellation();
                    var instance = document.GetElement(id) as RevitLinkInstance;
                    if (instance == null) throw MissingElement();
                    project.Links.Add(new McpLinkData
                    {
                        InstanceId = PositiveId(instance.Id),
                        UniqueId = instance.UniqueId,
                        Name = context.Text(FileNameOnly(instance.Name), MaxLabelLength),
                        IsLoaded = RevitLinkType.IsLoaded(document, instance.GetTypeId())
                    });
                }
            }
            context.Note("Pagination applies to host Revit link instances; project metadata is returned on every page. Link names omit directory information.");
        }

        private static void ReadSelection(Document document, UIDocument uiDocument, McpArguments args, ReadContext context)
        {
            var ids = CollectIds(uiDocument.Selection.GetElementIds(), context);
            context.Result.Elements = Page(ids, args, context)
                .Select(id => Describe(RequireElement(document, id), context)).ToList();
            context.Note("Selection is captured at request time and may change without a modelRevision change. Linked selections expose only their host link instance, when available.");
        }

        private static void ReadElements(Document document, McpArguments args, ReadContext context)
        {
            BuiltInCategory category;
            if (!Categories.TryGetValue(args.Category, out category))
                throw new InvalidOperationException("Choose a supported category.");
            using (var collector = new FilteredElementCollector(document).OfCategory(category).WhereElementIsNotElementType())
            {
                var ids = CollectIds(collector, context);
                if (!string.IsNullOrEmpty(args.Query))
                {
                    ids = ids.Where(id =>
                    {
                        context.CheckCancellation();
                        string name = RequireElement(document, id).Name ?? "";
                        if (name.Length > MaxTextLength)
                        {
                            name = name.Substring(0, MaxTextLength);
                            context.Truncate("Element name searches examine at most the first 2048 characters of each name.");
                        }
                        return name.IndexOf(args.Query, StringComparison.OrdinalIgnoreCase) >= 0;
                    }).ToList();
                }
                context.Result.Elements = Page(ids, args, context)
                    .Select(id => Describe(RequireElement(document, id), context)).ToList();
            }
            context.Note("Results contain instances in the requested category, sorted by numeric element ID. Query matches the element name, ignoring case.");
        }

        private static void ReadParameters(Document document, McpArguments args, ReadContext context)
        {
            Element element = ResolveElement(document, args);
            context.Result.Elements = new List<McpElementData> { Describe(element, context) };
            var parameters = new List<ParameterEntry>();
            AddParameters(element, element is ElementType, parameters, context);
            if (args.IncludeType && !(element is ElementType))
            {
                ElementId typeId = element.GetTypeId();
                if (typeId != null && RevitCompat.Id(typeId) > 0 && RevitCompat.Id(typeId) != RevitCompat.Id(element.Id))
                {
                    Element type = document.GetElement(typeId);
                    if (type != null) AddParameters(type, true, parameters, context);
                }
            }
            parameters.Sort((left, right) =>
            {
                context.CheckCancellation();
                int comparison = left.IsType.CompareTo(right.IsType);
                if (comparison == 0) comparison = RevitCompat.Id(left.Parameter.Id).CompareTo(RevitCompat.Id(right.Parameter.Id));
                if (comparison == 0) comparison = string.Compare(left.Parameter.Definition.Name, right.Parameter.Definition.Name, StringComparison.Ordinal);
                return comparison == 0 ? left.Ordinal.CompareTo(right.Ordinal) : comparison;
            });
            context.Result.Parameters = Page(parameters, args, context).Select(entry => DescribeParameter(entry, context)).ToList();
            context.Note("Pagination applies to parameters. Duplicate names are preserved; parameterId, ownerId and isType distinguish entries. Numeric raw values use Revit internal units and invariant formatting; display values use Revit project formatting. Parameter IDs and raw ElementId values may be negative Revit built-ins or sentinels.");
        }

        private static void ReadSheets(Document document, McpArguments args, ReadContext context)
        {
            using (var collector = new FilteredElementCollector(document).OfClass(typeof(ViewSheet)).WhereElementIsNotElementType())
            {
                var ids = CollectIds(collector, context);
                context.Result.Sheets = Page(ids, args, context).Select(id =>
                {
                    context.CheckCancellation();
                    var sheet = document.GetElement(id) as ViewSheet;
                    if (sheet == null) throw MissingElement();
                    return new McpSheetData
                    {
                        ElementId = PositiveId(sheet.Id), UniqueId = sheet.UniqueId,
                        Number = context.Text(sheet.SheetNumber, MaxLabelLength),
                        Name = context.Text(sheet.Name, MaxLabelLength), IsPlaceholder = sheet.IsPlaceholder
                    };
                }).ToList();
            }
            context.Note("Sheets include placeholders and are sorted by numeric element ID.");
        }

        private static void ReadWarnings(Document document, McpArguments args, ReadContext context)
        {
            // Revit offers a native warning list rather than a streaming collector. Bound all
            // processing after that API call, including the nested affected-element arrays.
            var warnings = new List<FailureMessage>();
            foreach (FailureMessage warning in document.GetWarnings())
            {
                context.CheckCancellation();
                if (warnings.Count == MaxExaminedElements)
                {
                    context.Truncate("Only the first 20000 native warning records were examined; further warnings are not available through this snapshot.");
                    break;
                }
                warnings.Add(warning);
            }
            context.Result.Warnings = Page(warnings, args, context).Select(warning =>
            {
                context.CheckCancellation();
                return new McpWarningData
                {
                    Description = context.Text(warning.GetDescriptionText(), MaxTextLength),
                    Severity = warning.GetSeverity().ToString(),
                    FailureDefinitionId = warning.GetFailureDefinitionId().Guid.ToString("D"),
                    FailingIds = WarningIds(warning.GetFailingElements(), context),
                    AdditionalIds = WarningIds(warning.GetAdditionalElements(), context)
                };
            }).ToList();
            context.Note("Warnings use Revit's native record order within this model revision. Revit materializes its warning list before bounded processing; affected-element arrays and descriptions may be truncated independently.");
        }

        private static List<ElementId> CollectIds(FilteredElementCollector collector, ReadContext context)
        {
            var ids = new List<ElementId>();
            int examined = 0;
            using (FilteredElementIdIterator iterator = collector.GetElementIdIterator())
            {
                iterator.Reset();
                while (iterator.MoveNext())
                {
                    context.CheckCancellation();
                    if (examined++ == MaxExaminedElements)
                    {
                        MarkElementScanLimit(context);
                        break;
                    }
                    ElementId id = iterator.Current;
                    if (id != null && RevitCompat.Id(id) > 0) ids.Add(id);
                }
            }
            ids.Sort((left, right) => RevitCompat.Id(left).CompareTo(RevitCompat.Id(right)));
            return ids;
        }

        private static List<ElementId> CollectIds(IEnumerable<ElementId> source, ReadContext context)
        {
            var ids = new List<ElementId>();
            int examined = 0;
            foreach (ElementId id in source)
            {
                context.CheckCancellation();
                if (examined++ == MaxExaminedElements)
                {
                    MarkElementScanLimit(context);
                    break;
                }
                if (id != null && RevitCompat.Id(id) > 0) ids.Add(id);
            }
            ids.Sort((left, right) => RevitCompat.Id(left).CompareTo(RevitCompat.Id(right)));
            return ids;
        }

        private static void MarkElementScanLimit(ReadContext context)
        {
            context.Truncate("The scan examined at most 20000 candidate elements. Sorting, filtering and pagination apply only to that examined subset, which is not guaranteed to contain the globally lowest IDs. Unexamined candidates may match; hasMore describes available pages in the examined subset only.");
        }

        private static List<T> Page<T>(List<T> source, McpArguments args, ReadContext context)
        {
            context.CheckCancellation();
            var page = source.Skip(args.Offset).Take(args.Limit).ToList();
            context.Result.Returned = page.Count;
            context.Result.HasMore = args.Offset + page.Count < source.Count;
            context.Result.NextOffset = context.Result.HasMore ? (int?)(args.Offset + page.Count) : null;
            return page;
        }

        private static Element ResolveElement(Document document, McpArguments args)
        {
            Element byId = null;
            Element byUniqueId = null;
            if (!string.IsNullOrEmpty(args.ElementId))
            {
                long id;
                if (!long.TryParse(args.ElementId, NumberStyles.None, CultureInfo.InvariantCulture, out id) || id <= 0)
                    throw new InvalidOperationException("Element ID must be a positive 64-bit integer string.");
                try { byId = document.GetElement(RevitCompat.ElementId(id)); }
                catch (OverflowException) { throw new InvalidOperationException("The element ID is outside this Revit version's supported range."); }
                if (byId == null) throw MissingElement();
            }
            if (!string.IsNullOrWhiteSpace(args.UniqueId))
            {
                try { byUniqueId = document.GetElement(args.UniqueId); }
                catch (Autodesk.Revit.Exceptions.ArgumentException) { throw MissingElement(); }
                if (byUniqueId == null) throw MissingElement();
            }
            if (byId != null && byUniqueId != null && RevitCompat.Id(byId.Id) != RevitCompat.Id(byUniqueId.Id))
                throw new InvalidOperationException("elementId and uniqueId identify different host-document elements.");
            Element element = byId ?? byUniqueId;
            if (element == null || RevitCompat.Id(element.Id) <= 0) throw MissingElement();
            return element;
        }

        private static McpElementData Describe(Element element, ReadContext context)
        {
            context.CheckCancellation();
            ElementType type = element as ElementType;
            if (type == null)
            {
                ElementId typeId = element.GetTypeId();
                if (typeId != null && RevitCompat.Id(typeId) > 0) type = element.Document.GetElement(typeId) as ElementType;
            }
            Element level = null;
            ElementId levelId = element.LevelId;
            if (levelId != null && RevitCompat.Id(levelId) > 0) level = element.Document.GetElement(levelId);
            return new McpElementData
            {
                ElementId = PositiveId(element.Id), UniqueId = element.UniqueId,
                Name = context.Text(element.Name, MaxLabelLength),
                Category = context.Text(element.Category == null ? null : element.Category.Name, MaxLabelLength),
                Family = context.Text(type == null ? null : type.FamilyName, MaxLabelLength),
                Type = context.Text(type == null ? null : type.Name, MaxLabelLength),
                Level = context.Text(level == null ? null : level.Name, MaxLabelLength)
            };
        }

        private static void AddParameters(Element owner, bool isType, List<ParameterEntry> target, ReadContext context)
        {
            foreach (Parameter parameter in owner.Parameters)
            {
                context.CheckCancellation();
                if (target.Count == MaxExaminedParameters)
                {
                    context.Truncate("At most 2000 parameters across the instance and requested type were examined; remaining parameters are not available through this snapshot.");
                    break;
                }
                target.Add(new ParameterEntry { Parameter = parameter, OwnerId = PositiveId(owner.Id), IsType = isType, Ordinal = target.Count });
            }
        }

        private static McpParameterData DescribeParameter(ParameterEntry entry, ReadContext context)
        {
            context.CheckCancellation();
            Parameter parameter = entry.Parameter;
            string raw = null;
            string display = null;
            if (parameter.HasValue)
            {
                switch (parameter.StorageType)
                {
                    case StorageType.String: raw = parameter.AsString(); break;
                    case StorageType.Integer: raw = parameter.AsInteger().ToString(CultureInfo.InvariantCulture); break;
                    case StorageType.Double: raw = parameter.AsDouble().ToString("R", CultureInfo.InvariantCulture); break;
                    case StorageType.ElementId: raw = RevitCompat.Id(parameter.AsElementId()).ToString(CultureInfo.InvariantCulture); break;
                }
                if (parameter.StorageType == StorageType.String) display = raw;
                else
                {
                    try { display = parameter.AsValueString(); }
                    catch (Autodesk.Revit.Exceptions.InvalidOperationException)
                    {
                        context.Note("Revit could not format one or more parameter values; those display values use the raw value.");
                    }
                    if (display == null) display = raw;
                }
            }
            return new McpParameterData
            {
                ParameterId = RevitCompat.Id(parameter.Id).ToString(CultureInfo.InvariantCulture),
                OwnerId = entry.OwnerId, Name = context.Text(parameter.Definition.Name, MaxLabelLength),
                StorageType = parameter.StorageType.ToString(), HasValue = parameter.HasValue,
                RawValue = context.Text(raw, MaxTextLength), DisplayValue = context.Text(display, MaxTextLength),
                SpecId = context.Text(parameter.Definition.GetDataType().TypeId, MaxLabelLength),
                IsReadOnly = parameter.IsReadOnly, IsType = entry.IsType
            };
        }

        private static List<string> WarningIds(IEnumerable<ElementId> source, ReadContext context)
        {
            var ids = new List<long>();
            int examined = 0;
            foreach (ElementId id in source)
            {
                context.CheckCancellation();
                if (examined++ == MaxWarningIds || context.RemainingWarningIds == 0)
                {
                    context.Truncate("Warning element IDs are limited to 100 per failing/additional array and 5000 across this response. Arrays may be incomplete.");
                    break;
                }
                if (id != null && RevitCompat.Id(id) > 0)
                {
                    ids.Add(RevitCompat.Id(id));
                    context.RemainingWarningIds--;
                }
            }
            return ids.Distinct().OrderBy(id => id).Select(id => id.ToString(CultureInfo.InvariantCulture)).ToList();
        }

        private static Element RequireElement(Document document, ElementId id)
        {
            Element element = document.GetElement(id);
            if (element == null) throw MissingElement();
            return element;
        }

        private static InvalidOperationException MissingElement()
        {
            return new InvalidOperationException("The requested host-document element was not found. Refresh project info and element identity before retrying.");
        }

        private static string PositiveId(ElementId id)
        {
            long value = RevitCompat.Id(id);
            if (value <= 0) throw new InvalidOperationException("The requested element does not have a positive host-document identity.");
            return value.ToString(CultureInfo.InvariantCulture);
        }

        private static string FileNameOnly(string name)
        {
            if (string.IsNullOrEmpty(name)) return name;
            int separator = Math.Max(name.LastIndexOf('/'), name.LastIndexOf('\\'));
            return separator < 0 ? name : name.Substring(separator + 1);
        }

        private sealed class ParameterEntry
        {
            public Parameter Parameter;
            public string OwnerId;
            public bool IsType;
            public int Ordinal;
        }

        private sealed class ReadContext
        {
            private int remainingText = 64000;
            private readonly CancellationToken cancellation;
            public int RemainingWarningIds = 5000;
            public McpReadResult Result { get; private set; }
            public ReadContext(McpReadResult result, CancellationToken cancellation) { Result = result; this.cancellation = cancellation; }

            public void CheckCancellation() { cancellation.ThrowIfCancellationRequested(); }

            public string Text(string value, int maximum)
            {
                CheckCancellation();
                if (value == null) return null;
                int allowed = Math.Min(maximum, remainingText);
                if (value.Length <= allowed)
                {
                    remainingText -= value.Length;
                    return value;
                }
                Truncate("Text fields are capped at 512 characters for labels, 2048 for parameter values/descriptions, and 64000 characters across this response. Truncated values end with an ellipsis when space permits.");
                remainingText -= allowed;
                if (allowed == 0) return "";
                int length = allowed - 1;
                // Never split a UTF-16 surrogate pair at the truncation boundary.
                if (length > 0 && char.IsHighSurrogate(value[length - 1])) length--;
                return value.Substring(0, length) + "\u2026";
            }

            public void Note(string note)
            {
                if (!Result.Notes.Contains(note)) Result.Notes.Add(note);
            }

            public void Truncate(string note)
            {
                Result.Truncated = true;
                Note(note);
            }
        }
    }
}
