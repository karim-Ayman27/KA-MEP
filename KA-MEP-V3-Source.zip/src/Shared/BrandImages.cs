using System;
using System.Drawing;
using System.IO;

namespace KAMEP.Branding
{
    /// <summary>Loads brand assets embedded in each executable or add-in; no external files are required.</summary>
    internal static class BrandImages
    {
        internal static byte[] LogoBytes(int size)
        {
            return ReadLogoBytes(size, "Logo");
        }

        internal static byte[] RibbonLogoBytes(int size)
        {
            return ReadLogoBytes(size, "RibbonLogo");
        }

        private static byte[] ReadLogoBytes(int size, string prefix)
        {
            int assetSize = size <= 16 ? 16 : size <= 32 ? 32 : size <= 64 ? 64 : size <= 128 ? 128 : 256;
            using (var stream = typeof(BrandImages).Assembly.GetManifestResourceStream("KAMEP.Branding." + prefix + assetSize + ".png"))
            {
                if (stream == null) throw new InvalidOperationException("The KA MEP logo resource is missing.");
                using (var buffer = new MemoryStream()) { stream.CopyTo(buffer); return buffer.ToArray(); }
            }
        }

        internal static Bitmap Logo(int size)
        {
            using (var stream = new MemoryStream(LogoBytes(size)))
            using (var source = new Bitmap(stream)) return new Bitmap(source);
        }

        internal static Icon WindowIcon()
        {
            using (var stream = typeof(BrandImages).Assembly.GetManifestResourceStream("KAMEP.Branding.Logo.ico"))
            {
                if (stream == null) throw new InvalidOperationException("The KA MEP icon resource is missing.");
                using (var source = new Icon(stream)) return (Icon)source.Clone();
            }
        }
    }
}
