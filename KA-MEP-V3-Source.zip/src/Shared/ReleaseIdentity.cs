using System.Reflection;

namespace KAMEP.Branding
{
    internal static class ReleaseIdentity
    {
        internal static string VersionLabel
        {
            get { return "Version " + typeof(ReleaseIdentity).Assembly.GetName().Version.ToString(2); }
        }

        internal static string BuildId
        {
            get
            {
                var attribute = typeof(ReleaseIdentity).Assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>();
                var value = attribute == null ? string.Empty : attribute.InformationalVersion;
                var separator = value.IndexOf('+');
                return separator >= 0 ? value.Substring(separator + 1) : "unidentified";
            }
        }

        internal static string Display { get { return VersionLabel + " | Build " + BuildId; } }
    }
}
